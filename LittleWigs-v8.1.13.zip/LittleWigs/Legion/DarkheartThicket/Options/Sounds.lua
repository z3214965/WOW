
BigWigs:AddSounds("Archdruid Glaidalis", {
	[198379] = "Warning",
	[198408] = "Alarm",
})

BigWigs:AddSounds("Oakheart", {
	[204646] = "Alert",
	[204666] = "Alarm",
	[204667] = "Info",
})

BigWigs:AddSounds("Dresaron", {
	[191325] = "Info",
	[199345] = "Warning",
	[199460] = "Alarm",
})

BigWigs:AddSounds("Shade of Xavius", {
	[200050] = "Info",
	[200185] = "Alert",
	[200238] = "Warning",
	[200289] = "Alarm",
})

BigWigs:AddSounds("Darkheart Thicket Trash", {
	[200580] = "Warning",
	[200658] = "Alarm",
	[200684] = "Alert",
	[200768] = "Warning",
	[201226] = "Warning",
	[201272] = "Alert",
	[201399] = "Alarm",
	[218759] = "Warning",
	[225562] = "Warning",
})
