local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "deDE")
if not L then return end
if L then
	L.ruiner = "Verheerer der Schreckensseele"
	L.poisoner = "Vergifter der Schreckensseele"
	L.razorbeak = "Wahnsinniger Klingenschnabel"
	L.grizzly = "Eiterpelzgrizzly"
	L.fury = "Blutbesudelter Zornbrodler"
	L.imp = "Schreckensfeuerwichtel"
end
