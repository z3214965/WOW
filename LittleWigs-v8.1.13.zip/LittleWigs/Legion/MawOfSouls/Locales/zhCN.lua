local L = BigWigs:NewBossLocale("Maw of Souls Trash", "zhCN")
if not L then return end
if L then
	L.soulguard = "浸水的灵魂卫士"
	L.champion = "海拉加尔勇士"
	L.mariner = "守夜水手"
	L.swiftblade = "海咒快刀手"
	L.mistmender = "海咒雾疗师"
	L.mistcaller = "海拉加尔召雾者"
	L.skjal = "斯卡加尔"
end
