
BigWigs:AddColors("Zuraal", {
	[244433] = "blue",
	[244579] = "orange",
	[244602] = "yellow",
	[244621] = {"cyan","green"},
	[244653] = "blue",
	[246134] = "red",
})

BigWigs:AddColors("Saprish", {
	[245802] = {"blue","yellow"},
	[245873] = "cyan",
	[247206] = "yellow",
	[247245] = {"blue","orange"},
	[248831] = "red",
})

BigWigs:AddColors("Viceroy Nezhar", {
	[-15926] = "yellow",
	[244751] = "orange",
	[244906] = "blue",
	[246324] = {"green","red"},
	[248736] = {"cyan","green"},
	[248804] = {"cyan","yellow"},
})

BigWigs:AddColors("L'ura", {
	[245164] = "red",
	[247795] = "red",
	[247816] = "green",
	[247930] = "yellow",
	[248535] = "cyan",
	[249009] = "orange",
})

BigWigs:AddColors("Seat of the Triumvirate Trash", {
	[245510] = "blue",
	[248227] = "red",
	[249078] = "yellow",
	[249081] = "blue",
})
