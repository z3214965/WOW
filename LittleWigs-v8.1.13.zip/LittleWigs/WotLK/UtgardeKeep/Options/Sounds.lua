
BigWigs:AddSounds("Prince Keleseth", {
	[48400] = "Warning",
})

BigWigs:AddSounds("Skarvald & Dalronn", {
	["stages"] = "Info",
})

BigWigs:AddSounds("Ingvar the Plunderer", {
	[42708] = "Warning",
	[42730] = "Alarm",
})
