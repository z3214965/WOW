local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "koKR")
if not L then return end
if L then
	L.berserker = "이미야르 광전사"
end
