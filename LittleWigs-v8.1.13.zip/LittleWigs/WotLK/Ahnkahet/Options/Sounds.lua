
BigWigs:AddSounds("Prince Taldaram", {
	[59513] = "Warning",
})

BigWigs:AddSounds("Amanitar", {
	[57055] = "Info",
})

BigWigs:AddSounds("Ahn'kahet Trash", {
	[13338] = "Alarm",
	[56728] = "Alert",
	[59102] = {"Long","Warning"},
})
