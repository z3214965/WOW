local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "zhCN")
if not L then return end
if L then
	L.spellflinger = "安卡哈爆法者"
	L.eye = "塔达拉姆之眼"
	L.darkcaster = "暮光黑暗法师"
end
