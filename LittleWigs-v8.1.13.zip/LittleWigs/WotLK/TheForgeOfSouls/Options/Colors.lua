
BigWigs:AddColors("Bronjahm", {
	[68839] = {"blue","orange"},
	[68872] = "red",
})

BigWigs:AddColors("Devourer of Souls", {
	[68912] = "red",
	[69051] = {"blue","orange"},
})
