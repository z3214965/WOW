local L = BigWigs:NewBossLocale("The Violet Hold Trash", "zhCN")
if not L then return end
if L then
	L.portals = "传送门"
	L.portals_desc = "传送门相关信息。"
end
