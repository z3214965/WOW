
BigWigs:AddSounds("Grand Champions", {
	[-7534] = "Alarm",
})

BigWigs:AddSounds("Argent Confessor Paletress", {
	[66515] = "Info",
})

BigWigs:AddSounds("The Black Knight", {
	[67781] = "Alarm",
})
