local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "deDE")
if not L then return end
if L then
	L.runeshaper = "Sturmgeschmiedeter Runenformer"
	L.sentinel = "Sturmgeschmiedete Schildwache"
end
