
BigWigs:AddColors("Trollgore", {
	[49637] = {"blue","orange"},
})

BigWigs:AddColors("Novos the Summoner", {
	[49034] = "blue",
	[50089] = {"blue","orange"},
	[59910] = "yellow",
	["adds"] = "yellow",
	["stages"] = "cyan",
})

BigWigs:AddColors("King Dred", {
	[48878] = {"blue","orange"},
	[59416] = "yellow",
})

BigWigs:AddColors("The Prophet Tharon'ja", {
	[49527] = {"blue","orange"},
	[59971] = "blue",
	["stages"] = "cyan",
})
