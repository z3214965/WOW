
BigWigs:AddSounds("Novos the Summoner", {
	[49034] = "Alert",
	["adds"] = "Alarm",
})

BigWigs:AddSounds("King Dred", {
	[48878] = "Alarm",
})

BigWigs:AddSounds("The Prophet Tharon'ja", {
	[59971] = "Alert",
})
