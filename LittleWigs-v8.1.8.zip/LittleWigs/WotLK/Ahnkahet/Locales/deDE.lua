local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "deDE")
if not L then return end
if L then
	L.spellflinger = "Zauberwerfer der Ahn'kahar"
	L.eye = "Auge von Taldaram"
	L.darkcaster = "Zwielichtdunkelzauberer"
end
