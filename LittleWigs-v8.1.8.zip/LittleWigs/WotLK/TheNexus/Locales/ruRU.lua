local L = BigWigs:NewBossLocale("The Nexus Trash", "ruRU")
if not L then return end
if L then
	L.slayer = "Убийца магов"
	L.steward = "Распорядитель"
end
