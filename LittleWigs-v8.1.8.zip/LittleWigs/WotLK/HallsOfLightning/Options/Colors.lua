
BigWigs:AddColors("General Bjarngrim", {
	[16856] = {"blue","red"},
	[41107] = {"green","orange"},
})

BigWigs:AddColors("Volkhan", {
	[59529] = "orange",
})

BigWigs:AddColors("Ionar", {
	[52770] = "orange",
	[59795] = {"blue","yellow"},
})

BigWigs:AddColors("Loken", {
	[59835] = "orange",
})

BigWigs:AddColors("Halls of Lightning Trash", {
	[59165] = {"blue","yellow"},
	[61581] = "red",
})
