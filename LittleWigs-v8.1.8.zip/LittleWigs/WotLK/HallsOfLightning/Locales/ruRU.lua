local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "ruRU")
if not L then return end
if L then
	L.runeshaper = "Рунодел клана Закаленных Бурей"
	L.sentinel = "Часовой клана Закаленных Бурей"
end
