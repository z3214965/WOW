
BigWigs:AddSounds("The Violet Hold Trash", {
	["portals"] = "Info",
})
