
BigWigs:AddSounds("Falric", {
	[72426] = "Warning",
})
