local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "itIT")
if not L then return end
if L then
	L.ruiner = "Polverizzatore Tetranima"
	L.poisoner = "Avvelenatore Tetranima"
	L.razorbeak = "Beccolesto Frenetico"
	L.grizzly = "Grizzly Putrescente"
	L.fury = "Furia Marcasangue"
	L.imp = "Imp Malofuoco"
end
