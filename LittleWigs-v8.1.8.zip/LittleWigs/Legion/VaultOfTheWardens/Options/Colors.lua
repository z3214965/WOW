
BigWigs:AddColors("Tirathon Saltheril", {
	[190830] = "yellow",
	[191823] = "orange",
	[191853] = "blue",
	[191941] = {"blue","orange","red"},
	[192504] = "cyan",
	[202740] = "cyan",
})

BigWigs:AddColors("Inquisitor Tormentorum", {
	[196208] = "orange",
	[199918] = "blue",
	[200898] = "yellow",
	[200904] = {"blue","red","yellow"},
	[201488] = "orange",
	[202455] = "green",
	[203685] = {"blue","orange"},
	[212564] = "orange",
})

BigWigs:AddColors("Ashgolm", {
	[-12727] = "green",
	[192517] = "green",
	[192519] = "blue",
	[192520] = "red",
	[192522] = "yellow",
})

BigWigs:AddColors("Glazer", {
	[194323] = "orange",
	[194333] = "green",
	[194945] = {"blue","red"},
	[202046] = "blue",
})

BigWigs:AddColors("Cordana Felsong", {
	[197333] = "red",
	[197422] = {"cyan","red"},
	[197796] = {"green","orange"},
	[204481] = {"cyan","green"},
	[206567] = {"blue","cyan","orange","yellow"},
	[213583] = "yellow",
	["kick_combo"] = "yellow",
})

BigWigs:AddColors("Vault of the Wardens Trash", {
	[191527] = "red",
	[191735] = "red",
	[193069] = {"blue","orange","yellow"},
	[193164] = {"blue","orange"},
	[194071] = "blue",
	[196249] = "orange",
	[196796] = "orange",
	[196799] = "yellow",
	[202607] = "blue",
	[202615] = {"blue","orange"},
	[210202] = "blue",
})
