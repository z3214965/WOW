
BigWigs:AddSounds("Doom's Howl", {
	[271120] = "alarm",
	[271163] = "alert",
	[271164] = "info",
	[271223] = "long",
	[271800] = "warning",
})

BigWigs:AddSounds("Warbringer Yenajz", {
	[274842] = "info",
	[274904] = "alarm",
	[274932] = "long",
})
