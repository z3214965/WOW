
BigWigs:AddColors("Doom's Howl", {
	[271120] = "blue",
	[271163] = "purple",
	[271164] = "orange",
	[271223] = "cyan",
	[271800] = "red",
})

BigWigs:AddColors("Warbringer Yenajz", {
	[274842] = "yellow",
	[274904] = "blue",
	[274932] = "red",
})
