# BigWigs

## [v113](https://github.com/BigWigsMods/BigWigs/tree/v113) (2018-09-12)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v112.1...v113)

- bump version  
- Uldir/Zekvoz: No adds in LFR.  
- Uldir/Vectis: More infobox fixes.  
- Uldir/Devourer: Add respawn timer, finetune debuff warnings  
- Uldir/Taloc: Do not show Defensive Beam timers on LFR/Normal  
- Uldir/Zul: Fix error on Dark Revelation  
- Uldir/Devourer: Update add spawn timers and fix stacking Malodorous Miasma say countdowns for Mythic  
