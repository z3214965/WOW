# BadBoy

## [v8.1.3](https://github.com/funkydude/BadBoy/tree/v8.1.3) (2019-01-14)
[Full Changelog](https://github.com/funkydude/BadBoy/compare/v8.1.2...v8.1.3)

- anti-spam update  
