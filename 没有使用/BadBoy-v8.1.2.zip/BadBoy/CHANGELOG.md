# BadBoy

## [v8.1.2](https://github.com/funkydude/BadBoy/tree/v8.1.2) (2018-12-21)
[Full Changelog](https://github.com/funkydude/BadBoy/compare/v8.1.1...v8.1.2)

- bump toc  
- anti-spam update  
