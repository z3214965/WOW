select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("itIT", {
    ["Drywhisker Mine"] = "Miniera dei Baffosecco",
    ["Galson's Lode"] = "Vena Mineraria di Galson",
    ["Boulderfist Outpost"] = "Avamposto dei Rocciadura",
    ["Witherbark Village"] = "Villaggio degli Scorzasecca",
    ["Boulderfist Hall"] = "Fortilizio dei Rocciadura",
    ["Drywhisker Gorge"] = "Gola dei Baffosecco",
})
