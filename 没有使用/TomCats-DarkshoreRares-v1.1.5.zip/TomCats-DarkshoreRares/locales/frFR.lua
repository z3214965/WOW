select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("frFR", {
    ["Drywhisker Mine"] = "Mine des Sèches-Moustaches",
    ["Galson's Lode"] = "Filon de Galson",
    ["Boulderfist Outpost"] = "Avant-poste rochepoing",
    ["Witherbark Village"] = "Fanécorce",
    ["Boulderfist Hall"] = "Hall Rochepoing",
    ["Drywhisker Gorge"] = "Gorge des Sèches-Moustaches",
})
