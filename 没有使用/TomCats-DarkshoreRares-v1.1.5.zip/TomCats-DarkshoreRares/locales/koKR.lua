select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("koKR", {
    ["Drywhisker Mine"] = "마른수염 광산",
    ["Galson's Lode"] = "갤슨의 광맥",
    ["Boulderfist Outpost"] = "돌주먹 전초기지",
    ["Witherbark Village"] = "마른나무껍질 마을",
    ["Boulderfist Hall"] = "돌주먹 소굴",
    ["Drywhisker Gorge"] = "마른수염 골짜기",
})
