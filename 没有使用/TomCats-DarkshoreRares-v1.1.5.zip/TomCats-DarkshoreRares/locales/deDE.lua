select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("deDE", {
    ["Drywhisker Mine"] = "Die Mine der Trockenstoppel",
    ["Galson's Lode"] = "Galsons Mine",
    ["Boulderfist Outpost"] = "Der Außenposten der Felsfäuste",
    ["Witherbark Village"] = "Das Lager der Bleichborken",
    ["Boulderfist Hall"] = "Die Halle der Felsfäuste",
    ["Drywhisker Gorge"] = "Die Schlucht der Trockenstoppel",
})
