# BadBoy_CCleaner

## [v8.0.0](https://github.com/funkydude/BadBoy_CCleaner/tree/v8.0.0) (2018-07-17)
[Full Changelog](https://github.com/funkydude/BadBoy_CCleaner/compare/v7.3.0...v8.0.0)

- bump version  
- update travis file  
