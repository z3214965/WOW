select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("zhTW", {
    ["Drywhisker Mine"] = "枯鬚礦場",
    ["Galson's Lode"] = "賈爾森礦場",
    ["Boulderfist Outpost"] = "石拳崗哨",
    ["Witherbark Village"] = "枯木村",
    ["Boulderfist Hall"] = "石拳大廳",
    ["Drywhisker Gorge"] = "枯鬚峽谷",
})
