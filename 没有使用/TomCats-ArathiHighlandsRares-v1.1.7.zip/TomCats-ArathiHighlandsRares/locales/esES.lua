select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("esES", {
    ["Drywhisker Mine"] = "Mina Mostacho Seco",
    ["Galson's Lode"] = "Mina de Galson",
    ["Boulderfist Outpost"] = "Avanzada Puño de Roca",
    ["Witherbark Village"] = "Poblado Secacorteza",
    ["Boulderfist Hall"] = "Sala Puño de Roca",
    ["Drywhisker Gorge"] = "Cañón Mostacho Seco",
})
