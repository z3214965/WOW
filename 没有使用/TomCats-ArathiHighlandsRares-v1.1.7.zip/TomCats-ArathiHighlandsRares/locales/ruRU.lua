select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("ruRU", {
    ["Drywhisker Mine"] = "Рудник Сухоусов",
    ["Galson's Lode"] = "Рудник Гальсона",
    ["Boulderfist Outpost"] = "Аванпост Тяжелого Кулака",
    ["Witherbark Village"] = "Деревня Сухокожих",
    ["Boulderfist Hall"] = "Крепость Тяжелого Кулака",
    ["Drywhisker Gorge"] = "Теснина Сухоусов",
})
