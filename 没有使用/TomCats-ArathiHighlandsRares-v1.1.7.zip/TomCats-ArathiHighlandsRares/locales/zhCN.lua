select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("zhCN", {
    ["Drywhisker Mine"] = "枯须矿洞",
    ["Galson's Lode"] = "加尔森的矿洞",
    ["Boulderfist Outpost"] = "石拳岗哨",
    ["Witherbark Village"] = "枯木村",
    ["Boulderfist Hall"] = "石拳大厅",
    ["Drywhisker Gorge"] = "枯须峡谷",
})
