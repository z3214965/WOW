select(2, ...).TomCatsLibs.Locales.AddLocaleLookup("ptBR", {
    ["Drywhisker Mine"] = "Mina Bigodesseco",
    ["Galson's Lode"] = "Veio do Galson",
    ["Boulderfist Outpost"] = "Posto Avançado Punho de Pedra",
    ["Witherbark Village"] = "Aldeia Cascasseca",
    ["Boulderfist Hall"] = "Forte Punho de Pedra",
    ["Drywhisker Gorge"] = "Garganta Seca",
})
