local addon = select(2, ...)
addon.TomCatsLibs.Data.ContributionCollectorIDs = {
    ["Alliance"] = 116,
    ["Horde"] = 11,
}
