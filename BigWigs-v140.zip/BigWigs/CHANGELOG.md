# BigWigs

## [v140](https://github.com/BigWigsMods/BigWigs/tree/v140) (2019-03-13)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v139...v140)

- Use C\_CVar where appropriate.  
- bump version  
- Core: Don't hard error when an invalid optionHeader is present  
- BattleOfDazaralor/GrongAlliance: Fix optionHeaders error from Blizz patch 8.1.5, closes #619  
