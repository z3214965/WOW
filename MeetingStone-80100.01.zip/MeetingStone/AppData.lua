BuildEnv(...)

MOUNT_MAP = nil
APP_RAID_MAPS = ListToMap{1861}
APP_RAID_DIFFICULTIES = ListToMap{14,15,16}
