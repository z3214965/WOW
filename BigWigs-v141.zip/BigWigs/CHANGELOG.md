# BigWigs

## [v141](https://github.com/BigWigsMods/BigWigs/tree/v141) (2019-03-15)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v140...v141)

- bump version  
- Update option files  
- BattleOfDazaralor/Rastakhan: Make seal of purification faster, closes #614  
- Update esES (#621)  
- BattleOfDazaralor/Opulence: Show a message when hex is removed from you.  
- BattleOfDazaralor/Rastakhan: Show stack warnings for Deathly Withering when in the death realm.  
- BattleOfDazaralor/Champion: Cancel the disorient bar if you kill the crusader mid cast.  
- BattleOfDazaralor/Rastakhan: Cancel the leap countdown and show a message when Roka dies mid cast.  
- BattleOfDazaralor/Jaina: Add a VerifyEnable to prevent re-enabling after winning.  
- BattleOfDazaralor/Blockade: Add Crackling Lightning warning.  
