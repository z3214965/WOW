
BigWigs:AddSounds("Shivermaw", {
	[201354] = "Alarm",
	[201355] = "Alert",
	[201379] = "Warning",
	[201672] = "Long",
	[201960] = "Info",
	[202062] = "Warning",
})

BigWigs:AddSounds("Thalena", {
	[202779] = {"Alert","Info"},
	[202947] = "Alarm",
	[203381] = "Long",
})

BigWigs:AddSounds("Festerface", {
	[201598] = "Alarm",
	[201729] = "Alert",
})

BigWigs:AddSounds("Millificent Manastorm", {
	[201240] = "Info",
	[201392] = "Alarm",
	[201572] = "Warning",
})

BigWigs:AddSounds("Kaahrj", {
	[201146] = "Alarm",
	[201148] = "Info",
	[201153] = "Long",
})

BigWigs:AddSounds("Anub'esset", {
	[201863] = "Info",
	[202217] = "Alarm",
	[202341] = "Long",
	[202480] = "Warning",
	[202485] = "Alarm",
})

BigWigs:AddSounds("Saelorn", {
	[202306] = "Alarm",
	[202414] = "Alert",
	[202473] = "Long",
})

BigWigs:AddSounds("Fel Lord Betrug", {
	[202328] = "Long",
	[205233] = {"Alarm","Info"},
	[210879] = "Alert",
})

BigWigs:AddSounds("Assault on Violet Hold Trash", {
	[204140] = "Alert",
	[204608] = "Alarm",
	[204876] = "Alert",
	[204901] = "Alert",
	[205088] = "Alert",
})
