
BigWigs:AddColors("Commander Kolurg/Stoutbeard", {
	[38618] = "orange",
})

BigWigs:AddColors("Grand Magus Telestra", {
	[-7395] = "green",
	[47731] = {"blue","orange"},
})

BigWigs:AddColors("Anomalus", {
	[47743] = "yellow",
})

BigWigs:AddColors("Ormorok the Tree-Shaper", {
	[47981] = "yellow",
	[48017] = "red",
})

BigWigs:AddColors("Keristrasza", {
	[8599] = "red",
	[48095] = "blue",
	[48179] = "orange",
	[50997] = {"blue","yellow"},
})

BigWigs:AddColors("The Nexus Trash", {
	[30849] = {"blue","yellow"},
	[47779] = {"blue","orange"},
})
