local L = BigWigs:NewBossLocale("The Nexus Trash", "deDE")
if not L then return end
if L then
	L.slayer = "Magiertöter"
	L.steward = "Bediensteter"
end
