local L = BigWigs:NewBossLocale("The Nexus Trash", "esES") or BigWigs:NewBossLocale("The Nexus Trash", "esMX")
if not L then return end
if L then
	L.slayer = "Asesino de magos"
	L.steward = "Administrador"
end
