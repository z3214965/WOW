
BigWigs:AddSounds("Maiden of Grief", {
	[59726] = "Warning",
	[59772] = "Alert",
})

BigWigs:AddSounds("Tribunal of Ages", {
	[59866] = "Alert",
	[59868] = "Alarm",
	["timers"] = "Info",
})

BigWigs:AddSounds("Sjonnir The Ironshaper", {
	[50834] = "Alarm",
})
