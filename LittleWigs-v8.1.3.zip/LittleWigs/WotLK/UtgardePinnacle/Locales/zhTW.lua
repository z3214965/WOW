local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "zhTW")
if not L then return end
if L then
	--L.berserker = "Ymirjar Berserker"
end
