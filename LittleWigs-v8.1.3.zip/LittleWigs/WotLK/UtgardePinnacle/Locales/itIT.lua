local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "itIT")
if not L then return end
if L then
	L.berserker = "Berserker Ymirjar"
end
