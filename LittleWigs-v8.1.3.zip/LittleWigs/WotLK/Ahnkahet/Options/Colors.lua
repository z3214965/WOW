
BigWigs:AddColors("Elder Nadox", {
	[-6042] = "red",
	[56130] = {"blue","yellow"},
})

BigWigs:AddColors("Prince Taldaram", {
	[55931] = "red",
	[59513] = {"blue","green","red"},
})

BigWigs:AddColors("Jedoga Shadowseeker", {
	[60029] = "red",
})

BigWigs:AddColors("Amanitar", {
	[57055] = "yellow",
})

BigWigs:AddColors("Herald Volazj", {
	[57496] = "red",
	[59978] = {"blue","yellow"},
})

BigWigs:AddColors("Ahn'kahet Trash", {
	[13338] = {"blue","yellow"},
	[56728] = {"blue","red"},
	[59102] = "red",
})
