local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "ptBR")
if not L then return end
if L then
	L.spellflinger = "Sortílego Ahn'kahar"
	L.eye = "Olho de Taldaram"
	L.darkcaster = "Taumaturgo do Crepúsculo"
end
