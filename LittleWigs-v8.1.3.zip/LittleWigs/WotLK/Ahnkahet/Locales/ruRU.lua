local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "ruRU")
if not L then return end
if L then
	L.spellflinger = "Ан'кахарский метатель заклинаний"
	L.eye = "Глаз Талдарама"
	L.darkcaster = "Сумеречный черный маг"
end
