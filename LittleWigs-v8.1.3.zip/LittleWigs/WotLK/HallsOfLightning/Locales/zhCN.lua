local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "zhCN")
if not L then return end
if L then
	L.runeshaper = "雷铸符文师"
	L.sentinel = "雷铸斥候"
end
