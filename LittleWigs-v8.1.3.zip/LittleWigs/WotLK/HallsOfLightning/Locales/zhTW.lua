local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "zhTW")
if not L then return end
if L then
	--L.runeshaper = "Stormforged Runeshaper"
	--L.sentinel = "Stormforged Sentinel"
end
