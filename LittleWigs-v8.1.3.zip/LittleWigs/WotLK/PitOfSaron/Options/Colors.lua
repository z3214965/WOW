
BigWigs:AddColors("Forgemaster Garfrost", {
	[68789] = "blue",
	[70381] = {"blue","yellow"},
})

BigWigs:AddColors("Ick & Krick", {
	[68987] = {"blue","yellow"},
	[68989] = "orange",
	[69263] = "red",
	[70274] = "blue",
})

BigWigs:AddColors("Scourgelord Tyrannus", {
	[69167] = "red",
	[69172] = {"blue","yellow"},
	[69275] = {"blue","red"},
})
