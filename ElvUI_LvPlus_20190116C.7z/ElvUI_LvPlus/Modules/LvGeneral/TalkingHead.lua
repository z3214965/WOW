local E, L, V, P, G = unpack(ElvUI); 
local TH = E:NewModule('TalkingHead', 'AceHook-3.0');

local function ToggleTalkingFrame()
	if(TalkingHeadFrame and TalkingHeadFrame:IsVisible()) then
		TalkingHeadFrame.MainFrame.CloseButton:GetScript("OnClick")();
	end
end
TH.ToggleTalkingFrame = ToggleTalkingFrame

local TalkingHooked = false
function TH:ToggleTalkingHead()
	if not TalkingHooked and TalkingHeadFrame then
		TalkingHeadFrame:HookScript("OnShow", ToggleTalkingFrame)
		TalkingHooked = true
	end
end

function TH:Initialize()
	self:RegisterEvent("TALKINGHEAD_REQUESTED", "ToggleTalkingHead")
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvAboutUI.DisableTalking then return end
	TH:Initialize()
end

E:RegisterModule(TH:GetName(), InitializeCallback)