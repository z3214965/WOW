local E = unpack(ElvUI)
local SP = E:NewModule('SetPoi')

local function CreatePoi()
	local f = CreateFrame("Frame", "LvPlusPoi", E.UIParent)
	f:SetFrameStrata("DIALOG")
	f:SetSize(36,36)
	f:Point("CENTER",0,0)
	f.text = f:CreateFontString(nil, "ARTWORK")
	f.text:SetAllPoints(f)
	f:Hide()
	return f
end

function SP:SetPoi()
	if E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn then
		LvPlusPoi = LvPlusPoi or CreatePoi();
		LvPlusPoi.text:FontTemplate(nil, E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiTextSize, nil);
		
		LvPlusPoi.text:SetTextColor(E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiColor.r,
									E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiColor.g,
									E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiColor.b)
									
		LvPlusPoi.text:SetText(E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiText)
		
		if E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiCombat then
			LvPlusPoi:RegisterEvent("PLAYER_REGEN_ENABLED")
			LvPlusPoi:RegisterEvent("PLAYER_REGEN_DISABLED")
			LvPlusPoi:SetScript("OnEvent", function(self, event)
				if not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiCombat then return; end
				if event == 'PLAYER_REGEN_DISABLED' then
					self:Show()
				else
					self:Hide()
				end
			end)
			LvPlusPoi:Hide()
		else
			LvPlusPoi:UnregisterAllEvents()
			LvPlusPoi:SetScript("OnEvent", nil)
			LvPlusPoi:Show()
		end
	else
		if LvPlusPoi then LvPlusPoi:Hide(); end
	end
end


function SP:Initialize()
	SP:SetPoi()
end


local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn then
		return
	end
	SP:Initialize()
end

E:RegisterModule(SP:GetName(), InitializeCallback)