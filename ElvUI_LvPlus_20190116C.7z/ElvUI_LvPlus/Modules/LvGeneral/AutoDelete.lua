local E, L, V, P, G = unpack(ElvUI)
local AD = E:NewModule('AutoDelete', 'AceHook-3.0')

local Panel = StaticPopupDialogs["DELETE_GOOD_ITEM"]

local function AddText(boxEditor)
	boxEditor.editBox:SetText("DELETE")
end

function AD:Initialize()
	hooksecurefunc(Panel, "OnShow", AddText)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoDelete then
		return
	end
	AD:Initialize()
end

E:RegisterModule(AD:GetName(), InitializeCallback)
