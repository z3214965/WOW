local E = unpack(ElvUI)
local SFK = E:NewModule('SetFocusKey')


local hooksecurefunc = hooksecurefunc
local SetOverrideBindingClick = SetOverrideBindingClick
	
local function SetFocusHotkey(frame)
	if not frame then return; end
	frame:SetAttribute(E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton1.."-type"..E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton2,"focus")
end
	
local function CreateFrame_Hook(type, name, parent, template)
	if template == "SecureUnitButtonTemplate" then
		SetFocusHotkey(_G[name])
	end
end

function SFK:Initialize()	
	hooksecurefunc("CreateFrame", CreateFrame_Hook)
	
	local f = CreateFrame("CheckButton", "FocuserButton", E.UIParent, "SecureActionButtonTemplate")
	f:SetAttribute("type1","macro")
	f:SetAttribute("macrotext","/focus mouseover")
	SetOverrideBindingClick(FocuserButton, true, E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton1.."-BUTTON"..E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton2, "FocuserButton")
	local duf = {
		ElvUF_Player,
		ElvUF_Pet,	
		ElvUF_Target,
		ElvUF_Targettarget,
		PlayerFrame,
		PetFrame,
		PartyMemberFrame1,
		PartyMemberFrame2,
		PartyMemberFrame3,
		PartyMemberFrame4,
		PartyMemberFrame1PetFrame,
		PartyMemberFrame2PetFrame,
		PartyMemberFrame3PetFrame,
		PartyMemberFrame4PetFrame,
		TargetFrame,
		TargetofTargetFrame,
	}

	for i,frame in pairs(duf) do
		SetFocusHotkey(frame)
	end
end

local function InitializeCallback()
	if E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton1 == 'none' then
		return
	end
	SFK:Initialize()
end

E:RegisterModule(SFK:GetName(), InitializeCallback)