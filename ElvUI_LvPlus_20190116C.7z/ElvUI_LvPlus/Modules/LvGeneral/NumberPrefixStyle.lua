local E, L, V, P, G = unpack(ElvUI);
local NPS = E:NewModule('NumberPrefixStyle', 'AceEvent-3.0');

local shortValueDec, shortValue
function NPS:Initialize()
	function E:ShortValue(v)
		shortValueDec = format("%%.%df", E.db.general.decimalLength or 1)
		shortValue = abs(v)
		if E.db.general.numberPrefixStyle == "METRIC" then
			if shortValue >= 1e12 then
				return format(shortValueDec.."T", v / 1e12)
			elseif shortValue >= 1e9 then
				return format(shortValueDec.."G", v / 1e9)
			elseif shortValue >= 1e6 then
				return format(shortValueDec.."M", v / 1e6)
			elseif shortValue >= 1e3 then
				return format(shortValueDec.."k", v / 1e3)
			else
				return format("%.0f", v)
			end
		elseif E.db.general.numberPrefixStyle == "CHINESE" then
			if shortValue >= 1e8 then
				return format(shortValueDec.."Y", v / 1e8)
			elseif shortValue >= 1e4 then
				return format(shortValueDec.."W", v / 1e4)
			else
				return format("%.0f", v)
			end
		elseif E.db.general.numberPrefixStyle == "LVCHINESE" then
			if shortValue >= 1e8 then
				return format(shortValueDec.."亿", v / 1e8)
			elseif shortValue >= 1e4 then
				return format(shortValueDec.."万", v / 1e4)
			else
				return format("%.0f", v)
			end
		elseif E.db.general.numberPrefixStyle == "KOREAN" then
			if shortValue >= 1e8 then
				return format(shortValueDec.."억", v / 1e8)
			elseif shortValue >= 1e4 then
				return format(shortValueDec.."만", v / 1e4)
			elseif shortValue >= 1e3 then
				return format(shortValueDec.."천", v / 1e3)
			else
				return format("%.0f", v)
			end
		elseif E.db.general.numberPrefixStyle == "GERMAN" then
			if shortValue >= 1e12 then
				return format(shortValueDec.."Bio", v / 1e12)
			elseif shortValue >= 1e9 then
				return format(shortValueDec.."Mrd", v / 1e9)
			elseif shortValue >= 1e6 then
				return format(shortValueDec.."Mio", v / 1e6)
			elseif shortValue >= 1e3 then
				return format(shortValueDec.."Tsd", v / 1e3)
			else
				return format("%.0f", v)
			end
		else
			if shortValue >= 1e12 then
				return format(shortValueDec.."T", v / 1e12)
			elseif shortValue >= 1e9 then
				return format(shortValueDec.."B", v / 1e9)
			elseif shortValue >= 1e6 then
				return format(shortValueDec.."M", v / 1e6)
			elseif shortValue >= 1e3 then
				return format(shortValueDec.."K", v / 1e3)
			else
				return format("%.0f", v)
			end
		end
	end
end

local function InitializeCallback()
	NPS:Initialize()
end

E:RegisterModule(NPS:GetName(), InitializeCallback)