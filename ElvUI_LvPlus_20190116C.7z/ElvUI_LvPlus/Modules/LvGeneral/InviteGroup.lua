local E, L, V, P, G = unpack(ElvUI); 
local IG = E:NewModule('InviteGroup', 'AceEvent-3.0');

local GuildControlGetNumRanks = GuildControlGetNumRanks

function IG:AutoInvite(...)
	local event, arg1, arg2 = ...
	if ((not UnitExists("party1") or UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")) and (arg1:lower() == E.db.LvPlus.LvGeneral.General.LvInviteGroup.Ainvkeyword:lower())) and E.db.LvPlus.LvGeneral.General.LvInviteGroup.EnableBtn == true then
		if event == 'CHAT_MSG_BN_WHISPER' then
			local totalBNet = BNGetNumFriends()
			for i = 1, totalBNet do
				local _, presenceName, _,_,_,bnetIDGameAccount,client,isOnline = BNGetFriendInfo(i)
				if isOnline and presenceName == arg2 and client == 'WoW' and bnetIDGameAccount then
					local _, charName, _, realmName = BNGetGameAccountInfo(bnetIDGameAccount)
					if realmName ~= GetRealmName() then charName = charName..'-'..realmName end
					InviteToGroup(charName)
					return;
				end
			end	
		else
			InviteToGroup(arg2)
		end
	end
end

function IG:GetGuildRanks()
	local value = {}
	if IsInGuild() then
		local ranks = GuildControlGetNumRanks()
		for i = 1, ranks do
			value[i] = GuildControlGetRankName(i)
		end
	end
	return value
end

function IG:InviteRanks()
	if not IsInGuild() then return end
	
	local numMembers = GetNumGuildMembers();
	for i = 1, numMembers do
		local name, _, rankIndex, _, _, _, _, _, online = GetGuildRosterInfo(i)
		if online and E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[rankIndex] then
			pcall(InviteUnit, name);
		end
		if not IsInRaid() and IsInGroup() and UnitIsGroupLeader("player") then ConvertToRaid(); end
	end
end

function IG:Initialize()
	self:RegisterEvent("CHAT_MSG_WHISPER", "AutoInvite")
	self:RegisterEvent("CHAT_MSG_BN_WHISPER", "AutoInvite")
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvInviteGroup.EnableBtn then
		return
	end
	IG:Initialize()
end

E:RegisterModule(IG:GetName(), InitializeCallback)