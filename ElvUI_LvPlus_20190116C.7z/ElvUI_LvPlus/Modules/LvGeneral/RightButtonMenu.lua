local E, L, V, P, G = unpack(ElvUI)
local RBM = E:NewModule('RightButtonMenu')

local locale = GetLocale()
local CHAT_BLACKLIST_INTRO = ''
if locale == 'zhCN' then
	CHAT_BLACKLIST_INTRO = ' 已被加入ElvUI信息过滤黑名单!'
elseif locale == 'zhTW' then
	CHAT_BLACKLIST_INTRO = ' 已被加入ElvUI資訊過濾黑名單!'
else
	CHAT_BLACKLIST_INTRO = ' Has been added to the ElvUI information filtering blacklist!'
end

local function urlencode(s)
	s = string.gsub(s, "([^%w%.%- ])", function(c)
			return format("%%%02X", string.byte(c))
		end)
	return string.gsub(s, " ", "+")
end

local function gethost()
	local host = "http://us.battle.net/wow/en/character/"
	if (GetLocale() == "zhTW") then
		host = "http://tw.battle.net/wow/zh/character/"
	elseif (GetLocale() == "zhCN") then
		host = "http://www.battlenet.com.cn/wow/zh/character/"
	end
	return host
end

local function getfullname()
	local unit = UIDROPDOWNMENU_INIT_MENU.unit
	local name = UIDROPDOWNMENU_INIT_MENU.name
	local server = UIDROPDOWNMENU_INIT_MENU.server

	if (server and (not unit or UnitRealmRelationship(unit) ~= LE_REALM_RELATION_SAME)) then
		return name .. "-" .. server
	else
		return name
	end
end

RBM.friend_features = {
	"ARMORY",
	"NAME_COPY",
	"SEND_WHO",
	"FRIEND_ADD",
	"GUILD_ADD",
	"MYSTATS",
	"LVBLACKNAME",
}
RBM.cr_features = {
	"NAME_COPY",
	"SEND_WHO",
	"FRIEND_ADD",
	"LVBLACKNAME",
}
RBM.guild_features = {
	"ARMORY",
	"NAME_COPY",
	"FRIEND_ADD",
	"LVBLACKNAME",
}
RBM.player_features = {
	"ARMORY",
	"NAME_COPY",
	"LVBLACKNAME",
}

RBM.UnitPopupButtonsExtra = {
	["ARMORY"] = true,
	["NAME_COPY"] = true,
	["SEND_WHO"] = true,
	["GUILD_ADD"] = true,
	["FRIEND_ADD"] = true,
	["MYSTATS"] = true,
	["LVBLACKNAME"] = true,
}

RBM.dropdownmenu_show = {
	["SELF"] = true,
	["PLAYER"] = true,
	["PARTY"] = true,
	["RAID_PLAYER"] = true,
	["TARGET"] = true,
}

UnitPopupButtons["LVPLUS"] = {
	text = "增强功能",
	isTitle = true,
	isUninteractable = true,
	isSubsection = true,
	isSubsectionTitle = true,
	isSubsectionSeparator = true,
}

UnitPopupButtons["ARMORY"] = {
	text = L["Armory"],
	func = function()
		local name = UIDROPDOWNMENU_INIT_MENU.name
		local server = UIDROPDOWNMENU_INIT_MENU.server

		if name then
			local armory = gethost() .. urlencode(server or GetRealmName()) .. "/" .. urlencode(name) .. "/advanced"
			local editBox = ChatEdit_ChooseBoxForSend()
			ChatEdit_ActivateChat(editBox)
			editBox:SetText(armory)
			editBox:HighlightText()
		end
	end
}

UnitPopupButtons["SEND_WHO"] = {
	text = L["Query Detail"],
	func = function()
		local fullname = getfullname()

		if fullname then
			SendWho(fullname)
		end
	end
}

UnitPopupButtons["NAME_COPY"] = {
	text = L["Get Name"],
	func = function()
		local fullname = getfullname()
		if fullname then
			local editBox = ChatEdit_ChooseBoxForSend()
			ChatEdit_ActivateChat(editBox)
			editBox:Insert(fullname)
			editBox:HighlightText()
		end
	end
}

UnitPopupButtons["GUILD_ADD"] = {
	text = L["Guild Invite"],
	func = function()
		local fullname = getfullname()

		if fullname then
			GuildInvite(fullname)
		end
	end
}

UnitPopupButtons["FRIEND_ADD"] = {
	text = L["Add Friend"],
	func = function()
		local fullname = getfullname()

		if fullname then
			AddFriend(fullname)
		end
	end
}

UnitPopupButtons["MYSTATS"] = {
	text = L["Report MyStats"],
	func = function()
		local fullname = getfullname()

		if fullname then
			local CRITICAL = TEXT_MODE_A_STRING_RESULT_CRITICAL or STAT_CRITICAL_STRIKE
			CRITICAL = gsub(CRITICAL, "[()]","")
			SendChatMessage(format("%s:%.1f %s:%s", ITEM_LEVEL_ABBR, select(2,GetAverageItemLevel()), HP, AbbreviateNumbers(UnitHealthMax("player"))), "WHISPER", nil, fullname)
			SendChatMessage(format(" - %s:%.2f%%", STAT_HASTE, GetHaste()), "WHISPER", nil, fullname)
			SendChatMessage(format(" - %s:%.2f%%", STAT_MASTERY, GetMasteryEffect()), "WHISPER", nil, fullname)
			SendChatMessage(format(" - %s:%.2f%%", CRITICAL, max(GetRangedCritChance(), GetCritChance(), GetSpellCritChance(2))), "WHISPER", nil, fullname)
			SendChatMessage(format(" - %s:%.2f%%", STAT_VERSATILITY, GetCombatRatingBonus(CR_VERSATILITY_DAMAGE_DONE) + GetVersatilityBonus(CR_VERSATILITY_DAMAGE_DONE)), "WHISPER", nil, fullname)
		end
	end
}

UnitPopupButtons["LVBLACKNAME"] = {
	text = L["LVBLACKNAME"],
	func = function()
		if not ElvUI then 
			DEFAULT_CHAT_FRAME:AddMessage('Not find ElvUI!',1,1,0);
			return;
		end
		local fullname = getfullname()

		if fullname then
			E.global.LvPlus.InfoFilter.BlackName[fullname] = true
			DEFAULT_CHAT_FRAME:AddMessage(fullname.. CHAT_BLACKLIST_INTRO,1,1,0);
			if IsAddOnLoaded('ElvUI_Config') then
				for k, v in pairs(E.global.LvPlus.InfoFilter.BlackName) do
					E.Options.args.LvPlus.args.InfoFilter.args.BlackName.args.BlackNameList.values[k] = k
				end
			end
		end
	end
}

function RBM:Initialize()
	tinsert(UnitPopupMenus["FRIEND"], #UnitPopupMenus["FRIEND"] - 1, "LVPLUS")
	for _, v in pairs(RBM.friend_features) do
		tinsert(UnitPopupMenus["FRIEND"], #UnitPopupMenus["FRIEND"] - 1, v)
	end
	
	hooksecurefunc("UnitPopup_ShowMenu", function(dropdownMenu, which, unit, name, userData, ...)
		for i=1, UIDROPDOWNMENU_MAXBUTTONS do
			local button = _G["DropDownList" .. UIDROPDOWNMENU_MENU_LEVEL .. "Button" .. i]
			if RBM.UnitPopupButtonsExtra[button.value] then
				button.func = UnitPopupButtons[button.value].func
			end
		end
	end)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvAboutUI.RightButtonMenu then
		return
	end
	RBM:Initialize()
end

E:RegisterModule(RBM:GetName(), InitializeCallback)