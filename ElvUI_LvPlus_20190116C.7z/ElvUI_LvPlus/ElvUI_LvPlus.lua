local E, L, V, P, G = unpack(ElvUI);
local LP = E:NewModule('LvPlus');
local EP = LibStub("LibElvUIPlugin-1.0")
local addonName, addonTable = ...
if not IsAddOnLoaded('ElvUI_LvPlus') then return end

P["LvPlus"] = {
	["LvGeneral"]  = {
		["General"] = {		
			["LvAboutUI"] = {
				["RightButtonMenu"] = true,
				["DisableTalking"] = false,
				["AlreadyKnown"] = true,
				["ClassColors"] = true,
				["AutoDelete"] = true,
				["AutoScreenShoot"] = {
					["EnableBtn"] = true,
				},
				["RaidMarkingKey"] = {
					["RaidMarkingButton1"] = 'alt',
					["RaidMarkingButton2"] = 'LeftButton',
				},
				["SetFocusKey"] = {
					["SetFocusButton1"] = 'shift',
					["SetFocusButton2"] = '1',
				},
				["SetPoi"] = {
					["EnableBtn"] = false,
					["PoiCombat"] = true,
					["PoiColor"] = { r = 0.5, g = 1, b = 1 },
					["PoiText"] = '╋',
					["PoiTextSize"] = 22,
				}
			},
			["LvNamePlates"] = {
				["NamePlatesCastBar"] = true,
			},
			["LvSetCVAR"] = {
				["AutoCompare"] = true,
				["CameraFactor"] = 2,
			},
			["LvChatFrame"] = {
				["ChatBar"] = true,
			},
			["LvToolTips"] = {
				["MountInfo"] = true,
			},
			["LvMinimap"] = {
				["EnableBtn"] = true,
				["SquareMinimapDC"] = 'DOWN',
			},
			["LvCombatNotification"] = {
				["EnableBtn"] = true,
				["CombatNotiEntering"] = "进入战斗",
				["CombatNotiLeaving"] = "离开战斗",
			},
			["LvInviteGroup"] = {
				["EnableBtn"] = true,
				["Ainvkeyword"] = "123",
				["InviteRank"] = {},
			},
		}
	}
}
G["LvPlus"] = {
	["InfoFilter"] = {
		["EnableBtn"] = true,
		["Debug"] = false,
		["KeywordsMatchNumber"] = 1,
		["RtNum"] = 3,
		["FilterFriend"] = true,
		["NoWhisperSticky"] = true,
		["DisableProfanityFilter"] = true,
		["LevelFilter"] = 10,
		["RepeatTime"] = 30,
		["BlackWord"] = {
			["平台交易"] = true,
			["担保"] = true,
			["纯手工"] = true,
			["淘宝"] = true,
			["游戏币"] = true,
			["代打"] = true,
			["代练"] = true,
			["工作室"] = true,
			["战点"] = true,
			["手工金"] = true,
			["手工G"] = true,
			["皇冠店"] = true,
			["一赔"] = true,
			["点心"] = true,
			["冲钻"] = true,
			["店铺"] = true,
			["皇冠"] = true,
			["评级"] = true,
			["套餐"] = true,
			["手工带"] = true,
			["塞纳"] = true,
			["代刷"] = true,
			["带刷"] = true,
			["牛肉"] = true,
			["1-60"] = true,
			["1-90"] = true,
			["90-100"] = true,
			["元="] = true,
			["G="] = true,
			["消保"] = true,
			["好评"] = true,
		},
		['BlackName'] = {},
	}
}

function LP:CreatLvPlus()
	local LvChangeLog = {
	"修复成就自动截图功能",
	"20190116",
	"修复右键增强黑名单功能",
	"升级了右键增强功能",
	"修复信息过滤中的一处判断错误，现在能正确的防刷屏了",
	"增加自动填入DELETE",
	"重写已学物品染色功能，现在能正确的开启和关闭了",
	"临时修复已学物品染色报错，但暂时无法按钮开关该功能，默认为开",
	"20190115",
	"增加成就自动截图",
	"增加好友列表职业染色",
	"增加已学物品染色",
	"增加了全局中文单位选择 增强功能-一般设置-界面相关中选择",
	"优化了部分功能使其在正确的时间调用",
	"20190114",
	"再次修复了小地图无法正确收集小图标的问题",
	"临时修复了便捷组队的一处错误",
	"增加聊天频道条包含频道切换条;TAB切换;属性通报/Boss一句话攻略;聊天表情;ROLL点;加入/离开大脚世界频道",
	"增加便捷组队，关键词自动组队，公会按级别组队功能",
	"增加禁用剧情对话框按钮",
	"20190113",
	"重写框架所有代码便于扩展",
	"右键增强增加英雄榜/添加黑名单功能",
	"修复收集小地图图标与Addonskin的冲突，现在能正确的收集小图标了",
	"增加信息过滤/防刷屏/屏蔽黑名单功能",
	"20190112",
	"添加自定义进出战斗提示",
	"添加右键菜单增强功能",
	"修复了姓名板施法条颜色问题",
	"20190111",
	"CVAR镜头最远距离",
	"屏幕中心指示器",
	"姓名板施法条显示当前目标",
	"CVAR装备自动对比",
	"快速团队标记",
	"快速设置焦点",
	"坐骑信息",
	"收集小地图图标",
	}

	local DeleteChoisedToggle = false;
	local DeleteAllToggle = false;

	E.Options.args.LvPlus = {
		order = 1,
		type = "group",
		name = L["LvPlus"],
		args = {
			ChangeLog = {
				order = -1,
				type = "group",
				guiInline = true,
				name = L["ChangeLog"],
				args = {},
			},
			LvGeneral = {
				order = 1,
				type = "group",
				name = L["LvGeneral"],
				childGroups = "tab",
				args = {
					General = {
						order = 1,
						type = "group",
						name = L["General"],
						args = {
							LvSetCVAR = {
								order = 1,
								type = "group",
								guiInline = false,
								name = L["LvSetCVAR"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] = value end,
								args = {
									AutoCompare = {
										order = 1,
										type = "toggle",
										name = L["AutoCompare"],
										desc = L["AutoCompare_DESC"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] = value;
											if not value then
												SetCVar("alwaysCompareItems", "0");
											else
												SetCVar("alwaysCompareItems", "1");
											end							
										end,
									},
									CameraFactor = {
										order = 2,
										type = "range",
										min = 1, max = 2.6, step = 0.1,
										name = L["CameraFactor"],
										set = function(info, value) SetCVar("cameraDistanceMaxZoomFactor", value);
											E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] = value
										end,
									},
								}
							},
							LvAboutUI = {
								order = 2,
								type = "group",
								guiInline = false,
								name = L["LvAboutUI"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value end,
								args = {
									RightButtonMenu = {
										order = 1,
										type = "toggle",
										name = L["RightButtonMenu"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")		
										end,
									},
									DisableTalking = {
										order = 2,
										type = 'toggle',
										name = L["DisableTalking"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									AlreadyKnown = {
										order = 3,
										type = 'toggle',
										name = L["AlreadyKnown"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									ClassColors = {
										order = 4,
										type = 'toggle',
										name = L["ClassColors"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									AutoDelete = {
										order = 5,
										type = "toggle",
										name = L["AutoDelete"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									numberPrefixStyle = {
										order = 6,
										type = "select",
										name = L["Unit Prefix Style"],
										desc = L["The unit prefixes you want to use when values are shortened in ElvUI. This is mostly used on UnitFrames."],
										get = function(info) return E.db.general.numberPrefixStyle end,
										set = function(info, value) E.db.general.numberPrefixStyle = value; E:StaticPopup_Show("CONFIG_RL") end,
										values = {
											["METRIC"] = "Metric (k, M, G)",
											["ENGLISH"] = "English (K, M, B)",
											["CHINESE"] = "Chinese (W, Y)",
											["KOREAN"] = "Korean (천, 만, 억)",
											["GERMAN"] = "German (Tsd, Mio, Mrd)",
											["LVCHINESE"] = "中文 (万, 亿)",
										},
									},
									AutoScreenShoot = {
										order = 7,
										type = "group",
										guiInline = true,
										name = L["AutoScreenShoot"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")
												end,
											},
											ScreenFormat = {
												order = 2,
												name = L["ScreenFormat"],
												type = "select",
												values = {
													["jpeg"] = "JPG",
													["tga"] = "TGA",
												},
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn end,
												get = function(info) return GetCVar("screenshotFormat") end,
												set = function(info, value) SetCVar("screenshotFormat", value) end,
											},
											ScreenQuality = {
												order = 3,
												name = L["ScreenQuality"],
												type = "range",
												min = 3, max = 10, step = 1,
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn end,
												get = function(info) return tonumber(GetCVar("screenshotQuality")) end,
												set = function(info, value) SetCVar("screenshotQuality", tostring(value)) end,
											},
										},
									},
									RaidMarkingKey = {
										order = 8,
										type = "group",
										guiInline = true,
										name = L["RaidMarkingKey"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey[ info[#info] ] = value end,
										args = {
											RaidMarkingButton1 = {
												order = 1,
												type = "select",
												name = L["RaidMarkingButton"]..'1',
												values = {
													['ctrl'] = "Ctrl",
													['alt'] = "Alt",
													['shift'] = "Shift",
													['none'] = NONE,
												}
											},
											RaidMarkingButton2 = {
												order = 2,
												type = "select",
												name = L["RaidMarkingButton"]..'2',
												disabled = function() return E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey.RaidMarkingButton1 == 'none' end,
												values = {
													["LeftButton"] = L["MouseButton1"],
													["RightButton"] = L["MouseButton2"],
												}
											}
										}
									},
									SetFocusKey = {
										order = 9,
										type = "group",
										guiInline = true,
										name = L["SetFocusKey"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
										args = {
											SetFocusButton1 = {
												order = 1,
												type = "select",
												name = L["SetFocusButton"]..'1',
												values = {
													['shift'] = 'Shift',
													['ctrl'] = 'Ctrl',
													['alt'] = 'Alt',
													['none'] = NONE,
												}
											},
											SetFocusButton2 = {
												order = 2,
												type = "select",
												name = L["SetFocusButton"]..'2',
												values = {
													['1'] = L["MouseButton1"],
													['2'] = L["MouseButton2"],
													['3'] = L["MouseButton3"],
													['4'] = L["MouseButton4"],
												},
												disabled = function() return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton1 == 'none' end,
											}
										}
									},
									SetPoi = {
										order = 10,
										type = "group",
										guiInline = true,
										name = L["SetPoi"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiCombat = {
												order = 2,
												type = 'toggle',
												name = L["PoiCombat"],
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiColor = {
												order = 3,
												type = "color",
												name = L["PoiColor"],
												hasAlpha = false,
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												get = function(info)
													local t = E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													local d = P.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													return t.r, t.g, t.b, t.a, d.r, d.g, d.b
												end,
												set = function(info, r, g, b)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiColor = {}
													local t = E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													t.r, t.g, t.b = r, g, b
													E:GetModule('SetPoi'):SetPoi();
												end,	
											},
											PoiText = {
												order = 4,
												type = 'select',
												name = L["PoiText"],
												values = {
													['┼'] = '┼',
													['╋'] = '╋',
													['◆'] = '◆',
													['■'] = '■',
													['●'] = '●',
													['※'] = '※',
													['↓'] = '↓',
												},
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiTextSize = {
												order = 5,
												type = 'range',
												name = L["PoiTextSize"],
												min = 10, max = 50, step = 1,
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
										}
									}
								}
							},
							LvNamePlates = {
								order = 3,
								type = "group",
								guiInline = false,
								name = L["LvNamePlates"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvNamePlates[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvNamePlates[ info[#info] ] = value end,
								args = {
									NamePlatesCastBar ={
										order = 1,
										type = "toggle",
										name = L["NamePlatesCastBar"],
										desc = L["NamePlatesCastBar_DESC"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvNamePlates[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
											
									}
								}
							},
							LvChatFrame = {
								order = 4,
								type = "group",
								guiInline = false,
								name = L["LvChatFrame"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									ChatBar = {
										order = 1,
										type = "toggle",
										name = L["ChatBar"],
										desc = L["ChatBar_DESC"],
									},				
								}
							},
							LvToolTips = {
								order = 5,
								type = "group",
								guiInline = false,
								name = L["LvToolTips"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvToolTips[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvToolTips[ info[#info] ] = value end,
								args = {
									MountInfo = {
										order = 1,
										type = "toggle",
										name = L["MountInfo"],
										desc = L["MountInfo_DESC"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvToolTips[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")					
										end,
									},
								}
							},
							LvMinimap = {
								order = 6,
								type = "group",
								guiInline = false,
								name = L["LvMinimap"],
								args = {
									SquareMinimap = {
										order = 1,
										type = "group",
										guiInline = true,
										name = L["SquareMinimap"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")	
												end,
											},
											SquareMinimapDC = {
												order = 20,
												type = 'select',
												name = L["SquareMinimapDC"],
												values = {
													['UP'] = L['UP'],
													['DOWN'] = L['DOWN'],
													['LEFT'] = L['LEFT'],
													['RIGHT'] = L['RIGHT'],
												},
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvMinimap.EnableBtn end,
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")	
												end,
											}
										}
									}
								}
							},
							LvCombatNotification = {
								order = 7,
								type = "group",
								guiInline = false,
								name = L["LvCombatNotification"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										width = "full",
										name = L["EnableBtn"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									CombatNotiEntering = {
										order = 2,
										type = "input",
										name = L["CombatNotiEntering"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value end,
									},
									CombatNotiLeaving = {
										order = 3,
										type = "input",
										name = L["CombatNotiLeaving"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value end,
									}
								}
							},
							LvInviteGroup = {
								order = 8,
								type = 'group',
								name = L["LvInviteGroup"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value end,						
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									Ainvkeyword = {
										order = 2,
										type = "input",
										name = L["Ainvkeyword"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvInviteGroup.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value end,					
									},
									Spacer = {
										order = 3,
										type = 'description',
										name = '',
										desc = '',
									},
									InviteRank = {
										order = 4,
										type = 'multiselect',
										name = L["InviteRank"],
										disabled = function() return not IsInGuild() end,
										values = E:GetModule('InviteGroup'):GetGuildRanks(),
										get = function(info, k) return E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[k] end,
										set = function(info, k, v) E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[k] = v; end,
									},						
									RefreshRank = {
										order = 5,
										type = 'execute',
										name = L["RefreshRank"],
										func = function()
											E.Options.args.LvPlus.args.LvGeneral.args.General.args.LvInviteGroup.args.InviteRank.values = E:GetModule('InviteGroup'):GetGuildRanks();
										end,
									},
									StartInvite = {
										order = 6,
										type = 'execute',
										name = L['StartInvite'],
										disabled = function() return not IsInGuild() end,
										func = function() 
											for k, v in pairs(E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank) do
												if v then
													SendChatMessage(format(L['Invite guild ranks is %s member, in 10 sec.'], GuildControlGetRankName(k)), 'GUILD')
												end
											end
											E:ScheduleTimer(E:GetModule('InviteGroup').InviteRanks, 10);
										end,
									},
								},
							},
						}
					}
				}
			},
			InfoFilter = {
				order = 2,
				type = "group",
				name = L["InfoFilter"],
				get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
				set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value; end,
				args = {
					EnableBtn = {
						order = 1,
						type = "toggle",
						name = L["EnableBtn"],
						set = function(info, value)
							E.global.LvPlus.InfoFilter.EnableBtn = value;
							E:StaticPopup_Show("CONFIG_RL");
						end,
					},
					InfoFilterGeneral = {
						order = 2,
						type = "group",
						name = L["InfoFilterGeneral"],
						guiInline = true,
						disabled = function() return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value; end,
						args = {
							Debug = {
								order = 1,
								type = "toggle",
								name = L["Debug"],
							},
							KeywordsMatchNumber = {
								order = 2,
								type = "range",
								name = L["KeywordsMatchNumber"],
								min = 1, max = 10, step = 1,
							},
							RtNum = {
								order = 3,
								type = 'range',
								min = 0, max = 8, step = 1,
								name = L["RtNum"],
								desc = L["RtNum_DESC"],
							},
							FilterFriend = {
								order = 4,
								type = "toggle",
								name = L["FilterFriend"],
								desc = L["FilterFriend_DESC"],
							},
							NoWhisperSticky = {
								order = 5,
								type = "toggle",
								name = L["NoWhisperSticky"],
								set = function(info, value)
									E.global.LvPlus.InfoFilter[ info[#info] ] = value;
									if value then
										ChatTypeInfo.WHISPER.sticky = 0
										ChatTypeInfo.BN_WHISPER.sticky = 0
									else
										ChatTypeInfo.WHISPER.sticky = 1
										ChatTypeInfo.BN_WHISPER.sticky = 1
									end
								end,
							},
							DisableProfanityFilter = {
								order = 6,
								type = "toggle",
								name = L["DisableProfanityFilter"],
								set = function(info, value)
									E.global.LvPlus.InfoFilter[ info[#info] ] = value;
									if value then
										SetCVar("profanityFilter", "0");
									else
										SetCVar("profanityFilter", "1");
									end
								end,
							},
							LevelFilter = {
								order = 7,
								type = 'range',
								min = 0, max = MAX_PLAYER_LEVEL-1, step = 1,
								name = L["LevelFilter"],
								desc = L["LevelFilter_DESC"],
								set = function(info, value)
									if E.global.LvPlus.InfoFilter[ info[#info] ] < 1 and value >= 1 then
										E.global.LvPlus.InfoFilter[ info[#info] ] = value;
										E:StaticPopup_Show("CONFIG_RL");
									end
									if E.global.LvPlus.InfoFilter[ info[#info] ] >= 1 and value < 1 then
										E.global.LvPlus.InfoFilter[ info[#info] ] = value;
										E:StaticPopup_Show("CONFIG_RL");
									end
									E.global.LvPlus.InfoFilter[ info[#info] ] = value;
								end,
							},
							RepeatTime = {
								order = 8,
								type = 'range',
								min = 0, max = 100, step = 1,
								name = L["RepeatTime"],
								desc = L["RepeatTime_DESC"],
							},
						},
					},
					BlackWord = {
						order = 3,
						type = "group",
						name = L["BlackWord"],
						guiInline = true,
						disabled = function() return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value; end,
						args = {
							BlackWordIntro = {
								order = 1,
								type = "description",
								name = L["BlackWordIntro"],
							},
							NewWord = {
								order = 2,
								type = "input",
								name = L["NewWord"],
								get = function(info) return "" end,
								set = function(info, value)
									E.global.LvPlus.InfoFilter.BlackWord[value] = true
									E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[value] = value;
								end,
							},
							DeleteWord = {
								order = 3,
								type = "input",
								name = L["DeleteWord"],
								get = function(info) return "" end,
								set = function(info, value)
									if E.global.LvPlus.InfoFilter.BlackWord[value] ~= nil then
										E.global.LvPlus.InfoFilter.BlackWord[value] = nil
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[value] = nil
									end
								end,
							},
							BlackWordSpacer = {
								order = 4,
								type = 'description',
								name = '',
							},				
							DeleteChoisedKeywords= {
								order = 5,
								type = "execute",
								name = L["DeleteChoisedKeywords"],
								func = function()
									if not DeleteChoisedToggle then
										DeleteChoisedToggle = true;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywordsYES"];
										C_Timer.After(5, function()
											DeleteChoisedToggle = false;
											E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywords"];
										end)
									else						
										for k, v in pairs(E.global.LvPlus.InfoFilter.BlackWord) do
											if v then
												E.global.LvPlus.InfoFilter.BlackWordList[k] = nil;
											end
										end
										DeleteChoisedToggle = false;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywords"];
										wipe(E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values);
										for k, v in pairs(E.global.LvPlus.InfoFilter.BlackWord) do
											E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[k] = k
										end
									end
								end,
							},
							DeleteAllKeywords = {
								order = 6,
								type = "execute",
								name = L["DeleteAllKeywords"],
								func = function()
									if not DeleteAllToggle then
										DeleteAllToggle = true;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywordsYES"];
										C_Timer.After(5, function()
											DeleteAllToggle = false;
											E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywords"];
										end)							
									else						
										wipe(E.global.LvPlus.InfoFilter.BlackWord);
										wipe(E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values);
										DeleteAllToggle = false;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywords"];
									end
								end,
							},				
							BlackWordList = {
								order = 10,
								type = "multiselect",
								name = L["BlackWordList"],
								get = function(info, k) return E.global.LvPlus.InfoFilter.BlackWord[k] end,
								set = function(info, k, v)
									E.global.LvPlus.InfoFilter.BlackWord[k] = v
								end,
								values = {
								}
							}
						}
					},
					BlackName = {
						order = 4,
						type = "group",
						name = L["BlackName"],
						guiInline = true,
						disabled = function() return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value; end,
						args = {
							BlackNameIntro = {
								order = 0,
								type = "description",
								name = L["BlackNameIntro"],
							},
							NewName = {
								order = 1,
								type = "input",
								name = L["NewName"],
								get = function(info) return "" end,
								set = function(info, value)
									E.global.LvPlus.InfoFilter.BlackName[value] = value
								end,
							},
							DeleteName = {
								order = 2,
								type = "input",
								name = L["DeleteName"],
								get = function(info) return "" end,
								set = function(info, value)
									if E.global.LvPlus.InfoFilter.BlackName[value] ~= nil then
										E.global.LvPlus.InfoFilter.BlackName[value] = nil
									end
								end,
							},
							RestoreDefaults = {
								order = 3,
								type = "execute",
								name = L["RestoreDefaults"],
								func = function() wipe(E.global.LvPlus.InfoFilter.BlackName);
									E:StaticPopup_Show("CONFIG_RL")
								end,
							},
							BlackNameList = {
								order = 4,
								type = "multiselect",
								name = L["BlackNameList"],
								get = function(info, k) return E.global.LvPlus.InfoFilter.BlackName[k] end,
								set = function(info, k, v)
									E.global.LvPlus.InfoFilter.BlackName[k] = v
								end,
								values = {
								},
							}
						}
					}
				}
			}
		}
	}

	for i = 1, #LvChangeLog do
		local Lvlog = LvChangeLog[i]
		E.Options.args.LvPlus.args.ChangeLog.args[Lvlog] = {
			order = i,
			type  = "description",
			name  = LvChangeLog[i],
		}
	end
	
	for k, v in pairs(E.global.LvPlus.InfoFilter.BlackWord) do
		E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[k] = k
	end
	
	for k, v in pairs(E.global.LvPlus.InfoFilter.BlackName) do
		E.Options.args.LvPlus.args.InfoFilter.args.BlackName.args.BlackNameList.values[k] = k
	end	
end

function LP:Initialize()
	EP:RegisterPlugin(addonName, LP.CreatLvPlus)
end

local function InitializeCallback()
	LP:Initialize()
end

E:RegisterModule(LP:GetName(), InitializeCallback)