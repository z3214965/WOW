local L = BigWigs:NewBossLocale("Lord Walden", "frFR")
if not L then return end
if L then
	-- %s will be either "Toxic Coagulant" or "Toxic Catalyst"
	--L.coagulant = "%s: Move to dispel"
	--L.catalyst = "%s: Crit Buff"
	--L.toxin_healer_message = "%: DoT on everyone"
end
