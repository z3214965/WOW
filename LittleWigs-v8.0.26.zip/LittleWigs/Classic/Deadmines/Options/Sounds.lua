
BigWigs:AddSounds("Helix Gearbreaker", {
	[88352] = "Alert",
})

BigWigs:AddSounds("Foe Reaper 5000", {
	[88481] = "Alarm",
	[88495] = "Alert",
	[88522] = "Long",
})

BigWigs:AddSounds("Vanessa VanCleef", {
	[95542] = "Long",
})
