
BigWigs:AddColors("Peroth'arn", {
	[105442] = {"blue","yellow"},
	[105493] = {"blue","yellow"},
	[105544] = {"blue","red"},
	["eyes"] = "green",
})

BigWigs:AddColors("Queen Azshara", {
	[-3969] = {"green","orange"},
	[-3968] = "yellow",
})

BigWigs:AddColors("Mannoroth and Varo'then", {
	[-4287] = "yellow",
})
