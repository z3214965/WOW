local L = BigWigs:NewBossLocale("Siamat", "frFR")
if not L then return end
if L then
	L.servant = "Invocation de serviteur"
	L.servant_desc = "Prévient quand un Serviteur de Siamat est invoqué."
end
