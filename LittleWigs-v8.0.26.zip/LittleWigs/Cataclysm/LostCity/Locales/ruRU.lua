local L = BigWigs:NewBossLocale("Siamat", "ruRU")
if not L then return end
if L then
	L.servant = "Призывание Служителя"
	L.servant_desc = "Сообщать когда Служитель Сиамата призван."
end
