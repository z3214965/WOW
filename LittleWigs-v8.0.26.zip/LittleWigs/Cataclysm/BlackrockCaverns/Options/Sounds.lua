
BigWigs:AddSounds("Rom'ogg Bonecrusher", {
	[75272] = "Alert",
	[75539] = "Alarm",
})

BigWigs:AddSounds("Corla, Herald of Twilight", {
	[75697] = "Warning",
	[75823] = {"Alarm","Alert"},
})

BigWigs:AddSounds("Karsh Steelbender", {
	[75842] = "Alert",
	[75846] = {"Info","Warning"},
})

BigWigs:AddSounds("Beauty", {
	[76628] = "Alert",
})

BigWigs:AddSounds("Ascendant Lord Obsidius", {
	[76188] = "Alarm",
})
