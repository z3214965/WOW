
BigWigs:AddColors("Rom'ogg Bonecrusher", {
	[75272] = {"blue","yellow"},
	[75539] = {"red","yellow"},
	[75543] = "orange",
})

BigWigs:AddColors("Corla, Herald of Twilight", {
	[75697] = {"blue","green"},
	[75823] = {"blue","orange","red"},
})

BigWigs:AddColors("Karsh Steelbender", {
	[75842] = "yellow",
	[75846] = {"blue","red"},
})

BigWigs:AddColors("Beauty", {
	[76028] = {"blue","yellow"},
	[76031] = {"blue","orange"},
	[76628] = "blue",
})

BigWigs:AddColors("Ascendant Lord Obsidius", {
	[-2385] = {"orange","yellow"},
	[76188] = {"blue","red"},
	[76189] = {"blue","yellow"},
})
