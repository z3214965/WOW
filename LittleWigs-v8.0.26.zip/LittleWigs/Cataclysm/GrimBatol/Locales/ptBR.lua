local L = BigWigs:NewBossLocale("Erudax", "ptBR")
if not L then return end
if L then
	L.summon = "Evoca Corruptor Sem-Rosto"
	L.summon_desc = "Avisa quando Erudax sumonar um Corruptor Sem-Rosto"
	L.summon_message = "Corruptor Sem-Rosto Sumonado"
	L.summon_trigger = "evoca um"
end
