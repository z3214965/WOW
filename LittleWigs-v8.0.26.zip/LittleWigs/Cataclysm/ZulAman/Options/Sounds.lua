
BigWigs:AddSounds("Akil'zon", {
	[43648] = "Alert",
	[97318] = "Alert",
})

BigWigs:AddSounds("Nalorakk", {
	[42398] = "Info",
	[42402] = "Alarm",
})

BigWigs:AddSounds("Jan'alai", {
	[-2625] = "Long",
	[-2622] = "Info",
	[97497] = "Alert",
})

BigWigs:AddSounds("Halazzi", {
	[43302] = "Alert",
	[43303] = "Alarm",
	[97499] = "Alert",
})

BigWigs:AddSounds("Hex Lord Malacrass", {
	[43421] = "Alarm",
	[43431] = "Alarm",
	[43451] = "Alarm",
	[43548] = "Alarm",
})

BigWigs:AddSounds("Daakara", {
	[43093] = "Alarm",
	[43095] = "Warning",
	[43150] = "Alert",
})
