local L = BigWigs:NewBossLocale("Ozumat", "ptBR")
if not L then return end
if L then
	L.custom_on_autotalk = "Conversa Automática"
	L.custom_on_autotalk_desc = "Instantaneamente seleciona a opção de conversa para iniciar a luta."
end
