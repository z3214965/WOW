local L = BigWigs:NewBossLocale("Jin'do the Godbreaker", "koKR")
if not L then return end
if L then
	--L.barrier_down_message = "Barrier down, %d remaining" -- short name for "Brittle Barrier" (97417)
end
