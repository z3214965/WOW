local L = BigWigs:NewBossLocale("Dazar, The First King", "zhTW")
if not L then return end
if L then
	-- L.spears_active = "Spear Launchers Active"
end

L = BigWigs:NewBossLocale("King's Rest Trash", "zhTW")
if L then
	-- L.guardian = "Animated Guardian"
	-- L.minion = "Minion of Zul"
	-- L.champion = "Shadow-Borne Champion"
	-- L.shadow_witchdoctor = "Shadow-Borne Witch Doctor"
	-- L.warrior = "Shadow-Borne Warrior"
	-- L.timalji = "King Timalji"
	-- L.wasi = "Queen Wasi"
	-- L.rahuai = "King Rahu'ai"
	-- L.atu = "Guard Captain Atu"
	-- L.mbara = "Seneschal M'bara"
	-- L.patla = "Queen Patlaa"
	-- L.raptor = "Skeletal Hunting Raptor"
	-- L.aakul = "King A'akul"
	-- L.agent = "Bloodsworn Agent"
	-- L.purification_construct = "Purification Construct"
	-- L.fluid = "Embalming Fluid"
	-- L.interment_construct = "Interment Construct"
	-- L.hex_priest = "Spectral Hex Priest"
	-- L.berserker = "Spectral Berserker"
	-- L.spectral_witchdoctor = "Spectral Witch Doctor"
	-- L.beastmaster = "Spectral Beastmaster"
	-- L.brute = "Spectral Brute"
	-- L.zul = "Shadow of Zul"

	-- L.casting_on_you = "Casting %s on YOU"
	-- L.casting_on_other = "Casting %s: %s"
end
