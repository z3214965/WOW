
BigWigs:AddColors("The Golden Serpent", {
	[265773] = {"blue","orange"},
	[265781] = "red",
	[265910] = "purple",
	[265923] = "yellow",
})

BigWigs:AddColors("Mchimba the Embalmer", {
	[267618] = {"blue","orange"},
	[267639] = "red",
	[267702] = {"blue","green","yellow"},
})

BigWigs:AddColors("The Council of Tribes", {
	[266206] = "yellow",
	[266231] = {"blue","orange"},
	[266237] = "purple",
	[266951] = {"blue","red"},
	[267060] = "yellow",
	[267273] = "orange",
	["stages"] = "cyan",
})

BigWigs:AddColors("Dazar, The First King", {
	[268586] = "purple",
	[268932] = {"blue","orange"},
	[269231] = "blue",
	[269369] = "red",
	["stages"] = {"cyan","yellow"},
})

BigWigs:AddColors("King's Rest Trash", {
	[269931] = {"blue","orange"},
	[269936] = "blue",
	[269972] = "red",
	[269976] = "orange",
	[270003] = "red",
	[270016] = "orange",
	[270084] = "yellow",
	[270284] = {"blue","orange"},
	[270482] = "yellow",
	[270487] = {"blue","purple"},
	[270492] = {"blue","cyan","orange"},
	[270499] = {"blue","cyan"},
	[270503] = "blue",
	[270507] = {"blue","cyan","red"},
	[270514] = "orange",
	[270865] = {"blue","yellow"},
	[270872] = "orange",
	[270891] = {"blue","orange"},
	[270901] = {"cyan","red"},
	[270920] = {"blue","yellow"},
	[270928] = {"blue","orange"},
	[270931] = "blue",
	[271555] = {"blue","orange"},
	[271564] = "blue",
	[271640] = {"blue","orange"},
	["healing_tide_totem"] = "red",
})
