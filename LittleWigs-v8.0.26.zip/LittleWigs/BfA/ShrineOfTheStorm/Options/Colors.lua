
BigWigs:AddColors("Aqu'sirr", {
	[264101] = "yellow",
	[264166] = {"blue","orange"},
	[264560] = {"blue","yellow"},
	[264903] = "cyan",
	[265001] = "orange",
})

BigWigs:AddColors("Tidesage Coucil", {
	[267818] = "yellow",
	[267891] = {"cyan","green"},
	[267899] = "yellow",
	[267905] = "cyan",
})

BigWigs:AddColors("Lord Stormsong", {
	[268347] = "yellow",
	[269097] = "orange",
	[269131] = {"blue","red"},
})

BigWigs:AddColors("Vol'zith the Whisperer", {
	[267037] = {"blue","cyan"},
	[267360] = "red",
	[267385] = "orange",
	[269399] = "yellow",
})
