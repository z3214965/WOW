local L = BigWigs:NewBossLocale("Aqu'sirr", "zhTW")
if not L then return end
if L then
	-- L.warmup_trigger = "How dare you sully this holy place with your presence!"
end

L = BigWigs:NewBossLocale("Lord Stormsong", "zhTW")
if L then
	-- L.warmup_trigger = "Intruders?! I shall cast your bodies to the blackened depths, to be crushed for eternity!"
end
