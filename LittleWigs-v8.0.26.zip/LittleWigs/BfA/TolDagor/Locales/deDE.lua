local L = BigWigs:NewBossLocale("Tol Dagor Trash", "deDE")
if not L then return end
if L then
	L.vicejaw = "Kanalisationszangenkiefer"
	L.thug = "Schläger der Eisenfluträuber"
	L.seaspeaker = "Seesprecher der Bilgeratten"
	L.flamecaster = "Aschenwindflammenschleuderin"
	L.officer = "Aschenwindoffizierin"
	L.marine = "Aschenwindmarinesoldat"
	L.priest = "Aschenwindpriesterin"
end
