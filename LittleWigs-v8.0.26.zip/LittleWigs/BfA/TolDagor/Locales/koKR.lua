local L = BigWigs:NewBossLocale("Tol Dagor Trash", "koKR")
if not L then return end
if L then
	-- L.vicejaw = "Sewer Vicejaw"
	-- L.thug = "Irontide Thug"
	-- L.seaspeaker = "Bilge Rat Seaspeaker"
	-- L.flamecaster = "Ashvane Flamecaster"
	-- L.officer = "Ashvane Officer"
	-- L.marine = "Ashvane Marine"
	-- L.priest = "Ashvane Priest"
end
