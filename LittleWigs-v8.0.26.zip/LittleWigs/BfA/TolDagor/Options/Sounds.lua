
BigWigs:AddSounds("The Sand Queen", {
	[257092] = "alert",
	[257495] = "long",
	[257608] = "alarm",
	[257609] = "info",
})

BigWigs:AddSounds("Jes Howlis", {
	[257777] = "alarm",
	[257785] = "warning",
	[257791] = "alert",
	[257793] = "long",
	[257827] = {"alert","info"},
})

BigWigs:AddSounds("Knight Captain Valyri", {
	[256955] = "warning",
	[256970] = "alert",
	[257028] = "alarm",
})

BigWigs:AddSounds("Overseer Korgus", {
	[256038] = "warning",
	[256083] = "alert",
	[256105] = {"alarm","warning"},
	[256198] = "info",
	[256199] = "info",
	[263345] = "alert",
})

BigWigs:AddSounds("Tol Dagor Trash", {
	[258079] = "alarm",
	[258128] = "alert",
	[258153] = "alert",
	[258313] = "warning",
	[258634] = "alarm",
	[258864] = "long",
	[258917] = "alarm",
	[258935] = "warning",
})
