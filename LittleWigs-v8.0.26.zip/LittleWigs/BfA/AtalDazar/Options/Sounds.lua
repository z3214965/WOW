
BigWigs:AddSounds("Priestess Alun'za", {
	[255558] = "warning",
	[255577] = "warning",
	[255579] = "alert",
	[255582] = "info",
	[258709] = "alarm",
})

BigWigs:AddSounds("Vol'kaal", {
	[250241] = "info",
	[250258] = "alert",
	[250585] = "alarm",
	[259572] = {"alert","warning"},
})

BigWigs:AddSounds("Rezan", {
	[255371] = "warning",
	[255434] = "alert",
	[257407] = "alarm",
})

BigWigs:AddSounds("Yazma", {
	[249919] = "alert",
	[250036] = "alarm",
	[250050] = "info",
	[250096] = "alert",
	[259187] = "warning",
})

BigWigs:AddSounds("Atal'Dazar Trash", {
	[252687] = "alarm",
	[252781] = "alarm",
	[253517] = "info",
	[253544] = "warning",
	[253583] = "alarm",
	[253721] = "long",
	[255041] = "warning",
	[255567] = "alert",
	[256849] = "alert",
	[260666] = "alert",
})
