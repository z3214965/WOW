local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "zhTW")
if not L then return end
if L then
	-- L.skyscreamer = "Feasting Skyscreamer"
	-- L.tlonja = "T'lonja"
	-- L.shieldbearer = "Shieldbearer of Zul"
	-- L.witchdoctor = "Zanchuli Witch-Doctor"
	-- L.kisho = "Dinomancer Kish'o"
	-- L.priestess = "Gilded Priestess"
	-- L.stalker = "Shadowblade Stalker"
	-- L.confessor = "Dazar'ai Confessor"
	-- L.augur = "Dazar'ai Augur"
end
