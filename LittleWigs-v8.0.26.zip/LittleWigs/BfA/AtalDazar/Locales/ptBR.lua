local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "ptBR")
if not L then return end
if L then
	L.skyscreamer = "Gritacéu Devorante"
	L.tlonja = "T'lonja"
	L.shieldbearer = "Escudeiro de Zul"
	L.witchdoctor = "Mandingueira Zanchuli"
	L.kisho = "Dinomante Kish'o"
	L.priestess = "Sacerdotisa Dourada"
	L.stalker = "Espreitador Umbralâmina"
	L.confessor = "Confessor Dazar'ai"
	L.augur = "Áugure Dazar'ai"
end
