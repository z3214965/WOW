local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "koKR")
if not L then return end
if L then
	-- L.skyscreamer = "Feasting Skyscreamer"
	-- L.tlonja = "T'lonja"
	-- L.shieldbearer = "Shieldbearer of Zul"
	-- L.witchdoctor = "Zanchuli Witch-Doctor"
	-- L.kisho = "Dinomancer Kish'o"
	-- L.priestess = "Gilded Priestess"
	-- L.stalker = "Shadowblade Stalker"
	L.confessor = "다자르아이 고해사제"
	L.augur = "다자르아이 점술가"
end
