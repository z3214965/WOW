local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "itIT")
if not L then return end
if L then
	L.skyscreamer = "Urlacieli Banchettante"
	L.tlonja = "T'lonja"
	L.shieldbearer = "Portascudi di Zul"
	L.witchdoctor = "Taumaturga Zanchuli"
	L.kisho = "Dinomante Kish'o"
	L.priestess = "Sacedotessa Branclin"
	L.stalker = "Inseguitore Lama dell'Ombra"
	L.confessor = "Confessore Dazar'ai"
	L.augur = "Divinatore Dazar'ai"
end
