local L = BigWigs:NewBossLocale("Waycrest Manor Trash", "koKR")
if not L then return end
if L then
	-- L.steward = "Banquet Steward"
	-- L.gorger = "Pallid Gorger"
	-- L.marksman = "Crazed Marksman"
	-- L.runeweaver = "Heartsbane Runeweaver"
	L.vinetwister = "심장파멸 덩굴왜곡사"
	-- L.survivalist = "Maddened Survivalist"
	-- L.bryndle = "Matron Bryndle"
	-- L.thornshaper = "Coven Thornshaper"
	-- L.thornguard = "Thornguard"
	-- L.toad = "Blight Toad"
	-- L.raven = "Dreadwing Raven"
	-- L.soulcharmer = "Heartsbane Soulcharmer"
	-- L.captain = "Bewitched Captain"
	-- L.disciple = "Runic Disciple"
	-- L.sister = "Marked Sister"
	-- L.alma = "Matron Alma"
end
