
BigWigs:AddSounds("Coin-Operated Crowd Pummeler", {
	[256493] = {"alarm","info"},
	[257337] = "alarm",
	[262347] = "alert",
	[269493] = "long",
})

BigWigs:AddSounds("Tik'ali", {
	[257582] = "warning",
	[257593] = "info",
	[258622] = "long",
	[271698] = "alert",
})

BigWigs:AddSounds("Rixxa Fluxflame", {
	[259853] = "alarm",
	[260669] = "alert",
	[270042] = "long",
})

BigWigs:AddSounds("Mogul Razzdunk", {
	[260280] = "alert",
	[260829] = "warning",
	[271456] = "alert",
	["stages"] = "info",
})
