local L = BigWigs:NewBossLocale("Underrot Trash", "zhTW")
if not L then return end
if L then
	-- L.spirit = "Befouled Spirit"
	-- L.priest = "Devout Blood Priest"
	-- L.maggot = "Fetid Maggot"
	-- L.matron = "Chosen Blood Matron"
	-- L.lasher = "Diseased Lasher"
	-- L.bloodswarmer = "Feral Bloodswarmer"
	-- L.rot = "Living Rot"
	-- L.deathspeaker = "Fallen Deathspeaker"
	-- L.defiler = "Bloodsworn Defiler"
	-- L.corruptor = "Faceless Corruptor"
end
