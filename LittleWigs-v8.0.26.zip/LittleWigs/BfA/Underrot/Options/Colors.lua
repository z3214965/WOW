
BigWigs:AddColors("Elder Leaxa", {
	[260879] = "orange",
	[260894] = "yellow",
	[264603] = {"cyan","green","red"},
	[264757] = "yellow",
})

BigWigs:AddColors("Infested Crawg", {
	[260292] = "yellow",
	[260333] = "orange",
	[260793] = "red",
})

BigWigs:AddColors("Sporecaller Zancha", {
	[259718] = {"blue","orange"},
	[259732] = "red",
	[259830] = "cyan",
	[272457] = "purple",
	[273285] = "yellow",
})

BigWigs:AddColors("Unbound Abomination", {
	[269301] = {"blue","orange"},
	[269310] = {"blue","green"},
	[269843] = "red",
	["stages"] = "cyan",
})

BigWigs:AddColors("Underrot Trash", {
	[265019] = {"blue","red","yellow"},
	[265081] = "red",
	[265089] = "orange",
	[265091] = {"red","yellow"},
	[265433] = "orange",
	[265487] = "red",
	[265523] = "yellow",
	[265540] = "yellow",
	[265568] = {"blue","cyan"},
	[265668] = {"blue","yellow"},
	[266106] = "red",
	[266107] = "blue",
	[266209] = "cyan",
	[272183] = "yellow",
	[272592] = "cyan",
	[272609] = "orange",
	[278961] = {"blue","orange","yellow"},
})
