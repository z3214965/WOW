
BigWigs:AddColors("Adderis and Aspix", {
	[263246] = "cyan",
	[263371] = {"blue","orange"},
	[263573] = "yellow",
})

BigWigs:AddColors("Merektha", {
	[263912] = "yellow",
	[263914] = "red",
	[263927] = "blue",
	[263958] = {"blue","red"},
	[264206] = {"cyan","green"},
	[264239] = "orange",
})

BigWigs:AddColors("Galvazzt", {
	[266512] = "red",
	[266923] = {"blue","orange"},
})

BigWigs:AddColors("Avatar of Sethraliss", {
	[268024] = "yellow",
	[269686] = {"blue","orange"},
	[269688] = "cyan",
	[273677] = "red",
})
