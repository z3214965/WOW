
BigWigs:AddColors("Chopper Redhook", {
	[257326] = "orange",
	[257348] = {"blue","red"},
	[257459] = {"blue","yellow"},
	[257585] = "orange",
	[273721] = "green",
	["adds"] = "yellow",
})

BigWigs:AddColors("Sergeant Bainbridge", {
	[257585] = "orange",
	[260924] = "orange",
	[260954] = {"blue","yellow"},
	[261428] = {"blue","red"},
	[277965] = "green",
	["adds"] = "yellow",
})

BigWigs:AddColors("Dread Captain Lockwood", {
	[268230] = "purple",
	[268260] = "orange",
	[268752] = {"green","yellow"},
	[268963] = "cyan",
	[269029] = "orange",
	[272471] = "yellow",
})

BigWigs:AddColors("Hadal Darkfathom", {
	[257882] = "orange",
	[261563] = "yellow",
	[276068] = "red",
})

BigWigs:AddColors("Viq'Goth", {
	[269266] = "purple",
	[269366] = "cyan",
	[270185] = "orange",
	[275014] = {"blue","yellow"},
	["demolishing"] = "yellow",
	["stages"] = "green",
})
