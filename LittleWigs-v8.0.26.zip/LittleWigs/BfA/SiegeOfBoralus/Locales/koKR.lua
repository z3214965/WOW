local L = BigWigs:NewBossLocale("Viq'Goth", "koKR")
if not L then return end
if L then
	-- L.demolishing_desc = "Warnings and timers for when the Demolishing Terror spawns."
end
