
BigWigs:AddColors("Agronox", {
	[235751] = "orange",
	[236524] = "yellow",
	[236527] = "yellow",
	[236639] = "yellow",
	[236640] = "blue",
	[236650] = {"blue","yellow"},
	[238674] = "blue",
})

BigWigs:AddColors("Thrashbite the Scornful", {
	[237276] = "orange",
	[237726] = {"blue","orange"},
	[243124] = "red",
})

BigWigs:AddColors("Domatrax", {
	[-15076] = "red",
	[234107] = "orange",
	[236543] = "yellow",
	[238410] = {"blue","orange"},
})

BigWigs:AddColors("Mephistroth", {
	[233155] = "yellow",
	[233196] = {"blue","red","yellow"},
	[233206] = {"green","yellow"},
	[234817] = "yellow",
})

BigWigs:AddColors("Cathedral of Eternal Night Trash", {
	[236737] = {"blue","yellow"},
	[237391] = "orange",
	[237565] = "yellow",
	[238543] = "orange",
	[238653] = "orange",
	[239101] = "orange",
	[239232] = "orange",
	[239320] = "orange",
	[241598] = "yellow",
	[241772] = "orange",
	[242760] = "red",
})
