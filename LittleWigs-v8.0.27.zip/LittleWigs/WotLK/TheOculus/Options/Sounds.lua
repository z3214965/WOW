
BigWigs:AddSounds("Varos Cloudstrider", {
	[51021] = "Alert",
})

BigWigs:AddSounds("Mage-Lord Urom", {
	[51103] = "Alert",
	[51121] = "Alert",
})
