local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "esES") or BigWigs:NewBossLocale("Halls of Lightning Trash", "esMX")
if not L then return end
if L then
	L.runeshaper = "Creador de runas Tronaforjado"
	L.sentinel = "Centinela Tronaforjado"
end
