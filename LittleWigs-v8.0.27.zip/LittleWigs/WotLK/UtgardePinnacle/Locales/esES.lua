local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "esES") or BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "esMX")
if not L then return end
if L then
	L.berserker = "Rabioso Ymirjar"
end
