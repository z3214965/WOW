
BigWigs:AddColors("Svala Sorrowgrave", {
	[48267] = {"blue","red"},
	[48276] = {"orange","yellow"},
})

BigWigs:AddColors("Gortok Palehoof", {
	[59267] = "orange",
	[59268] = {"blue","yellow"},
})

BigWigs:AddColors("Skadi the Ruthless", {
	[59322] = {"blue","orange"},
})

BigWigs:AddColors("King Ymiron", {
	[59300] = {"blue","orange"},
	[59301] = {"green","orange"},
})

BigWigs:AddColors("Utgarde Pinnacle Trash", {
	[49106] = {"blue","orange"},
})
