
BigWigs:AddSounds("Commander Kolurg/Stoutbeard", {
	[38618] = "Info",
})

BigWigs:AddSounds("Grand Magus Telestra", {
	[47731] = "Alert",
})

BigWigs:AddSounds("Keristrasza", {
	[8599] = "Info",
	[48095] = "Alarm",
})

BigWigs:AddSounds("The Nexus Trash", {
	[30849] = "Alarm",
	[47779] = "Alert",
})
