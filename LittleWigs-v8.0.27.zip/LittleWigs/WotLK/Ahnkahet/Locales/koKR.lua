local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "koKR")
if not L then return end
if L then
	L.spellflinger = "안카하르 주문술사"
	L.eye = "탈다람의 눈"
	L.darkcaster = "황혼의 암흑술사"
end
