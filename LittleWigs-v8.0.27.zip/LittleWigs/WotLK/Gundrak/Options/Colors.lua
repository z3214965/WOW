
BigWigs:AddColors("Slad'ran", {
	[59842] = {"blue","yellow"},
})

BigWigs:AddColors("Drakkari Colossus", {
	[59451] = "blue",
	["stages"] = {"red","yellow"},
})

BigWigs:AddColors("Moorabi", {
	[55098] = {"green","orange"},
})

BigWigs:AddColors("Eck the Ferocious", {
	[55817] = "blue",
})

BigWigs:AddColors("Gal'darah", {
	[59825] = "blue",
	[59827] = {"blue","yellow"},
	["forms"] = "yellow",
})
