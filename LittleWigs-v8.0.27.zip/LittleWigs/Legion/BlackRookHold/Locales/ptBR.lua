local L = BigWigs:NewBossLocale("Black Rook Hold Trash", "ptBR")
if not L then return end
if L then
	L.arcanist = "Arcanista Reanimado"
	L.champion = "Campeão Almapartida"
	L.swordsman = "Espadachim Revivido"
	L.archer = "Arqueira Erguida"
	L.scout = "Batedor Reanimado"
	L.councilor = "Conselheiro Fantasmagórico"
	L.dominator = "Dominador Rancorvil"
end
