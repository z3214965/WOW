
BigWigs:AddSounds("Rokmora", {
	[188114] = "Alert",
	[188169] = "Warning",
	[192800] = "Alarm",
})

BigWigs:AddSounds("Ularogg Cragshaper", {
	[198428] = "Alarm",
	[198496] = "Alert",
	[198564] = "Long",
	["bellow"] = "Info",
})

BigWigs:AddSounds("Naraxas", {
	[-12527] = "Info",
	[199178] = {"Alarm","Warning"},
	[199775] = "Long",
	[205549] = "Alert",
	[210150] = "Alert",
})

BigWigs:AddSounds("Dargrul", {
	[200154] = "Alarm",
	[200404] = "Long",
	[200551] = "Alarm",
	[200700] = "Alert",
	[200732] = "Warning",
})

BigWigs:AddSounds("Neltharions Lair Trash", {
	[183088] = "Long",
	[193585] = "Alarm",
	[202181] = "Alarm",
	[226296] = "Warning",
})
