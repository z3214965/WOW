
BigWigs:AddColors("Shivermaw", {
	[201354] = "orange",
	[201355] = "orange",
	[201379] = "yellow",
	[201672] = "red",
	[201960] = "cyan",
	[202062] = "red",
})

BigWigs:AddColors("Thalena", {
	[202779] = {"blue","green"},
	[202947] = "blue",
	[203381] = "yellow",
})

BigWigs:AddColors("Festerface", {
	[201598] = "red",
	[201729] = "orange",
})

BigWigs:AddColors("Millificent Manastorm", {
	[201159] = {"blue","orange"},
	[201240] = "yellow",
	[201392] = "red",
	[201572] = "cyan",
})

BigWigs:AddColors("Kaahrj", {
	[201146] = {"blue","orange"},
	[201148] = "yellow",
	[201153] = "red",
})

BigWigs:AddColors("Anub'esset", {
	[201863] = "orange",
	[202217] = {"blue","yellow"},
	[202341] = {"blue","red"},
	[202480] = "blue",
	[202485] = "blue",
})

BigWigs:AddColors("Saelorn", {
	[202306] = {"blue","orange"},
	[202414] = {"blue","yellow"},
	[202473] = "red",
})

BigWigs:AddColors("Fel Lord Betrug", {
	[202328] = "orange",
	[203641] = "red",
	[205233] = {"blue","green","red"},
	[210879] = {"blue","yellow"},
})

BigWigs:AddColors("Assault on Violet Hold Trash", {
	[204140] = "red",
	[204608] = {"blue","orange"},
	[204876] = "red",
	[204901] = "red",
	[205088] = "red",
})
