local E, L, DF = unpack(ElvUI); 
local CE = E:NewModule('ChatEmote')
local CH = E:GetModule('Chat')

local CreateFrame = CreateFrame
local ChatEdit_ChooseBoxForSend = ChatEdit_ChooseBoxForSend

local ChatEmote = {}

CE.ChatEmote = ChatEmote

ChatEmote.Config = {
	iconSize = 24,
	enableEmoteInput = true,
}

if (GetLocale() == "zhCN") then
	ChatEmote.tipstr = "点击打开聊天表情框"
elseif (GetLocale() == "zhTW") then
	ChatEmote.tipstr = "點擊打開聊天表情框"
else
	ChatEmote.tipstr = "Click to open emoticon frame"
end
local customEmoteStartIndex = 9

local emotes = {
	{"{rt1}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_1]=]},
	{"{rt2}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_2]=]},
	{"{rt3}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_3]=]},
	{"{rt4}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_4]=]},
	{"{rt5}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_5]=]},
	{"{rt6}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_6]=]},
	{"{rt7}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_7]=]},
	{"{rt8}",	[=[Interface\TargetingFrame\UI-RaidTargetingIcon_8]=]},
	{"{天使}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Angel]=]},
	{"{生气}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Angry]=]},

	{"{大笑}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Biglaugh]=]},
	{"{鼓掌}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Clap]=]},
	{"{酷}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Cool]=]},
	{"{哭}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Cry]=]},
	{"{可爱}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Cutie]=]},
	{"{鄙视}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Despise]=]},
	{"{美梦}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Dreamsmile]=]},
	{"{尴尬}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Embarrass]=]},
	{"{邪恶}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Evil]=]},
	{"{兴奋}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Excited]=]},

	{"{晕}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Faint]=]},
	{"{打架}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Fight]=]},
	{"{流感}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Flu]=]},
	{"{呆}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Freeze]=]},
	{"{皱眉}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Frown]=]},
	{"{致敬}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Greet]=]},
	{"{鬼脸}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Grimace]=]},
	{"{龇牙}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Growl]=]},
	{"{开心}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Happy]=]},
	{"{心}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Heart]=]},

	{"{恐惧}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Horror]=]},
	{"{生病}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Ill]=]},
	{"{无辜}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Innocent]=]},
	{"{功夫}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Kongfu]=]},
	{"{花痴}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Love]=]},
	{"{邮件}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Mail]=]},
	{"{化妆}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Makeup]=]},
	{"{马里奥}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Mario]=]},
	{"{沉思}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Meditate]=]},
	{"{可怜}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Miserable]=]},

	{"{好}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Okay]=]},
	{"{漂亮}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Pretty]=]},
	{"{吐}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Puke]=]},
	{"{握手}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Shake]=]},
	{"{喊}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Shout]=]},
	{"{闭嘴}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Shuuuu]=]},
	{"{害羞}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Shy]=]},
	{"{睡觉}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Sleep]=]},
	{"{微笑}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Smile]=]},
	{"{吃惊}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Suprise]=]},

	{"{失败}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Surrender]=]},
	{"{流汗}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Sweat]=]},
	{"{流泪}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Tear]=]},
	{"{悲剧}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Tears]=]},
	{"{想}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Think]=]},
	{"{偷笑}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Titter]=]},
	{"{猥琐}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Ugly]=]},
	{"{胜利}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Victory]=]},
	{"{雷锋}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Volunteer]=]},
	{"{委屈}",	[=[Interface\AddOns\ElvUI_LvPlus\Media\icon\Wronged]=]},
}

CE.emotes = emotes

local ShowEmoteTableButton
local EmoteTableFrame, EmoteClubTableFrame

local function CreateEmoteClubTableFrame()
	EmoteClubTableFrame = CreateFrame("Frame", "EmoteClubTableFrame", CommunitiesFrame)
	EmoteClubTableFrame:SetTemplate("Default")
	EmoteClubTableFrame:SetWidth((ChatEmote.Config.iconSize+2) * 12+4)
	EmoteClubTableFrame:SetHeight((ChatEmote.Config.iconSize+2) * 5+4)
	EmoteClubTableFrame:SetPoint("BOTTOMLEFT", CommunitiesFrame, "BOTTOMRIGHT", E:Scale(2), 0)
	EmoteClubTableFrame:Hide()
	EmoteClubTableFrame:SetFrameStrata("DIALOG")

	local icon, row, col
	row = 1
	col = 1
	for i=1,#emotes do 
		text = emotes[i][1]
		texture = emotes[i][2]
		icon = CreateFrame("Frame", format("IconButton%d",i), EmoteClubTableFrame)
		icon:SetWidth(ChatEmote.Config.iconSize)
		icon:SetHeight(ChatEmote.Config.iconSize)
		icon.text = text
		icon.texture = icon:CreateTexture(nil,"ARTWORK")
		icon.texture:SetTexture(texture)
		icon.texture:SetAllPoints(icon)
		icon:Show()
		icon:SetPoint("TOPLEFT", (col-1)*(ChatEmote.Config.iconSize+2)+2, -(row-1)*(ChatEmote.Config.iconSize+2)-2)
		icon:SetScript("OnMouseUp", ChatEmote.EmoteClubIconMouseUp)
		icon:EnableMouse(true)
		col = col + 1 
		if (col>12) then
			row = row + 1
			col = 1
		end
	end
end

local function CreateEmoteTableFrame()
	EmoteTableFrame = CreateFrame("Frame", "EmoteTableFrame", E.UIParent)
	EmoteTableFrame:SetTemplate("Default")
	EmoteTableFrame:SetWidth((ChatEmote.Config.iconSize+2) * 12+4)
	EmoteTableFrame:SetHeight((ChatEmote.Config.iconSize+2) * 5+4)
	EmoteTableFrame:SetPoint("BOTTOMLEFT", LeftChatPanel, "TOPLEFT", 0, 20)
	EmoteTableFrame:Hide()
	EmoteTableFrame:SetFrameStrata("DIALOG")

	local icon, row, col
	row = 1
	col = 1
	for i=1,#emotes do 
		text = emotes[i][1]
		texture = emotes[i][2]
		icon = CreateFrame("Frame", format("IconButton%d",i), EmoteTableFrame)
		icon:SetWidth(ChatEmote.Config.iconSize)
		icon:SetHeight(ChatEmote.Config.iconSize)
		icon.text = text
		icon.texture = icon:CreateTexture(nil,"ARTWORK")
		icon.texture:SetTexture(texture)
		icon.texture:SetAllPoints(icon)
		icon:Show()
		icon:SetPoint("TOPLEFT", (col-1)*(ChatEmote.Config.iconSize+2)+2, -(row-1)*(ChatEmote.Config.iconSize+2)-2)
		icon:SetScript("OnMouseUp", ChatEmote.EmoteIconMouseUp)
		icon:EnableMouse(true)
		col = col + 1 
		if (col>12) then
			row = row + 1
			col = 1
		end
	end
end

function ChatEmote.ToggleEmoteTable()
	if (not EmoteTableFrame) then CreateEmoteTableFrame() end
	if (EmoteTableFrame:IsShown()) then
		EmoteTableFrame:Hide()
	else
		EmoteTableFrame:Show()
	end
end

function ChatEmote.ToggleClubEmoteTable()
	if (not EmoteClubTableFrame) then CreateEmoteClubTableFrame() end
	if (EmoteClubTableFrame:IsShown()) then
		EmoteClubTableFrame:Hide()
	else
		EmoteClubTableFrame:Show()
	end
end

function ChatEmote.EmoteClubIconMouseUp(frame, button)
	if (button == "LeftButton") then
		CommunitiesFrame.ChatEditBox:Insert(frame.text)
	end
	ChatEmote.ToggleClubEmoteTable()
end

function ChatEmote.EmoteIconMouseUp(frame, button)
	if (button == "LeftButton") then
		local ChatFrameEditBox = ChatEdit_ChooseBoxForSend()
		if (not ChatFrameEditBox:IsShown()) then
			ChatEdit_ActivateChat(ChatFrameEditBox)
		end
		ChatFrameEditBox:Insert(frame.text)
	end
	ChatEmote.ToggleEmoteTable()
end


local C_Club_GetMessageInfo = C_Club.GetMessageInfo
function C_Club.GetMessageInfo(clubId, streamId, messageId)
	local message = C_Club_GetMessageInfo(clubId, streamId, messageId);
	message.content = CH:GetSmileyReplacementText(message.content)
	
	return message
end

local C_Club_GetMessagesBefore = C_Club.GetMessagesBefore
function C_Club.GetMessagesBefore(clubId, streamId, messageRangeOldest, maxCount)
	local messages = C_Club_GetMessagesBefore(clubId, streamId, messageRangeOldest, maxCount);
	if #messages == 0 then
		return;
	end

	for index = 1, #messages do
		messages[index].content = CH:GetSmileyReplacementText(messages[index].content)
	end

	return messages
end

function CE:Initialize()
	function CH:InsertEmotions(msg)
		for k, v in pairs(CE.emotes) do
			msg = gsub(msg, v[1], "|T"..v[2]..":16|t");
		end

		local emoji, pattern
		for word in gmatch(msg, "%s-%S+%s*") do
			pattern = gsub(strtrim(word), '([%(%)%.%%%+%-%*%?%[%^%$])', '%%%1')
			emoji = CH.Smileys[pattern]
			if emoji and strmatch(msg, '[%s%p]-'..pattern..'[%s%p]*') then
				msg = gsub(msg, '([%s%p]-)'..pattern..'([%s%p]*)', '%1'..emoji..'%2');
			end
		end
		return msg
	end
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatBar then
		return
	end
	CE:Initialize()
end

E:RegisterModule(CE:GetName(), InitializeCallback)

