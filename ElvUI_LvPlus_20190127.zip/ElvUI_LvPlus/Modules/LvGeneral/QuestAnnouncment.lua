local E, L, V, P, G = unpack(ElvUI)
local QA = E:NewModule('QuestAnnouncment', 'AceHook-3.0', 'AceEvent-3.0', 'AceTimer-3.0');

local GetQuestLogTitle = GetQuestLogTitle
local GetQuestLink = GetQuestLink
local IsQuestWatched = IsQuestWatched
local RemoveQuestWatch = RemoveQuestWatch
local GetNumQuestLeaderBoards = GetNumQuestLeaderBoards
local GetQuestLogLeaderBoard = GetQuestLogLeaderBoard
local SendChatMessage = SendChatMessage
local IsInGroup, IsInRaid, LE_PARTY_CATEGORY_HOME, LE_PARTY_CATEGORY_INSTANCE, UnitInParty, UnitInRaid = IsInGroup, IsInRaid, LE_PARTY_CATEGORY_HOME, LE_PARTY_CATEGORY_INSTANCE, UnitInParty, UnitInRaid
local find, pairs = string.find, pairs

local QN_Locale   = {
	["Colon"]       = ":",
	["Quest"]       = "Quest",
	["Progress"]    = "Progress",
	["Complete"]    = "Completed!", 
	["Accept"]      = "Accept Quest",
}
if GetLocale() == 'zhCN' then
	QN_Locale = {
		["Colon"]       = "：",
		["Quest"]       = "任务",
		["Progress"]    = "进度",
		["Complete"]    = "已完成!",
		["Accept"]      = "接受任务",
	}
elseif GetLocale() == 'zhTW' then
	QN_Locale = {
		["Colon"]       = ":",
		["Quest"]       = "任務",
		["Progress"]    = "進度",
		["Complete"]    = "已完成!",
		["Accept"]      = "接受任務",
	}
end

local QHisFirst = true
local lastList
local RGBStr = {
	R = "|CFFFF0000",
	G = "|CFF00FF00",
	B = "|CFF0000FF",
	Y = "|CFFFFFF00",
	K = "|CFF00FFFF",
	D = "|C0000AAFF",
	P = "|CFFD74DE1"
}

local function RScanQuests()
	local QuestList = {}
	local qIndex = 1
	local qLink
	local splitdot = QN_Locale["Colon"]
	while GetQuestLogTitle(qIndex) do
		local qTitle, qLevel, qGroup, qisHeader, qisCollapsed, qisComplete, frequency, qID = GetQuestLogTitle(qIndex)
		local qTag, qTagName = GetQuestTagInfo(qID)
		if not qisHeader then
			qLink = GetQuestLink(qID)
				QuestList[qID]={
				Title    =qTitle,
				Level    =qLevel,
				Tag      =qTagName,
				Group    =qGroup,
				Header   =qisHeader,
				Collapsed=qisCollapsed,
				Complete =qisComplete,
				Daily    =0,
				QuestID  =qID,
				Link     =qLink
			}
			if qisComplete == 1 and ( IsQuestWatched(qIndex) ) then
				RemoveQuestWatch(qIndex)
				ObjectiveTracker_Update()
			end
			for i=1,GetNumQuestLeaderBoards(qIndex) do
				local leaderboardTxt, itemType, isDone = GetQuestLogLeaderBoard (i,qIndex);
				local _, _, numItems, numNeeded, itemName = find(leaderboardTxt, "(%d+)/(%d+) ?(.*)")
				QuestList[qID][i]={
					NeedItem =itemName,
					NeedNum  = numNeeded,
					DoneNum  = numItems
				}
			end
		end

		qIndex = qIndex + 1
	end
	return QuestList
end

local function PrtChatMsg(msg)
	if not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestAnnouncmentBtn then return end
	if (not IsInGroup(LE_PARTY_CATEGORY_HOME) or IsInRaid(LE_PARTY_CATEGORY_HOME)) and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
		if E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestInstance then
			SendChatMessage(msg, "instance_chat", nil)
		end
	elseif UnitInRaid("player") then
		if E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestRaid then
			SendChatMessage(msg, "raid", nil)
		end
	elseif UnitInParty("Party1") then
		if E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestParty then
			SendChatMessage(msg, "party", nil)
		end
	else
		if E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestSolo then
			ChatFrame1:AddMessage(msg)
		end
	end
end

local function CreateQuestAnnouncmentButton()
	if LvPlusQuestAnnouncmentButton then return; end
	local accept = CreateFrame("CheckButton", "LvPlusQuestAnnouncmentButton", ObjectiveTrackerFrame.HeaderMenu, "UICheckButtonTemplate")
	accept:Size(24, 24)
	accept.text:SetText(L["QuestAnnouncment"]);
	accept:Point("LEFT", ObjectiveTrackerFrame.HeaderMenu, "LEFT", E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation and -155 or -235, 10)
	if E.db.LvPlus.LvGeneral.QuestGroup.ButtonElvUI then
		E.Skins:HandleCheckBox(accept)
	end
	accept:SetScript("OnClick", function(self)
		E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestAnnouncmentBtn = not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestAnnouncmentBtn;
	end)
	accept:SetChecked(E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestAnnouncmentBtn);
end

function QA:Initialize()
	CreateQuestAnnouncmentButton()
	
	local QN = CreateFrame("Frame")
	QN:RegisterEvent("QUEST_LOG_UPDATE")
	QN:SetScript("OnEvent", function(self, event)
		local QN_Progress = QN_Locale["Progress"]
		local QN_ItemMsg,QN_ItemColorMsg = " "," "

		if QHisFirst then
			lastList = RScanQuests()
			QHisFirst = false
		end

		local currList = RScanQuests()

		for i,v in pairs(currList) do
			local TagStr = " ";
			if currList[i].Tag and (currList[i].Group < 2) then TagStr = RGBStr.Y .. "["..currList[i].Tag.."]|r" end
			if currList[i].Tag and (currList[i].Group > 1) then TagStr = RGBStr.Y .. "["..currList[i].Tag..currList[i].Group.."]|r" end
			if currList[i].Daily == 1 and currList[i].Tag then
				TagStr = RGBStr.D .. "[" .. DAILY .. currList[i].Tag .. "]|r" ;
			elseif currList[i].Daily == 1 then
				TagStr = RGBStr.D .. "[" .. DAILY .. "]|r";
			elseif currList[i].Tag then
				TagStr = "["..currList[i].Tag .. "]";
			end

			if lastList[i] then
				if not lastList[i].Complete then
					if (#currList[i] > 0) and (#lastList[i] > 0) then
						for j=1,#currList[i] do
							if currList[i][j] and lastList[i][j] and currList[i][j].DoneNum and lastList[i][j].DoneNum then
								if currList[i][j].DoneNum > lastList[i][j].DoneNum then
									QN_ItemMsg = QN_Progress ..":" .. currList[i][j].NeedItem ..": ".. currList[i][j].DoneNum .. "/"..currList[i][j].NeedNum
									QN_ItemColorMsg = RGBStr.G..QN_Locale["Quest"].."|r".. RGBStr.P .. "["..currList[i].Level.."]|r "..currList[i].Link..RGBStr.G..QN_Progress..":|r"..RGBStr.K..currList[i][j].NeedItem..":|r"..RGBStr.Y..currList[i][j].DoneNum .. "/"..currList[i][j].NeedNum .."|r"
									if not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.QuestNoDetail then
										PrtChatMsg(QN_ItemMsg)
									end
								end
							end
						end
					end
				end
				if (#currList[i] > 0) and (#lastList[i] > 0) and (currList[i].Complete == 1) then
					if not lastList[i].Complete then
						if (currList[i].Group > 1) and currList[i].Tag then
							QN_ItemMsg = QN_Locale["Quest"].."["..currList[i].Level.."]".."["..currList[i].Tag..currList[i].Group.."]"..currList[i].Link.." "..QN_Locale["Complete"]
						else
							QN_ItemMsg = QN_Locale["Quest"].."["..currList[i].Level.."]"..currList[i].Link.." "..QN_Locale["Complete"]
						end
						QN_ItemColorMsg = RGBStr.G .. QN_Locale["Quest"] .. "|r" .. RGBStr.P .. "[" .. currList[i].Level .. "]|r " .. currList[i].Link .. TagStr .. RGBStr.K .. QN_Locale["Complete"] .. "|r"
						PrtChatMsg(QN_ItemMsg)
						UIErrorsFrame:AddMessage(QN_ItemColorMsg);
					end
				end
			end

			if not lastList[i] then
				if (currList[i].Group > 1) and currList[i].Tag then
					QN_ItemMsg = QN_Locale["Accept"]..":["..currList[i].Level.."]".."["..currList[i].Tag..currList[i].Group.."]"..currList[i].Link
				elseif currList[i].Daily == 1 then
					QN_ItemMsg = QN_Locale["Accept"]..":["..currList[i].Level.."]".."[" .. DAILY .. "]"..currList[i].Link
				else
					QN_ItemMsg = QN_Locale["Accept"]..":["..currList[i].Level.."]"..currList[i].Link
				end
				QN_ItemColorMsg = RGBStr.K .. QN_Locale["Accept"]..":|r" .. RGBStr.P .."["..currList[i].Level.."]|r "..TagStr..currList[i].Link
				PrtChatMsg(QN_ItemMsg)
			end
		end

		lastList = currList
	end)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn then return end
	QA:Initialize()
end
E:RegisterModule(QA:GetName(), InitializeCallback)
