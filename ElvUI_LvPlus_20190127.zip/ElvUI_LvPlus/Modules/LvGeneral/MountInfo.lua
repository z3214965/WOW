local E, L, V, P, G = unpack(ElvUI);
local MI = E:NewModule('MountInfo', 'AceHook-3.0')

local C_MountJournal_GetMountIDs = C_MountJournal.GetMountIDs
local C_MountJournal_GetMountInfo = C_MountJournal.GetMountInfoByID
local C_MountJournal_GetMountInfoExtra = C_MountJournal.GetMountInfoExtraByID

function MI:SetUnitAura(tt, unit, index, filter)
	if tt:IsForbidden() then return end
	local _, _, _, _, _, _, caster, _, _, id = UnitAura(unit, index, filter)
	local showIt = false
	if id then
		for i,mid in ipairs(C_MountJournal_GetMountIDs()) do
			local creatureName, spellID, icon, active, isUsable, sourceType, isFavorite, isFactionSpecific, faction, hideOnChar, isCollected = C_MountJournal_GetMountInfo(mid)
			if spellID == id then
				local creatureDisplayID, descriptionText, sourceText, isSelfMount = C_MountJournal_GetMountInfoExtra(mid)
				tt:AddLine(' ')
				tt:AddLine(L["MountInfo"], 1, 1, 1)
				tt:AddLine(sourceText, 1, 1, 1)						
				if isCollected then
					tt:AddLine(L["MountInfohaved"], GREEN_FONT_COLOR.r, GREEN_FONT_COLOR.g, GREEN_FONT_COLOR.b)
				else
					tt:AddLine(L["MountInfonothaved"], RED_FONT_COLOR.r, RED_FONT_COLOR.g, RED_FONT_COLOR.b)
				end
				break;
			end
		end	
		showIt = true		
	end
	if showIt then tt:Show() end
end

function MI:Initialize()
	self:SecureHook(GameTooltip, "SetUnitAura")
	self:SecureHook(GameTooltip, "SetUnitBuff", "SetUnitAura")
	self:SecureHook(GameTooltip, "SetUnitDebuff", "SetUnitAura")
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvToolTips.MountInfo then
		return
	end
	MI:Initialize()
end

E:RegisterModule(MI:GetName(), InitializeCallback)