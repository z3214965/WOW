local E, L, V, P, G = unpack(ElvUI)
local LSM = LibStub("LibSharedMedia-3.0")
local QLE = E:NewModule('QuestListEnhanced', 'AceHook-3.0', 'AceEvent-3.0', 'AceTimer-3.0');
local _G = _G

local function SetBlockHeader_hook()
	if not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel.TitleLevel then return end
	for i = 1, GetNumQuestWatches() do
		local questID, title, questLogIndex, numObjectives, requiredMoney, isComplete, startEvent, isAutoComplete, failureTime, timeElapsed, questType, isTask, isStory, isOnMap, hasLocalPOI = GetQuestWatchInfo(i)
		if ( not questID ) then
			break
		end
		local oldBlock = QUEST_TRACKER_MODULE:GetExistingBlock(questID)
		if oldBlock then
			local oldHeight = QUEST_TRACKER_MODULE:SetStringText(oldBlock.HeaderText, title, nil, OBJECTIVE_TRACKER_COLOR["Header"])
			local questLevel = select(2, GetQuestLogTitle(questLogIndex))
			local newTitle = title
			if questLevel ~= 120 then
				newTitle = "["..questLevel.."] "..title
			elseif not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel.IgnoreHighLevel then
				newTitle = "["..questLevel.."] "..title
			end

			local newHeight = QUEST_TRACKER_MODULE:SetStringText(oldBlock.HeaderText, newTitle, nil, OBJECTIVE_TRACKER_COLOR["Header"])
		end
	end
end

local function QuestInfo_hook(template, parentFrame, acceptButton, material, mapView)
	if not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel.TitleLevel then return end
	local elementsTable = template.elements
	for i = 1, #elementsTable, 3 do
		if elementsTable[i] == QuestInfo_ShowTitle then
			if QuestInfoFrame.questLog then
				local questLogIndex = GetQuestLogSelection()
				local level = select(2, GetQuestLogTitle(questLogIndex))
				if level ~= 0 then
					local newTitle = "["..level.."] "..QuestInfoTitleHeader:GetText()
					QuestInfoTitleHeader:SetText(newTitle)
				end
			end
		end
	end
end

function QLE:Initialize()
	local vm = ObjectiveTrackerFrame

	local r, g, b = 103/255, 103/255, 103/255
	local class = select(2, UnitClass("player"))
	local colour = CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[class] or RAID_CLASS_COLORS[class]
	hooksecurefunc(QUEST_TRACKER_MODULE, "SetBlockHeader", function(_, block)
		local fontname = E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList.TitleFont
		local fontsize = E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList.TitleFontSize
		local fontflag = E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList.TitleFontFlag

		block.HeaderText:SetFont(LSM:Fetch('font', fontname), fontsize, fontflag)
		block.HeaderText:SetShadowOffset(.7, -.7)
		block.HeaderText:SetShadowColor(0, 0, 0, 1)
		if E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.TitleColor then
			block.HeaderText:SetTextColor(colour.r, colour.g, colour.b)
		end
		block.HeaderText:SetJustifyH("Left")
		local heightcheck = block.HeaderText:GetNumLines()      
		if heightcheck == 2 then
			local height = block:GetHeight()   
			block:SetHeight(height + 2)
		end

		fontname = E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList.InfoFont
		fontsize = E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList.InfoFontSize
		fontflag = E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList.InfoFontFlag

		for objectiveKey, line in pairs(block.lines) do
			line.Text:SetFont(LSM:Fetch('font', fontname), fontsize, fontflag)
		end
	end)

	local function hoverquest(_, block)
	    block.HeaderText:SetTextColor(colour.r, colour.g, colour.b)
	end
	  
	local function hoverachieve( _, block)
		block.HeaderText:SetTextColor(colour.r, colour.g, colour.b)
	end

	hooksecurefunc(ACHIEVEMENT_TRACKER_MODULE, "SetBlockHeader", function(_, block)
	    local trackedAchievements = {GetTrackedAchievements()}
	    
	    for i = 1, #trackedAchievements do
		    local achieveID = trackedAchievements[i]
		    local _, achievementName, _, completed, _, _, _, description, _, icon, _, _, wasEarnedByMe = GetAchievementInfo(achieveID)
	        local showAchievement = true
	        
		    if wasEarnedByMe then
			    showAchievement = false
		    elseif displayOnlyArena then
			    if GetAchievementCategory(achieveID)~=ARENA_CATEGORY then
				    showAchievement = false
			    end
		    end
		    
	        if showAchievement then
	            block.HeaderText:SetFont(STANDARD_TEXT_FONT, 13,"OUTLINE")
	            block.HeaderText:SetShadowOffset(.7, -.7)
	            block.HeaderText:SetShadowColor(0, 0, 0, 1)
	            if E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.TitleColor then
					block.HeaderText:SetTextColor(colour.r, colour.g, colour.b)
				end
	            block.HeaderText:SetJustifyH("Left")
	        end
	    end
	end)

	if E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.TitleColor then
		hooksecurefunc(QUEST_TRACKER_MODULE, "OnBlockHeaderEnter", hoverquest)  
		hooksecurefunc(QUEST_TRACKER_MODULE, "OnBlockHeaderLeave", hoverquest)
		hooksecurefunc(ACHIEVEMENT_TRACKER_MODULE, "OnBlockHeaderEnter", hoverachieve)
		hooksecurefunc(ACHIEVEMENT_TRACKER_MODULE, "OnBlockHeaderLeave", hoverachieve)
	end
	hooksecurefunc(QUEST_TRACKER_MODULE, "Update", SetBlockHeader_hook)
	hooksecurefunc("QuestInfo_Display", QuestInfo_hook)

	if not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.FrameTitle then
		_G["ObjectiveTrackerFrame"].HeaderMenu.Title:Hide()
		_G["ObjectiveTrackerBlocksFrame"].QuestHeader.Text:Hide()
		hooksecurefunc("ObjectiveTracker_Collapse", function() _G["ObjectiveTrackerFrame"].HeaderMenu.Title:Hide() end)
		hooksecurefunc("ObjectiveTracker_Expand", function() _G["ObjectiveTrackerBlocksFrame"].QuestHeader.Text:Hide() end)
		if E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.LeftSide then
			local HM = _G["ObjectiveTrackerFrame"].HeaderMenu
			local ofx = -E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.LeftSideSize - 222
			HM.MinimizeButton:SetPoint("TOPRIGHT", ofx, 0)
			HM.MinimizeButton:SetSize(E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.LeftSideSize, E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.LeftSideSize)
		end
	end
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn then return end
	QLE:Initialize()
end

E:RegisterModule(QLE:GetName(), InitializeCallback)
