local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
	E.Options.args.lui.args.modules.args.unitframes = {
        order = 13,
		type = "group",
		childGroups = "tab",
        name = L["unitframes"],
        get = function(info)
            return E.db.lui.modules.unitframes[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.unitframes[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
			name = {
				order = 0,
				type = "header",
				name = LUI:cOption(L["unitframes"]),
			},
            playerframe = {
                order = 1,
                type = "group",
                name = L["playerframe"],
                get = function(info)
                    return E.db.lui.modules.unitframes.playerframe[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.unitframes.playerframe[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
                    gcdBar = {
                        order = 1,
                        type = "toggle",
                        width = "full",
                        name = L["gcdBar"],
                    },
                    swingBar = {
                        order = 1,
                        type = "group",
                        guiInline = true,
                        name = L["swingBar"],
                        get = function(info)
                            return E.db.lui.modules.unitframes.playerframe.swingBar[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.unitframes.playerframe.swingBar[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
                            },
                            spacer1 = {
                                order = 2,
                                type = "description",
                                name = "",
                            },
                            swingBarColor = {
                                type = "color",
                                order = 3,
                                name = L["swingBarColor"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                                get = function(info)
                                    local t = E.db.lui.modules.unitframes.playerframe.swingBar[info[#info]];
                                    local d = P.lui.modules.unitframes.playerframe.swingBar[info[#info]];
                                    return t.r, t.g, t.b, t.a, d.r, d.g, d.b, d.a;
                                end,
                                set = function(info, r, g, b, a)
                                    E.db.lui.modules.unitframes.playerframe.swingBar[info[#info]] = {};
                                    local t = E.db.lui.modules.unitframes.playerframe.swingBar[info[#info]];
                                    t.r, t.g, t.b, t.a = r, g, b, a;
                                    E:StaticPopup_Show("PRIVATE_RL");
                                end,
                            },
                            swingBarWidth = {
                                order = 4,
                                type = "range",
                                min = 20, max = 600, step = 1,
                                name = L["swingBarWidth"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                            swingBarHeight = {
                                order = 5,
                                type = "range",
                                min = 1, max = 200, step = 1,
                                name = L["swingBarHeight"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                            spacer2 = {
                                order = 6,
                                type = "description",
                                name = "",
                            },
                            remainingText = {
                                order = 7,
                                type = "toggle",
                                name = L["remainingText"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                            durationText = {
                                order = 8,
                                type = "toggle",
                                name = L["durationText"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                            spacer3 = {
                                order = 9,
                                type = "description",
                                name = "",
                            },
                            swingBarFontName = {
                                order = 10,
                                type = "select",
                                dialogControl = "LSM30_Font",
                                values = LUI.fontName,
                                name = L["swingBarFontName"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                            swingBarFontSize = {
                                order = 11,
                                type = "range",
                                min = 4, max = 212, step = 1,
                                name = L["swingBarFontSize"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                            swingBarFontFlag = {
                                order = 12,
                                type = "select",
                                values = LUI.fontFlagValues,
                                name = L["swingBarFontFlag"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"];
                                end,
                            },
                        }
                    }
                }
            },
            targetframe = {
                order = 2,
                type = "group",
                name = L["targetframe"],
                get = function(info)
                    return E.db.lui.modules.unitframes.targetframe[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.unitframes.targetframe[info[#info]] = value;
                end,
                args = {
                    rangeText = {
                        order = 1,
                        type = "group",
                        guiInline = true,
                        name = L["rangeText"],
                        get = function(info)
                            return E.db.lui.modules.unitframes.targetframe.rangeText[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.unitframes.targetframe.rangeText[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                width = "full",
                                name = L["enableBtn"],
                            },
                            rangeFontName = {
                                order = 2,
                                type = "select",
                                dialogControl = "LSM30_Font",
                                values = LUI.fontName,
                                name = L["rangeFontName"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"];
                                end,
                            },
                            rangeFontSize = {
                                order = 3,
                                type = "range",
                                min = 4, max = 212, step = 1,
                                name = L["rangeFontSize"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"];
                                end,
                            },
                            rangeFontFlag = {
                                order = 4,
                                type = "select",
                                values = LUI.fontFlagValues,
                                name = L["rangeFontFlag"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"];
                                end,
                            },
                            spacer1 = {
                                order = 5,
                                type = "description",
                                name = "",
                            },
                            rangePoi = {
                                order = 6,
                                type = "select",
                                values = LUI.positionValues,
                                name = L["rangePoi"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"];
                                end,
                            },
                            rangePoiX = {
                                order = 7,
                                type = "range",
                                min = -500, max = 500, step = 1,
                                name = L["rangePoiX"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"];
                                end,
                            },
                            rangePoiY = {
                                order = 8,
                                type = "range",
                                min = -500, max = 500, step = 1,
                                name = L["rangePoiY"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"];
                                end,
                            }
                        }
                    }
                }
            },
            focusframe = {
                order = 3,
                type = "group",
                name = L["focusframe"],
                get = function(info)
                    return E.db.lui.modules.unitframes.focusframe[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.unitframes.focusframe[info[#info]] = value;
                end,
                args = {
                    rangeText = {
                        order = 1,
                        type = "group",
                        guiInline = true,
                        get = function(info)
                            return E.db.lui.modules.unitframes.focusframe.rangeText[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.unitframes.focusframe.rangeText[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        name = L["rangeText"],
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                width = "full",
                                name = L["enableBtn"],
                            },
                            rangeFontName = {
                                order = 2,
                                type = "select",
                                dialogControl = "LSM30_Font",
                                values = LUI.fontName,
                                name = L["rangeFontName"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"];
                                end,
                            },
                            rangeFontSize = {
                                order = 3,
                                type = "range",
                                min = 4, max = 212, step = 1,
                                name = L["rangeFontSize"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"];
                                end,
                            },
                            rangeFontFlag = {
                                order = 4,
                                type = "select",
                                values = LUI.fontFlagValues,
                                name = L["rangeFontFlag"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"];
                                end,
                            },
                            spacer1 = {
                                order = 5,
                                type = "description",
                                name = "",
                            },
                            rangePoi = {
                                order = 6,
                                type = "select",
                                values = LUI.positionValues,
                                name = L["rangePoi"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"];
                                end,
                            },
                            rangePoiX = {
                                order = 7,
                                type = "range",
                                min = -500, max = 500, step = 1,
                                name = L["rangePoiX"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"];
                                end,
                            },
                            rangePoiY = {
                                order = 8,
                                type = "range",
                                min = -500, max = 500, step = 1,
                                name = L["rangePoiY"],
                                disabled = function(info)
                                    return not E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"];
                                end,
                            }
                        }
                    }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
