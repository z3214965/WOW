local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
    E.Options.args.lui.args.modules.args.blizzard = {
        order = 5,
        type = "group",
        childGroups = "tab",
        name = L["blizzard"],
        get = function(info)
            return E.db.lui.modules.blizzard[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.blizzard[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["blizzard"]),
            },
            castbarTime = {
                order = 1,
                type = "toggle",
                name = L["castbarTime"],
            },
            minimapWheel = {
                order = 2,
                type = "toggle",
                name = L["minimapWheel"],
            },
            blizzardMoveFrames = {
                order = 3,
                type = "group",
                guiInline = true,
                name = L["blizzardMoveFrames"],
                get = function(info)
                    return E.db.lui.modules.blizzard.blizzardMoveFrames[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.blizzard.blizzardMoveFrames[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args ={
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    remember = {
                        order = 2,
                        type = "toggle",
                        name = L["remember"],
                    },
                    errorframe = {
                        order = 3,
                        type = "group",
                        guiInline = true,
                        name = L["errorframe"],
                        get = function(info)
                            return E.db.lui.modules.blizzard.blizzardMoveFrames.errorframe[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.blizzard.blizzardMoveFrames.errorframe[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args = {
                            width = {
                                order = 1,
                                name = L["width"],
                                type = "range",
                                min = 100, max = 1000, step = 1,
                            },
                            height = {
                                order = 2,
                                name = L["height"],
                                type = "range",
                                min = 30, max = 300, step = 15,
                            },
                        }
                    }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
