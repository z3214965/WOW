local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
    E.Options.args.lui.args.modules.args.actionbars = {
        order = 2,
        type = "group",
        childGroups = "tab",
        name = L["actionbars"],
        get = function(info)
            return E.db.lui.modules.actionbars[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.actionbars[info[#info]] = value;
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["actionbars"]),
            },
            randomHearthstone = {
                order = 1,
                type = "group",
                name = L["randomHearthstone"],
                get = function(info)
                    return E.db.lui.modules.actionbars.randomHearthstone[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.actionbars.randomHearthstone[info[#info]] = value;
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    creatRHS = {
                        order = 2,
                        type = "execute",
                        name = L["creatRHS"],
                        disabled = function(info)
                            return not E.db.lui.modules.actionbars.randomHearthstone["enableBtn"];
                        end,
                        func = function()
                            LUI:GetModule("LUIActionbars"):Macro_Refresh();
                            E:ToggleConfig();
                        end,
                    }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
