local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
    E.Options.args.lui.args.modules.args.misc = {
        order = 1,
        type = "group",
        childGroups = "tab",
        name = L["misc"],
        get = function(info)
            return E.db.lui.modules.misc[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.misc[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["misc"]),
            },
            general = {
                order = 1,
                type = "group",
                name = L["general"],
                get = function(info) return
                    E.db.lui.modules.misc.general[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.misc.general[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
                    numberPrefixStyle = {
                        order = 1,
                        type = "select",
                        name = L["Unit Prefix Style"],
                        desc = L["The unit prefixes you want to use when values are shortened in ElvUI. This is mostly used on UnitFrames."],
                        get = function(info)
                            return E.db.general["numberPrefixStyle"];
                        end,
                        set = function(info, value)
                            E.db.general["numberPrefixStyle"] = value;
                            E.db.lui.modules.misc.general["numberPrefixStyle"] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        values = {
                            ["METRIC"] = "Metric (k, M, G)",
                            ["ENGLISH"] = "English (K, M, B)",
                            ["CHINESE"] = "Chinese (W, Y)",
                            ["KOREAN"] = "Korean (천, 만, 억)",
                            ["GERMAN"] = "German (Tsd, Mio, Mrd)",
                            ["LUICHINESE"] = "中文 (万, 亿)",
                        },
                    },
                    autoDelete = {
                        order = 2,
                        type = "toggle",
                        name = L["autoDelete"],
                    },
                    autoRelease = {
                        order = 3,
                        type = "toggle",
                        name = L["autoRelease"],
                    },
                    autoRepChange = {
                        order = 4,
                        type = "toggle",
                        name = L["autoRepChange"],
                    },
                    classColors = {
                        order = 5,
                        type = "toggle",
                        name = L["classColors"],
                    },
                    disableTalking = {
                        order = 6,
                        type = "toggle",
                        name = L["disableTalking"],
                    },
                    rightButtonMenu = {
                        order = 7,
                        type = "toggle",
                        name = L["rightButtonMenu"],
                    },
                    alreadyKnown = {
                        order = 8,
                        type = "group",
                        guiInline = true,
                        name = L["alreadyKnown"],
                        get = function(info) return
                            E.db.lui.modules.misc.general.alreadyKnown[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.misc.general.alreadyKnown[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
                            },
                            color = {
                                order = 2,
                                type = "color",
                                name = L["color"],
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.alreadyKnown["enableBtn"];
                                end,
                                get = function(info)
                                    local t = E.db.lui.modules.misc.general.alreadyKnown[info[#info]];
                                    local d = P.lui.modules.misc.general.alreadyKnown[info[#info]];
                                    return t.r, t.g, t.b, t.a, d.r, d.g, d.b, d.a;
                                end,
                                set = function(info, r, g, b, a)
                                    E.db.lui.modules.misc.general.alreadyKnown[info[#info]] = {};
                                    local t = E.db.lui.modules.misc.general.alreadyKnown[info[#info]];
                                    t.r, t.g, t.b, t.a = r, g, b, a;
                                    E:StaticPopup_Show("PRIVATE_RL");
                                end,
                            }
                        }
                    },
                    talentProfiles = {
                        order = 9,
                        type = "group",
                        guiInline = true,
                        name = L["talentProfiles"],
                        get = function(info)
                            return E.db.lui.modules.misc.general.talentProfiles[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.misc.general.talentProfiles[info[#info]] = value;
                        end,
                        args = {
                            enableBtn = {
                                order = 5,
                                type = "toggle",
                                name = L["enableBtn"],
                            },
                            talentButtonElvUI = {
                                order = 6,
                                type = "toggle",
                                name = L["talentButtonElvUI"],
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.talentProfiles["enableBtn"];
                                end,
                            }
                        }
                    },
                    setPoi = {
                        order = 10,
                        type = "group",
                        guiInline = true,
                        name = L["setPoi"],
                        get = function(info)
                            return E.db.lui.modules.misc.general.setPoi[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.misc.general.setPoi[info[#info]] = value;
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
                                set = function(info, value)
                                    E.db.lui.modules.misc.general.setPoi["enableBtn"] = value;
                                    LUI:GetModule("LUIMisc"):LoadSetPoi()
                                end,
                            },
                            poiCombat = {
                                order = 2,
                                type = "toggle",
                                name = L["poiCombat"],
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.setPoi["enableBtn"];
                                end,
                                set = function(info, value)
                                    E.db.lui.modules.misc.general.setPoi[info[#info]] = value;
                                    LUI:GetModule("LUIMisc"):LoadSetPoi()
                                end,
                            },
                            poiColor = {
                                order = 3,
                                type = "color",
                                name = L["poiColor"],
                                hasAlpha = false,
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.setPoi["enableBtn"];
                                end,
                                get = function(info)
                                    local t = E.db.lui.modules.misc.general.setPoi[info[#info]];
                                    local d = P.lui.modules.misc.general.setPoi[info[#info]];
                                    return t.r, t.g, t.b, t.a, d.r, d.g, d.b, d.a;
                                end,
                                set = function(info, r, g, b, a)
                                    E.db.lui.modules.misc.general.setPoi.poiColor = {};
                                    local t = E.db.lui.modules.misc.general.setPoi[info[#info]];
                                    t.r, t.g, t.b, t.a = r, g, b, a;
                                    LUI:GetModule("LUIMisc"):LoadSetPoi()
                                    E:StaticPopup_Show("PRIVATE_RL");
                                end,
                            },
                            poiText = {
                                order = 4,
                                type = "select",
                                name = L["poiText"],
                                values = {
                                    ["┼"] = "┼",
                                    ["╋"] = "╋",
                                    ["◆"] = "◆",
                                    ["■"] = "■",
                                    ["●"] = "●",
                                    ["※"] = "※",
                                    ["↓"] = "↓",
                                },
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.setPoi["enableBtn"];
                                end,
                                set = function(info, value)
                                    E.db.lui.modules.misc.general.setPoi[info[#info]] = value;
                                    LUI:GetModule("LUIMisc"):LoadSetPoi()
                                end,
                            },
                            poiTextSize = {
                                order = 5,
                                type = "range",
                                name = L["poiTextSize"],
                                min = 10, max = 50, step = 1,
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.setPoi["enableBtn"];
                                end,
                                set = function(info, value)
                                    E.db.lui.modules.misc.general.setPoi[info[#info]] = value;
                                    LUI:GetModule("LUIMisc"):LoadSetPoi()
                                end,
                            },
                        },
                    },
                    autoScreenShoot = {
                        order = 11,
                        type = "group",
                        guiInline = true,
                        name = L["autoScreenShoot"],
                        get = function(info)
                            return E.db.lui.modules.misc.general.autoScreenShoot[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.misc.general.autoScreenShoot[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
                            },
                            screenFormat = {
                                order = 2,
                                name = L["screenFormat"],
                                type = "select",
                                values = {
                                    ["jpeg"] = "JPG",
                                    ["tga"] = "TGA",
                                },
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.autoScreenShoot["enableBtn"];
                                end,
                                get = function(info)
                                    return GetCVar("screenshotFormat");
                                end,
                                set = function(info, value)
                                    SetCVar("screenshotFormat", value);
                                end,
                            },
                            screenQuality = {
                                order = 3,
                                name = L["screenQuality"],
                                type = "range",
                                min = 3, max = 10, step = 1,
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.general.autoScreenShoot["enableBtn"];
                                end,
                                get = function(info)
                                    return T.tonumber(GetCVar("screenshotQuality"));
                                end,
                                set = function(info, value)
                                    SetCVar("screenshotQuality", T.tostring(value));
                                end,
                            }
                        }
                    }
                }
            },
            inviteGroup = {
                order = 2,
                type = "group",
                name = L["inviteGroup"],
                get = function(info)
                    return E.db.lui.modules.misc.inviteGroup[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.misc.inviteGroup[info[#info]] = value;
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                        set = function(info, value)
                            E.db.lui.modules.misc.inviteGroup[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                    },
                    ainvkeyword = {
                        order = 2,
                        type = "input",
                        name = L["ainvkeyword"],
                        disabled = function(info)
                            return not E.db.lui.modules.misc.inviteGroup["enableBtn"];
                        end,
                    },
                    spacer = {
                        order = 3,
                        type = "description",
                        name = "",
                        desc = "",
                    },
                    inviteRank = {
                        order = 4,
                        type = "multiselect",
                        name = L["inviteRank"],
                        values = LUI:GetModule("LUIMisc"):GetGuildRanks(),
                        disabled = function(info)
                            return not T.IsInGuild();
                        end,
                        get = function(info, k)
                            return E.db.lui.modules.misc.inviteGroup.inviteRank[k];
                        end,
                        set = function(info, k, v)
                            E.db.lui.modules.misc.inviteGroup.inviteRank[k] = v;
                        end,
                    },
                    refreshRank = {
                        order = 5,
                        type = "execute",
                        name = L["refreshRank"],
                        func = function()
                            E.Options.args.lui.args.modules.args.misc.args.inviteGroup.args.inviteRank.values = LUI:GetModule("LUIMisc"):GetGuildRanks();
                        end,
                    },
                    startInvite = {
                        order = 6,
                        type = "execute",
                        name = L["startInvite"],
                        disabled = function(info)
                            return not T.IsInGuild();
                        end,
                        func = function()
                            for k, v in T.pairs(E.db.lui.modules.misc.inviteGroup.inviteRank) do
                                if v then
                                    T.SendChatMessage(T.format(L["LUI_INVITEGROUP_MSG"], GuildControlGetRankName(k)), "GUILD");
                                end
                            end
                            E:ScheduleTimer(LUI:GetModule("LUIMisc").InviteRanks, 10);
                        end,
                    },
                },
            },
            loot = {
                order = 3,
                type = "group",
                name = L["loot"],
                get = function(info)
                    return E.db.lui.modules.misc.loot[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.misc.loot[info[#info]] = value;
                end,
                args = {
                    lootSpecManager = {
                        order = 1,
                        type = "group",
                        guiInline = true,
                        name = L["lootSpecManager"],
                        get = function(info)
                            return E.db.lui.modules.misc.loot.lootSpecManager[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.misc.loot.lootSpecManager[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args ={
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
                            },
                            lootSpecManagerBtn ={
                                order = 2,
                                type = "execute",
                                name = L["lootSpecManagerBtn"],
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.loot.lootSpecManager["enableBtn"];
                                end,
                                func = function()
                                    if LTSM_GUI then
                                        LTSM_GUI.frame:Show();
                                        E:ToggleConfig();
                                    end
                                end,
                            }
                        }
                    },
                    fastLoot = {
                        order = 2,
                        type = "group",
                        guiInline = true,
                        name = L["fastLoot"],
                        get = function(info)
                            return E.db.lui.modules.misc.loot.fastLoot[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.misc.loot.fastLoot[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
                            },
                            lootSpeed = {
                                order = 2,
                                type = "select",
                                name = L["lootSpeed"],
                                values = {
                                    ["光速"] = "光速",
                                    ["极快"] = "极快",
                                    ["稍快"] = "稍快",
                                },
                                disabled = function(info)
                                    return not E.db.lui.modules.misc.loot.fastLoot["enableBtn"];
                                end,
                            },
                        },
                    },
                },
            },
        },
    }
end
T.tinsert(LUI.Configs, configTable);
