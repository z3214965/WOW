local LUI, T, E, L, V, P, G = unpack(select(2, ...))


local function configTable()
    E.Options.args.lui.args.modules.args.combat = {
        order = 7,
        type = "group",
        childGroups = "tab",
        name = L["combat"],
        get = function(info)
            return E.db.lui.modules.combat[info[#info]]
        end,
        set = function(info, value)
            E.db.lui.modules.combat[info[#info]] = value
            E:StaticPopup_Show("PRIVATE_RL")
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["combat"]),
            },
            combatNotification = {
                order = 1,
                type = "group",
                name = L["combatNotification"],
                get = function(info)
                    return E.db.lui.modules.combat.combatNotification[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.combat.combatNotification[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    combatNotiEntering = {
                        order = 3,
                        type = "input",
                        name = L["combatNotiEntering"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    combatNotiLeaving = {
                        order = 4,
                        type = "input",
                        name = L["combatNotiLeaving"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    spacer2 = {
                        order = 5,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    combatNotiFont = {
                        order = 6,
                        type = "select",
                        dialogControl = "LSM30_Font",
                        values = LUI.fontName,
                        name = L["combatNotiFont"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    combatNotiSize = {
                        order = 7,
                        type = "range",
                        min = 1, max = 100, step = 1,
                        name = L["combatNotiSize"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    combatNotiFlag = {
                        order = 8,
                        type = "select",
                        values = LUI.fontFlagValues,
                        name = L["combatNotiFlag"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    spacer3 = {
                        order = 9,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    rangePoiX = {
                        order = 10,
                        type = "range",
                        min = -1000, max = 1000, step = 1,
                        name = L["rangePoiX"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    },
                    rangePoiY = {
                        order = 11,
                        type = "range",
                        min = -500, max = 500, step = 1,
                        name = L["rangePoiY"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.combatNotification["enable"]
                        end,
                    }
                }
            },
            combatShortcut = {
                order = 2,
                type = "group",
                name = L["combatShortcut"],
                get = function(info)
                    return E.db.lui.modules.combat.combatShortcut[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.combat.combatShortcut[info[#info]] = value
					E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    raidMarkingKey = {
                        order = 9,
                        type = "group",
                        guiInline = true,
                        name = L["raidMarkingKey"],
						get = function(info)
							return E.db.lui.modules.combat.combatShortcut.raidMarkingKey[info[#info]]
						end,
						set = function(info, value)
							E.db.lui.modules.combat.combatShortcut.raidMarkingKey[info[#info]] = value
							E:StaticPopup_Show("PRIVATE_RL")
						end,
                        args = {
                            raidMarkingButton1 = {
                                order = 1,
                                type = "select",
                                name = L["raidMarkingButton"] .. "1",
                                values = {
                                    ["ctrl"] = "Ctrl",
                                    ["alt"] = "Alt",
                                    ["shift"] = "Shift",
                                    ["none"] = NONE,
                                }
                            },
                            raidMarkingButton2 = {
                                order = 2,
                                type = "select",
                                name = L["raidMarkingButton"] .. "2",
								disabled = function(info)
									return E.db.lui.modules.combat.combatShortcut.raidMarkingKey["raidMarkingButton1"] == "none"
								end,
                                values = {
                                    ["LeftButton"] = L["mouseButton1"],
                                    ["RightButton"] = L["mouseButton2"],
                                }
                            }
                        }
                    },
                    setFocusKey = {
                        order = 10,
                        type = "group",
                        guiInline = true,
                        name = L["setFocusKey"],
						get = function(info)
							return E.db.lui.modules.combat.combatShortcut.setFocusKey[info[#info]]
						end,
						set = function(info, value)
							E.db.lui.modules.combat.combatShortcut.setFocusKey[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            setFocusButton1 = {
                                order = 1,
                                type = "select",
                                name = L["setFocusButton"] .. "1",
                                values = {
                                    ["shift"] = "Shift",
                                    ["ctrl"] = "Ctrl",
                                    ["alt"] = "Alt",
                                    ["none"] = NONE,
                                }
                            },
                            setFocusButton2 = {
                                order = 2,
                                type = "select",
                                name = L["setFocusButton"] .. "2",
                                values = {
                                    ["1"] = L["mouseButton1"],
                                    ["2"] = L["mouseButton2"],
                                    ["3"] = L["mouseButton3"],
                                    ["4"] = L["mouseButton4"],
                                },
								disabled = function(info)
									return E.db.lui.modules.combat.combatShortcut.setFocusKey["setFocusButton1"] == "none"
								end,
                            }
                        }
                    }
                }
            },
            announceSystem = {
                order = 3,
                type = "group",
                name = L["announceSystem"],
				get = function(info)
					return E.db.lui.modules.combat.announceSystem[info[#info]]
				end,
				set = function(info, value)
					E.db.lui.modules.combat.announceSystem[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    raidSpells = {
                        order = 2,
                        type = "group",
                        guiInline = true,
                        name = L["raidSpells"],
                        hidden = function(info)
                            return not E.db.lui.modules.combat.announceSystem["enable"]
                        end,
						get = function(info)
							return E.db.lui.modules.combat.announceSystem.raidSpells[info[#info]]
						end,
						set = function(info, value)
							E.db.lui.modules.combat.announceSystem.raidSpells[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enable = {
                                order = 1,
                                type = "toggle",
                                name = L["Enable"],
                            },
                        },
                    },
                    resAndThreatSpells = {
                        order = 3,
                        type = "group",
                        guiInline = true,
                        name = L["resAndThreatSpells"],
						hidden = function(info)
                            return not E.db.lui.modules.combat.announceSystem["enable"]
                        end,
						get = function(info)
							return E.db.lui.modules.combat.announceSystem.resAndThreatSpells[info[#info]]
						end,
						set = function(info, value)
							E.db.lui.modules.combat.announceSystem.resAndThreatSpells[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enable = {
                                order = 0,
                                type = "toggle",
                                name = L["Enable"],
                            },
                            resAndThreat = {
                                order = 1,
                                type = "toggle",
                                name = L["resAndThreat"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.resAndThreatSpells["enable"]
                                end,
                            },
                            resThanks = {
                                order = 2,
                                type = "toggle",
                                name = L["resThanks"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.resAndThreatSpells["enable"]
                                end,
                            },
                        },
                    },
                    taunt = {
                        order = 5,
                        type = "group",
                        guiInline = true,
                        name = L["taunt"],
						hidden = function(info)
                            return not E.db.lui.modules.combat.announceSystem["enable"]
                        end,
						get = function(info)
							return E.db.lui.modules.combat.announceSystem.taunt[info[#info]]
						end,
						set = function(info, value)
							E.db.lui.modules.combat.announceSystem.taunt[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enable = {
                                order = 0,
                                type = "toggle",
                                name = L["Enable"],
                            },
                            spacer1 = {
                                order = 1,
                                type = "description",
                                name = "",
                            },
                            playerSmart = {
                                order = 2,
                                type = "toggle",
                                name = L["playerSmart"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.taunt["enable"]
                                end,
                            },
                            includeMiss = {
                                order = 3,
                                type = "toggle",
                                name = L["includeMiss"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.taunt["enable"]
                                end,
                            },
                            otherTankSmart = {
                                order = 4,
                                type = "toggle",
                                name = L["otherTankSmart"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.taunt["enable"]
                                end,
                            },
                            includeOtherTank = {
                                order = 5,
                                type = "toggle",
                                name = L["includeOtherTank"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.taunt["enable"]
                                end,
                            },
                            petSmart = {
                                order = 6,
                                type = "toggle",
                                name = L["petSmart"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.taunt["enable"]
                                end,
                            },
                            includePet = {
                                order = 7,
                                type = "toggle",
                                name = L["includePet"],
                                hidden = function(info)
                                    return not E.db.lui.modules.combat.announceSystem.taunt["enable"]
                                end,
                            }
                        }
                    }
                }
            }
        }
    }
end
T.table_insert(LUI.Configs, configTable)
