local LUI, T, E, L, V, P, G = unpack(select(2, ...));


local function configTable()
    E.Options.args.lui.args.modules.args.combat = {
        order = 7,
        type = "group",
        childGroups = "tab",
        name = L["combat"],
        get = function(info)
            return E.db.lui.modules.combat[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.combat[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["combat"]),
            },
            combatNotification = {
                order = 1,
                type = "group",
                name = L["combatNotification"],
                get = function(info)
                    return E.db.lui.modules.combat.combatNotification[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.combat.combatNotification[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                    },
                    combatNotiEntering = {
                        order = 3,
                        type = "input",
                        name = L["combatNotiEntering"],
						disabled = function(info)
							return not E.db.lui.modules.combat.combatNotification["enableBtn"];
						end,
                    },
                    combatNotiLeaving = {
                        order = 4,
                        type = "input",
                        name = L["combatNotiLeaving"],
						disabled = function(info)
							return not E.db.lui.modules.combat.combatNotification["enableBtn"];
						end,
                    },
                    spacer2 = {
                        order = 5,
                        type = "description",
                        name = "",
                    },
                    combatNotiFont = {
                        order = 6,
                        type = "select",
                        dialogControl = "LSM30_Font",
                        values = LUI.fontName,
                        name = L["combatNotiFont"],
						disabled = function(info)
							return not E.db.lui.modules.combat.combatNotification["enableBtn"];
						end,
                    },
                    combatNotiSize = {
                        order = 7,
                        type = "range",
                        min = 1, max = 100, step = 1,
                        name = L["combatNotiSize"],
						disabled = function(info)
							return not E.db.lui.modules.combat.combatNotification["enableBtn"];
						end,
                    },
                    combatNotiFlag = {
                        order = 8,
                        type = "select",
                        values = LUI.fontFlagValues,
                        name = L["combatNotiFlag"],
						disabled = function(info)
							return not E.db.lui.modules.combat.combatNotification["enableBtn"];
						end,
                    },
                }
            },
            combatShortcut = {
                order = 2,
                type = "group",
                name = L["combatShortcut"],
                get = function(info)
                    return E.db.lui.modules.combat.combatShortcut[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.combat.combatShortcut[info[#info]] = value;
					E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    raidMarkingKey = {
                        order = 9,
                        type = "group",
                        guiInline = true,
                        name = L["raidMarkingKey"],
						get = function(info)
							return E.db.lui.modules.combat.combatShortcut.raidMarkingKey[info[#info]];
						end,
						set = function(info, value)
							E.db.lui.modules.combat.combatShortcut.raidMarkingKey[info[#info]] = value;
							E:StaticPopup_Show("PRIVATE_RL")
						end,
                        args = {
                            raidMarkingButton1 = {
                                order = 1,
                                type = "select",
                                name = L["raidMarkingButton"] .. "1",
                                values = {
                                    ["ctrl"] = "Ctrl",
                                    ["alt"] = "Alt",
                                    ["shift"] = "Shift",
                                    ["none"] = NONE,
                                }
                            },
                            raidMarkingButton2 = {
                                order = 2,
                                type = "select",
                                name = L["raidMarkingButton"] .. "2",
								disabled = function(info)
									return E.db.lui.modules.combat.combatShortcut.raidMarkingKey["raidMarkingButton1"] == "none";
								end,
                                values = {
                                    ["LeftButton"] = L["mouseButton1"],
                                    ["RightButton"] = L["mouseButton2"],
                                }
                            }
                        }
                    },
                    setFocusKey = {
                        order = 10,
                        type = "group",
                        guiInline = true,
                        name = L["setFocusKey"],
						get = function(info)
							return E.db.lui.modules.combat.combatShortcut.setFocusKey[info[#info]];
						end,
						set = function(info, value)
							E.db.lui.modules.combat.combatShortcut.setFocusKey[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            setFocusButton1 = {
                                order = 1,
                                type = "select",
                                name = L["setFocusButton"] .. "1",
                                values = {
                                    ["shift"] = "Shift",
                                    ["ctrl"] = "Ctrl",
                                    ["alt"] = "Alt",
                                    ["none"] = NONE,
                                }
                            },
                            setFocusButton2 = {
                                order = 2,
                                type = "select",
                                name = L["setFocusButton"] .. "2",
                                values = {
                                    ["1"] = L["mouseButton1"],
                                    ["2"] = L["mouseButton2"],
                                    ["3"] = L["mouseButton3"],
                                    ["4"] = L["mouseButton4"],
                                },
								disabled = function(info)
									return E.db.lui.modules.combat.combatShortcut.setFocusKey["setFocusButton1"] == "none";
								end,
                            }
                        }
                    }
                }
            },
            announceSystem = {
                order = 3,
                type = "group",
                name = L["announceSystem"],
				get = function(info)
					return E.db.lui.modules.combat.announceSystem[info[#info]];
				end,
				set = function(info, value)
					E.db.lui.modules.combat.announceSystem[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        width = "full",
                        name = L["enableBtn"],
                    },
                    raidSpells = {
                        order = 2,
                        type = "group",
                        guiInline = true,
                        name = L["raidSpells"],
						get = function(info)
							return E.db.lui.modules.combat.announceSystem.raidSpells[info[#info]]
						end,
						set = function(info, value)
							E.db.lui.modules.combat.announceSystem.raidSpells[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enableBtn = {
                                order = 1,
                                type = "toggle",
                                name = L["enableBtn"],
								disabled = function(info)
									return not E.db.lui.modules.combat.announceSystem["enableBtn"]
								end,
                            },
                        },
                    },
                    resAndThreatSpells = {
                        order = 3,
                        type = "group",
                        guiInline = true,
                        name = L["resAndThreatSpells"],
						disabled = function(info)
							return not E.db.lui.modules.combat.announceSystem["enableBtn"];
						end,
						get = function(info)
							return E.db.lui.modules.combat.announceSystem.resAndThreatSpells[info[#info]];
						end,
						set = function(info, value)
							E.db.lui.modules.combat.announceSystem.resAndThreatSpells[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enableBtn = {
                                order = 0,
                                type = "toggle",
                                width = "full",
                                name = L["enableBtn"],
                            },
                            resAndThreat = {
                                order = 1,
                                type = "toggle",
                                name = L["resAndThreat"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.resAndThreatSpells["enableBtn"];
                                    end
                                end,
                            },
                            resThanks = {
                                order = 2,
                                type = "toggle",
                                name = L["resThanks"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.resAndThreatSpells["enableBtn"];
                                    end
                                end,
                            },
                        },
                    },
                    taunt = {
                        order = 5,
                        type = "group",
                        guiInline = true,
                        name = L["taunt"],
						disabled = function(info)
							return not E.db.lui.modules.combat.announceSystem["enableBtn"];
						end,
						get = function(info)
							return E.db.lui.modules.combat.announceSystem.taunt[info[#info]];
						end,
						set = function(info, value)
							E.db.lui.modules.combat.announceSystem.taunt[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            enableBtn = {
                                order = 0,
                                type = "toggle",
                                width = "full",
                                name = L["enableBtn"],
                            },
                            playerSmart = {
                                order = 1,
                                type = "toggle",
                                name = L["playerSmart"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.taunt["enableBtn"];
                                    end
                                end,
                            },
                            includeMiss = {
                                order = 2,
                                type = "toggle",
                                name = L["includeMiss"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.taunt["enableBtn"];
                                    end
                                end,
                            },
                            otherTankSmart = {
                                order = 3,
                                type = "toggle",
                                name = L["otherTankSmart"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.taunt["enableBtn"];
                                    end
                                end,
                            },
                            includeOtherTank = {
                                order = 4,
                                type = "toggle",
                                name = L["includeOtherTank"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.taunt["enableBtn"];
                                    end
                                end,
                            },
                            petSmart = {
                                order = 5,
                                type = "toggle",
                                name = L["petSmart"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.taunt["enableBtn"];
                                    end
                                end,
                            },
                            includePet = {
                                order = 6,
                                type = "toggle",
                                name = L["includePet"],
                                disabled = function(info)
                                    if not E.db.lui.modules.combat.announceSystem["enableBtn"] then
                                        return not E.db.lui.modules.combat.announceSystem["enableBtn"];
                                    else
                                        return not E.db.lui.modules.combat.announceSystem.taunt["enableBtn"];
                                    end
                                end,
                            }
                        }
                    }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
