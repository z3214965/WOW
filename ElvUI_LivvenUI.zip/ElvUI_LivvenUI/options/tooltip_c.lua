local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
	E.Options.args.lui.args.modules.args.tooltip = {
        order = 12,
		type = "group",
		childGroups = "tab",
        name = L["tooltip"],
        get = function(info)
            return E.db.lui.modules.tooltip[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.tooltip[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
            name = {
				order = 0,
				type = "header",
				name = LUI:cOption(L["tooltip"]),
            },
            atlasLootReverse = {
                order = 1,
                type = "toggle",
                name = L["atlasLootReverse"],
            },
            tooltipIcon = {
				order = 2,
				type = "toggle",
				name = L["tooltipIcon"],
            },
            nameHover = {
                order = 3,
				type = "group",
				name = L["nameHover"],
                guiInline = true,
                get = function(info)
                    return E.db.lui.modules.tooltip.nameHover[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.tooltip.nameHover[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
					enableBtn = {
						order = 1,
						type = "toggle",
						name = L["enableBtn"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                    },
                    fontName = {
                        order = 3,
                        type = "select",
                        dialogControl = "LSM30_Font",
                        name = L["fontName"],
                        values = LUI.fontName,
                    },
                    fontSize = {
                        order = 4,
                        name = L["fontSize"],
                        type = "range",
                        min = 6, max = 48, step = 1,
                    },
                    fontFlag = {
                        order = 5,
                        type = "select",
                        name = L["fontFlag"],
                        values = LUI.fontFlagValues,
                    },
                    spacer2 = {
                        order = 6,
                        type = "description",
                        name = "",
                    },
                    guildName = {
						order = 7,
						type = "toggle",
						name = L["guildName"],
                    },
                    guildRank = {
						order = 8,
						type = "toggle",
						name = L["guildRank"],
                    },
                    spacer3 = {
                        order = 9,
                        type = "description",
                        name = "",
                    },
                    race = {
						order = 10,
						type = "toggle",
						name = L["race"],
                    },
                    realm = {
                        order = 11,
						type = "toggle",
						name = L["realm"],
                    },
                    titles = {
                        order = 12,
						type = "toggle",
						name = L["titles"],
                    }
                }
            },
            raidProg = {
                order = 4,
				type = "group",
				name = L["raidProg"],
                guiInline = true,
                get = function(info)
                    return E.db.lui.modules.tooltip.raidProg[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.tooltip.raidProg[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
				args = {
					enableBtn = {
						order = 1,
						type = "toggle",
						name = L["enableBtn"],
					},
					nameStyle = {
						order = 2,
						name = L["nameStyle"],
						type = "select",
						values = {
							["LONG"] = L["Full"],
							["SHORT"] = L["Short"],
                        },
                        disabled = function(info)
                            return not E.db.lui.modules.tooltip.raidProg["enableBtn"];
                        end,
					},
					difStyle = {
						order = 3,
						name = L["difStyle"],
						type = "select",
						values = {
							["LONG"] = L["Full"],
							["SHORT"] = L["Short"],
                        },
                        disabled = function(info)
                            return not E.db.lui.modules.tooltip.raidProg["enableBtn"];
                        end,
					},
					raids = {
                        order = 4,
                        name = L["raids"],
						type = "group",
                        guiInline = true,
                        disabled = function(info)
                            return not E.db.lui.modules.tooltip.raidProg["enableBtn"];
                        end,
                        get = function(info)
                            return E.db.lui.modules.tooltip.raidProg.raids[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.tooltip.raidProg.raids[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
						args = {
							uldir = { order = -45, type = "toggle", name = LUI:GetMapInfo(1148, "name") },
							daz = { order = -44, type = "toggle", name = LUI:GetMapInfo(1358, "name") },
							sc = { order = -43, type = "toggle", name = LUI:GetMapInfo(1345, "name") },
						},
					},
				},
			},
		}
	}
end
T.tinsert(LUI.Configs, configTable);