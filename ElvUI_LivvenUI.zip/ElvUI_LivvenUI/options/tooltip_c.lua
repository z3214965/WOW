local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local function configTable()
	E.Options.args.lui.args.modules.args.tooltip = {
        order = 12,
		type = "group",
		childGroups = "tab",
        name = L["tooltip"],
        get = function(info)
            return E.db.lui.modules.tooltip[info[#info]]
        end,
        set = function(info, value)
            E.db.lui.modules.tooltip[info[#info]] = value
            E:StaticPopup_Show("PRIVATE_RL")
        end,
        args = {
            name = {
				order = 0,
				type = "header",
				name = LUI:cOption(L["tooltip"]),
            },
            atlasLootReverse = {
                order = 1,
                type = "toggle",
                name = L["atlasLootReverse"],
            },
            tooltipIcon = {
				order = 2,
				type = "toggle",
				name = L["tooltipIcon"],
            },
            flashingCursor = {
                order = 3,
				type = "toggle",
				name = L["flashingCursor"],
            },
            nameHover = {
                order = 4,
				type = "group",
				name = L["nameHover"],
                guiInline = true,
                get = function(info)
                    return E.db.lui.modules.tooltip.nameHover[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.tooltip.nameHover[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
					enable = {
						order = 1,
						type = "toggle",
                        name = L["Enable"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    fontName = {
                        order = 3,
                        type = "select",
                        dialogControl = "LSM30_Font",
                        name = L["fontName"],
                        values = LUI.fontName,
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    fontSize = {
                        order = 4,
                        name = L["fontSize"],
                        type = "range",
                        min = 6, max = 48, step = 1,
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    fontFlag = {
                        order = 5,
                        type = "select",
                        name = L["fontFlag"],
                        values = LUI.fontFlagValues,
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    spacer2 = {
                        order = 6,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    guildName = {
						order = 7,
						type = "toggle",
                        name = L["guildName"],
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    guildRank = {
						order = 8,
						type = "toggle",
                        name = L["guildRank"],
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    spacer3 = {
                        order = 9,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    race = {
						order = 10,
						type = "toggle",
                        name = L["race"],
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    realm = {
                        order = 11,
						type = "toggle",
                        name = L["realm"],
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    },
                    titles = {
                        order = 12,
						type = "toggle",
                        name = L["titles"],
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.nameHover["enable"]
                        end,
                    }
                }
            },
            raidProg = {
                order = 5,
				type = "group",
				name = L["raidProg"],
                guiInline = true,
                get = function(info)
                    return E.db.lui.modules.tooltip.raidProg[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.tooltip.raidProg[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
				args = {
					enable = {
						order = 1,
						type = "toggle",
                        name = L["Enable"],
					},
					nameStyle = {
						order = 2,
						name = L["nameStyle"],
						type = "select",
						values = {
							["LONG"] = L["Full"],
							["SHORT"] = L["Short"],
                        },
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.raidProg["enable"]
                        end,
					},
					difStyle = {
						order = 3,
						name = L["difStyle"],
						type = "select",
						values = {
							["LONG"] = L["Full"],
							["SHORT"] = L["Short"],
                        },
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.raidProg["enable"]
                        end,
					},
					raids = {
                        order = 4,
                        name = L["raids"],
						type = "group",
                        guiInline = true,
                        hidden = function(info)
                            return not E.db.lui.modules.tooltip.raidProg["enable"]
                        end,
                        get = function(info)
                            return E.db.lui.modules.tooltip.raidProg.raids[info[#info]]
                        end,
                        set = function(info, value)
                            E.db.lui.modules.tooltip.raidProg.raids[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
						args = {
							uldir = { order = -45, type = "toggle", name = LUI:GetMapInfo(1148, "name") },
							daz = { order = -44, type = "toggle", name = LUI:GetMapInfo(1358, "name") },
							sc = { order = -43, type = "toggle", name = LUI:GetMapInfo(1345, "name") },
						},
					},
				},
			},
		}
	}
end
T.table_insert(LUI.Configs, configTable)