local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
    E.Options.args.lui.args.modules.args.quest = {
        order = 10,
        type = "group",
        name = L["quest"],
        get = function(info)
            return E.db.lui.modules.quest[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.quest[info[#info]] = value;
        end,
        args = {
            name = {
				order = 0,
				type = "header",
				name = LUI:cOption(L["quest"]),
			},
            questAutomation = {
                order = 1,
                type = "group",
                guiInline = true,
                name = L["questAutomation"],
                get = function(info)
                    return E.db.lui.modules.quest.questAutomation[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.quest.questAutomation[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        width = "full",
                        name = L["enableBtn"],
                    },
                    autoChoices = {
                        order = 2,
                        type = "toggle",
                        name = L["autoChoices"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAutomation["enableBtn"];
                        end,
                    },
                    spacer1 = {
                        order = 3,
                        type = "description",
                        name = "",
                    },
                    frameBtn = {
                        order = 4,
                        type = "toggle",
                        name = L["frameBtn"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAutomation["enableBtn"];
                        end,
                    },
                    frameBtnElvUI = {
                        order = 5,
                        type = "toggle",
                        name = L["frameBtnElvUI"],
                        disabled = function(info)
                            if not E.db.lui.modules.quest.questAutomation["enableBtn"] then
                                return not E.db.lui.modules.quest.questAutomation["enableBtn"];
                            else
                                return not E.db.lui.modules.quest.questAutomation["frameBtn"];
                            end
                        end,
                    },
                }
            },
            questAnnouncment = {
                order = 2,
                type = "group",
                guiInline = true,
                name = L["questAnnouncment"],
                get = function(info)
                    return E.db.lui.modules.quest.questAnnouncment[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.quest.questAnnouncment[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        width = "full",
                        name = L["enableBtn"],
                    },
                    questSolo = {
                        order = 2,
                        type = "toggle",
                        name = L["questSolo"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                        end,
                    },
                    questParty = {
                        order = 3,
                        type = "toggle",
                        name = L["questParty"],
                        
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                        end,
                    },
                    questRaid = {
                        order = 4,
                        type = "toggle",
                        name = L["questRaid"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                        end,
                    },
                    questInstance = {
                        order = 5,
                        type = "toggle",
                        name = L["questInstance"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                        end,
                    },
                    questNoDetail = {
                        order = 6,
                        type = "toggle",
                        name = L["questNoDetail"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                        end,
                    },
                    spacer1 = {
                        order = 7,
                        type = "description",
                        name = "",
                    },
                    frameBtn = {
                        order = 8,
                        type = "toggle",
                        name = L["frameBtn"],
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                        end,
                    },
                    frameBtnElvUI = {
                        order = 9,
                        type = "toggle",
                        name = L["frameBtnElvUI"],
                        disabled = function(info)
                            if not E.db.lui.modules.quest.questAnnouncment["enableBtn"] then
                                return not E.db.lui.modules.quest.questAnnouncment["enableBtn"];
                            else
                                return not E.db.lui.modules.quest.questAnnouncment["frameBtn"];
                            end
                        end,
                    },
                },
            },
            questListEnhanced = {
                order = 3,
                type = "group",
                name = L["questListEnhanced"],
                guiInline = true,
                get = function(info)
                    return E.db.lui.modules.quest.questListEnhanced[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.quest.questListEnhanced[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    -- questTitleColor = {
                    --     order = 2,
                    --     type = "toggle",
                    --     name = L["questTitleColor"],
                    --     disabled = function(info)
                    --         return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                    --     end,
                    -- },
                    -- questList = {
                    --     order = 3,
                    --     type = "group",
                    --     name = L["questList"],
                    --     guiInline = true,
                    --     disabled = function(info)
                    --         return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                    --     end,
                    --     get = function(info)
                    --         return E.db.lui.modules.quest.questListEnhanced.questList[info[#info]];
                    --     end,
                    --     set = function(info, value)
                    --         E.db.lui.modules.quest.questListEnhanced.questList[info[#info]] = value;
                    --         E:StaticPopup_Show("PRIVATE_RL");
                    --     end,
                    --     args = {
                    --         titleFont = {
                    --             order = 1,
                    --             type = "select",
                    --             dialogControl = "LSM30_Font",
                    --             values = LUI.fontName,
                    --             name = L["titleFont"],
                    --         },
                    --         titleFontSize = {
                    --             order = 2,
                    --             type = "range",
                    --             min = 6, max = 22, step = 1,
                    --             name = L["titleFontSize"],
                    --         },
                    --         titleFontFlag = {
                    --             order = 3,
                    --             type = "select",
                    --             values = LUI.fontFlagValues,
                    --             name = L["titleFontFlag"],
					-- 		},
					-- 		spacer1 = {
					-- 			order = 4,
					-- 			type = "description",
					-- 			name = "",
					-- 		},
                    --         infoFont = {
                    --             order = 5,
                    --             type = "select",
                    --             dialogControl = "LSM30_Font",
                    --             values = LUI.fontName,
                    --             name = L["infoFont"],
                    --         },
                    --         infoFontSize = {
                    --             order = 6,
                    --             type = "range",
                    --             min = 6, max = 22, step = 1,
                    --             name = L["infoFontSize"],
                    --         },
                    --         infoFontFlag = {
                    --             order = 7,
                    --             type = "select",
                    --             values = LUI.fontFlagValues,
                    --             name = L["infoFontFlag"],
                    --         },
                    --     },
                    -- },
                    questLevel = {
                        order = 4,
                        type = "group",
                        name = L["questLevel"],
                        guiInline = true,
                        disabled = function(info)
                            return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                        end,
                        get = function(info)
                            return E.db.lui.modules.quest.questListEnhanced.questLevel[info[#info]];
                        end,
                        set = function(info, value)
                            E.db.lui.modules.quest.questListEnhanced.questLevel[info[#info]] = value;
                            E:StaticPopup_Show("PRIVATE_RL");
                        end,
                        args = {
                            titleLevel = {
                                order = 1,
                                type = "toggle",
                                name = L["titleLevel"],
                            },
                            detailLevel = {
                                order = 2,
                                type = "toggle",
                                name = L["detailLevel"],
                            },
                            ignoreHighLevel = {
                                order = 3,
                                type = "toggle",
                                name = L["ignoreHighLevel"],
                            },
                        },
                    },
                    -- questFrame = {
                    --     order = 5,
                    --     type = "group",
                    --     name = L["questFrame"],
                    --     guiInline = true,
                    --     disabled = function(info)
                    --         return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                    --     end,
                    --     get = function(info)
                    --         return E.db.lui.modules.quest.questListEnhanced.questFrame[info[#info]];
                    --     end,
                    --     set = function(info, value)
                    --         E.db.lui.modules.quest.questListEnhanced.questFrame[info[#info]] = value;
                    --         E:StaticPopup_Show("PRIVATE_RL");
                    --     end,
                    --     args = {
                    --         frameTitle = {
                    --             order = 1,
                    --             type = "toggle",
                    --             name = DISABLE .. L["frameTitle"],
                    --             disabled = function(info)
                    --                 return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                    --             end,
                    --         },
                    --         leftSide = {
                    --             order = 2,
                    --             type = "toggle",
                    --             name = L["leftSide"],
                    --             disabled = function(info)
                    --                 if not E.db.lui.modules.quest.questListEnhanced["enableBtn"] then
                    --                     return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                    --                 else
                    --                     return not E.db.lui.modules.quest.questListEnhanced.questFrame["frameTitle"];
                    --                 end
                    --             end,
                    --         },
                    --         leftSideSize = {
                    --             order = 3,
                    --             type = "range",
                    --             min = 10, max = 30, step = 1,
                    --             name = L["leftSideSize"],
                    --             disabled = function(info)
                    --                 if not E.db.lui.modules.quest.questListEnhanced["enableBtn"] then
                    --                     return not E.db.lui.modules.quest.questListEnhanced["enableBtn"];
                    --                 elseif E.db.lui.modules.quest.questListEnhanced.questFrame["frameTitle"] then
                    --                     return not E.db.lui.modules.quest.questListEnhanced.questFrame["frameTitle"];
                    --                 else
                    --                     return not E.db.lui.modules.quest.questListEnhanced.questFrame["leftSide"];
                    --                 end
                    --             end,
                    --         }
                    --     }
                    -- }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
