local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local function configTable()
    E.Options.args.lui.args.modules.args.quest = {
        order = 10,
        type = "group",
        name = L["quest"],
        get = function(info)
            return E.db.lui.modules.quest[info[#info]]
        end,
        set = function(info, value)
            E.db.lui.modules.quest[info[#info]] = value
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["quest"]),
            },
            questAutomation = {
                order = 1,
                type = "group",
                guiInline = true,
                name = L["questAutomation"],
                get = function(info)
                    return E.db.lui.modules.quest.questAutomation[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.quest.questAutomation[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                    },
                    autoChoices = {
                        order = 3,
                        type = "toggle",
                        name = L["autoChoices"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAutomation["enable"]
                        end,
                    },
                    spacer2 = {
                        order = 4,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAutomation["enable"]
                        end,
                    },
                    frameBtn = {
                        order = 5,
                        type = "toggle",
                        name = L["frameBtn"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAutomation["enable"]
                        end,
                    },
                    frameBtnElvUI = {
                        order = 6,
                        type = "toggle",
                        name = L["frameBtnElvUI"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAutomation["enable"] or not E.db.lui.modules.quest.questAutomation["frameBtn"]
                        end,
                    },
                }
            },
            questAnnouncment = {
                order = 2,
                type = "group",
                guiInline = true,
                name = L["questAnnouncment"],
                get = function(info)
                    return E.db.lui.modules.quest.questAnnouncment[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.quest.questAnnouncment[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                    },
                    questSolo = {
                        order = 3,
                        type = "toggle",
                        name = L["questSolo"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    questParty = {
                        order = 4,
                        type = "toggle",
                        name = L["questParty"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    questRaid = {
                        order = 5,
                        type = "toggle",
                        name = L["questRaid"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    questInstance = {
                        order = 6,
                        type = "toggle",
                        name = L["questInstance"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    questNoDetail = {
                        order = 7,
                        type = "toggle",
                        name = L["questNoDetail"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    spacer1 = {
                        order = 8,
                        type = "description",
                        name = "",
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    frameBtn = {
                        order = 9,
                        type = "toggle",
                        name = L["frameBtn"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"]
                        end,
                    },
                    frameBtnElvUI = {
                        order = 10,
                        type = "toggle",
                        name = L["frameBtnElvUI"],
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questAnnouncment["enable"] or not E.db.lui.modules.quest.questAnnouncment["frameBtn"]
                        end,
                    },
                },
            },
            questListEnhanced = {
                order = 3,
                type = "group",
                name = L["questListEnhanced"],
                guiInline = true,
                get = function(info)
                    return E.db.lui.modules.quest.questListEnhanced[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.quest.questListEnhanced[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    questLevel = {
                        order = 4,
                        type = "group",
                        name = L["questLevel"],
                        guiInline = true,
                        hidden = function(info)
                            return not E.db.lui.modules.quest.questListEnhanced["enable"]
                        end,
                        get = function(info)
                            return E.db.lui.modules.quest.questListEnhanced.questLevel[info[#info]]
                        end,
                        set = function(info, value)
                            E.db.lui.modules.quest.questListEnhanced.questLevel[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            titleLevel = {
                                order = 1,
                                type = "toggle",
                                name = L["titleLevel"],
                            },
                            detailLevel = {
                                order = 2,
                                type = "toggle",
                                name = L["detailLevel"],
                            },
                            ignoreHighLevel = {
                                order = 3,
                                type = "toggle",
                                name = L["ignoreHighLevel"],
                            },
                        }
                    }
                }
            }
        }
    }
end
T.table_insert(LUI.Configs, configTable)
