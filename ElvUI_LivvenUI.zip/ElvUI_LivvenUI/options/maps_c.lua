local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
    E.Options.args.lui.args.modules.args.maps = {
        order = 8,
        type = "group",
        childGroups = "tab",
        name = L["maps"],
        get = function(info)
            return E.db.lui.modules.maps[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.maps[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["maps"]),
            },
            whoClickMinimap = {
                order = 1,
                type = "toggle",
                name = L["whoClickMinimap"],
            },
            squareMinimap = {
                order = 2,
                type = "group",
                guiInline = true,
                name = L["squareMinimap"],
                get = function(info) return E.db.lui.modules.maps.squareMinimap[info[#info]] end,
                set = function(info, value)E.db.lui.modules.maps.squareMinimap[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    squareMinimapDC = {
                        order = 20,
                        type = "select",
                        name = L["squareMinimapDC"],
                        values = {
                            ["UP"] = L["UP"],
                            ["DOWN"] = L["DOWN"],
                            ["LEFT"] = L["LEFT"],
                            ["RIGHT"] = L["RIGHT"],
                        },
                        disabled = function(info)
                            return not E.db.lui.modules.maps.squareMinimap["enableBtn"];
                        end,
                    }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
