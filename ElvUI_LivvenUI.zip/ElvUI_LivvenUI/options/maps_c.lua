local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local function configTable()
    E.Options.args.lui.args.modules.args.maps = {
        order = 8,
        type = "group",
        childGroups = "tab",
        name = L["maps"],
        get = function(info)
            return E.db.lui.modules.maps[info[#info]]
        end,
        set = function(info, value)
            E.db.lui.modules.maps[info[#info]] = value
            E:StaticPopup_Show("PRIVATE_RL")
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["maps"]),
            },
            general = {
                order = 1,
                type = "group",
                name = L["general"],
                get = function(info)
                    return E.db.lui.modules.maps.general[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.maps.general[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    whoClickMinimap = {
                        order = 1,
                        type = "toggle",
                        name = L["whoClickMinimap"],
                    },
                }
            },
            minimapIcons = {
                order = 2,
                type = "group",
                name = L["minimapIcons"],
                get = function(info)
                    return E.db.lui.modules.maps.minimapIcons[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.maps.minimapIcons[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    chooseMinimap = {
                        order = 2,
                        type = "select",
                        name = L["chooseMinimap"],
                        values = {
                            ["square"] = L["square"],
                            ["buttons"] = L["buttons"],
                        },
                        hidden = function(info)
                            return not E.db.lui.modules.maps.minimapIcons["enable"]
                        end,
                        set = function(info, value)
                            if value == "square" then
                                E.db.lui.modules.maps.minimapIcons.square["enable"] = true
                                E.db.lui.modules.maps.minimapIcons.buttons["enable"] = false
                            elseif  value == "buttons" then
                                E.db.lui.modules.maps.minimapIcons.buttons["enable"] = true
                                E.db.lui.modules.maps.minimapIcons.square["enable"] = false
                            end
                            E.db.lui.modules.maps.minimapIcons[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                    },
                    square = {
                        order = 3,
                        type = "group",
                        guiInline = true,
                        name = L["square"],
                        hidden = function(info)
                            return not E.db.lui.modules.maps.minimapIcons["enable"] or E.db.lui.modules.maps.minimapIcons["chooseMinimap"] == "buttons"
                        end,
                        get = function(info)
                            return E.db.lui.modules.maps.minimapIcons.square[info[#info]]
                        end,
                        set = function(info, value)
                            E.db.lui.modules.maps.minimapIcons.square[info[#info]] = value
                            E:StaticPopup_Show("PRIVATE_RL")
                        end,
                        args = {
                            squareMinimapDC = {
                                order = 1,
                                type = "select",
                                name = L["squareMinimapDC"],
                                values = {
                                    ["UP"] = L["UP"],
                                    ["DOWN"] = L["DOWN"],
                                    ["LEFT"] = L["LEFT"],
                                    ["RIGHT"] = L["RIGHT"],
                                }
                            }
                        }
                    },
                    buttons = {
                        order = 3,
                        type = "group",
                        guiInline = true,
                        name = L["buttons"],
                        hidden = function(info)
                            return not E.db.lui.modules.maps.minimapIcons["enable"] or E.db.lui.modules.maps.minimapIcons["chooseMinimap"] == "square"
                        end,
                        get = function(info)
                            return E.db.lui.modules.maps.minimapIcons.buttons[info[#info]]
                        end,
                        set = function(info, value)
                            E.db.lui.modules.maps.minimapIcons.buttons[info[#info]] = value
                            E:GetModule("LuiSquareMinimapButtons"):Update()
                        end,
                        args = {
                            barMouseOver = {
                                order = 1,
                                type = "toggle",
                                name = L["barMouseOver"],
                            },
                            backdrop = {
                                order = 2,
                                type = "toggle",
                                name = L["backdrop"],
                                set = function(info, value)
                                    E.db.lui.modules.maps.minimapIcons.buttons[info[#info]] = value
                                    E:StaticPopup_Show("PRIVATE_RL")
                                end,
                            },
                            hideInCombat = {
                                order = 3,
                                type = "toggle",
                                name = L["hideInCombat"],
                            },
                            iconSize = {
                                order = 5,
                                type = "range",
                                name = L["iconSize"],
                                min = 12, max = 48, step = 0.5,
                            },
                            buttonSpacing = {
                                order = 6,
                                type = "range",
                                name = L["buttonSpacing"],
                                min = -1, max = 10, step = 1,
                            },
                            buttonsPerRow = {
                                order = 7,
                                type = "range",
                                name = L["buttonsPerRow"],
                                min = 1, max = 12, step = 1,
                            },
                            visibility = {
                                order = 8,
                                type = "input",
                                name = L["visibility"],
                                set = function(info, value)
                                    E.db.lui.modules.maps.minimapIcons.buttons.visibility = value
                                    E:GetModule("LuiSquareMinimapButtons"):UpdateVisibility()
                                end,
                            },
                            blizzard = {
                                order = 9,
                                type = "group",
                                name = L["blizzard"],
                                guiInline = true,
                                get = function(info)
                                    return E.db.lui.modules.maps.minimapIcons.buttons[info[#info]]
                                end,
                                set = function(info, value)
                                    E.db.lui.modules.maps.minimapIcons.buttons[info[#info]] = value
                                    E:GetModule("LuiSquareMinimapButtons"):Update()
                                    E:GetModule("LuiSquareMinimapButtons"):HandleBlizzardButtons()
                                    E:StaticPopup_Show("PRIVATE_RL")
                                end,
                                args = {
                                    moveTracker = {
                                        order = 1,
                                        type = "toggle",
                                        name = L["moveTracker"],
                                    },
                                    moveQueue = {
                                        order = 2,
                                        type = "toggle",
                                        name = L["moveQueue"],
                                    },
                                    moveMail = {
                                        order = 3,
                                        type = "toggle",
                                        name = L["moveMail"],
                                    },
                                    hideGarrison = {
                                        order = 4,
                                        type = "toggle",
                                        name = L["hideGarrison"],
                                        disabled = function()
                                            return E.db.lui.modules.maps.minimapIcons.buttons["moveGarrison"]
                                        end,
                                    },
                                    moveGarrison = {
                                        order = 5,
                                        type = "toggle",
                                        name = L["moveGarrison"],
                                        disabled = function()
                                            return E.db.lui.modules.maps.minimapIcons.buttons["hideGarrison"]
                                        end,
                                    }
                                }
                            }
                        }
                    }
                }
            },
            enhancedWorldMap = {
                order = 3,
                type = "group",
                name = L["enhancedWorldMap"],
                get = function(info)
                    return E.db.lui.modules.maps.enhancedWorldMap[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.maps.enhancedWorldMap[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    spacer1 = {
                        order = 2,
                        type = "description",
                        name = "",
                    },
                    scale = {
                        order = 3,
                        type = "range",
                        name = L["scale"],
                        min = 0.5, max = 2, step = 0.1,
                        hidden = function()
                            return not E.db.lui.modules.maps.enhancedWorldMap["enable"]
                        end,
                        set = function(info, value)
                            E.db.lui.modules.maps.enhancedWorldMap[info[#info]] = value
                            E:GetModule("LuiEnhancedWorldMap"):SetMapScale()
                        end
                    },
                    useReveal = {
                        order = 4,
                        type = "toggle",
                        name = L["useReveal"],
                        hidden = function()
                            return not E.db.lui.modules.maps.enhancedWorldMap["enable"]
                        end,
                    },
                }
            }
        }
    }
end
T.table_insert(LUI.Configs, configTable)
