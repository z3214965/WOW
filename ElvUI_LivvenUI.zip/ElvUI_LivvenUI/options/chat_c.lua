local LUI, T, E, L, V, P, G = unpack(select(2, ...));

local function configTable()
    E.Options.args.lui.args.modules.args.chat = {
        order = 6,
        type = "group",
        name = L["chat"],
        get = function(info)
            return E.db.lui.modules.chat[info[#info]];
        end,
        set = function(info, value)
            E.db.lui.modules.chat[info[#info]] = value;
            E:StaticPopup_Show("PRIVATE_RL");
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["chat"]),
            },
            chatBar = {
                order = 1,
                type = "group",
                guiInline = true,
                name = L["chatBar"],
                get = function(info)
                    return E.db.lui.modules.chat.chatBar[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatBar[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL");
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    }
                }
            },
            chatTradeLog = {
                order = 2,
                type = "group",
                guiInline = true,
                name = L["chatTradeLog"],
                get = function(info)
                    return E.db.lui.modules.chat.chatTradeLog[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatTradeLog[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    tradeSendChat = {
                        order = 2,
                        type = "toggle",
                        name = L["tradeSendChat"],
                        disabled = function(info)
                            return not E.db.lui.modules.chat.chatTradeLog["enableBtn"];
                        end,
                    }
                }
            },
            chatMSGLoot = {
                order = 3,
                type = "group",
                guiInline = true,
                name = L["chatMSGLoot"],
                get = function(info)
                    return E.db.lui.modules.chat.chatMSGLoot[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatMSGLoot[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    chatMSGLootGS = {
                        order = 2,
                        type = "toggle",
                        name = L["chatMSGLootGS"],
                        disabled = function(info)
                            return not E.db.lui.modules.chat.chatMSGLoot["enableBtn"];
                        end,
                    }
                }
            },
            chatBub = {
                order = 4,
                type = "group",
                guiInline = true,
                name = L["chatBub"],
                get = function(info)
                    return E.db.lui.modules.chat.chatBub[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatBub[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    },
                    chatBubTip = {
                        order = 2,
                        type = "toggle",
                        name = L["chatBubTip"],
                        disabled = function(info)
                            return not E.db.lui.modules.chat.chatBub["enableBtn"];
                        end,
                    }
                }
            },
            chatRepChange = {
                order = 5,
                type = "group",
                guiInline = true,
                name = L["chatRepChange"],
                get = function(info)
                    return E.db.lui.modules.chat.chatRepChange[info[#info]];
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatRepChange[info[#info]] = value;
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enableBtn = {
                        order = 1,
                        type = "toggle",
                        name = L["enableBtn"],
                    }
                }
            }
        }
    }
end
T.tinsert(LUI.Configs, configTable);
