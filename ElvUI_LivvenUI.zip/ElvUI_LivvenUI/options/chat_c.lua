local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local function configTable()
    E.Options.args.lui.args.modules.args.chat = {
        order = 6,
        type = "group",
        name = L["chat"],
        get = function(info)
            return E.db.lui.modules.chat[info[#info]]
        end,
        set = function(info, value)
            E.db.lui.modules.chat[info[#info]] = value
            E:StaticPopup_Show("PRIVATE_RL")
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["chat"]),
            },
            chatBar = {
                order = 1,
                type = "group",
                guiInline = true,
                name = L["chatBar"],
                get = function(info)
                    return E.db.lui.modules.chat.chatBar[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatBar[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    }
                }
            },
            chatTradeLog = {
                order = 2,
                type = "group",
                guiInline = true,
                name = L["chatTradeLog"],
                get = function(info)
                    return E.db.lui.modules.chat.chatTradeLog[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatTradeLog[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    tradeSendChat = {
                        order = 2,
                        type = "toggle",
                        name = L["tradeSendChat"],
                        hidden = function(info)
                            return not E.db.lui.modules.chat.chatTradeLog["enable"]
                        end,
                    }
                }
            },
            chatMSGLoot = {
                order = 3,
                type = "group",
                guiInline = true,
                name = L["chatMSGLoot"],
                get = function(info)
                    return E.db.lui.modules.chat.chatMSGLoot[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatMSGLoot[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    chatMSGLootGS = {
                        order = 2,
                        type = "toggle",
                        name = L["chatMSGLootGS"],
                        hidden = function(info)
                            return not E.db.lui.modules.chat.chatMSGLoot["enable"]
                        end,
                    }
                }
            },
            chatBub = {
                order = 4,
                type = "group",
                guiInline = true,
                name = L["chatBub"],
                get = function(info)
                    return E.db.lui.modules.chat.chatBub[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatBub[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    },
                    chatBubTip = {
                        order = 2,
                        type = "toggle",
                        name = L["chatBubTip"],
                        hidden = function(info)
                            return not E.db.lui.modules.chat.chatBub["enable"]
                        end,
                    }
                }
            },
            chatRepChange = {
                order = 5,
                type = "group",
                guiInline = true,
                name = L["chatRepChange"],
                get = function(info)
                    return E.db.lui.modules.chat.chatRepChange[info[#info]]
                end,
                set = function(info, value)
                    E.db.lui.modules.chat.chatRepChange[info[#info]] = value
                    E:StaticPopup_Show("PRIVATE_RL")
                end,
                args = {
                    enable = {
                        order = 1,
                        type = "toggle",
                        name = L["Enable"],
                    }
                }
            }
        }
    }
end
T.table_insert(LUI.Configs, configTable)
