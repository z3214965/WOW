local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local function configTable()
    E.Options.args.lui.args.modules.args.armory = {
        order = 3,
        type = "group",
        childGroups = "tab",
        name = L["armory"],
        get = function(info)
            return E.db.lui.modules.armory[info[#info]]
        end,
        set = function(info, value)
            E.db.lui.modules.armory[info[#info]] = value
            E:StaticPopup_Show("PRIVATE_RL")
        end,
        args = {
            name = {
                order = 0,
                type = "header",
                name = LUI:cOption(L["armory"]),
            },
        }
    }
end
T.table_insert(LUI.Configs, configTable)
