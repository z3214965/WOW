local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local _G = _G

local DecorAddons = {
	{"BigWigs", L["BigWigs"], "bw"},
	{"WeakAuras", L["WeakAuras"], "wa"},
	{"BugSack", L["BugSack"], "bs"},
	{"Postal", L["Postal"], "po"},
	{"DBM-Core", L["Deadly Boss Mods"], "dbm"},
	{"Clique", L["Clique"], "cl"},
}

local SupportedProfiles = {
	{"AddOnSkins", "AddOnSkins"},
	{"BigWigs", "BigWigs"},
	{"Details", "Details"},
	{"Masque", "Masque"},
	{"Skada", "Skada"},
	{"DBM-Core", "Deadly Boss Mods"},
}

local profileString = T.string_format("|cfffff400%s |r", L["LivvenUI successfully created and applied profile(s) for:"])

local function configTable()
	E.Options.args.lui.args.skins = {
		order = 11,
		type = "group",
		name = L["skins"],
		childGroups = "tab",
		get = function(info) return E.db.lui.skins[ info[#info] ] end,
		set = function(info, value) E.db.lui.skins[ info[#info] ] = value
			E:StaticPopup_Show("PRIVATE_RL")
		end,
		args = {
			name = {
				order = 0,
				type = "header",
				name = LUI:cOption(L["skins"]),
			},
			enable = {
				order = 1,
				type = "toggle",
				name = L["Enable"],
			},
			skins = {
				order = 1,
				type = "group",
				name = L["General"],
				disabled = function()
					return not E.db.lui.skins["enable"]
				end,
				hidden = function()
					return not E.db.lui.skins["enable"]
				end,
				get = function(info) return E.db.lui.skins[ info[#info] ] end,
				set = function(info, value) E.db.lui.skins[ info[#info] ] = value
					E:StaticPopup_Show("PRIVATE_RL")
				end,
				args = {
					style = {
						order = 2,
						type = "select",
						name = L["style"],
						values = {
							["style1"] = L["style1"],
							["style2"] = L["style2"],
							["NONE"] = L["NONE"],
						},
					},
					shadowOverlay = {
						order = 3,
						type = "group",
						guiInline = true,
						name = L["shadowOverlay"],
						get = function(info) return E.db.lui.skins.shadowOverlay[ info[#info] ] end,
						set = function(info, value) E.db.lui.skins.shadowOverlay[ info[#info] ] = value
							E:StaticPopup_Show("PRIVATE_RL")
						end,
						args = {
							enable = {
								order = 1,
								type = "toggle",
								name = L["Enable"],
							},
							shadowAlpha = {
								order = 2,
								name = L["shadowAlpha"],
								type = "range",
								hidden = function()
									return not E.db.lui.skins.shadowOverlay["enable"]
								end,
								min = 0, max = 100, step = 10,
							},
						},
					},
				},
			},
			merchant = {
				order = 2,
				type = "group",
				name = L["merchant"],
				disabled = function()
					return not E.db.lui.skins["enable"]
				end,
				hidden = function()
					return not E.db.lui.skins["enable"]
				end,
				get = function(info)
					return E.private.lui.Pskins.merchant[ info[#info] ]
				end,
				set = function(info, value) E.private.lui.Pskins.merchant[ info[#info] ] = value
					E:StaticPopup_Show("PRIVATE_RL")
				end,
				args = {
					enable = {
						order = 1,
						type = "toggle",
						name = L["Enable"],
					},
					subpages = {
						order = 2,
						type = "range",
						name = L["subpages"],
						min = 2, max = 5, step = 1,
						hidden = function() return
							not E.private.lui.Pskins.merchant["enable"]
						end,
					},
				},
			},
		},
	}

	E.Options.args.lui.args.skins.args.addonskins = {
		order = 3,
		type = "group",
		name =L["AddOnSkins"],
		disabled = function()
			return not E.db.lui.skins["enable"]
		end,
		hidden = function()
			return not E.db.lui.skins["enable"]
		end,
		get = function(info) return E.private.lui.Pskins.addonSkins[ info[#info] ] end,
		set = function(info, value) E.private.lui.Pskins.addonSkins[ info[#info] ] = value E:StaticPopup_Show("PRIVATE_RL") end,
		args = {},
	}

	local addorder = 3
	for i, v in T.ipairs(DecorAddons) do
		local addonName, addonString, addonOption = unpack( v )
		E.Options.args.lui.args.skins.args.addonskins.args[addonOption] = {
			order = addorder + 1,
			type = "toggle",
			name = addonString,
			disabled = function() return not T.IsAddOnLoaded(addonName) end,
		}
	end

	E.Options.args.lui.args.skins.args.blizzard = {
		order = 4,
		type = "group",
		name = L["Blizzard"],
		disabled = function()
			return not E.db.lui.skins["enable"]
		end,
		hidden = function()
			return not E.db.lui.skins["enable"]
		end,
		get = function(info) return E.private.lui.Pskins.blizzard[ info[#info] ] end,
		set = function(info, value) E.private.lui.Pskins.blizzard[ info[#info] ] = value E:StaticPopup_Show("PRIVATE_RL") end,
		args = {
			enable = {
				order = 1,
				type = "toggle",
				name = L["Enable"],
			},
			space1 = {
				order = 2,
				type = "description",
				name = "",
				disabled = function() return
					not E.private.lui.Pskins.blizzard["enable"]
				end,
			},
			encounterjournal = {
				type = "toggle",
				name = ENCOUNTER_JOURNAL,
				disabled = function () return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.encounterjournal or not E.private.lui.Pskins.blizzard["enable"] end
			},
			spellbook = {
				type = "toggle",
				name = SPELLBOOK,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.spellbook or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			character = {
				type = "toggle",
				name = L["Character Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.character or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			gossip = {
				type = "toggle",
				name = L["Gossip Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.gossip or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			quest = {
				type = "toggle",
				name = L["Quest Frames"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.quest or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			questChoice = {
				type = "toggle",
				name = L["Quest Choice"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.questChoice or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			garrison = {
				type = "toggle",
				name = GARRISON_LOCATION_TOOLTIP,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.garrison or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			orderhall = {
				type = "toggle",
				name = L["Orderhall"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.orderhall or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			talent = {
				type = "toggle",
				name = TALENTS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.talent or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			auctionhouse = {
				type = "toggle",
				name = AUCTIONS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.auctionhouse or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			friends = {
				type = "toggle",
				name = FRIENDS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.friends or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			contribution = {
				type = "toggle",
				name = L["Contribution"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.Contribution or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			artifact = {
				type = "toggle",
				name = ITEM_QUALITY6_DESC,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.artifact or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			collections = {
				type = "toggle",
				name = COLLECTIONS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.collections or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			calendar = {
				type = "toggle",
				name = L["Calendar Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.calendar or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			merchant = {
				type = "toggle",
				name = L["Merchant Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.merchant or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			worldmap = {
				type = "toggle",
				name = WORLD_MAP,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.worldmap or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			pvp = {
				type = "toggle",
				name = L["PvP Frames"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.pvp or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			achievement = {
				type = "toggle",
				name = ACHIEVEMENTS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.achievement or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			tradeskill = {
				type = "toggle",
				name = TRADESKILLS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.tradeskill or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			lfg = {
				type = "toggle",
				name = LFG_TITLE,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.lfg or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			lfguild = {
				type = "toggle",
				name = L["LF Guild Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.lfguild or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			talkinghead = {
				type = "toggle",
				name = L["TalkingHead"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.talkinghead or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			guild = {
				type = "toggle",
				name = GUILD,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.guild or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			objectiveTracker = {
				type = "toggle",
				name = OBJECTIVES_TRACKER_LABEL,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.objectiveTracker or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			addonManager = {
				type = "toggle",
				name = L["AddOn Manager"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.addonManager or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			mail = {
				type = "toggle",
				name =  L["Mail Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.mail or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			raid = {
				type = "toggle",
				name = L["Raid Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.raid or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			dressingroom = {
				type = "toggle",
				name = DRESSUP_FRAME,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.dressingroom or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			timemanager = {
				type = "toggle",
				name = TIMEMANAGER_TITLE,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.timemanager or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			blackmarket = {
				type = "toggle",
				name = BLACK_MARKET_AUCTION_HOUSE,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.bmah or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			guildcontrol = {
				type = "toggle",
				name = L["Guild Control Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.guildcontrol or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			macro = {
				type = "toggle",
				name = MACROS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.macro or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			binding = {
				type = "toggle",
				name = KEY_BINDING,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.binding or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			gbank = {
				type = "toggle",
				name = GUILD_BANK,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.gbank or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			taxi = {
				type = "toggle",
				name = FLIGHT_MAP,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.taxi or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			help = {
				type = "toggle",
				name = L["Help Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.help or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			loot = {
				type = "toggle",
				name = L["Loot Frames"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.loot or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			warboard = {
				type = "toggle",
				name = L["Warboard"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.Warboard or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			deathRecap = {
				type = "toggle",
				name = DEATH_RECAP_TITLE,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.deathRecap or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			questPOI = {
				type = "toggle",
				name = L["QuestPOI"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.questChoice or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			channels = {
				type = "toggle",
				name = CHANNELS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.Channels or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			communities = {
				type = "toggle",
				name = COMMUNITIES,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.Communities or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			challenges = {
				type = "toggle",
				name = CHALLENGES,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			AzeriteUI = {
				type = "toggle",
				name = L["AzeriteUI"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.AzeriteUI or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			AzeriteRespec = {
				type = "toggle",
				name = AZERITE_RESPEC_TITLE,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.AzeriteRespec or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			IslandQueue = {
				type = "toggle",
				name = ISLANDS_HEADER,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.IslandQueue or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			IslandsPartyPose = {
				type = "toggle",
				name = L["Island Party Pose"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.IslandsPartyPose or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			minimap = {
				type = "toggle",
				name = L["Minimap"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			Scrapping = {
				type = "toggle",
				name = SCRAP_BUTTON,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.Scrapping or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			trainer = {
				type = "toggle",
				name = L["Trainer Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.trainer or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			debug = {
				type = "toggle",
				name = L["Debug Tools"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.debug or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			inspect = {
				type = "toggle",
				name = INSPECT,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.inspect or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			socket = {
				type = "toggle",
				name = L["Socket Frame"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.socket or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			itemUpgrade = {
				type = "toggle",
				name = L["Item Upgrade"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.itemUpgrade or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			trade = {
				type = "toggle",
				name = TRADESKILLS,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.trade or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			voidstorage = {
				type = "toggle",
				name = VOID_STORAGE,
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.voidstorage or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			AlliedRaces = {
				type = "toggle",
				name = L["Allied Races"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.AlliedRaces or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			GMChat = {
				type = "toggle",
				name = L["GM Chat"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.skins.blizzard.GMChat or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			raidInfo = {
				type = "toggle",
				name = L["raidInfo"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.lui.Pskins.blizzard["enable"] end,
			},
			raidUtility = {
				type = "toggle",
				name = L["raidUtility"],
				disabled = function() return not E.private.skins.blizzard.enable or not E.private.lui.Pskins.blizzard["enable"] end,
			},
		},
	}
end

T.table_insert(LUI.Configs, configTable)
