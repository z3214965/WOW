--来源：LivvenUI
--作者：L
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LME = LUI:NewModule("LUIMedia", "AceHook-3.0");

--Role icons
LUI.rolePaths = {
	["ElvUI"] = {
		TANK = [[Interface\AddOns\ElvUI\media\textures\tank]],
		HEALER = [[Interface\AddOns\ElvUI\media\textures\healer]],
		DAMAGER = [[Interface\AddOns\ElvUI\media\textures\dps]]
    },
}

local _G = _G;
local FadingFrame_Show = FadingFrame_Show;

LME.Zones = L["LUI_MEDIA_ZONES"];
LME.PvPInfo = L["LUI_MEDIA_PVP"];
LME.Subzones = L["LUI_MEDIA_SUBZONES"];
LME.PVPArena = L["LUI_MEDIA_PVPARENA"];

local Colors = {
    [1] = {0.41, 0.8, 0.94},
    [2] = {1.0, 0.1, 0.1},
    [3] = {0.1, 1.0, 0.1},
    [4] = {1.0, 0.7, 0},
    [5] = {1.0, 0.9294, 0.7607},
};

local ClassColor = RAID_CLASS_COLORS[E.myclass];

local function ZoneTextPos()
    if (_G["PVPInfoTextString"]:GetText() == "") then
        _G["SubZoneTextString"]:SetPoint("TOP", "ZoneTextString", "BOTTOM", 0, 0);
    else
        _G["SubZoneTextString"]:SetPoint("TOP", "PVPInfoTextString", "BOTTOM", 0, 0);
    end
end

local function MakeFont(obj, font, size, style, r, g, b, sr, sg, sb, sox, soy)
    obj:SetFont(font, size, style);
    if sr and sg and sb then obj:SetShadowColor(sr, sg, sb); end
    if sox and soy then obj:SetShadowOffset(sox, soy); end
    if r and g and b then obj:SetTextColor(r, g, b);
    elseif r then obj:SetAlpha(r); end
end

local questTrackerColor;

local function SetBlockHeaderEnterColor(_, block)
    questTrackerColor = E.db.lui.media.miscTexts.questTracker.fontcolor;
    block.HeaderText:SetTextColor(questTrackerColor.r, questTrackerColor.g, questTrackerColor.b);
end
local function SetBlockHeaderColor(_, block)
    questTrackerColor = E.db.lui.media.miscTexts.questTracker.fontcolor;
    block.HeaderText:SetTextColor(questTrackerColor.r * 0.748, questTrackerColor.g * 0.748, questTrackerColor.b * 0.748);
end

function LME:SetBlizzFonts()
    if E.private.general.replaceBlizzFonts then
        local zonedb = E.db.lui.media.zoneTexts;
        local miscdb = E.db.lui.media.miscTexts;

        if E.db.lui.media.zoneTexts["enableBtn"] then
            _G["ZoneTextString"]:SetFont(E.LSM:Fetch("font", zonedb.zoneText.fontName), zonedb.zoneText.fontSize, zonedb.zoneText.fontFlag)
            _G["PVPInfoTextString"]:SetFont(E.LSM:Fetch("font", zonedb.pvpstatusText.fontName), zonedb.pvpstatusText.fontSize, zonedb.pvpstatusText.fontFlag)
            _G["PVPArenaTextString"]:SetFont(E.LSM:Fetch("font", zonedb.pvpstatusText.fontName), zonedb.pvpstatusText.fontSize, zonedb.pvpstatusText.fontFlag)
            _G["SubZoneTextString"]:SetFont(E.LSM:Fetch("font", zonedb.subzoneText.fontName), zonedb.subzoneText.fontSize, zonedb.subzoneText.fontFlag)
        end
        
        if E.db.lui.media.miscTexts.mailText["enableBtn"] then
            _G["SendMailBodyEditBox"]:SetFont(E.LSM:Fetch("font", miscdb.mailText.fontName), miscdb.mailText.fontSize, miscdb.mailText.fontFlag);
            _G["OpenMailBodyText"]:SetFont(E.LSM:Fetch("font", miscdb.mailText.fontName), miscdb.mailText.fontSize, miscdb.mailText.fontFlag);
        end
        
        if E.db.lui.media.miscTexts.questGossip["enableBtn"] then
            _G["QuestFont"]:SetFont(E.LSM:Fetch("font", miscdb.questGossip.fontName), miscdb.questGossip.fontSize, miscdb.questGossip.fontFlag);
        end
        
        if E.db.lui.media.miscTexts.questFontSuperHuge["enableBtn"] then
            _G["QuestFont_Super_Huge"]:SetFont(E.LSM:Fetch("font", miscdb.questFontSuperHuge.fontName), miscdb.questFontSuperHuge.fontSize, miscdb.questFontSuperHuge.fontFlag);
            _G["QuestFont_Enormous"]:SetFont(E.LSM:Fetch("font", miscdb.questFontSuperHuge.fontName), miscdb.questFontSuperHuge.fontSize, miscdb.questFontSuperHuge.fontFlag);
		end
		
        if E.db.lui.media.miscTexts.editboxText["enableBtn"] then
			_G["NumberFont_Shadow_Med"]:SetFont(E.LSM:Fetch("font", miscdb.editboxText.fontName), miscdb.editboxText.fontSize, miscdb.editboxText.fontFlag);
		end
        
        if E.db.lui.media.miscTexts.questHeader["enableBtn"] then
            if not _G["ObjectiveTrackerFrame"].LUIHeaderHookedFonts then
                T.hooksecurefunc("ObjectiveTracker_Update", function(reason, id)
                    _G["ObjectiveTrackerFrame"].HeaderMenu.Title:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
                    _G["ObjectiveTrackerBlocksFrame"].QuestHeader.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
                    _G["ObjectiveTrackerBlocksFrame"].AchievementHeader.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
                    _G["ObjectiveTrackerBlocksFrame"].ScenarioHeader.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
                    _G["WORLD_QUEST_TRACKER_MODULE"].Header.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
                    _G["BONUS_OBJECTIVE_TRACKER_MODULE"].Header.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
                end)
                _G["ObjectiveTrackerFrame"].LUIHeaderHookedFonts = true;
            end
            _G["ObjectiveTrackerFrame"].HeaderMenu.Title:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
            _G["ObjectiveTrackerBlocksFrame"].QuestHeader.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
            _G["ObjectiveTrackerBlocksFrame"].AchievementHeader.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
            _G["ObjectiveTrackerBlocksFrame"].ScenarioHeader.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
            _G["BONUS_OBJECTIVE_TRACKER_MODULE"].Header.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
            _G["WORLD_QUEST_TRACKER_MODULE"].Header.Text:SetFont(E.LSM:Fetch("font", miscdb.questHeader.fontName), miscdb.questHeader.fontSize, miscdb.questHeader.fontFlag);
            
            local questHeaderColor = E.db.lui.media.miscTexts.questHeader.fontcolor;
            _G["ObjectiveTrackerFrame"].HeaderMenu.Title:SetTextColor(questHeaderColor.r, questHeaderColor.g, questHeaderColor.b);
            _G["ObjectiveTrackerBlocksFrame"].QuestHeader.Text:SetTextColor(questHeaderColor.r, questHeaderColor.g, questHeaderColor.b);
            _G["ObjectiveTrackerBlocksFrame"].AchievementHeader.Text:SetTextColor(questHeaderColor.r, questHeaderColor.g, questHeaderColor.b);
            _G["ObjectiveTrackerBlocksFrame"].ScenarioHeader.Text:SetTextColor(questHeaderColor.r, questHeaderColor.g, questHeaderColor.b);
            _G["BONUS_OBJECTIVE_TRACKER_MODULE"].Header.Text:SetTextColor(questHeaderColor.r, questHeaderColor.g, questHeaderColor.b);
            _G["WORLD_QUEST_TRACKER_MODULE"].Header.Text:SetTextColor(questHeaderColor.r, questHeaderColor.g, questHeaderColor.b);
        end
        
        if E.db.lui.media.miscTexts.questTracker["enableBtn"] then
            MakeFont(_G["ObjectiveFont"], E.LSM:Fetch("font", miscdb.questTracker.fontName), miscdb.questTracker.fontSize, miscdb.questTracker.fontFlag);
        end
    end
end

function LME:TextWidth()
    local db = E.db.lui.media.zoneTexts
    _G["ZoneTextString"]:SetWidth(db.zoneText.width)
    _G["PVPInfoTextString"]:SetWidth(db.pvpstatusText.width)
    _G["PVPArenaTextString"]:SetWidth(db.pvpstatusText.width)
    _G["SubZoneTextString"]:SetWidth(db.subzoneText.width)
end

function LME:TextShow()
    local z, i, a, s, c = T.random(1, #LME.Zones), T.random(1, #LME.PvPInfo), T.random(1, #LME.PVPArena), T.random(1, #LME.Subzones), T.random(1, #Colors)
    local red, green, blue = T.unpack(Colors[c])
    
    _G["ZoneTextString"]:SetText(LME.Zones[z])
    _G["PVPInfoTextString"]:SetText(LME.PvPInfo[i])
    _G["PVPArenaTextString"]:SetText(LME.PVPArena[a])
    _G["SubZoneTextString"]:SetText(LME.Subzones[s])
    
    ZoneTextPos();
    
    _G["ZoneTextString"]:SetTextColor(red, green, blue)
    _G["PVPInfoTextString"]:SetTextColor(red, green, blue)
    _G["PVPArenaTextString"]:SetTextColor(red, green, blue)
    _G["SubZoneTextString"]:SetTextColor(red, green, blue)
    
    FadingFrame_Show(_G["ZoneTextFrame"])
    FadingFrame_Show(_G["SubZoneTextFrame"])
end 

function LME:Initialize()
    if E.db.lui.media.zoneTexts["enableBtn"] then
        LME:TextWidth();
        T.hooksecurefunc("SetZoneText", ZoneTextPos);
    end
    
    if E.db.lui.media.miscTexts.questTracker["enableBtn"] then
        T.hooksecurefunc(QUEST_TRACKER_MODULE, "SetBlockHeader", SetBlockHeaderColor);
        T.hooksecurefunc(QUEST_TRACKER_MODULE, "OnBlockHeaderEnter", SetBlockHeaderEnterColor);
        T.hooksecurefunc(QUEST_TRACKER_MODULE, "OnBlockHeaderLeave", SetBlockHeaderColor);
        T.hooksecurefunc(ACHIEVEMENT_TRACKER_MODULE, "SetBlockHeader", SetBlockHeaderColor)
        T.hooksecurefunc(ACHIEVEMENT_TRACKER_MODULE, "OnBlockHeaderEnter", SetBlockHeaderEnterColor);
        T.hooksecurefunc(ACHIEVEMENT_TRACKER_MODULE, "OnBlockHeaderLeave", SetBlockHeaderColor);
    end

    T.hooksecurefunc(E, "UpdateBlizzardFonts", LME.SetBlizzFonts);
    LME.SetBlizzFonts();
end

local function InitializeCallback()
    LME:Initialize();
end

LUI:RegisterModule(LME:GetName(), InitializeCallback);
