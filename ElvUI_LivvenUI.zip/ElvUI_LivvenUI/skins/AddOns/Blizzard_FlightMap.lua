local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule("Skins")

local _G = _G

local function styleFlightMap()
	if E.private.skins.blizzard.enable ~= true or E.private.skins.blizzard.taxi ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.taxi ~= true then return end

	_G.FlightMapFrame:Styling()
end

S:AddCallbackForAddon("Blizzard_FlightMap", "LuiFlightMap", styleFlightMap)
