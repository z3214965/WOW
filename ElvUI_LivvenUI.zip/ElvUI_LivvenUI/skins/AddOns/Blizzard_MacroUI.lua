local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule("Skins")

local _G = _G

local function styleMacro()
	if E.private.skins.blizzard.enable ~= true or E.private.skins.blizzard.macro ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.macro ~= true then return end

	_G.MacroFrame:Styling()
	_G.MacroPopupFrame:Styling()
end

S:AddCallbackForAddon("Blizzard_MacroUI", "LuiMacro", styleMacro)
