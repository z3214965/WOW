local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule("Skins")

local _G = _G

local function styleGuildRecruitment()
	if E.private.skins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.skins.blizzard.guild ~= true then return end

	local rolesFrame = _G.CommunitiesGuildRecruitmentFrameRecruitment.RolesFrame
	LUI:ReskinRole(rolesFrame.TankButton, "TANK")
	LUI:ReskinRole(rolesFrame.HealerButton, "HEALER")
	LUI:ReskinRole(rolesFrame.DamagerButton, "DPS")
end

S:AddCallbackForAddon("Blizzard_GuildRecruitmentUI", "LuiGuildRecruitment", styleGuildRecruitment)
