local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule('Skins')

local _G = _G

local r, g, b = unpack(E["media"].rgbvaluecolor)

local function styleUIWidgets()
	if E.private.skins.blizzard.enable ~= true or E.private.skins.blizzard.Warboard ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.warboard ~= true then return end

	-- Used for Currency Fonts (Warfront only?)
	hooksecurefunc(UIWidgetBaseCurrencyTemplateMixin, "SetFontColor", function(self)
		self.Text:SetTextColor(1, 1, 1)
		self.LeadingText:SetTextColor(1, 1, 1)
	end)
end

S:AddCallbackForAddon("Blizzard_UIWidgets", "LuiUIWidgets", styleUIWidgets)
