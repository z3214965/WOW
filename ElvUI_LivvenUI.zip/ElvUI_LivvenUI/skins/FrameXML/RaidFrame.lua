local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule("Skins")

local _G = _G

local function styleRaidInfoFrame()
	if E.private.skins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.raidInfo ~= true then return end

	local RaidInfoFrame = _G.RaidInfoFrame
	if RaidInfoFrame.backdrop then
		RaidInfoFrame.backdrop:Styling()
	end
end

S:AddCallback("LuiRaidInfoFrame", styleRaidInfoFrame)
