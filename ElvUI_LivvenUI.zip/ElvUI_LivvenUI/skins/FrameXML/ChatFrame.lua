local LUI, T, E, L, V, P, G = unpack(select(2, ...))
local LS = E:GetModule("LuiSkins")
local S = E:GetModule("Skins")

-- Cache global variables
-- Lua functions
local _G = _G
-- WoW API
local hooksecurefunc = hooksecurefunc
-- Global variables that we don't cache, list them here for the mikk's Find Globals script
-- GLOBALS:

local function styleChatFrame()
	if E.private.chat.enable ~= true then return end

	local VoiceChatPromptActivateChannel = _G["VoiceChatPromptActivateChannel"]
	LS:CreateBD(VoiceChatPromptActivateChannel)
	VoiceChatPromptActivateChannel:Styling()
	LS:CreateBD(_G.VoiceChatChannelActivatedNotification)
	_G.VoiceChatChannelActivatedNotification:Styling()

	if E.db.chat.pinVoiceButtons and not E.db.chat.hideVoiceButtons then
		if _G.ChatFrameChannelButton then
			_G.ChatFrameChannelButton:StripTextures()
			_G.ChatFrameChannelButton.glow:Hide()
		end

		if _G.ChatFrameToggleVoiceDeafenButton then
			_G.ChatFrameToggleVoiceDeafenButton:StripTextures()
			_G.ChatFrameToggleVoiceDeafenButton.glow:Hide()
		end

		if _G.ChatFrameToggleVoiceMuteButton then
			_G.ChatFrameToggleVoiceMuteButton:StripTextures()
			_G.ChatFrameToggleVoiceMuteButton.glow:Hide()
		end
	else
		if _G.ChatButtonHolder then
			_G.ChatButtonHolder:Styling()
		end
	end
end

S:AddCallback("LuiChat", styleChatFrame)
