local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local LS = E:GetModule("LuiSkins")
local S = E:GetModule("Skins")

local _G = _G
local hooksecurefunc = hooksecurefunc

local function styleChatFrame()
	if E.private.chat.enable ~= true or E.private.lui.Pskins.blizzard.enable ~= true then return end

	local VoiceChatPromptActivateChannel = _G["VoiceChatPromptActivateChannel"]
	LS:CreateBD(VoiceChatPromptActivateChannel)
	VoiceChatPromptActivateChannel:Styling()
	LS:CreateBD(_G.VoiceChatChannelActivatedNotification)
	_G.VoiceChatChannelActivatedNotification:Styling()

	if E.db.chat.pinVoiceButtons and not E.db.chat.hideVoiceButtons then
		if _G.ChatFrameChannelButton then
			_G.ChatFrameChannelButton:StripTextures()
			if _G.ChatFrameChannelButton.glow then
				_G.ChatFrameChannelButton.glow:Hide()
			end
		end

		if _G.ChatFrameToggleVoiceDeafenButton then
			_G.ChatFrameToggleVoiceDeafenButton:StripTextures()
			if _G.ChatFrameToggleVoiceDeafenButton.glow then
				_G.ChatFrameToggleVoiceDeafenButton.glow:Hide()
			end
		end

		if _G.ChatFrameToggleVoiceMuteButton then
			_G.ChatFrameToggleVoiceMuteButton:StripTextures()
			if _G.ChatFrameToggleVoiceMuteButton.glow then
				_G.ChatFrameToggleVoiceMuteButton.glow:Hide()
			end
		end
	else
		if _G.ChatButtonHolder then
			_G.ChatButtonHolder:Styling()
		end
	end
end

S:AddCallback("LuiChat", styleChatFrame)
