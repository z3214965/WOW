local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local LS = E:GetModule("LuiSkins")
local S = E:GetModule("Skins")

local _G = _G
local unpack = unpack
local hooksecurefunc = hooksecurefunc

local r, g, b = unpack(E["media"].rgbvaluecolor)

local function styleUIDropDownMenu()
	if E.private.skins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.enable ~= true then return end

end

S:AddCallback("LuiUIDropDownMenu", styleUIDropDownMenu)
