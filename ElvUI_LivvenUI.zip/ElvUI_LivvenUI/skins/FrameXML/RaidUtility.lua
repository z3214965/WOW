local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule("Skins")

local _G = _G

local function styleRaidUtilityFrame()
	if E.private.skins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.raidUtility ~= true then return end
	local RaidUtilityPanel = _G.RaidUtilityPanel
	local RaidUtility_ShowButton = _G.RaidUtility_ShowButton
	local RaidUtility_CloseButton = _G.RaidUtility_CloseButton
	if RaidUtilityPanel then RaidUtilityPanel:Styling() end
	if RaidUtility_ShowButton then RaidUtility_ShowButton:Styling() end
	if RaidUtility_CloseButton then RaidUtility_CloseButton:Styling() end
end

S:AddCallback("LuiRaidUtilityFrame", styleRaidUtilityFrame)
