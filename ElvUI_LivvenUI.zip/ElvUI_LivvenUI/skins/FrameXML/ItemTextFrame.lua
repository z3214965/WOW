local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local LS = E:GetModule("LuiSkins")
local S = E:GetModule("Skins")

local _G = _G
local select = select

local function styleMerchant()
	if E.private.skins.blizzard.enable ~= true or E.private.skins.blizzard.gossip ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.gossip ~= true then return end

	local ItemTextFrame = _G.ItemTextFrame
	select(18, ItemTextFrame:GetRegions()):Hide()

	ItemTextFrame:Styling()
end

S:AddCallback("LuiItemText", styleMerchant)
