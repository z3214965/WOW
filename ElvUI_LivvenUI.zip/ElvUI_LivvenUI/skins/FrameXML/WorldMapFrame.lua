local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local LS = E:GetModule("LuiSkins")
local S = E:GetModule("Skins")

local _G = _G
local select = select
local CreateFrame = CreateFrame
local GetNumQuestLogEntries = GetNumQuestLogEntries

local r, g, b = unpack(E["media"].rgbvaluecolor)

local function styleWorldmap()
	if E.private.skins.blizzard.enable ~= true or E.private.skins.blizzard.worldmap ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.worldmap ~= true then return end

	_G.WorldMapFrame:Styling()

	local frame = CreateFrame("Frame", nil, _G.QuestScrollFrame)
	_G.QuestScrollFrame.QuestCountFrame = frame

	frame:RegisterEvent("QUEST_LOG_UPDATE")
	frame:Size(240, 20)
	frame:Point("TOP", -1, 22)
	LS:CreateBD(frame, .25)

	local text = LUI:CreateText(frame, "OVERLAY", 12, "OUTLINE")
	text:SetTextColor(r, g, b)
	text:SetAllPoints()

	frame.text = text
	local str = "%d / 25 Quests"
	frame.text:SetFormattedText(str, select(2, GetNumQuestLogEntries()))

	frame:SetScript("OnEvent", function(self, event)
		local _, quests = GetNumQuestLogEntries()
		frame.text:SetFormattedText(str, quests)
	end)

	if _G.QuestScrollFrame.DetailFrame.backdrop then
		_G.QuestScrollFrame.DetailFrame.backdrop:Hide()
	end
end

S:AddCallback("LuiSkinWorldMap", styleWorldmap)
