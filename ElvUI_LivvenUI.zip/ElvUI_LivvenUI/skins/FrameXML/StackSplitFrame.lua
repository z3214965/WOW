local LUI, T, E, L, V, P, G = unpack(select(2, ...))
local LS = E:GetModule("LuiSkins")
local S = E:GetModule("Skins")

local _G = _G

local function styleStyleStackSplitFrame()
	if E.private.skins.blizzard.enable ~= true then return end

	local StackSplitFrame = _G["StackSplitFrame"]
	if StackSplitFrame.backdrop then
		StackSplitFrame.backdrop:Styling()
	end
end

S:AddCallback("LuiStackSplitFrame", styleStyleStackSplitFrame)
