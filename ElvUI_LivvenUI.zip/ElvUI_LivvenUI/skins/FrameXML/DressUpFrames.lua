local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("db", "skins", "enable") or LUI:CheckDB("private", "Pskins", "blizzard", "enable") then return end
local S = E:GetModule("Skins")

local _G = _G

local function styleDressingroom()
	if E.private.skins.blizzard.enable ~= true or E.private.skins.blizzard.dressingroom ~= true or E.private.lui.Pskins.blizzard.enable ~= true or E.private.lui.Pskins.blizzard.dressingroom ~= true then return end

	_G.DressUpFrame:Styling()

	-- Wardrobe edit frame
	_G.WardrobeOutfitFrame:Styling()
end

S:AddCallback("LuiDressingRoom", styleDressingroom)
