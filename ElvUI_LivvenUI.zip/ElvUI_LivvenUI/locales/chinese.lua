local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "zhCN")
if not L then return end

--core
L["LUI_LOGIN_MSG"] = "欢迎使用%s。输入%s进入设置。若您有任何意见和建议请加战网: %s。"
L["LUI_ELV_OUTDATED_MSG"] = "您的ElvUI版本低于建议与|cff9482c9LivvenUI|r一起使用的版本。您的版本是|cfff960d9%.2f|r，建议为|cfff960d9%.2f|r。请更新您的ElvUI以避免错误。"

--menu
L["changelog"] = "更新日志"
L["LUI_CHANGELOG_TITLE"] = "%s - 更新日志"
L["modules"] = "功能模块"
L["information"] = "相关信息"
L["support"] = "支持"
L["contactAuthor"] = "联系作者"
L["version"] = "版本"

L["loginMsg"] = "登录信息"
L["splashScreen"] = "启动画面"
L["gamemenu"] = "菜单画面"

L["misc"] = "一般"
L["flashingCursor"] = "鼠标闪光"

L["UP"] = "上"
L["DOWN"] = "下"
L["LEFT"] = "左"
L["RIGHT"] = "右"
L["NONE"] = "无"

L["BOTTOM"] = "底部"
L["BOTTOMLEFT"] = "左下"
L["BOTTOMRIGHT"] = "右下"
L["CENTER"] = "中间"
L["LEFT"] = "左"
L["RIGHT"] = "右"
L["TOP"] = "顶部"
L["TOPLEFT"] = "左上"
L["TOPRIGHT"] = "右上"

L["proximity"] = "邻近"
--general
L["general"] = "一般"
--cvar
L["cvar"] = "设置CVar"
L["alwaysCompareItems"] = "装备鼠标提示对比"
L["alwaysCompareItems_DESC"] = "装备的鼠标提示总是开启对比\r\r默认：关闭"
L["breakUpLargeNumbers"] = "大数值逗号显示"
L["breakUpLargeNumbers_DESC"] = "大数值开启逗号显示\r\r默认：开启"
L["scriptErrors"] = "显示lua错误"
L["scriptErrors_DESC"] = "在聊天框显示与UI功能相关的错误信息\r\r默认：关闭"
L["enableWoWMouse"] = "检测wow专用鼠标"
L["enableWoWMouse_DESC"] = "启用此项以启用魔兽世界专用鼠标并对其进行额外的键位绑定\r\r默认：关闭"
L["trackQuestSorting"] = "追踪任务位置"
L["trackQuestSorting_DESC"] = "新追踪的任务将被排在目标追踪的位置\r\r默认：顶部"
L["chat"] = "聊天框"
L["profanityFilter"] = "语言过滤器"
L["profanityFilter_DESC"] = "开启不良语句过滤\r\r默认：开启"
L["removeChatDelay"] = "移除聊天标签延迟"
L["removeChatDelay_DESC"] = "移除聊天标签弹出延迟\r\r默认：关闭"
L["chatMouseScroll"] = "开启鼠标滑轮滚动"
L["chatMouseScroll_DESC"] = "勾选以使鼠标在悬停于聊天窗口时可使用滑轮滚动聊天文本\r\r默认：开启"
L["interface"] = "界面"
L["cameraDistanceMaxZoomFactor"] = "最大镜头距离"
L["cameraDistanceMaxZoomFactor_DESC"] = "调节镜头在角色身后的最大跟随距离\r\r默认：1.9"
L["ffxGlow"] = "全屏泛光"
L["ffxGlow_DESC"] = "默认：开启"
L["weatherDensity"] = "天气效果"
L["weatherDensity_DESC"] = "默认：3"
L["xpBarText"] = "经验条数字显示"
L["xpBarText_DESC"] = "总是在你的经验条上显示文字\r\r默认：开启"
L["combat"] = "战斗"
L["secureAbilityToggle"] = "技能锁定"
L["secureAbilityToggle_DESC"] = "勾选此项之后，你将不会因为在短时间内偶然多次点击快捷键而意外取消你的技能\r\r默认：开启"
L["stopAutoAttackOnTargetChange"] = "停止自动攻击"
L["stopAutoAttackOnTargetChange_DESC"] = "当你切换目标时停止自动攻击\r\r默认：关闭"
L["assistAttack"] = "协助攻击"
L["assistAttack_DESC"] = "自动攻击使用/assist指令选定的目标\r\r默认：关闭"
L["SpellQueueWindow"] = "延迟容限"
L["SpellQueueWindow_DESC"] = "在允许将释放技能请求发送到服务器之前，确定释放结束到开始释放可以提前多远。也就是说，它控制能力排队系统的内置延迟。理想情况下，您将希望将此设置为游戏内延迟\r\r默认：400"
L["combatText"] = "浮动战斗信息"
L["WorldTextScale"] = "游戏文本比例"
L["WorldTextScale_DESC"] = "游戏内伤害数值、经验值、增益等数值的显示比例\r\r默认：1.0"
L["targetCombatText"] = "目标浮动战斗信息"
L["floatingCombatTextCombatDamage"] = "伤害"
L["floatingCombatTextCombatDamage_DESC"] = "显示你对目标的伤害\r\r默认：开启"
L["floatingCombatTextCombatLogPeriodicSpells"] = "周期性伤害"
L["floatingCombatTextCombatLogPeriodicSpells_DESC"] = "显示周期性伤害数值，比如撕裂和暗言术：痛\r\r默认：开启"
L["floatingCombatTextPetMeleeDamage"] = "宠物伤害"
L["floatingCombatTextPetMeleeDamage_DESC"] = "显示你的宠物造成的伤害\r\r默认：开启"
L["floatingCombatTextCombatDamageDirectionalScale"] = "伤害浮动速度"
L["floatingCombatTextCombatDamageDirectionalScale_DESC"] = "默认：1"
L["floatingCombatTextCombatHealing"] = "治疗"
L["floatingCombatTextCombatHealing_DESC"] = "显示你对目标的治疗量\r\r默认：开启"
L["floatingCombatTextCombatHealingAbsorbTarget"] = "护盾（目标）"
L["floatingCombatTextCombatHealingAbsorbTarget_DESC"] = "显示你对目标增加的护盾吸收量\r\r默认：开启"
L["floatingCombatTextSpellMechanics"] = "效果"
L["floatingCombatTextSpellMechanics_DESC"] = "显示目标身上你的效果，比如沉默和诱捕\r\r默认：关闭"
L["floatingCombatTextSpellMechanicsOther"] = "目标其他玩家的效果"
L["floatingCombatTextSpellMechanicsOther_DESC"] = "显示目标身上其他玩家的效果，比如沉默和诱捕\r\r默认：关闭"
L["playerCombatText"] = "玩家浮动战斗信息"
L["enableFloatingCombatText"] = "开启玩家浮动信息"
L["enableFloatingCombatText_DESC"] = "勾选此项将在屏幕上直观显示额外的战斗信息\r\r默认：关闭"
L["floatingCombatTextFloatMode"] = "滚动战斗记录"
L["floatingCombatTextFloatMode_DESC"] = "设置战斗信息的滚动方向\r\r默认：向上滚动"
L["FloatModeUp"] = "向上滚动"
L["FloatModeDown"] = "向下滚动"
L["FloatModeARC"] = "弧形"
L["floatingCombatTextDodgeParryMiss"] = "躲闪/招架/未命中"
L["floatingCombatTextDodgeParryMiss_DESC"] = "当敌人的攻击未命中，或者被玩家躲闪、招架时显示信息\r\r默认：关闭"
L["floatingCombatTextCombatHealingAbsorbSelf"] = "护盾（玩家）"
L["floatingCombatTextCombatHealingAbsorbSelf_DESC"] = "当玩家获得护盾时显示信息\r\r默认：开启"
L["floatingCombatTextDamageReduction"] = "伤害减免"
L["floatingCombatTextDamageReduction_DESC"] = "当玩家抵抗攻击或法术时显示信息\r\r默认：关闭"
L["floatingCombatTextLowManaHealth"] = "生命/法力过低"
L["floatingCombatTextLowManaHealth_DESC"] = "当玩家生命值或法力值低于20%的时候显示信息\r\r默认：开启"
L["floatingCombatTextRepChanges"] = "声望变化"
L["floatingCombatTextRepChanges_DESC"] = "当玩家某个阵营中的声望提高或降低时显示信息\r\r默认：关闭"
L["floatingCombatTextEnergyGains"] = "能量获取"
L["floatingCombatTextEnergyGains_DESC"] = "显示所有立即获取的法力值、怒气值、能量值和真气值\r\r默认：关闭"
L["floatingCombatTextComboPoints"] = "连击点数"
L["floatingCombatTextComboPoints_DESC"] = "当玩家获得新的连击点时，显示连击点的数量\r\r默认：关闭"
L["floatingCombatTextReactives"] = "法术警报"
L["floatingCombatTextReactives_DESC"] = "当特定的重要时间发生时显示警报\r\r默认：开启"
L["floatingCombatTextPeriodicEnergyGains"] = "周期性能量获取"
L["floatingCombatTextPeriodicEnergyGains_DESC"] = "显示所有周期性获得的法力值、怒气值和能量值\r\r默认：关闭"
L["floatingCombatTextFriendlyHealers"] = "友方治疗者姓名"
L["floatingCombatTextFriendlyHealers_DESC"] = "当友方施法者对玩家施放治疗法术时，显示友方名字\r\r默认：关闭"
L["floatingCombatTextHonorGains"] = "荣誉消灭"
L["floatingCombatTextHonorGains_DESC"] = "显示玩家通过杀死其他玩家所得到荣誉值\r\r默认：关闭"
L["floatingCombatTextCombatState"] = "进入/离开战斗"
L["floatingCombatTextCombatState_DESC"] = "当玩家进入或脱离战斗士显示信息\r\r默认：关闭"
L["floatingCombatTextAuras"] = "获得/失去光环"
L["floatingCombatTextAuras_DESC"] = "当玩家获得或失去光环效果时显示信息\r\r默认：关闭"
L["unitframes"] = "单位框体"
L["noBuffDebuffFilterOnTarget"] = "显示非玩家光环"
L["noBuffDebuffFilterOnTarget_DESC"] = "不过滤目标的非玩家施放的Buff和Debuff，显示全部\r\r默认：关闭"
L["threatShowNumeric"] = "目标头像仇恨"
L["threatShowNumeric_DESC"] = "勾选此项以百分比形式显示威胁值\r\r默认：关闭"
L["nameplates"] = "姓名板"
L["nameplateMaxDistance"] = "姓名板显示距离"
L["nameplateMaxDistance_DESC"] = "姓名板显示的最远距离\r\r默认：60"
L["nameplateOtherAtBase"] = "姓名板显示位置"
L["nameplateOtherAtBase_DESC"] = "姓名板显示在模型的位置\r\r默认：上"
L["ShowClassColorInFriendlyNameplate"] = "友方姓名板职业色"
L["ShowClassColorInFriendlyNameplate_DESC"] = "开启友方姓名板时显示为职业色\r\r默认：开启"
L["nameplatePersonalShowAlways"] = "永远显示个人资源"
L["nameplatePersonalShowAlways_DESC"] = "开启系统显示个人资源后，永远显示个人资源\r\r默认：关闭"
L["nameplatePersonalShowWithTarget"] = "目标时显示个人资源"
L["nameplatePersonalShowWithTarget_DESC"] = "开启系统显示个人资源后，玩家有目标时显示个人资源\r\r默认：关闭"
L["nameplatePersonalShowInCombat"] = "战斗时显示个人资源"
L["nameplatePersonalShowInCombat_DESC"] = "开启系统显示个人资源后，玩家战斗时时显示个人资源\r\r默认：开启"
L["nameplateOtherTopInset"] = "目标屏幕上方距离"
L["nameplateOtherTopInset_DESC"] = "设置目标姓名板与屏幕上方的距离，将目标姓名板保持在屏幕内。设置为0时为禁用该功能\r\r默认：0.08"
L["nameplateOverlapV"] = "堆叠姓名板间隔"
L["nameplateOverlapV_DESC"] = "姓名板排列方式为堆叠时，设置姓名板间的间距\r\r默认：1.1"
L["nameplateMotionSpeed"] = "姓名板移动速度"
L["nameplateMotionSpeed_DESC"] = "设置姓名板移动的最快速度\r\r默认：0.025"
L["nameplateGlobalScale"] = "姓名板全局比例"
L["nameplateGlobalScale_DESC"] = "设置姓名板大小比例\r\r默认：1"
L["nameplateMinScale"] = "姓名板镜头最小比例"
L["nameplateMinScale_DESC"] = "根据姓名板距离镜头的远近，姓名板显示的最小比例，最远时最小比例。设置为1时，不根据镜头远近缩放姓名板\r\r默认：0.8"
--filters
L["filters"] = "过滤屏蔽"
L["infoFilter"] = "信息过滤"
L["debugFilter"] = "调试"
L["noPMSticky"] = "禁用密语粘滞"
L["repeatFilter"] = "重复屏蔽间隔"
L["keywordMatchNum"] = "关键词匹配数量"
L["emoticonMatchNum"] = "表情符号匹配数量"
L["keywordFilter"] = "关键词屏蔽"
L["addKeyword"] = "添加关键词"
L["delKeyword"] = "删除关键词"
L["delChoisedKeywords"] = "删除选中关键词"
L["delAllKeywords"] = "删除所有关键词"
L["keywordBlacklist"] = "关键词黑名单"
L["pmFilter"] = "密语过滤"
L["demoLevel"] = "屏蔽试玩角色密语"
L["levelFilter"] = "密语允许等级"
L["DKLevelFilter"] = "死亡骑士允许等级"
L["DHLevelFilter"] = "恶魔猎手允许等级"
L["playerFilter"] = "玩家过滤"
L["nameFilter"] = "玩家屏蔽"
L["addPlayer"] = "添加玩家"
L["delPlayer"] = "删除玩家"
L["delChoisedPlayers"] = "删除选中玩家"
L["delAllPlayers"] = "删除所有玩家"
L["playerBlacklist"] = "玩家黑名单"

--quest
L["quest"] = "任务"
L["questAutomation"] = "任务交接"
L["QuestFrameAutomationBtn"] = "交接"
L["autoChoices"] = "自动选择最贵奖励"
L["frameBtn"] = "任务框体按钮"
L["frameBtnElvUI"] = "框体按钮美化"
L["questAnnouncment"] = "任务通报"
L["QuestFrameAnnouncmentBtn"] = "通报"
L["questSolo"] = "个人"
L["questParty"] = "队伍"
L["questRaid"] = "团队"
L["questInstance"] = "副本"
L["questNoDetail"] = "非详细通报"
L["questListEnhanced"] = "任务列表增强"
L["questTitleColor"] = "标题职业色"
L["questList"] = "任务列表"
L["titleFont"] = "标题字体"
L["titleFontSize"] = "标题字体大小"
L["titleFontFlag"] = "标题字体描边"
L["infoFont"] = "信息字体"
L["infoFontSize"] = "信息字体大小"
L["infoFontFlag"] = "信息字体描边"
L["questLevel"] = "任务等级"
L["titleLevel"] = "任务标题等级"
L["detailLevel"] = "任务日志等级"
L["ignoreHighLevel"] = "忽略最高等级"
L["questFrame"] = "任务框体"
L["frameTitle"] = "任务框体标题"
L["leftSide"] = "折叠按钮移至左侧"
L["leftSideSize"] = "折叠按钮大小"
--unitframes
L["unitframes"] = "单位框架"
L["playerframe"] = "玩家框体"
L["gcdBar"] = "GCD计时条"
L["swingBar"] = "平砍计时条"
L["swingBarColor"] = "颜色"
L["swingBarWidth"] = "宽"
L["swingBarHeight"] = "高"
L["remainingText"] = "剩余时间文本"
L["durationText"] = "持续时间文本"
L["swingBarFontName"] = "字体"
L["swingBarFontSize"] = "字体大小"
L["swingBarFontFlag"] = "字体描边"
L["targetframe"] = "目标框体"
L["rangeText"] = "距离"
L["rangeFontName"] = "字体"
L["rangeFontSize"] = "字体大小"
L["rangeFontFlag"] = "字体描边"
L["rangePoi"] = "位置"
L["rangePoiX"] = "X方向偏移"
L["rangePoiY"] = "Y方向偏移"
L["focusframe"] = "焦点框体"

L["chatBar_says"] = "说"
L["chatBar_yells"] = "喊"
L["chatBar_G"] = "公"
L["chatBar_O"] = "官"
L["chatBar_P"] = "队"
L["chatBar_R"] = "团"
L["chatBar_RW"] = "警"
L["chatBar_I"] = "副"
L["chatBar_BG"] = "战"
L["chatBar"] = "频道条"
L["chatBar_DESC"] = "频道条包含频道切换条TAB切换属性通报聊天表情ROLL点加入/离开大脚世界频道"
L["chatBarPoi"] = "聊天条位置"
L["chatBarPoi_DESC"] = "内嵌暂时只能通过拉高左聊天框，暂无法减小文字框高度还原聊天框整体高度，待更新"
L["chatBub"] = "智能聊天气泡"
L["smartChatBub_DESC"] = "进入副本自动开启聊天气泡，出副本自动关闭，防止广告骚扰"
L["chatBubTip"] = "显示聊天提示"
L["smartChatBubTip_DESC"] = "进入游戏以及切换地图时，将在聊天框提示目前气泡开启/关闭状态"
L["chatTradeLog"] = "交易记录提醒"
L["tradeLog_DESC"] = "对话框内显示交易对象及交易情况"
L["tradeSendChat"] = "密语交易对象"
L["tradeSendChat_DESC"] = "将交易情况以密语的形式告知交易对象"
L["chatMSGLoot"] = "战利记录增强"
L["chatMSGLoot_DESC"] = "战利品记录玩家将以职业色显示，且可以直接点击密语"
L["chatMSGLootGS"] = "显示玩家装等"
L["chatMSGLootGS_DESC"] = "若已开启<团队信息统计>并已获取到该玩家装等，战利品记录玩家姓名后会添加该玩家装等"
L["chatRepChange"] = "智能声望显示"
L["chatMSGLootGS_DESC"] = "聊天框显示声望获取情况，包括巅峰声望以及可兑换奖励提醒"
L["roll 1-100"] = "Roll 1-100"
L["bigFootChannel"] = "大脚世界频道"
L["Enable/DisableBigFootChannel"] = "加入/离开大脚世界频道"
--misc
--general
L["rightButtonMenu"] = "右键菜单增强"
L["disableTalking"] = "禁用剧情对话框"
L["alreadyKnown"] = "已学物品染色"
L["autoRelease"] = "战场自动释放"
L["color"] = "颜色"
L["classColors"] = "好友职业染色"
L["autoScreenShoot"] = "成就自动截图"
L["autoDelete"] = "自动填入DELETE"
L["autoRepChange"] = "声望自动追踪"
L["talentProfiles"] = "天赋配置管理"
L["talentButtonElvUI"] = "天赋按钮美化"
L["screenFormat"] = "图片格式"
L["screenQuality"] = "图片质量"
L["mouseButton1"] = "鼠标左键"
L["mouseButton2"] = "鼠标右键"
L["mouseButton3"] = "鼠标中键"
L["mouseButton4"] = "鼠标侧键"
L["setPoi"] = "屏幕中心指示器"
L["poiCombat"] = "战斗切换"
L["poiColor"] = "指示器颜色"
L["poiText"] = "指示器形状"
L["poiTextSize"] = "指示器大小"
--inviteGroup
L["inviteGroup"] = "便捷组队"
L["ainvkeyword"] = "自动组队关键词"
L["inviteRank"] = "按公会级别邀请成员进团"
L["refreshRank"] = "刷新级别"
L["startInvite"] = "发起邀请"	
L["LUI_INVITEGROUP_MSG"] = "会阶为 %s 的成员,将在10秒后被邀请进团"
--loot
L["loot"] = "拾取"
L["fastLoot"] = "光速拾取"
L["fastLoot_DESC"] = "必须先游戏内设置开启自动拾取"
L["lootSpeed"] = "拾取速度"
L["lootSpeed_DESC"] = "游戏自带自动拾取默认间隔为300ms，光速为0ms，极快100ms，稍快200ms"
--actionbars
L["actionbars"] = "动作条"
L["randomHearthstone"] = "随机炉石玩具"
L["creatRHS"] = "创建炉石宏"
--armory
L["armory"] = "角色信息"
--blizzard
L["blizzard"] = "暴雪"
L["castbarTime"] = "施法条计时"
L["minimapWheel"] = "小地图滚轮"
--combat
L["combatNotification"] = "战斗提示"
L["combatNotiEntering"] = "进入战斗提示"
L["combatNotiLeaving"] = "离开战斗提示"
L["combatNotiFont"] = "提示预设字体"
L["combatNotiSize"] = "提示字体大小"
L["combatNotiFlag"] = "提示字体描边"
L["combatShortcut"] = "战斗快捷键"
L["raidMarkingKey"] = "快速团队标记"
L["raidMarkingButton"] = "标记快捷键"
L["setFocusKey"] = "快速设置焦点"
L["setFocusButton"] = "焦点快捷键"
L["announceSystem"] = "技能通告"
L["raidSpells"] = "团队技能通告"
L["raidSpells_DESC"] = "包括FS餐桌/传送门；SS灵魂之井/召唤仪式；大餐/机器人/邮箱及部分玩具等"
L["resAndThreatSpells"] = "战复/误导通告"
L["resAndThreat"] = "战复/误导"
L["resThanks"] = "战复感谢"
L["taunt"] = "嘲讽通告"
L["taunt_DESC"] = "开启后在所处团队/队伍/副本环境中通告"
L["include_DESC"] = "开启后仅在聊天框中显示而不进行通告"
L["playerSmart"] = "玩家智能通告"
L["includeMiss"] = "包括嘲讽失败"
L["otherTankSmart"] = "其他坦克智能通告"
L["includeOtherTank"] = "包括其他坦克"
L["petSmart"] = "宠物智能通告"
L["includePet"] = "包括宠物"
--maps
L["maps"] = "地图"
L["whoClickMinimap"] = "显示小地图点击者"
L["minimapIcons"] = "小地图图标"
L["chooseMinimap"] = "选择图标方式"
L["square"] = "收集"
L["buttons"] = "按钮"
L["squareMinimapDC"] = "延展方向"
L["backdrop"] = "背景"
L["barMouseOver"] = "鼠标滑过显示"
L["hideInCombat"] = "战斗中隐藏"
L["iconSize"] = "图标大小"
L["buttonSpacing"] = "按钮间距"
L["buttonsPerRow"] = "每行按钮数"
L["visibility"] = "可见状态"
L["moveTracker"] = "收集追踪图标"
L["moveQueue"] = "收集队列图标"
L["moveMail"] = "收集邮件图标"
L["hideGarrison"] = "隐藏任务图标"
L["moveGarrison"] = "收集任务图标"
--tooltip
L["tooltip"] = "鼠标提示"
L["tooltipIcon"] = "显示阵营图标"
L["raidProg"] = "显示团本成就"
L["Short"] = "短"
L["nameStyle"] = "团本名字风格"
L["difStyle"] = "团本难度风格"
L["raids"] = "团队副本"
--skins
L["skins"] = "材质皮肤"
L["statusbar"] = "材质包"
--special
L["special"] = "特殊"
--TeamStats
L["teamStats"] = "团队信息统计"

L["BtnRescanText"] = "重新获取"
L["BtnRescanTipTitle"] = "重新获取天赋/装等/珠宝信息"
L["BtnRescanTip"] = "为了减少资源占用,插件并不会实时更新成员信息，请选中要更新的成员后点击此按钮"

L["BtnAnnText"] = "信息广播"
L["BtnAnnTipTitle"] = "信息广播"
L["BtnAnnTip"] = "将选中团员的信息发布到团队频道, 请谨慎选择, 防止刷屏和纠纷。"
L["BtnAnnPopupText"] = "确定广播|cffff7f00[%d]|r条信息到|cffff7f00[%s]|r频道吗?"
L["BtnAnnNoSelect"] = "请至少选择一个团员"

L["TitleText"] = "团队信息统计"
L["HeaderClass"] = CLASS
L["HeaderPlayerName"] = "成员名称"
L["HeaderGS"] = "装等"
L["HeaderHealth"] = "血量"

L["StatusGetting"] = "正在获取资料"
L["StatusCannotGet"] = "有玩家距离过远,无法获得"
L["StatusAllDone"] = "全部资料获取完毕"
L["StatusPaused"] = "战斗中暂停获取"

L["HUNTER"]="猎人"
L["WARLOCK"]="术士"
L["PRIEST"]="牧师"
L["PALADIN"]="圣骑"
L["MAGE"]="法师"
L["ROGUE"]="盗贼"
L["DRUID"]="德鲁伊"
L["SHAMAN"]="萨满"
L["WARRIOR"]="战士"
L["DEATHKNIGHT"]="死骑"

L["MiniTipTitle"] = "团队信息统计"
L["MiniTip"] = "打开团队信息统计界面, 集中查看所有团员的天赋、装等和副本击杀情况. 图标闪烁表示有新获取的数据"

--AtlasLootReverse
L["atlasLootReverse"] = "物品来源查询"
L["Drops from %s"] = "来源：%s"
L["Heroic %s"] = "|cff00ff00英雄：%s|r"
L["25 Man %s"] = "%s[25]"
L["25 Man Heroic %s"] = "|cff00ff00英雄：%s[25]|r"
L["PvP %s Set"] = "PVP %s级套装"
L["Tier %s"] = "T%s"

--lootSpecManagerBtn
L["lootSpecManager"] = "自动切换拾取"
L["lootSpecManagerBtn"] = "设置专精拾取"

--rightButtonMenu
L["Armory"] = "英雄榜"
L["Query Detail"] = "查询玩家"
L["Get Name"] = "获取名字"
L["Guild Invite"] = "公会邀请"
L["Add Friend"] = "添加好友"
L["Report MyStats"] = "报告装等"
L["LUIBLACKPLAYER"] = "黑名单"
--raidprogress
L["RAID_ULDIR"] = "奥迪尔"
L["RAID_DAZALOR"] = "达萨罗"
L["RAID_STORMCRUS"] = "风暴熔炉"

-- ===================== Part for TradeLog ==================		
TRADE_LOG_MONEY_NAME = {
gold = "g",
silver = "s",
copper = "c",
}

CANCEL_REASON_TEXT = {
self = "我取消了交易",
other = "对方取消了交易",
toofar = "双方距离过远",
selfrunaway = "我超出了距离",
selfhideui = "我隐藏了界面,交易窗口关闭",
unknown = "未知原因",
}

TRADE_LOG_SUCCESS_NO_EXCHANGE = "与[%t]交易成功, 但是没有做任何交换。"
TRADE_LOG_SUCCESS = "与[%t]交易成功。"
TRADE_LOG_DETAIL = "详情"
TRADE_LOG_CANCELLED = "与[%t]交易取消: %r。"
TRADE_LOG_FAILED = "与[%t]交易失败: %r。"
TRADE_LOG_FAILED_NO_TARGET = "交易失败: %r。"
TRADE_LOG_HANDOUT = "交出"
TRADE_LOG_RECEIVE = "收到"
TRADE_LOG_ENCHANT = "附魔"
TRADE_LOG_ITEM_NUMBER = "%d件物品"
TRADE_LOG_CHANNELS = {
whisper = "密语",
raid = "团队",
party = "小队",
say = "说",
yell = "喊",
}
TRADE_LOG_ANNOUNCE = "通告"
TRADE_LOG_ANNOUNCE_TIP = "选中就会将交易信息发送到指定的频道"

TRADE_LOG_RESULT_TEXT_SHORT = { 
cancelled = "取消", 
complete = "成功", 
error = "失败", 
}

TRADE_LOG_RESULT_TEXT = { 
cancelled = "交易取消", 
complete = "交易成功", 
error = "交易失败", 
}

TRADE_LOG_MONTH_SUFFIX = "月"
TRADE_LOG_DAY_SUFFIX = "日"

TRADE_LOG_COMPLETE_TOOLTIP = "点击鼠标左键查看交易的详细信息"


RECENT_TRADE_TIME = "%d%s前"
RECENT_TRADE_TITLE = "近期与此人的交易"

-- ===================== Part for TradeList ==================
TRADE_LIST_CLEAR_HISTORY = "清除记录"
TRADE_LIST_SCALE = "详情窗口缩放"
TRADE_LIST_FILTER = "仅列出成功交易"

TRADE_LIST_HEADER_WHEN = "交易时间"
TRADE_LIST_HEADER_WHO = "交易对象"
TRADE_LIST_HEADER_WHERE = "交易地点"
TRADE_LIST_HEADER_SEND = "交出"
TRADE_LIST_HEADER_RECEIVE = "获得"
TRADE_LIST_HEADER_RESULT = "结果"

TRADE_LIST_CLEAR_CONFIRM = "今天以外的记录都将被清除!"

TRADE_LIST_TITLE = "交易记录"
TRADE_LIST_DESC = "可以查看最近所有的交易记录，包括失败的原因。"

L["castbarTarget"] = "显示施法条目标"
L["wipeDB"] = "重置数据库"
L["wipeDB_DESC"] = "发生不能正常关闭功能时使用"
--ElvUI
L["Item Level:"] = "装等:"
--blizzard
L["blizzardMoveFrames"] = "暴雪框体移动"
L["remember"] = "记忆位置"
L["errorframe"] = "错误框体"
L["width"] = "宽"
L["height"] = "高"

--bags
L["bags"] = "背包"
L["moveElvUIBags"] = "左键移动ElvUI背包"

--media
L["media"] = "材质"
L["questHeader"] = "任务栏标签文本"
L["fontcolor"] = "字体颜色"
L["fontName"] = "字体"
L["fontSize"] = "字体大小"
L["fontFlag"] = "字体描边"
L["questTracker"] = "任务栏标题及内容文本"
L["miscTexts"] = "各种文本"
L["questGossip"] = "任务日志文本"
L["questFontSuperHuge"] = "任务超大文本"
L["mailText"] = "邮件文本"
L["editboxText"] = "聊天输入框文本"

L["chatBubbles"] = "聊天气泡"

--Media
L["LUI_MEDIA_ZONES"] = {
"华盛顿",
"莫斯科",
"月球基地",
"妖精温泉度假胜地",
"光明会总部",
"弱电的衣橱",
"免费",
}
L["LUI_MEDIA_PVP"] = {
"(部落领土)",
"(联盟领土)",
"(有争议的领土)",
"(俄罗斯领土)",
"(外星人的领土)",
"(猫的领土)",
"(中国领土)",
"(EA领土)",
}
L["LUI_MEDIA_SUBZONES"] = {
"管理员",
"地狱",
"废话巷",
"胡椒博士存储",
"伏特加存储",
"失落的国家银行",
}
L["LUI_MEDIA_PVPARENA"] = {
"(PvP)",
"禁止吸烟!",
"只有5%税",
"自由",
"自我毁灭正在进行",
}
L["zoneTexts"] = "区域文本"
L["testBtn"] = "测试文本"
L["zoneText"] = "地区文本"
L["subzoneText"] = "分区文本"
L["pvpstatusText"] = "PvP状态文本"

--raid
L["raid"] = "团队"
L["raidManager"] = "团队管理职责图标"

--nameHover
L["nameHover"] = "角色名悬停"
L["guildName"] = "公会名称"
L["guildRank"] = "公会级别"
L["race"] = "等级/性别/种族/职业"
L["realm"] = "服务器名称"
L["titles"] = "头衔"
L["Male"] = "男"
L["Female"] = "女"

L["enhancedFriendsList"] = "好友列表增强"
L["NameFont"] = "姓名预设字体"
L["NameFontSize"] = "姓名字体大小"
L["NameFontFlag"] = "姓名字体描边"
L["InfoFont"] = "信息预设字体"
L["InfoFontSize"] = "信息字体大小"
L["InfoFontFlag"] = "信息字体描边"
L["GameIconPack"] = "游戏图标选择"
L["Default"] = "默认"
L["Blizzard Chat"] = "暴雪聊天框"
L["Flat Style"] = "扁平式"
L["Glossy"] = "光泽式"
L["Launcher"] = "暴雪战网式"
L["StatusIconPack"] = "状态图标选择"
L["Square"] = "方形"
L["GameIcons"] = "游戏图标"
L["Diablo 3"] = "暗黑破坏神 3"
L["Hearthstone"] = "炉石传说"
L["Starcraft"] = "星际争霸"
L["Starcraft 2"] = "星际争霸 2"
L["App"] = "战网"
L["BSAp"] = "手机app"
L["Hero of the Storm"] = "风暴英雄"
L["Overwatch"] = "守望先锋"
L["Destiny 2"] = "命运 2"
L["Call of Duty 4"] = "使命召唤 4"
L["StatusIcons"] = "状态图标"
--microBar
L["microBar"] = "微型系统菜单"
L["scale"] = "比例"
L["hideInCombat"] = "战斗中隐藏"
L["hideInOrderHall"] = "职业大厅隐藏"
L["text"] = "文本"
L["position"] = "位置"
L["Local Time"] = "本地时间"
L["Realm Time"] = "服务器时间"
L["Faction Assault"] = "突袭"
L["Current Invasion: "] = "当前入侵: "
L["Next Invasion: "] = "下次入侵: "
L["Missing invasion info on your realm."] = "未获取入侵信息"

L["enhancedWorldMap"] = "大地图增强"
L["useReveal"] = "地图全亮"

L["autoButtons"] = "饰品物品按键"
L["featureconfig"] = "一般设置"
L["bindFontSize"] = "键位字体大小"
L["countFontSize"] = "数量字体大小"
L["soltAutoButtons"] = "装备饰品按键"
L["slotBBColorByItem"] = "稀有度颜色边框"
L["slotBBColor"] = "自定义颜色"
L["slotNum"] = "装备按钮数量"
L["slotPerRow"] = "每行按钮数"
L["slotSize"] = "装备按钮大小"
L["questAutoButtons"] = "任务物品按键"
L["questBBColorByItem"] = "稀有度颜色边框"
L["questBBColor"] = "自定义颜色"
L["questNum"] = "物品按钮数量"
L["questPerRow"] = "每行按钮数"
L["questSize"] = "物品按钮大小"
L["whiteItemID"] = "物品ID"
L["AddItemID"] = "增加物品ID"
L["DeleteItemID"] = "删除物品ID"
L["whiteList"] = "物品列表"
L["blackitemID"] = "物品黑名单ID"
L["AddblackItemID"] = "增加物品黑名单ID"
L["DeleteblackItemID"] = "删除物品黑名单ID"
L["blackList"] = "物品黑名单列表"

L["Must is itemID!"] = "必须是物品ID"
L["is error itemID"] = "是错误的物品ID"

L["Hearthstone Location"] = "绑定炉石位置"
L["finishingMoveHighlight"] = "终结技高亮"

L["azerite"] = "艾泽里特"
L["skipAzeriteAnimations"] = "跳过艾泽里特动画"
L["azeriteTooltip"] = "艾泽里特鼠标提示"
L["removeBlizzard"] = "移除暴雪文字"
L["onlyIcon"] = "仅图标"
L["onlySpec"] = "仅当前专精"
L["bagIcon"] = "背包角标"
L["bagIconPosition"] = "背包角标位置"
L["characterIcon"] = "角色面板角标"
L["characterIconPosition"] = "角色角标位置"

L["questDirection"] = "物品按钮延展方向"
L["slotDirection"] = "装备按钮延展方向"

L["enhancedElvUIBank"] = "ElvUI银行增强"
L["moveElvUIBank"] = "左键移动ElvUI银行"
L["showBankTab"] = "自动开启材料栏"
L["autoDepositReagents"] = "自动存入材料"