﻿local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "enUS", true, true)

--core
L["LUI_LOGIN_MSG"] = "Welcome to %s. %s into the settings. If you have any comments and suggestions, Please add battle:%s."
L["LUI_ELV_OUTDATED_MSG"] = "Your ElvUI version is below the recommended version to use with |cff9482c9LivvenUI|r. Your version is |cfff960d9%.2f|r, recommended for |cfff960d9%.2f|r. Please update your ElvUI to avoid errors."

--menu
L["changelog"] = true
L["LUI_CHANGELOG_TITLE"] = "%s - Changelog"
L["modules"] = true
L["information"] = true
L["support"] = true
L["contactAuthor"] = true
L["version"] = true

L["loginMsg"] = true
L["splashScreen"] = true
L["gamemenu"] = true

L["misc"] = true
L["flashingCursor"] = true
L["cursorMode"] = true
L["always"] = true
L["modifier"] = true
L["cursorSize"] = true
L["cursorColor"] =true

L["UP"] = true
L["DOWN"] = true
L["LEFT"] = true
L["RIGHT"] = true
L["NONE"] = true

L["BOTTOM"] = true
L["BOTTOMLEFT"] = true
L["BOTTOMRIGHT"] = true
L["CENTER"] = true
L["LEFT"] = true
L["RIGHT"] = true
L["TOP"] = true
L["TOPLEFT"] = true
L["TOPRIGHT"] = true

L["proximity"] = true

--general
L["general"] = true
--cvar
L["cvar"] = true
L["alwaysCompareItems"] = true
L["alwaysCompareItems_DESC"] = "Item mouse prompt always on \r\r default: off"
L["breakUpLargeNumbers"] = true
L["breakUpLargeNumbers_DESC"] = "Big value open comma display \r\r default: open"
L["scriptErrors"] = true
L["scriptErrors_DESC"] = "Displaying error messages related to UI functions in the chat box \r\r default: off"
L["enableWoWMouse"] = true
L["enableWoWMouse_DESC"] = "Enable this to Enable world of warcraft mouse with additional key bindings \r\r default: off"
L["trackQuestSorting"] = true
L["trackQuestSorting_DESC"] = "New tracking tasks will be listed at target tracking location \r\r default: top"
L["chat"] = true
L["profanityFilter"] = true
L["profanityFilter_DESC"] = "Enable bad statement filtering \r\r default: Enable"
L["removeChatDelay"] = true
L["removeChatDelay_DESC"] = "移除聊天标签弹出延迟\r\r默认：关闭"
L["chatMouseScroll"] = true
L["chatMouseScroll_DESC"] = "Remove chat TAB popup delay \r\r default: off"
L["interface"] = true
L["cameraDistanceMaxZoomFactor"] = true
L["cameraDistanceMaxZoomFactor_DESC"] = "Adjust the maximum following distance of the lens behind the character \r\r default: 1.9"
L["ffxGlow"] = true
L["ffxGlow_DESC"] = "Default: on"
L["weatherDensity"] = true
L["weatherDensity_DESC"] = "Default: 3"
L["xpBarText"] = true
L["xpBarText_DESC"] = "Always show text on your experience bar \r\r default: on"
L["combat"] = true
L["secureAbilityToggle"] = true
L["secureAbilityToggle_DESC"] = "If checked, you won't accidentally cancel your skills by clicking on the shortcut key several times in a short time. \r\r default: on"
L["stopAutoAttackOnTargetChange"] = true
L["stopAutoAttackOnTargetChange_DESC"] = "Stop automatic attacks when you switch targets \r\r default: off"
L["assistAttack"] = true
L["assistAttack_DESC"] = "Auto attack using /assist instruction selected target \r\r default: off"
L["SpellQueueWindow"] = true
L["SpellQueueWindow_DESC"] = "Before allowing the release skill request to be sent to the server, determine how far in advance the release can be from the end of the release to the start of the release. That is, it has the ability to control the latency built into the queuing system. Ideally, you will want to set this to in-game delay \r\r default: 400"
L["combatText"] = true
L["WorldTextScale"] = true
L["WorldTextScale_DESC"] = "Display ratio of in-game damage value, experience value, gain and other values \r\r default: 1.0"
L["targetCombatText"] = true
L["floatingCombatTextCombatDamage"] = true
L["floatingCombatTextCombatDamage_DESC"] = "Show your damage to target \r\r default: on"
L["floatingCombatTextCombatLogPeriodicSpells"] = true
L["floatingCombatTextCombatLogPeriodicSpells_DESC"] = "Display periodic damage values such as tear and shadow word: pain \r\r default: on"
L["floatingCombatTextPetMeleeDamage"] = true
L["floatingCombatTextPetMeleeDamage_DESC"] = "Show damage caused by your pet \r\r default: on"
L["floatingCombatTextCombatDamageDirectionalScale"] = true
L["floatingCombatTextCombatDamageDirectionalScale_DESC"] = "Default: 1"
L["floatingCombatTextCombatHealing"] = true
L["floatingCombatTextCombatHealing_DESC"] = "Show your target amount of therapy \r\r default: on"
L["floatingCombatTextCombatHealingAbsorbTarget"] = true
L["floatingCombatTextCombatHealingAbsorbTarget_DESC"] = "Show your increased shield absorption to target \r\r default: on"
L["floatingCombatTextSpellMechanics"] = true
L["floatingCombatTextSpellMechanics_DESC"] = "Show your effects on the target, such as silence and entrapment \r\r default: off"
L["floatingCombatTextSpellMechanicsOther"] = true
L["floatingCombatTextSpellMechanicsOther_DESC"] = "Show other player effects on target, such as silence and entrapment \r\r default: off"
L["playerCombatText"] = true
L["enableFloatingCombatText"] = true
L["enableFloatingCombatText_DESC"] = "Tick this box to display additional combat information on screen \r\r default: off"
L["floatingCombatTextFloatMode"] = true
L["floatingCombatTextFloatMode_DESC"] = "Setting the scrolling direction of battle information \r\r default: scroll up"
L["FloatModeUp"] = true
L["FloatModeDown"] = true
L["FloatModeARC"] = true
L["floatingCombatTextDodgeParryMiss"] = true
L["floatingCombatTextDodgeParryMiss_DESC"] = "If the enemy's attack is not hit, or is evaded or parried by the player, \r\r display information by default: off"
L["floatingCombatTextCombatHealingAbsorbSelf"] = true
L["floatingCombatTextCombatHealingAbsorbSelf_DESC"] = "Display information when player gets shield \r\r default: on"
L["floatingCombatTextDamageReduction"] = true
L["floatingCombatTextDamageReduction_DESC"] = "Display information \r\r when player resists attack or spell: off by default"
L["floatingCombatTextLowManaHealth"] = true
L["floatingCombatTextLowManaHealth_DESC"] =  "Displays when player health or mana is below 20per \r\r default: on"
L["floatingCombatTextRepChanges"] = true
L["floatingCombatTextRepChanges_DESC"] = "Display information \r\r when player's reputation in a faction increases or decreases by default: off"
L["floatingCombatTextEnergyGains"] = true
L["floatingCombatTextEnergyGains_DESC"] = "Display all instantly acquired mana, rage, energy and true gas values \r\r default: off"
L["floatingCombatTextComboPoints"] = true
L["floatingCombatTextComboPoints_DESC"] = "When players get new combo points, display the number of combo points \r\r default: off"
L["floatingCombatTextReactives"] = true
L["floatingCombatTextReactives_DESC"] = "Show alarm when special important time occurs  \r\r default: on"
L["floatingCombatTextPeriodicEnergyGains"] = true
L["floatingCombatTextPeriodicEnergyGains_DESC"] = "Show all periodic mana, rage and energy values \r\r default: off"
L["floatingCombatTextFriendlyHealers"] = true
L["floatingCombatTextFriendlyHealers_DESC"] = "When the friendly caster casts healing spells on the player, show the friendly name \r\r default: off"
L["floatingCombatTextHonorGains"] = true
L["floatingCombatTextHonorGains_DESC"] = "Show honor value of player by killing other players \r\r default: off"
L["floatingCombatTextCombatState"] = true
L["floatingCombatTextCombatState_DESC"] = "When a player enters or leaves the combatant displays information \r\r default: off"
L["floatingCombatTextAuras"] = true
L["floatingCombatTextAuras_DESC"] = "Display information when player gains or loses halo effect \r\r default: off"
L["unitframes"] = true
L["noBuffDebuffFilterOnTarget"] = true
L["noBuffDebuffFilterOnTarget_DESC"] = "Buff and Debuff for non-player with unfiltered target, show all \r\r: off by default"
L["threatShowNumeric"] = true
L["threatShowNumeric_DESC"] = "Ticked to show threat value as a percentage \r\r default: off"
L["nameplates"] = true
L["nameplateMaxDistance"] = true
L["nameplateMaxDistance_DESC"] = "The most distance displayed on name board \r\r default: 60"
L["nameplateOtherAtBase"] = true
L["nameplateOtherAtBase_DESC"] = "Name board displayed on model location \r\r default:"
L["ShowClassColorInFriendlyNameplate"] = true
L["ShowClassColorInFriendlyNameplate_DESC"] = "Display professional color on friend name board \r\r default: on"
L["nameplatePersonalShowAlways"] = true
L["nameplatePersonalShowAlways_DESC"] = "After opening the system to display personal resources, always display personal resources \r\r default: off"
L["nameplatePersonalShowWithTarget"] = true
L["nameplatePersonalShowWithTarget_DESC"] = "After opening the system to display personal resources displays personal resources when the player has a target \r\r default: off"
L["nameplatePersonalShowInCombat"] = true
L["nameplatePersonalShowInCombat_DESC"] = "After opening the system to display personal resources, players always display personal resources in battle \r\r default: on"
L["nameplateOtherTopInset"] = true
L["nameplateOtherTopInset_DESC"] = "Set the distance between the target nameplate and the top of the screen, and keep the target nameplate in the screen. Item \r\r default: 0.08"
L["nameplateOverlapV"] = true
L["nameplateOverlapV_DESC"] = "If name plates are stacked, set the spacing between name plates \r\r default: 1.1"
L["nameplateMotionSpeed"] = true
L["nameplateMotionSpeed_DESC"] = "Setting the fastest moving speed of nameplate \r\r default: 0.025"
L["nameplateGlobalScale"] = true
L["nameplateGlobalScale_DESC"] = "Setting name board size ratio \r\r default: 1"
L["nameplateMinScale"] = true
L["nameplateMinScale_DESC"] = "According to the distance of the nameplate from the lens, the nameplate displays the minimum proportion, the minimum proportion at the furthest. Item \r\r default: 0.8"
--filters
L["filters"] = true
L["infoFilter"] = true
L["debugFilter"] = true
L["noPMSticky"] = true
L["repeatFilter"] = true
L["keywordMatchNum"] = true
L["emoticonMatchNum"] = true
L["keywordFilter"] = true
L["addKeyword"] = true
L["delKeyword"] = true
L["delChoisedKeywords"] = true
L["delAllKeywords"] = true
L["keywordBlacklist"] = true
L["pmFilter"] = true
L["demoLevel"] = true
L["levelFilter"] = true
L["DKLevelFilter"] = true
L["DHLevelFilter"] = true
L["playerFilter"] = true
L["nameFilter"] = true
L["addPlayer"] = true
L["delPlayer"] = true
L["delChoisedPlayers"] = true
L["delAllPlayers"] = true
L["playerBlacklist"] = true

--quest
L["quest"] = true
L["questAutomation"] = true
L["QuestFrameAutomationBtn"] = "Automation"
L["autoChoices"] = true
L["frameBtn"] = true
L["frameBtnElvUI"] = true
L["questAnnouncment"] = true
L["QuestFrameAnnouncmentBtn"] = "Announcment"
L["questSolo"] = "solo"
L["questParty"] = "party"
L["questRaid"] = "raid"
L["questInstance"] = "inInstance"
L["questNoDetail"] = "noDetail"
L["questListEnhanced"] = true
L["questTitleColor"] = true
L["questList"] = true
L["titleFont"] = true
L["titleFontSize"] = true
L["titleFontFlag"] = true
L["infoFont"] = true
L["infoFontSize"] = true
L["infoFontFlag"] = true
L["questLevel"] = true
L["titleLevel"] = true
L["detailLevel"] = true
L["ignoreHighLevel"] = true
L["questFrame"] = true
L["frameTitle"] = true
L["leftSide"] = true
L["leftSideSize"] = true
--unitframes
L["unitframes"] = true
L["playerframe"] = true
L["gcdBar"] = true
L["swingBar"] = true
L["swingBarColor"] = true
L["swingBarWidth"] = true
L["swingBarHeight"] = true
L["remainingText"] = true
L["durationText"] = true
L["swingBarFontName"] = true
L["swingBarFontSize"] = true
L["swingBarFontFlag"] = true
L["targetframe"] = true
L["rangeText"] = true
L["rangeFontName"] = true
L["rangeFontSize"] = true
L["rangeFontFlag"] = true
L["rangePoi"] = true
L["rangePoiX"] = true
L["rangePoiY"] = true
L["focusframe"] = true

L["chatBar_says"] = "S"
L["chatBar_yells"] = "Y"
L["chatBar_G"] = "G"
L["chatBar_O"] = "O"
L["chatBar_P"] = "P"
L["chatBar_R"] = "R"
L["chatBar_RW"] = "W"
L["chatBar_I"] = "I"
L["chatBar_BG"] = "B"
L["chatBar"] = true
L["chatIME"] = true
L["chatTradeLog"] = true
L["tradeSendChat"] = true
L["chatMSGLoot"] = true
L["chatMSGLootGS"] = true
L["chatRepChange"] = true
L["roll 1-100"] = true
L["bigFootChannel"] = true
L["Enable/DisableBigFootChannel"] = true
--misc
--general
L["rightButtonMenu"] = true
L["disableTalking"] = true
L["alreadyKnown"] = true
L["autoRelease"] = true
L["color"] = true
L["classColors"] = true
L["autoScreenShoot"] = true
L["autoDelete"] = true
L["autoRepChange"] = true
L["talentProfiles"] = true
L["talentButtonElvUI"] = true
L["screenFormat"] = true
L["screenQuality"] = true
L["MOUSEBUTTON1"] = "Left mouse button"
L["MOUSEBUTTON2"] = "Right mouse button"
L["MOUSEBUTTON3"] = "Middle mouse button"
L["MOUSEBUTTON4"] = "Mouse 4 button"
L["MOUSEBUTTON5"] = "Mouse 5 button"
L["setPoi"] = true
L["poiCombat"] = true
L["poiColor"] = true
L["poiText"] = true
L["poiTextSize"] = true
L["inviteGroup"] = true
L["ainvkeyword"] = true
L["inviteRank"] = true
L["refreshRank"] = true
L["startInvite"] = true
L["LUI_INVITEGROUP_MSG"] = "Members of order %s will be invited into the group after 10 seconds."
--loot
L["loot"] = true
L["fastLoot"] = true
L["lootSpeed"] = true
--actionbars
L["actionbars"] = true
L["randomHearthstone"] = true
L["creatRHS"] = true
--armory
L["armory"] = true
--blizzard
L["blizzard"] = true
L["castbarTime"] = true
L["minimapWheel"] = true
--combat
L["combatNotification"] = true
L["combatNotiEntering"] = true
L["combatNotiLeaving"] = true
L["combatNotiFont"] = true
L["combatNotiSize"] = true
L["combatNotiFlag"] = true
L["combatShortcut"] = true
L["raidMarkingKey"] = true
L["raidMarkingButton"] = true
L["setFocusKey"] = true
L["setFocusButton"] = true
L["announceSystem"] = true
L["raidSpells"] = true
L["resAndThreatSpells"] = true
L["resAndThreat"] = true
L["resThanks"] = true
L["taunt"] = true
L["playerSmart"] = true
L["includeMiss"] = true
L["otherTankSmart"] = true
L["includeOtherTank"] = true
L["petSmart"] = true
L["includePet"] = true
--maps
L["maps"] = true
L["whoClickMinimap"] = true
L["minimapIcons"] = true
L["chooseMinimap"] = true
L["square"] = true
L["buttons"] = true
L["squareMinimapDC"] = true
L["backdrop"] = true
L["barMouseOver"] = true
L["hideInCombat"] = true
L["iconSize"] = true
L["buttonSpacing"] = true
L["buttonsPerRow"] = true
L["visibility"] = true
L["moveTracker"] = true
L["moveQueue"] = true
L["moveMail"] = true
L["hideGarrison"] = true
L["moveGarrison"] = true
--tooltip
L["tooltip"] = true
L["tooltipIcon"] = true
L["raidProg"] = true
L["Short"] = true
L["nameStyle"] = true
L["difStyle"] = true
L["raids"] = true
--skins
L["skins"] = true
L["statusbar"] = true
--special
L["special"] = true
--TeamStats
L["teamStats"] = true

L["BtnRescanText"] = "Reacquire"
L["BtnRescanTipTitle"] = "Regain talent/costume/jewelry info"
L["BtnRescanTip"] = "To reduce resource consumption, the plug-in does not update the member information in real time. Please select the member to be updated and click this button."

L["BtnAnnText"] = "Information broadcast"
L["BtnAnnTipTitle"] = "Information broadcast"
L["BtnAnnTip"] = "Please post the information of selected members to the team channel. Please choose carefully to prevent refresh and disputes."
L["BtnAnnPopupText"] = "Are you sure you want to broadcast |cffff7f00[%d]|r message to |cffff7f00[%s]|r channel?"
L["BtnAnnNoSelect"] = "Please select at least one member"

L["TitleText"] = true
L["HeaderClass"] = CLASS
L["HeaderPlayerName"] = true
L["HeaderGS"] = true
L["HeaderHealth"] = true

L["StatusGetting"] = "Accessing data"
L["StatusCannotGet"] = "There are players too far away to get it."
L["StatusAllDone"] = "All data obtained"
L["StatusPaused"] = "Suspended gain in combat"

L["HUNTER"] = true
L["WARLOCK"] = true
L["PRIEST"] = true
L["PALADIN"] = true
L["MAGE"] = true
L["ROGUE"] = true
L["DRUID"] = true
L["SHAMAN"] = true
L["WARRIOR"] = true
L["DEATHKNIGHT"] = true

L["MiniTipTitle"] = "Team stats"
L["MiniTip"] = "Open the statistics screen of team information, and focus on the talent, loading and dungeon kill status of all team members. The icon flashes to indicate the newly acquired data."

--AtlasLootReverse
L["atlasLootReverse"] = true
L["Drops from %s"] = true
L["Heroic %s"] = true
L["25 Man %s"] = true
L["25 Man Heroic %s"] = true
L["PvP %s Set"] = true
L["Tier %s"] = true

--lootSpecManagerBtn
L["lootSpecManager"] = "Auto switch pickup"
L["lootSpecManagerBtn"] = "Setup specialized pickup"

--rightButtonMenu
L["Armory"] = true
L["Query Detail"] = true
L["Get Name"] = true
L["Guild Invite"] = true
L["Add Friend"] = true
L["Report MyStats"] = true
L["LUIBLACKPLAYER"] = true
--raidprogress
L["RAID_ULDIR"] = "ULDIR"
L["RAID_DAZALOR"] = "DAZALOR"
L["RAID_STORMCRUS"] = "STORMCRUS"

-- ===================== Part for TradeLog ==================
TRADE_LOG_MONEY_NAME = {
gold = "g",
silver = "s",
copper = "c",
}

CANCEL_REASON_TEXT = {
self = "I cancelled it",
other = "target cancelled it",
toofar = "we are too faraway",
selfrunaway = "I moved away",
selfhideui = "I hid ui",
unknown = "unknown reason",
}

TRADE_LOG_SUCCESS_NO_EXCHANGE = "Trade with [%t] was COMPLETED, but no exchange made."
TRADE_LOG_SUCCESS = "Trade with [%t] was COMPLETED."
TRADE_LOG_DETAIL = "Detail"
TRADE_LOG_CANCELLED = "Trade with [%t] was CANCELLED: %r."
TRADE_LOG_FAILED = "Trade with [%t] was FAILED: %r."
TRADE_LOG_FAILED_NO_TARGET = "Trade FAILED: %r."
TRADE_LOG_HANDOUT = "lost"
TRADE_LOG_RECEIVE = "got"
TRADE_LOG_ENCHANT = "enchant"
TRADE_LOG_ITEM_NUMBER = "%d items"
TRADE_LOG_CHANNELS = {
whisper = "Whisper",
raid = "Raid",
party = "Party",
say = "Say",
yell = "Yell",
}
TRADE_LOG_ANNOUNCE = "NOTIFY"
TRADE_LOG_ANNOUNCE_TIP = "Check this to automatically announce after trading."

TRADE_LOG_RESULT_TEXT_SHORT = { 
cancelled = "cancel", 
complete = "ok", 
error = "failed", 
}

TRADE_LOG_RESULT_TEXT = {
cancelled = "Trade Cancelled", 
complete = "Trade Completed", 
error = "Trade Failed", 
}

TRADE_LOG_MONTH_SUFFIX = "-"
TRADE_LOG_DAY_SUFFIX = ""

TRADE_LOG_COMPLETE_TOOLTIP = "Click to show detail"


RECENT_TRADE_TIME = "%d %s ago"
RECENT_TRADE_TITLE = "Recent Trade"

-- ===================== Part for TradeList ==================
TRADE_LIST_CLEAR_HISTORY = "CLEAR"
TRADE_LIST_SCALE = "Detail Scale"
TRADE_LIST_FILTER = "Completed Only"

TRADE_LIST_HEADER_WHEN = "Time"
TRADE_LIST_HEADER_WHO = "Recipent"
TRADE_LIST_HEADER_WHERE = "Location"
TRADE_LIST_HEADER_SEND = "Lost"
TRADE_LIST_HEADER_RECEIVE = "Got"
TRADE_LIST_HEADER_RESULT = "Result"

TRADE_LIST_CLEAR_CONFIRM = "Records before today will be totally cleared!"

TRADE_LIST_TITLE = "TradeLog"
TRADE_LIST_DESC = "Show recent trade logs, or the reasons of failed trades."

L["castbarTarget"] = "Show cast bar target"
L["wipeDB"] = "Reset database"
L["wipeDB_DESC"] = "Use when the function cannot be shut down normally"
--ElvUI
L["Item Level:"] = true
--blizzard
L["blizzardMoveFrames"] = true
L["remember"] = true
L["errorframe"] = true
L["width"] = true
L["height"] = true

--bags
L["bags"] = true
L["moveElvUIBags"] = true

--media
L["media"] = true
L["questHeader"] = true
L["fontcolor"] = true
L["fontName"] = true
L["fontSize"] = true
L["fontFlag"] = true
L["questTrackerTitle"] = true
L["questTrackerInfo"] = true
L["miscTexts"] = true
L["questGossip"] = true
L["questFontSuperHuge"] = true
L["mailText"] = true
L["editboxText"] = true

--Media
L["SLE_MEDIA_ZONES"] = {
"Washington",
"Moscow",
"Moon Base",
"Goblin Spa Resort",
"Illuminati Headquarters",
"Elv's Closet",
"BlizzCon",
}
L["SLE_MEDIA_PVP"] = {
"(Horde Territory)",
"(Alliance Territory)",
"(Contested Territory)",
"(Russian Territory)",
"(Aliens Territory)",
"(Cats Territory)",
"(Japanese Territory)",
"(EA Territory)",
}
L["SLE_MEDIA_SUBZONES"] = {
"Administration",
"Hellhole",
"Alley of Bullshit",
"Dr. Pepper Storage",
"Vodka Storage",
"Last National Bank",
}
L["SLE_MEDIA_PVPARENA"] = {
"(PvP)",
"No Smoking!",
"Only 5% Taxes",
"Free For All",
"Self destruction is in process",
}
L["zoneTexts"] = true
L["testBtn"] = true
L["zoneText"] = true
L["subzoneText"] = true
L["pvpstatusText"] = true

--raid
L["raid"] = true
L["raidManager"] = true

--nameHover
L["nameHover"] = true
L["guildName"] = true
L["guildRank"] = true
L["race"] = true
L["realm"] = true
L["titles"] = true
L["Male"] = true
L["Female"] = true

L["enhancedFriendsList"] = true
L["NameFont"] = true
L["NameFontSize"] = true
L["NameFontFlag"] = true
L["InfoFont"] = true
L["InfoFontSize"] = true
L["InfoFontFlag"] = true
L["GameIconPack"] = true
L["Default"] = true
L["Blizzard Chat"] = true
L["Flat Style"] = true
L["Glossy"] = true
L["Launcher"] = true
L["StatusIconPack"] = true
L["Square"] = true
L["GameIcons"] = true
L["Diablo 3"] = true
L["Hearthstone"] = true
L["Starcraft"] = true
L["Starcraft 2"] = true
L["App"] = true
L["BSAp"] = "Mobile"
L["Hero of the Storm"] = true
L["Overwatch"] = true
L["Destiny 2"] = true
L["Call of Duty 4"] = true
L["StatusIcons"] = true

--microBar
L["microBar"] = true
L["scale"] = true
L["hideInCombat"] = true
L["hideInOrderHall"] = true
L["text"] = true
L["position"] = true
L["Local Time"] = true
L["Realm Time"] = true
L["Faction Assault"] = true
L["Current Invasion: "] = true
L["Next Invasion: "] = true
L["Missing invasion info on your realm."] = true

L["enhancedWorldMap"] = true
L["useReveal"] = true

L["autoButtons"] = true
L["featureconfig"] = true
L["bindFontSize"] = true
L["countFontSize"] = true
L["soltAutoButtons"] = true
L["slotBBColorByItem"] = true
L["slotBBColor"] = true
L["slotNum"] = true
L["slotPerRow"] = true
L["slotSize"] = true
L["questAutoButtons"] = true
L["questBBColorByItem"] = true
L["questBBColor"] = true
L["questNum"] = true
L["questPerRow"] = true
L["questSize"] = true
L["whiteItemID"] = true
L["AddItemID"] = true
L["DeleteItemID"] = true
L["whiteList"] = true
L["blackitemID"] = true
L["AddblackItemID"] = true
L["DeleteblackItemID"] = true
L["blackList"] = true

L["Must is itemID!"] = true
L["is error itemID"] = true

L["Hearthstone Location"] = true
L["finishingMoveHighlight"] = true

L["azerite"] = true
L["skipAzeriteAnimations"] = true
L["azeriteTooltip"] = true
L["removeBlizzard"] = true
L["onlyIcon"] = true
L["onlySpec"] = true
L["bagIcon"] = true
L["bagIconPosition"] = true
L["characterIcon"] = true
L["characterIconPosition"] = true

L["questDirection"] = true
L["slotDirection"] = true

L["enhancedElvUIBank"] = true
L["moveElvUIBank"] = true
L["showBankTab"] = true
L["autoDepositReagents"] = true

L["shareMedia"] = true
L["Teleports"] = true
L["Portals"] = true
L["barBackdrop"] = true
L["borderAlpha"] = true

L["hideMana"] = true
L["elvuiFrames"] = true
L["blizzardFrames"] = true
L["chatItemlevelLink"] = true
L["itemsolt"] = true
L["NameLevel"] = true
L["InfoColor"] = true

L["delete_macro"] = "Are you sure to delete the custom macro?"
L["viiClickSet"] = "Click Cast"
L["MOUSE WHEEL UP"] = "Roll up"
L["MOUSE WHEEL DOWN"] = "Roller Down"
L["customClickSet"] = "Custom Skills and Macros"
L["clickset_newname"] = "Add Skills"
L["clickset_newname_desc"] = "Please enter the skill ID or name you want to add"
L["clickset_newname_err"] = "No skill with corresponding ID or name"
L["clickset_deletename"] = "Delete Skills"
L["clickset_deletename_desc"] = "Please enter the skill ID or name you want to delete"
L["clickset_deletename_err"] = "This skill has not been added"
L["clicksetlist"] = "Custom Skill List"
L["type1"] = "left mouse button"
L["TYPE1_DESC"] = "Use the left mouse button to cast a spell"
L["shiftztype1"] = "Shift + left mouse button"
L["SHIFTZTYPE1_DESC"] = "Use Shift + left mouse button to cast"
L["ctrlztype1"] = "Ctrl + left mouse button"
L["CTRLZTYPE1_DESC"] = "Use Ctrl + left mouse button to cast"
L["altztype1"] = "Alt+left mouse button"
L["ALTZTYPE1_DESC"] = "Use Alt+left mouse button to cast"
L["altzctrlztype1"] = "Alt+Ctrl+left mouse button"
L["ALTZCTRLZTYPE1_DESC"] = "Use Alt+Ctrl+Left mouse button to cast"
L["shiftzaltztype1"] = "Shift+Alt+left mouse button"
L["SHIFTZALTZTYPE1_DESC"] = "Use Shift+Alt+left mouse button to cast"
L["type2"] = "right mouse button"
L["TYPE2_DESC"] = "Use the right mouse button to cast a spell"
L["shiftztype2"] = "Shift + right mouse button"
L["SHIFTZTYPE2_DESC"] = "Use Shift + right mouse button to cast"
L["ctrlztype2"] = "Ctrl + right mouse button"
L["CTRLZTYPE2_DESC"] = "Use Ctrl + right mouse button to cast"
L["altztype2"] = "Alt + right mouse button"
L["ALTZTYPE2_DESC"] = "Use Alt+Right Click to Cast"
L["altzctrlztype2"] = "Alt+Ctrl+right mouse button"
L["ALTZCTRLZTYPE2_DESC"] = "Use Alt+Ctrl+Right mouse button to cast"
L["shiftzaltztype2"] = "Shift+Alt+right mouse button"
L["SHIFTZALTZTYPE2_DESC"] = "Use Shift+Alt+ right mouse button to cast"
L["type3"] = "Mouse middle button"
L["TYPE3_DESC"] = "Use the middle mouse button to cast"
L["shiftztype3"] = "Shift + middle mouse button"
L["SHIFTZTYPE3_DESC"] = "Use Shift + middle mouse button to cast"
L["ctrlztype3"] = "Ctrl + middle mouse button"
L["CTRLZTYPE3_DESC"] = "Use Ctrl + middle mouse button to cast"
L["altztype3"] = "Alt+mouse middle button"
L["ALTZTYPE3_DESC"] = "Use Alt+Mouse Middle to cast a spell"
L["altzctrlztype3"] = "Alt+Ctrl+middle mouse button"
L["ALTZCTRLZTYPE3_DESC"] = "Use Alt+Ctrl+middle mouse button to cast"
L["shiftzaltztype3"] = "Shift+Alt+mouse middle button"
L["SHIFTZALTZTYPE3_DESC"] = "Use Shift+Alt+mouse middle button to cast"
L["type4"] = "Mouse 4 button"
L["TYPE4_DESC"] = "Use the mouse 4 button to cast a spell"
L["shiftztype4"] = "Shift + mouse 4 button"
L["SHIFTZTYPE4_DESC"] = "Use Shift + Mouse 44 to cast a spell"
L["ctrlztype4"] = "Ctrl+Mouse 4"
L["CTRLZTYPE4_DESC"] = "Use Ctrl+Mouse 4 to cast a spell"
L["altztype4"] = "Alt + mouse 4 key"
L["ALTZTYPE4_DESC"] = "Use Alt+Mouse 4 to cast a spell"
L["altzctrlztype4"] = "Alt+Ctrl+4"
L["ALTZCTRLZTYPE4_DESC"] = "Use Alt+Ctrl+Mouse 4 to cast a spell"
L["shiftzaltztype4"] = "Shift+Alt+Mouse 4"
L["SHIFTZALTZTYPE4_DESC"] = "Use Shift+Alt+Mouse 4 to cast a spell"
L["type5"] = "Mouse 5"
L["TYPE5_DESC"] = "Use the mouse 5 button to cast a spell"
L["shiftztype5"] = "Shift+Mouse 5"
L["SHIFTZTYPE5_DESC"] = "Use Shift+Mouse 5 to cast a spell"
L["ctrlztype5"] = "Ctrl+Mouse 5"
L["CTRLZTYPE5_DESC"] = "Use Ctrl+Mouse 5 to cast a spell"
L["altztype5"] = "Alt+Mouse 5"
L["ALTZTYPE5_DESC"] = "Use Alt+Mouse 5 to cast a spell"
L["altzctrlztype5"] = "Alt+Ctrl+Mouse 5"
L["ALTZCTRLZTYPE5_DESC"] = "Use Alt+Ctrl+Mouse 5 to cast a spell"
L["shiftzaltztype5"] = "Shift+Alt+Mouse 5"
L["SHIFTZALTZTYPE5_DESC"] = "Use Shift+Alt+Mouse 5 to cast a spell"
L["typeup"] = "Mouse up wheel"
L["TYPE5UP_DESC"] = "Use the mouse to scroll up the wheel"
L["shiftztypeup"] = "Shift + mouse up wheel"
L["SHIFTZTYPEUP_DESC"] = "Use Shift+Mouse up wheel to cast"
L["ctrlztypeup"] = "Ctrl + mouse up wheel"
L["CTRLZTYPEUP_DESC"] = "Use Ctrl+Mouse to scroll up the wheel"
L["altztypeup"] = "Alt+mouse up wheel"
L["ALTZTYPEUP_DESC"] = "Use Alt+Mouse to scroll up the wheel"
L["altzctrlztypeup"] = "Alt+Ctrl+Mouse Up Wheel"
L["ALTZCTRLZTYPEUP_DESC"] = "Use Alt+Ctrl+Mouse to scroll up"
L["shiftzaltztypeup"] = "Shift+Alt+Mouse Up Wheel"
L["SHIFTZALTZTYPEUP_DESC"] = "Use Shift+Alt+mouse to scroll up the wheel"
L["typedown"] = "Mouse down wheel"
L["TYPEDOWN_DESC"] = "Use the mouse to scroll down the wheel"
L["shiftztypedown"] = "Shift + mouse down wheel"
L["SHIFTZTYPEDOWN_DESC"] = "Use Shift+Mouse down wheel to cast"
L["ctrlztypedown"] = "Ctrl + mouse down wheel"
L["CTRLZTYPEDOWN_DESC"] = "Use Ctrl+Mouse to scroll down the wheel"
L["altztypedown"] = "Alt + mouse down wheel"
L["ALTZTYPEDOWN_DESC"] = "Use Alt+Mouse down wheel to cast"
L["altzctrlztypedown"] = "Alt+Ctrl+Mouse Down Wheel"
L["ALTZCTRLZTYPEDOWN_DESC"] = "Use Alt+Ctrl+Mouse down wheel to cast"
L["shiftzaltztypedown"] = "Shift+Alt+Mouse Down Wheel"
L["SHIFTZALTZTYPEDOWN_DESC"] = "Use Shift+Alt+Mouse down wheel to cast"
L["focus"] = "focus"
L["target"] = "target"
L["blizzardMacro"] = "Load Blizzard Character Dedicated Macro"
L["blizzardFrames"] = "Blizzard Frame"
L["blizzardPartyFrames"] = "Squad"
L["blizzardCompactFrames"] = "Team"
L["blizzardBossFrames"] = "Boss"
L["elvuiPartyFrames"] = "Squad"
L["elvuiRaidFrames"] = "Team"
L["elvuiRaid40Frames"] = "40 people team"
L["elvuiBossFrames"] = "Boss"
L["newMacro"] = "Add a custom macro name"
L["newMacro_desc"] = "Please enter the name of the macro (after entering the name, the following content box will be displayed in the list and the custom macro will not occupy the Blizzard macro command position)"
L["chooseMacro"] = "Select Edit Macro"
L["chooseMacro_desc"] = "Select a macro to edit"
L["delMacro"] = "Select Delete Macro"
L["editMacro"] = "Edit Macro Content"
L["editMacro_desc"] = "Enter the macro content and click Accept to complete the macro creation. The macro of the same content only reflects one in the binding key list (please note the symbol and macro syntax)"

L["presetSpell"] = "Load preset skills"
L["customMacro"] = "Custom Macro"
L["customSpell"] = "Custom Skills"
L["clickSetFrames"] = "Support frame"
L["blizzardPlayerFrame"] = "Player"
L["blizzardPetFrame"] = "Pet"
L["blizzardTargetFrame"] = "Target"
L["blizzardFocusFrame"] = "Focus"
L["elvuiPlayerFrame"] = "Player"
L["elvuiPetFrame"] = "Pet"
L["elvuiTargetFrame"] = "Target"
L["elvuiFocusFrame"] = "Focus"
L["elvuiArenaFrames"] = "Arena"
L["clickset_newMacro_err"] = "Custom macro name cannot be empty"
L["clickset_editMacro_err"] = "Custom macro content cannot be empty"

L["group"] = true
L["lfgMemberInfo"] = true
L["DAMAGER"] = true
L["TANK"] = true
L["hideManaFrames"] = true
L["hideManaRoles"] = true
L["icons"] = true
L["CombatLog"] = true

L["chatShortChannel"] = "Channel Name Abbreviation"
L["hideChannelNum"] = "Hide channel number"
L["channelLen"] = "Channel Name Words"
L["CSCdesc"] = "Disable ElvUI before use - Chat box - Hide channel name and reload"

L["roleIcons"] = true
L["roleIconsdesc"] = true
L["emoteTip"] = true
L["togglemenu"] = true