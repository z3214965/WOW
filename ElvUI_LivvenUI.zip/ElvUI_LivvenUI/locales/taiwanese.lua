local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "zhTW")
if not L then return end

--core
L["LUI_LOGIN_MSG"] = "歡迎使用%s。輸入%s進入設置。若您有任何意見和建議請加戰網: %s。"
L["LUI_ELV_OUTDATED_MSG"] = "您的ElvUI版本低於建議與|cff9482c9LivvenUI|r壹起使用的版本。您的版本是|cfff960d9%.2f|r，建議為|cfff960d9%.2f|r。請更新您的ElvUI以避免錯誤。"

--menu
L["changelog"] = "更新日誌"
L["LUI_CHANGELOG_TITLE"] = "%s - 更新日誌"
L["modules"] = "功能模塊"
L["information"] = "相關信息"
L["support"] = "支持"
L["contactAuthor"] = "聯系作者"
L["version"] = "版本"

L["loginMsg"] = "登錄信息"
L["splashScreen"] = "啟動畫面"
L["gamemenu"] = "菜單畫面"

L["misc"] = "壹般"
L["flashingCursor"] = "鼠標閃光"

L["UP"] = "上"
L["DOWN"] = "下"
L["LEFT"] = "左"
L["RIGHT"] = "右"
L["NONE"] = "無"

L["BOTTOM"] = "底部"
L["BOTTOMLEFT"] = "左下"
L["BOTTOMRIGHT"] = "右下"
L["CENTER"] = "中間"
L["LEFT"] = "左"
L["RIGHT"] = "右"
L["TOP"] = "頂部"
L["TOPLEFT"] = "左上"
L["TOPRIGHT"] = "右上"

L["proximity"] = "鄰近"

--general
L["general"] = "壹般"
--cvar
L["cvar"] = "設置CVar"
L["alwaysCompareItems"] = "裝備鼠標提示對比"
L["alwaysCompareItems_DESC"] = "裝備的鼠標提示總是開啟對比\r\r默認：關閉"
L["breakUpLargeNumbers"] = "大數值逗號顯示"
L["breakUpLargeNumbers_DESC"] = "大數值開啟逗號顯示\r\r默認：開啟"
L["scriptErrors"] = "顯示lua錯誤"
L["scriptErrors_DESC"] = "在聊天框顯示與UI功能相關的錯誤信息\r\r默認：關閉"
L["enableWoWMouse"] = "檢測wow專用鼠標"
L["enableWoWMouse_DESC"] = "啟用此項以啟用魔獸世界專用鼠標並對其進行額外的鍵位綁定\r\r默認：關閉"
L["trackQuestSorting"] = "追蹤任務位置"
L["trackQuestSorting_DESC"] = "新追蹤的任務將被排在目標追蹤的位置\r\r默認：頂部"
L["chat"] = "聊天框"
L["profanityFilter"] = "語言過濾器"
L["profanityFilter_DESC"] = "開啟不良語句過濾\r\r默認：開啟"
L["removeChatDelay"] = "移除聊天標簽延遲"
L["removeChatDelay_DESC"] = "移除聊天標簽彈出延遲\r\r默認：關閉"
L["chatMouseScroll"] = "開啟鼠標滑輪滾動"
L["chatMouseScroll_DESC"] = "勾選以使鼠標在懸停於聊天窗口時可使用滑輪滾動聊天文本\r\r默認：開啟"
L["interface"] = "界面"
L["cameraDistanceMaxZoomFactor"] = "最大鏡頭距離"
L["cameraDistanceMaxZoomFactor_DESC"] = "調節鏡頭在角色身後的最大跟隨距離\r\r默認：1.9"
L["ffxGlow"] = "全屏泛光"
L["ffxGlow_DESC"] = "默認：開啟"
L["weatherDensity"] = "天氣效果"
L["weatherDensity_DESC"] = "默認：3"
L["xpBarText"] = "經驗條數字顯示"
L["xpBarText_DESC"] = "總是在妳的經驗條上顯示文字\r\r默認：開啟"
L["combat"] = "戰鬥"
L["secureAbilityToggle"] = "技能鎖定"
L["secureAbilityToggle_DESC"] = "勾選此項之後，妳將不會因為在短時間內偶然多次點擊快捷鍵而意外取消妳的技能\r\r默認：開啟"
L["stopAutoAttackOnTargetChange"] = "停止自動攻擊"
L["stopAutoAttackOnTargetChange_DESC"] = "當妳切換目標時停止自動攻擊\r\r默認：關閉"
L["assistAttack"] = "協助攻擊"
L["assistAttack_DESC"] = "自動攻擊使用/assist指令選定的目標\r\r默認：關閉"
L["SpellQueueWindow"] = "延遲容限"
L["SpellQueueWindow_DESC"] = "在允許將釋放技能請求發送到服務器之前，確定釋放結束到開始釋放可以提前多遠。也就是說，它控制能力排隊系統的內置延遲。理想情況下，您將希望將此設置為遊戲內延遲\r\r默認：400"
L["combatText"] = "浮動戰鬥信息"
L["WorldTextScale"] = "遊戲文本比例"
L["WorldTextScale_DESC"] = "遊戲內傷害數值、經驗值、增益等數值的顯示比例\r\r默認：1.0"
L["targetCombatText"] = "目標浮動戰鬥信息"
L["floatingCombatTextCombatDamage"] = "傷害"
L["floatingCombatTextCombatDamage_DESC"] = "顯示妳對目標的傷害\r\r默認：開啟"
L["floatingCombatTextCombatLogPeriodicSpells"] = "周期性傷害"
L["floatingCombatTextCombatLogPeriodicSpells_DESC"] = "顯示周期性傷害數值，比如撕裂和暗言術：痛\r\r默認：開啟"
L["floatingCombatTextPetMeleeDamage"] = "寵物傷害"
L["floatingCombatTextPetMeleeDamage_DESC"] = "顯示妳的寵物造成的傷害\r\r默認：開啟"
L["floatingCombatTextCombatDamageDirectionalScale"] = "傷害浮動速度"
L["floatingCombatTextCombatDamageDirectionalScale_DESC"] = "默認：1"
L["floatingCombatTextCombatHealing"] = "治療"
L["floatingCombatTextCombatHealing_DESC"] = "顯示妳對目標的治療量\r\r默認：開啟"
L["floatingCombatTextCombatHealingAbsorbTarget"] = "護盾（目標）"
L["floatingCombatTextCombatHealingAbsorbTarget_DESC"] = "顯示妳對目標增加的護盾吸收量\r\r默認：開啟"
L["floatingCombatTextSpellMechanics"] = "效果"
L["floatingCombatTextSpellMechanics_DESC"] = "顯示目標身上妳的效果，比如沈默和誘捕\r\r默認：關閉"
L["floatingCombatTextSpellMechanicsOther"] = "目標其他玩家的效果"
L["floatingCombatTextSpellMechanicsOther_DESC"] = "顯示目標身上其他玩家的效果，比如沈默和誘捕\r\r默認：關閉"
L["playerCombatText"] = "玩家浮動戰鬥信息"
L["enableFloatingCombatText"] = "開啟玩家浮動信息"
L["enableFloatingCombatText_DESC"] = "勾選此項將在屏幕上直觀顯示額外的戰鬥信息\r\r默認：關閉"
L["floatingCombatTextFloatMode"] = "滾動戰鬥記錄"
L["floatingCombatTextFloatMode_DESC"] = "設置戰鬥信息的滾動方向\r\r默認：向上滾動"
L["FloatModeUp"] = "向上滾動"
L["FloatModeDown"] = "向下滾動"
L["FloatModeARC"] = "弧形"
L["floatingCombatTextDodgeParryMiss"] = "躲閃/招架/未命中"
L["floatingCombatTextDodgeParryMiss_DESC"] = "當敵人的攻擊未命中，或者被玩家躲閃、招架時顯示信息\r\r默認：關閉"
L["floatingCombatTextCombatHealingAbsorbSelf"] = "護盾（玩家）"
L["floatingCombatTextCombatHealingAbsorbSelf_DESC"] = "當玩家獲得護盾時顯示信息\r\r默認：開啟"
L["floatingCombatTextDamageReduction"] = "傷害減免"
L["floatingCombatTextDamageReduction_DESC"] = "當玩家抵抗攻擊或法術時顯示信息\r\r默認：關閉"
L["floatingCombatTextLowManaHealth"] = "生命/法力過低"
L["floatingCombatTextLowManaHealth_DESC"] = "當玩家生命值或法力值低於20%的時候顯示信息\r\r默認：開啟"
L["floatingCombatTextRepChanges"] = "聲望變化"
L["floatingCombatTextRepChanges_DESC"] = "當玩家某個陣營中的聲望提高或降低時顯示信息\r\r默認：關閉"
L["floatingCombatTextEnergyGains"] = "能量獲取"
L["floatingCombatTextEnergyGains_DESC"] = "顯示所有立即獲取的法力值、怒氣值、能量值和真氣值\r\r默認：關閉"
L["floatingCombatTextComboPoints"] = "連擊點數"
L["floatingCombatTextComboPoints_DESC"] = "當玩家獲得新的連擊點時，顯示連擊點的數量\r\r默認：關閉"
L["floatingCombatTextReactives"] = "法術警報"
L["floatingCombatTextReactives_DESC"] = "當特定的重要時間發生時顯示警報\r\r默認：開啟"
L["floatingCombatTextPeriodicEnergyGains"] = "周期性能量獲取"
L["floatingCombatTextPeriodicEnergyGains_DESC"] = "顯示所有周期性獲得的法力值、怒氣值和能量值\r\r默認：關閉"
L["floatingCombatTextFriendlyHealers"] = "友方治療者姓名"
L["floatingCombatTextFriendlyHealers_DESC"] = "當友方施法者對玩家施放治療法術時，顯示友方名字\r\r默認：關閉"
L["floatingCombatTextHonorGains"] = "榮譽消滅"
L["floatingCombatTextHonorGains_DESC"] = "顯示玩家通過殺死其他玩家所得到榮譽值\r\r默認：關閉"
L["floatingCombatTextCombatState"] = "進入/離開戰鬥"
L["floatingCombatTextCombatState_DESC"] = "當玩家進入或脫離戰鬥士顯示信息\r\r默認：關閉"
L["floatingCombatTextAuras"] = "獲得/失去光環"
L["floatingCombatTextAuras_DESC"] = "當玩家獲得或失去光環效果時顯示信息\r\r默認：關閉"
L["unitframes"] = "單位框體"
L["noBuffDebuffFilterOnTarget"] = "顯示非玩家光環"
L["noBuffDebuffFilterOnTarget_DESC"] = "不過濾目標的非玩家施放的Buff和Debuff，顯示全部\r\r默認：關閉"
L["threatShowNumeric"] = "目標頭像仇恨"
L["threatShowNumeric_DESC"] = "勾選此項以百分比形式顯示威脅值\r\r默認：關閉"
L["nameplates"] = "姓名板"
L["nameplateMaxDistance"] = "姓名板顯示距離"
L["nameplateMaxDistance_DESC"] = "姓名板顯示的最遠距離\r\r默認：60"
L["nameplateOtherAtBase"] = "姓名板顯示位置"
L["nameplateOtherAtBase_DESC"] = "姓名板顯示在模型的位置\r\r默認：上"
L["ShowClassColorInFriendlyNameplate"] = "友方姓名板職業色"
L["ShowClassColorInFriendlyNameplate_DESC"] = "開啟友方姓名板時顯示為職業色\r\r默認：開啟"
L["nameplatePersonalShowAlways"] = "永遠顯示個人資源"
L["nameplatePersonalShowAlways_DESC"] = "開啟系統顯示個人資源後，永遠顯示個人資源\r\r默認：關閉"
L["nameplatePersonalShowWithTarget"] = "目標時顯示個人資源"
L["nameplatePersonalShowWithTarget_DESC"] = "開啟系統顯示個人資源後，玩家有目標時顯示個人資源\r\r默認：關閉"
L["nameplatePersonalShowInCombat"] = "戰鬥時顯示個人資源"
L["nameplatePersonalShowInCombat_DESC"] = "開啟系統顯示個人資源後，玩家戰鬥時時顯示個人資源\r\r默認：開啟"
L["nameplateOtherTopInset"] = "目標屏幕上方距離"
L["nameplateOtherTopInset_DESC"] = "設置目標姓名板與屏幕上方的距離，將目標姓名板保持在屏幕內。設置為0時為禁用該功能\r\r默認：0.08"
L["nameplateOverlapV"] = "堆疊姓名板間隔"
L["nameplateOverlapV_DESC"] = "姓名板排列方式為堆疊時，設置姓名板間的間距\r\r默認：1.1"
L["nameplateMotionSpeed"] = "姓名板移動速度"
L["nameplateMotionSpeed_DESC"] = "設置姓名板移動的最快速度\r\r默認：0.025"
L["nameplateGlobalScale"] = "姓名板全局比例"
L["nameplateGlobalScale_DESC"] = "設置姓名板大小比例\r\r默認：1"
L["nameplateMinScale"] = "姓名板鏡頭最小比例"
L["nameplateMinScale_DESC"] = "根據姓名板距離鏡頭的遠近，姓名板顯示的最小比例，最遠時最小比例。設置為1時，不根據鏡頭遠近縮放姓名板\r\r默認：0.8"
--filters
L["filters"] = "過濾屏蔽"
L["infoFilter"] = "信息過濾"
L["debugFilter"] = "調試"
L["noPMSticky"] = "禁用密語粘滯"
L["repeatFilter"] = "重復屏蔽間隔"
L["keywordMatchNum"] = "關鍵詞匹配數量"
L["emoticonMatchNum"] = "表情符號匹配數量"
L["keywordFilter"] = "關鍵詞屏蔽"
L["addKeyword"] = "添加關鍵詞"
L["delKeyword"] = "刪除關鍵詞"
L["delChoisedKeywords"] = "刪除選中關鍵詞"
L["delAllKeywords"] = "刪除所有關鍵詞"
L["keywordBlacklist"] = "關鍵詞黑名單"
L["pmFilter"] = "密語過濾"
L["demoLevel"] = "屏蔽試玩角色密語"
L["levelFilter"] = "密語允許等級"
L["DKLevelFilter"] = "死亡騎士允許等級"
L["DHLevelFilter"] = "惡魔獵手允許等級"
L["playerFilter"] = "玩家過濾"
L["nameFilter"] = "玩家屏蔽"
L["addPlayer"] = "添加玩家"
L["delPlayer"] = "刪除玩家"
L["delChoisedPlayers"] = "刪除選中玩家"
L["delAllPlayers"] = "刪除所有玩家"
L["playerBlacklist"] = "玩家黑名單"

--quest
L["quest"] = "任務"
L["questAutomation"] = "任務交接"
L["QuestFrameAutomationBtn"] = "交接"
L["autoChoices"] = "自動選擇最貴獎勵"
L["frameBtn"] = "任務框體按鈕"
L["frameBtnElvUI"] = "框體按鈕美化"
L["questAnnouncment"] = "任務通報"
L["QuestFrameAnnouncmentBtn"] = "通報"
L["questSolo"] = "個人"
L["questParty"] = "隊伍"
L["questRaid"] = "團隊"
L["questInstance"] = "副本"
L["questNoDetail"] = "非詳細通報"
L["questListEnhanced"] = "任務列表增強"
L["questTitleColor"] = "標題職業色"
L["questList"] = "任務列表"
L["titleFont"] = "標題字體"
L["titleFontSize"] = "標題字體大小"
L["titleFontFlag"] = "標題字體描邊"
L["infoFont"] = "信息字體"
L["infoFontSize"] = "信息字體大小"
L["infoFontFlag"] = "信息字體描邊"
L["questLevel"] = "任務等級"
L["titleLevel"] = "任務標題等級"
L["detailLevel"] = "任務日誌等級"
L["ignoreHighLevel"] = "忽略最高等級"
L["questFrame"] = "任務框體"
L["frameTitle"] = "任務框體標題"
L["leftSide"] = "折疊按鈕移至左側"
L["leftSideSize"] = "折疊按鈕大小"
--unitframes
L["unitframes"] = "單位框架"
L["playerframe"] = "玩家框體"
L["gcdBar"] = "GCD計時條"
L["swingBar"] = "平砍計時條"
L["swingBarColor"] = "顏色"
L["swingBarWidth"] = "寬"
L["swingBarHeight"] = "高"
L["remainingText"] = "剩余時間文本"
L["durationText"] = "持續時間文本"
L["swingBarFontName"] = "字體"
L["swingBarFontSize"] = "字體大小"
L["swingBarFontFlag"] = "字體描邊"
L["targetframe"] = "目標框體"
L["rangeText"] = "距離"
L["rangeFontName"] = "字體"
L["rangeFontSize"] = "字體大小"
L["rangeFontFlag"] = "字體描邊"
L["rangePoi"] = "位置"
L["rangePoiX"] = "X方向偏移"
L["rangePoiY"] = "Y方向偏移"
L["focusframe"] = "焦點框體"

L["chatBar_says"] = "說"
L["chatBar_yells"] = "喊"
L["chatBar_G"] = "公"
L["chatBar_O"] = "官"
L["chatBar_P"] = "隊"
L["chatBar_R"] = "團"
L["chatBar_RW"] = "警"
L["chatBar_I"] = "副"
L["chatBar_BG"] = "戰"
L["chatBar"] = "頻道條"
L["chatBar_DESC"] = "頻道條包含頻道切換條TAB切換屬性通報聊天表情ROLL點加入/離開組隊頻道"
L["chatBarPoi"] = "聊天條位置"
L["chatBarPoi_DESC"] = "內嵌暫時只能通過拉高左聊天框，暫無法減小文字框高度還原聊天框整體高度，待更新"
L["chatBub_MSG"] = "聊天氣泡"	
L["chatBub"] = "智能聊天氣泡"
L["smartChatBub_DESC"] = "進入副本自動開啟聊天氣泡，出副本自動關閉，防止廣告騷擾"
L["chatBubTip"] = "顯示聊天提示"
L["smartChatBubTip_DESC"] = "進入遊戲以及切換地圖時，將在聊天框提示目前氣泡開啟/關閉狀態"
L["chatTradeLog"] = "交易記錄提醒"
L["tradeLog_DESC"] = "對話框內顯示交易對象及交易情況"
L["tradeSendChat"] = "密語交易對象"
L["tradeSendChat_DESC"] = "將交易情況以密語的形式告知交易對象"
L["chatMSGLoot"] = "戰利記錄增強"
L["chatMSGLoot_DESC"] = "戰利品記錄玩家將以職業色顯示，且可以直接點擊密語"
L["chatMSGLootGS"] = "顯示玩家裝等"
L["chatMSGLootGS_DESC"] = "若已開啟<團隊信息統計>並已獲取到該玩家裝等，戰利品記錄玩家姓名後會添加該玩家裝等"
L["chatRepChange"] = "智能聲望顯示"
L["chatMSGLootGS_DESC"] = "聊天框顯示聲望獲取情況，包括巔峰聲望以及可兌換獎勵提醒"
L["roll 1-100"] = "Roll 1-100"
L["bigFootChannel"] = "組隊頻道"
L["Enable/DisableBigFootChannel"] = "加入/離開組隊頻道"
--misc
--general
L["rightButtonMenu"] = "右鍵菜單增強"
L["disableTalking"] = "禁用劇情對話框"
L["alreadyKnown"] = "已學物品染色"
L["autoRelease"] = "戰場自動釋放"
L["color"] = "顏色"
L["classColors"] = "好友職業染色"
L["autoScreenShoot"] = "成就自動截圖"
L["autoDelete"] = "自動填入DELETE"
L["autoRepChange"] = "聲望自動追蹤"
L["talentProfiles"] = "天賦配置管理"
L["talentButtonElvUI"] = "天賦按鈕美化"
L["screenFormat"] = "圖片格式"
L["screenQuality"] = "圖片質量"
L["mouseButton1"] = "鼠標左鍵"
L["mouseButton2"] = "鼠標右鍵"
L["mouseButton3"] = "鼠標中鍵"
L["mouseButton4"] = "鼠標側鍵"
L["setPoi"] = "屏幕中心指示器"
L["poiCombat"] = "戰鬥切換"
L["poiColor"] = "指示器顏色"
L["poiText"] = "指示器形狀"
L["poiTextSize"] = "指示器大小"
--inviteGroup
L["inviteGroup"] = "便捷組隊"
L["ainvkeyword"] = "自動組隊關鍵詞"
L["inviteRank"] = "按公會級別邀請成員進團"
L["refreshRank"] = "刷新級別"
L["startInvite"] = "發起邀請"	
L["LUI_INVITEGROUP_MSG"] = "會階為 %s 的成員,將在10秒後被邀請進團"
--loot
L["loot"] = "拾取"
L["fastLoot"] = "光速拾取"
L["fastLoot_DESC"] = "必須先遊戲內設置開啟自動拾取"
L["lootSpeed"] = "拾取速度"
L["lootSpeed_DESC"] = "遊戲自帶自動拾取默認間隔為300ms，光速為0ms，極快100ms，稍快200ms"
--actionbars
L["actionbars"] = "動作條"
L["randomHearthstone"] = "隨機爐石玩具"
L["creatRHS"] = "創建爐石宏"
--armory
L["armory"] = "角色信息"
--blizzard
L["blizzard"] = "暴雪界面"
L["castbarTime"] = "施法條計時"
L["minimapWheel"] = "小地圖滾輪"
--combat
L["combatNotification"] = "戰鬥提示"
L["combatNotiEntering"] = "進入戰鬥提示"
L["combatNotiLeaving"] = "離開戰鬥提示"
L["combatNotiFont"] = "提示預設字體"
L["combatNotiSize"] = "提示字體大小"
L["combatNotiFlag"] = "提示字體描邊"
L["combatShortcut"] = "戰鬥快捷鍵"
L["raidMarkingKey"] = "快速團隊標記"
L["raidMarkingButton"] = "標記快捷鍵"
L["setFocusKey"] = "快速設置焦點"
L["setFocusButton"] = "焦點快捷鍵"
L["announceSystem"] = "技能通告"
L["raidSpells"] = "團隊技能通告"
L["raidSpells_DESC"] = "包括FS餐桌/傳送門；SS靈魂之井/召喚儀式；大餐/機器人/郵箱及部分玩具等"
L["resAndThreatSpells"] = "戰復/誤導通告"
L["resAndThreat"] = "戰復/誤導"
L["resThanks"] = "戰復感謝"
L["taunt"] = "嘲諷通告"
L["taunt_DESC"] = "開啟後在所處團隊/隊伍/副本環境中通告"
L["include_DESC"] = "開啟後僅在聊天框中顯示而不進行通告"
L["playerSmart"] = "玩家智能通告"
L["includeMiss"] = "包括嘲諷失敗"
L["otherTankSmart"] = "其他坦克智能通告"
L["includeOtherTank"] = "包括其他坦克"
L["petSmart"] = "寵物智能通告"
L["includePet"] = "包括寵物"
--maps
L["maps"] = "地圖"
L["whoClickMinimap"] = "顯示小地圖點擊者"
L["minimapIcons"] = "小地圖圖標"
L["chooseMinimap"] = "選擇圖標方式"
L["square"] = "收集"
L["buttons"] = "按鈕"
L["squareMinimapDC"] = "延展方向"
L["backdrop"] = "背景"
L["barMouseOver"] = "鼠標滑過顯示"
L["hideInCombat"] = "戰鬥中隱藏"
L["iconSize"] = "圖標大小"
L["buttonSpacing"] = "按鈕間距"
L["buttonsPerRow"] = "每行按鈕數"
L["visibility"] = "可見狀態"
L["moveTracker"] = "收集追蹤圖標"
L["moveQueue"] = "收集隊列圖標"
L["moveMail"] = "收集郵件圖標"
L["hideGarrison"] = "隱藏任務圖標"
L["moveGarrison"] = "收集任務圖標"
--tooltip
L["tooltip"] = "鼠標提示"
L["tooltipIcon"] = "顯示陣營圖標"
L["raidProg"] = "顯示團本成就"
L["Short"] = "短"
L["nameStyle"] = "團本名字風格"
L["difStyle"] = "團本難度風格"
L["raids"] = "團隊副本"
--skins
L["skins"] = "材質皮膚"
L["statusbar"] = "材質包"
--special
L["special"] = "特殊"
--TeamStats
L["teamStats"] = "團隊信息統計"

L["BtnRescanText"] = "重新獲取"
L["BtnRescanTipTitle"] = "重新獲取天賦/裝等/珠寶信息"
L["BtnRescanTip"] = "為了減少資源占用,插件並不會實時更新成員信息，請選中要更新的成員後點擊此按鈕"

L["BtnAnnText"] = "信息廣播"
L["BtnAnnTipTitle"] = "信息廣播"
L["BtnAnnTip"] = "將選中團員的信息發布到團隊頻道, 請謹慎選擇, 防止刷屏和糾紛。"
L["BtnAnnPopupText"] = "確定廣播|cffff7f00[%d]|r條信息到|cffff7f00[%s]|r頻道嗎?"
L["BtnAnnNoSelect"] = "請至少選擇壹個團員"

L["TitleText"] = "團隊信息統計"
L["HeaderClass"] = CLASS
L["HeaderPlayerName"] = "成員名稱"
L["HeaderGS"] = "裝等"
L["HeaderHealth"] = "血量"

L["StatusGetting"] = "正在獲取資料"
L["StatusCannotGet"] = "有玩家距離過遠,無法獲得"
L["StatusAllDone"] = "全部資料獲取完畢"
L["StatusPaused"] = "戰鬥中暫停獲取"

L["HUNTER"]="獵人"
L["WARLOCK"]="術士"
L["PRIEST"]="牧師"
L["PALADIN"]="聖騎"
L["MAGE"]="法師"
L["ROGUE"]="盜賊"
L["DRUID"]="德魯伊"
L["SHAMAN"]="薩滿"
L["WARRIOR"]="戰士"
L["DEATHKNIGHT"]="死騎"

L["MiniTipTitle"] = "團隊信息統計"
L["MiniTip"] = "打開團隊信息統計界面, 集中查看所有團員的天賦、裝等和副本擊殺情況. 圖標閃爍表示有新獲取的數據"

--AtlasLootReverse
L["atlasLootReverse"] = "物品來源查詢"
L["Drops from %s"] = "來源：%s"
L["Heroic %s"] = "|cff00ff00英雄：%s|r"
L["25 Man %s"] = "%s[25]"
L["25 Man Heroic %s"] = "|cff00ff00英雄：%s[25]|r"
L["PvP %s Set"] = "PVP %s級套裝"
L["Tier %s"] = "T%s"

--lootSpecManagerBtn
L["lootSpecManager"] = "自動切換拾取"
L["lootSpecManagerBtn"] = "設置專精拾取"

--rightButtonMenu
L["Armory"] = "英雄榜"
L["Query Detail"] = "查詢玩家"
L["Get Name"] = "獲取名字"
L["Guild Invite"] = "公會邀請"
L["Add Friend"] = "添加好友"
L["Report MyStats"] = "報告裝等"
L["LUIBLACKPLAYER"] = "黑名單"
--raidprogress
L["RAID_ULDIR"] = "奧迪爾"
L["RAID_DAZALOR"] = "達薩羅"
L["RAID_STORMCRUS"] = "風暴熔爐"

-- ===================== Part for TradeLog ==================
TRADE_LOG_MONEY_NAME = {
gold = "g",
silver = "s",
copper = "c",
}

CANCEL_REASON_TEXT = {
self = "我取消了交易",
other = "對方取消了交易",
toofar = "雙方距離過遠",
selfrunaway = "我超出了距離",
selfhideui = "我隱藏了界面,交易窗口關閉",
unknown = "未知原因",
}

TRADE_LOG_SUCCESS_NO_EXCHANGE = "與[%t]交易成功, 但是沒有做任何交換。"
TRADE_LOG_SUCCESS = "與[%t]交易成功。"
TRADE_LOG_DETAIL = "詳情"
TRADE_LOG_CANCELLED = "與[%t]交易取消: %r。"
TRADE_LOG_FAILED = "與[%t]交易失敗: %r。"
TRADE_LOG_FAILED_NO_TARGET = "交易失敗: %r。"
TRADE_LOG_HANDOUT = "交出"
TRADE_LOG_RECEIVE = "收到"
TRADE_LOG_ENCHANT = "附魔"
TRADE_LOG_ITEM_NUMBER = "%d件物品"
TRADE_LOG_CHANNELS = {
whisper = "密語",
raid = "團隊",
party = "小隊",
say = "說",
yell = "喊",
}
TRADE_LOG_ANNOUNCE = "通告"
TRADE_LOG_ANNOUNCE_TIP = "選中就會將交易信息發送到指定的頻道"

TRADE_LOG_RESULT_TEXT_SHORT = { 
cancelled = "取消", 
complete = "成功", 
error = "失敗", 
}

TRADE_LOG_RESULT_TEXT = { 
cancelled = "交易取消", 
complete = "交易成功", 
error = "交易失敗", 
}

TRADE_LOG_MONTH_SUFFIX = "月"
TRADE_LOG_DAY_SUFFIX = "日"

TRADE_LOG_COMPLETE_TOOLTIP = "點擊鼠標左鍵查看交易的詳細信息"


RECENT_TRADE_TIME = "%d%s前"
RECENT_TRADE_TITLE = "近期與此人的交易"

-- ===================== Part for TradeList ==================
TRADE_LIST_CLEAR_HISTORY = "清除記錄"
TRADE_LIST_SCALE = "詳情窗口縮放"
TRADE_LIST_FILTER = "僅列出成功交易"

TRADE_LIST_HEADER_WHEN = "交易時間"
TRADE_LIST_HEADER_WHO = "交易對象"
TRADE_LIST_HEADER_WHERE = "交易地點"
TRADE_LIST_HEADER_SEND = "交出"
TRADE_LIST_HEADER_RECEIVE = "獲得"
TRADE_LIST_HEADER_RESULT = "結果"

TRADE_LIST_CLEAR_CONFIRM = "今天以外的紀錄都將被清除!"
TRADE_LIST_TITLE = "交易記錄"
TRADE_LIST_DESC = "可以查看最近所有的交易記錄，包括失敗的原因。"

L["castbarTarget"] = "顯示施法條目標"
L["wipeDB"] = "重置數據庫"
L["wipeDB_DESC"] = "發生不能正常關閉功能時使用"
--ElvUI
L["Item Level:"] = "裝等:"
--blizzard
L["blizzardMoveFrames"] = "暴雪框體移動"
L["remember"] = "記憶位置"
L["errorframe"] = "錯誤框體"
L["width"] = "寬"
L["height"] = "高"

--bags
L["bags"] = "背包"
L["moveElvUIBags"] = "左鍵移動ElvUI背包"

--media
L["media"] = "材質"
L["questHeader"] = "任務欄標簽文本"
L["fontcolor"] = "字體顏色"
L["fontName"] = "字體"
L["fontSize"] = "字體大小"
L["fontFlag"] = "字體描邊"
L["questTracker"] = "任務欄標題及內容文本"
L["miscTexts"] = "各種文本"
L["questGossip"] = "任務日誌文本"
L["questFontSuperHuge"] = "任務超大文本"
L["mailText"] = "郵件文本"
L["editboxText"] = "聊天輸入框文本"

L["chatBubbles"] = "聊天氣泡"

--Media
L["LUI_MEDIA_ZONES"] = {
"華盛頓",
"莫斯科",
"月球基地",
"妖精溫泉度假勝地",
"光明會總部",
"弱電的衣櫥",
"免費",
}
L["LUI_MEDIA_PVP"] = {
"(部落領土)",
"(聯盟領土)",
"(有爭議的領土)",
"(俄羅斯領土)",
"(外星人的領土)",
"(貓的領土)",
"(中國領土)",
"(EA領土)",
}
L["LUI_MEDIA_SUBZONES"] = {
"管理員",
"地獄",
"廢話巷",
"胡椒博士存儲",
"伏特加存儲",
"失落的國家銀行",
}
L["LUI_MEDIA_PVPARENA"] = {
"(PvP)",
"禁止吸煙!",
"只有5%稅",
"自由",
"自我毀滅正在進行",
}
L["zoneTexts"] = "區域文本"
L["testBtn"] = "測試文本"
L["zoneText"] = "地區文本"
L["subzoneText"] = "分區文本"
L["pvpstatusText"] = "PvP狀態文本"

--raid
L["raid"] = "團隊"
L["raidManager"] = "團隊管理職責圖標"

--nameHover
L["nameHover"] = "角色名懸停"
L["guildName"] = "公會名稱"
L["guildRank"] = "公會級別"
L["race"] = "等級/性別/種族/職業"
L["realm"] = "服務器名稱"
L["titles"] = "頭銜"
L["Male"] = "男"
L["Female"] = "女"

L["enhancedFriendsList"] = "好友列表增強"
L["NameFont"] = "姓名預設字體"
L["NameFontSize"] = "姓名字體大小"
L["NameFontFlag"] = "姓名字體描邊"
L["InfoFont"] = "信息預設字體"
L["InfoFontSize"] = "信息字體大小"
L["InfoFontFlag"] = "信息字體描邊"
L["GameIconPack"] = "遊戲圖標選擇"
L["Default"] = "默認"
L["Blizzard Chat"] = "暴雪聊天框"
L["Flat Style"] = "扁平式"
L["Glossy"] = "光澤式"
L["Launcher"] = "暴雪戰網式"
L["StatusIconPack"] = "狀態圖標選擇"
L["Square"] = "方形"
L["GameIcons"] = "遊戲圖標"
L["Diablo 3"] = "暗黑破壞神 3"
L["Hearthstone"] = "爐石傳說"
L["Starcraft"] = "星際爭霸"
L["Starcraft 2"] = "星際爭霸 2"
L["App"] = "戰網"
L["BSAp"] = "手機app"
L["Hero of the Storm"] = "風暴英雄"
L["Overwatch"] = "守望先鋒"
L["Destiny 2"] = "命運 2"
L["Call of Duty 4"] = "使命召喚 4"
L["StatusIcons"] = "狀態圖標"

L["microBar"] = "微型系統菜單"
L["scale"] = "比例"
L["hideInCombat"] = "戰鬥中隱藏"
L["hideInOrderHall"] = "職業大廳隱藏"
L["text"] = "文本"
L["position"] = "位置"
L["Local Time"] = "本地時間"
L["Realm Time"] = "服務器時間"
L["Faction Assault"] = "突襲"
L["Current Invasion: "] = "當前入侵: "
L["Next Invasion: "] = "下次入侵: "
L["Missing invasion info on your realm."] = "未獲取入侵信息"

L["enhancedWorldMap"] = "大地圖增強"
L["useReveal"] = "地圖全亮"

L["autoButtons"] = "飾品物品按鍵"
L["featureconfig"] = "壹般設置"
L["bindFontSize"] = "鍵位字體大小"
L["countFontSize"] = "數量字體大小"
L["soltAutoButtons"] = "裝備飾品按鍵"
L["slotBBColorByItem"] = "稀有度顏色邊框"
L["slotBBColor"] = "自定義顏色"
L["slotNum"] = "裝備按鈕數量"
L["slotPerRow"] = "每行按鈕數"
L["slotSize"] = "裝備按鈕大小"
L["questAutoButtons"] = "任務物品按鍵"
L["questBBColorByItem"] = "稀有度顏色邊框"
L["questBBColor"] = "自定義顏色"
L["questNum"] = "物品按鈕數量"
L["questPerRow"] = "每行按鈕數"
L["questSize"] = "物品按鈕大小"
L["whiteItemID"] = "物品ID"
L["AddItemID"] = "增加物品ID"
L["DeleteItemID"] = "刪除物品ID"
L["whiteList"] = "物品列表"
L["blackitemID"] = "物品黑名單ID"
L["AddblackItemID"] = "增加物品黑名單ID"
L["DeleteblackItemID"] = "刪除物品黑名單ID"
L["blackList"] = "物品黑名單列表"

L["Must is itemID!"] = "必須是物品ID"
L["is error itemID"] = "是錯誤的物品ID"

L["Hearthstone Location"] = "綁定爐石位置"
L["finishingMoveHighlight"] = "終結技高亮"

L["azerite"] = "艾澤裏特"
L["skipAzeriteAnimations"] = "跳過艾澤裏特動畫"
L["azeriteTooltip"] = "艾澤裏特鼠標提示"
L["removeBlizzard"] = "移除暴雪文字"
L["onlyIcon"] = "僅圖標"
L["onlySpec"] = "僅當前專精"
L["bagIcon"] = "背包角標"
L["bagIconPosition"] = "背包角標位置"
L["characterIcon"] = "角色面板角標"
L["characterIconPosition"] = "角色角標位置"

L["questDirection"] = "物品按鈕延展方向"
L["slotDirection"] = "裝備按鈕延展方向"

L["enhancedElvUIBank"] = "ElvUI銀行增強"
L["moveElvUIBank"] = "左鍵移動ElvUI銀行"
L["showBankTab"] = "自動開啟材料欄"
L["autoDepositReagents"] = "自動存入材料"