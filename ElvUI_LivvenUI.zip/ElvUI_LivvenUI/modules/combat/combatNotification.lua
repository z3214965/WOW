-- 来源：EUI
-- 作者：EUI
-- 链接：
-- 修改：L
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "combat", "combatNotification", "enableBtn") == true then return; end

local LSM = LibStub("LibSharedMedia-3.0");
local LCO = LUI:GetModule("LUICombat");

function LCO:LoadCombatNotification()
	local FadingFrame_Show = FadingFrame_Show;
	local UnitIsDead = UnitIsDead;

	local GetNextChar = function(word,num)
		local c = word:byte(num);
		local shift;
		if not c then return "", num; end
			if (c > 0 and c <= 127) then
				shift = 1;
			elseif (c >= 192 and c <= 223) then
				shift = 2;
			elseif (c >= 224 and c <= 239) then
				shift = 3;
			elseif (c >= 240 and c <= 247) then
				shift = 4;
			end
		return word:sub(num, num + shift - 1), (num + shift);
	end

	local updaterun = T.CreateFrame("Frame");

	local fontname = E.db.lui.modules.combat.combatNotification.combatNotiFont;
	local fontsize = E.db.lui.modules.combat.combatNotification.combatNotiSize;
	local fontflag = E.db.lui.modules.combat.combatNotification.combatNotiFlag;
		
	local flowingframe = T.CreateFrame("Frame",nil,E.UIParent);
	flowingframe:SetFrameStrata("HIGH");
	flowingframe:SetPoint("CENTER",E.UIParent,0,136);
	flowingframe:SetHeight(64);
	flowingframe:SetScript("OnUpdate", FadingFrame_OnUpdate);
	flowingframe:Hide();
	flowingframe.fadeInTime = 0;
	flowingframe.holdTime = 1;
	flowingframe.fadeOutTime = .3;
	
	local flowingtext = flowingframe:CreateFontString(nil,"OVERLAY");
		flowingtext:SetPoint("Left");
		flowingtext:FontTemplate(LSM:Fetch("font", fontname), fontsize, fontflag);
		flowingtext:SetShadowOffset(0,0);
		flowingtext:SetJustifyH("LEFT");
		
	local rightchar = flowingframe:CreateFontString(nil,"OVERLAY");
		rightchar:SetPoint("LEFT",flowingtext,"RIGHT");
		rightchar:FontTemplate(LSM:Fetch("font", fontname), fontsize * 2, fontflag);
		rightchar:SetShadowOffset(0,0);
		rightchar:SetJustifyH("LEFT");

	local count, len, step, word, stringE, a;

	local speed = .03333;

	local nextstep = function()
		a,step = GetNextChar(word,step);
		flowingtext:SetText(stringE);
		stringE = stringE .. a;
		a = T.upper(a);
		rightchar:SetText(a);
	end

	local updatestring = function(self, t)
		count = count - t;
		if count < 0 then
			if step > len then 
				self:Hide();
				flowingtext:SetText(stringE);
				FadingFrame_Show(flowingframe);
				rightchar:SetText("");
				word = "";
			else 
				nextstep();
				FadingFrame_Show(flowingframe);
				count = speed;
			end
		end
	end

	updaterun:SetScript("OnUpdate",updatestring);
	updaterun:Hide();

	E.LvCombatNotiRun = function(f,r,g,b)
		flowingframe:Hide();
		updaterun:Hide();
		
		flowingtext:SetText(f);
		local l = flowingtext:GetWidth();
			
		local color1 = r or 1;
		local color2 = g or 1;
		local color3 = b or 1;
		
		flowingtext:SetTextColor(color1 * .95,color2 * .95,color3 * .95);
		rightchar:SetTextColor(color1,color2,color3);
		
		word = f;
		len = f:len();
		step = 1;
		count = speed;
		stringE = "";
		a = "";
		
		flowingtext:SetText("");
		flowingframe:SetWidth(l);
			
		rightchar:SetText("");
		FadingFrame_Show(flowingframe);
		updaterun:Show();
	end
	
	local CombatNotification = T.CreateFrame ("Frame");
	
	CombatNotification:RegisterEvent("PLAYER_REGEN_ENABLED");
	CombatNotification:RegisterEvent("PLAYER_REGEN_DISABLED");
	CombatNotification:SetScript("OnEvent", function (self,event)
		if (UnitIsDead("player")) then return; end
		if event == "PLAYER_REGEN_ENABLED" then
			E.LvCombatNotiRun(E.db.lui.modules.combat.combatNotification.combatNotiLeaving,0.1,1,0.1);
		elseif event == "PLAYER_REGEN_DISABLED" then
			E.LvCombatNotiRun(E.db.lui.modules.combat.combatNotification.combatNotiEntering,1,0.1,0.1);
		end
	end)
end