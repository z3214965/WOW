local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LCO = LUI:NewModule("LUICombat");

function LCO:Initialize()
	if E.db.lui.modules.combat.combatNotification["enableBtn"] then self:LoadCombatNotification(); end
	if E.db.lui.modules.combat.announceSystem["enableBtn"] then self:LoadAnnounceSystem(); end
	if E.db.lui.modules.combat.combatShortcut.setFocusKey.setFocusButton1 ~= "none" then self:LoadSetFocusKey(); end
	if E.db.lui.modules.combat.combatShortcut.raidMarkingKey.raidMarkingButton1 ~= "none" then self:LoadRaidMarkingKey(); end
end

local function InitializeCallback()
	LCO:Initialize();
end

LUI:RegisterModule(LCO:GetName(), InitializeCallback);
