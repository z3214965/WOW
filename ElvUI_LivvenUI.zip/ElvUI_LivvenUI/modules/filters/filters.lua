local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LFI = LUI:NewModule("LUIFilters");

function LFI:Initialize()
    if E.global.lui.modules.filters.infoFilter["enableBtn"] then self:LoadInfoFilter(); end
    if E.global.lui.modules.filters.pmFilter["enableBtn"] then self:LoadPMFilter(); end
end

local function InitializeCallback()
	LFI:Initialize();
end

LUI:RegisterModule(LFI:GetName(), InitializeCallback);
