local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LMA = LUI:NewModule("LUIMaps", "AceEvent-3.0");

function LMA:Initialize()
	if E.db.lui.modules.maps.squareMinimap["enableBtn"] then self:LoadSquareMinimap(); end
	if E.db.lui.modules.maps["whoClickMinimap"] then self:LoadWhoClickMinimap(); end
end

local function InitializeCallback()
	LMA:Initialize();
end

LUI:RegisterModule(LMA:GetName(), InitializeCallback);
