local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LAB = LUI:NewModule("LUIActionbars");

function LAB:Initialize()
    if E.db.lui.modules.actionbars.randomHearthstone["enableBtn"] then self:LoadRandomHearthStone(); end
end

local function InitializeCallback()
    LAB:Initialize();
end

LUI:RegisterModule(LAB:GetName(), InitializeCallback)
