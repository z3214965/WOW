--来源：NGA
--作者：混乱时雨
--链接：https://bbs.nga.cn/read.php?tid=16385126&_ff=200
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LAB = LUI:GetModule("LUIActionbars");

local HearthStoneList = {
    162973, --冬天爷爷的炉石 278244
    163045, --无头骑士的炉石 278559
    165669, --春节长者的炉石 285362
    165670, --小匹德菲特的可爱炉石
    64488, --旅店老板的女儿
    93672, --黑暗之门
    54452, --虚灵之门
    142542, --城镇传送门 231504
};
local HearthStoneListChecked = {};
local HearthStoneName = {};

local function HearthStoneToUse_UpdateList()
    for k, v in T.ipairs(HearthStoneList) do
        if PlayerHasToy(v) then
            T.tinsert(HearthStoneListChecked, v);
        end
    end
    local num = #HearthStoneListChecked;
    if num and num >= 1 then
        for k, v in T.ipairs(HearthStoneListChecked) do
            local name = T.GetItemInfo(v);
            if name then
                T.tinsert(HearthStoneName, name);
                T.tremove(HearthStoneListChecked, k);
            end
        end
    end
end

local function HearthStoneToUse_Random(frame)
    if (#HearthStoneName >= 1) then
        if (not T.InCombatLockdown()) then
            HearthStoneToUse = HearthStoneName[T.random(#HearthStoneName)];
            frame:SetAttribute("item", HearthStoneToUse);
            frame.NeedToRandom = false;
        else
            frame.NeedToRandom = true;
        end
    end
end

function LAB:Macro_Refresh()
    local name = GetMacroInfo("RHS");
    local HSNAME = T.GetItemInfo(6948);
    if (not HSNAME) or (T.InCombatLockdown()) then return; end
    if not name then
        local gNum, pNum = GetNumMacros();
        if (gNum == 72) then return; end
        local macroId = CreateMacro("RHS", "INV_MISC_QUESTIONMARK",
            "#showtooltip " .. HSNAME .. [[

]]
            
            .. [[
/rhs check
/click RandomHearthStone]]
            
            ,
            nil, 1)
        LUI:Print("已创建随机炉石玩具宏，请放至动作栏！")
        PickupMacro("RHS")
    else
        local macroID = EditMacro("RHS", "RHS", "INV_MISC_QUESTIONMARK",
            "#showtooltip " .. HSNAME .. [[

]]
            
            .. [[
/rhs check
/click RandomHearthStone]]
        
        )
        LUI:Print("已创建随机炉石玩具宏，请放至动作栏！")
        PickupMacro("RHS")
    end
end


function LAB:LoadRandomHearthStone()
    local HearthStoneToUse = T.GetItemInfo(6948);
    local RandomHearthStone = T.CreateFrame("Button", "RandomHearthStone", nil, "SecureActionButtonTemplate");
    RandomHearthStone:SetAttribute("type", "item");
    RandomHearthStone:SetAttribute("item", HearthStoneToUse);
    RandomHearthStone.NeedToRandom = false;
    
    RandomHearthStone:RegisterEvent("PLAYER_ENTERING_WORLD");
    RandomHearthStone:RegisterEvent("PLAYER_REGEN_ENABLED");
    RandomHearthStone:SetScript("OnEvent", function(self, event)
        if event == "PLAYER_ENTERING_WORLD" then
            if not RandomHearthstone_DB then
                RandomHearthstone_DB = {};
                RandomHearthstone_DB.Version = 1;
            end
            if RandomHearthstone_DB.Version < 1 then
                Macro_Refresh();
            end
            
            HearthStoneToUse_UpdateList();
            HearthStoneToUse_Random(RandomHearthStone);
            C_Timer.After(5, function(self2)
                HearthStoneToUse_UpdateList();
                HearthStoneToUse_Random(RandomHearthStone);
            end)
        end
        if event == "PLAYER_REGEN_ENABLED" then
            if self.NeedToRandom == true then
                HearthStoneToUse_UpdateList();
                HearthStoneToUse_Random(RandomHearthStone);
            end
        end
    end)
    
    SlashCmdList["RHS"] = function(msg)
        if msg == "check" then
            HearthStoneToUse_UpdateList();
            HearthStoneToUse_Random(RandomHearthStone);
        else
            self:Macro_Refresh();
        end
    end
    SLASH_RHS1 = "/rhs";
end
