local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LUF = LUI:NewModule("LUIUnitframes", "AceEvent-3.0");
local RC = LibStub("LibRangeCheck-2.0");

local _G = _G;

function LUF:UpdateRangeText(frame)
    local rcText;
    if not frame or not frame.unitframeType then return; end
    
    if not T.UnitName(frame.unitframeType) then
        rcText = "";
    else
        local minRange, maxRange = RC:getRange(frame.unitframeType);
        if maxRange == nil then
            minRange = "?";
            maxRange = "?";
        end
        rcText = minRange .. "-" .. maxRange;
    end
    frame.RangeText.rcText:SetText(rcText);
end

function LUF:Initialize()
    if E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"] and (_G["ElvUF_Target"]) then LUF:LoadTargetRangeText(_G["ElvUF_Target"]); end
    if E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"] and (_G["ElvUF_Focus"]) then LUF:LoadFocusRangeText(_G["ElvUF_Focus"]); end
    if E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"] then LUF:LoadSwingBar(_G["ElvUF_Player"]); end
    if E.db.lui.modules.unitframes.playerframe["gcdBar"] then LUF:LoadGCDBar(_G["ElvUF_Player"]); end
end

local function InitializeCallback()
    LUF:Initialize();
end

LUI:RegisterModule(LUF:GetName(), InitializeCallback);
