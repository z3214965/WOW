--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "unitframes", "focusframe", "rangeText", "enableBtn") == true then return; end

local LUF = LUI:GetModule('LUIUnitframes');
local LSM = LibStub('LibSharedMedia-3.0');

function LUF:LoadFocusRangeText(frame)
    if not frame then return; end
    frame.RangeText = T.CreateFrame("Frame", "FocusRangeText", frame);
    local RT = frame.RangeText;
    RT.rcText = frame.RaisedElementParent:CreateFontString(nil, 'OVERLAY');
    RT.rcText:ClearAllPoints();
    local fontname = E.db.lui.modules.unitframes.focusframe.rangeText['rangeFontName'];
    local fontsize = E.db.lui.modules.unitframes.focusframe.rangeText['rangeFontSize'];
    local fontflag = E.db.lui.modules.unitframes.focusframe.rangeText['rangeFontFlag'];
    local rangePoi = E.db.lui.modules.unitframes.focusframe.rangeText['rangePoi'];
    local rangePoiX = E.db.lui.modules.unitframes.focusframe.rangeText['rangePoiX'];
    local rangePoiY = E.db.lui.modules.unitframes.focusframe.rangeText['rangePoiY'];
    RT.rcText:FontTemplate(LSM:Fetch('font', fontname), fontsize, fontflag);
    RT.rcText:Point(rangePoi, frame.Health, rangePoi, rangePoiX, rangePoiY);
    RT.rcText:Show();
    RT:SetScript("OnUpdate", function(self, elapsed)
        if (self.elapsed and self.elapsed > 0.2) then
            LUF:UpdateRangeText(frame);
            self.elapsed = 0;
        else
            self.elapsed = (self.elapsed or 0) + elapsed;
        end
    end)
end
