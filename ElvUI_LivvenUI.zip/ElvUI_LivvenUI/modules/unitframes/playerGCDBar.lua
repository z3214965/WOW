--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "unitframes", "playerframe", "gcdBar") == true then return; end

local LUF = LUI:GetModule("LUIUnitframes");

local gcdbar;

local function OnUpdate()
    if not starttime then return gcdbar:Hide(); end
    gcdbar.spark:ClearAllPoints();
    local perc = (T.GetTime() - starttime) / duration;
    local width = gcdbar:GetWidth();
    if perc > 1 then
        return gcdbar:Hide();
    else
        gcdbar.spark:SetPoint("CENTER", gcdbar, "LEFT", width * perc, 0);
    end
end

function LUF:CheckGCD(event, unit, guid, spell)
    if unit == "player" then
        local start, dur = T.GetSpellCooldown(spell);
        if dur and dur > 0 and dur <= 1.5 then
            starttime = start;
            duration = dur;
            gcdbar:Show();
        end
    end
end

function LUF:LoadGCDBar(frame)
    if not frame then return; end
    self:RegisterEvent("UNIT_SPELLCAST_START", "CheckGCD");
    self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED", "CheckGCD");
    
    gcdbar = T.CreateFrame("Frame", "GCDBar", frame);
    gcdbar:SetFrameStrata("HIGH");
    gcdbar.Color = {1, 1, 1};
    if frame then
        gcdbar:Width(frame.db.width);
        gcdbar:Point("BOTTOMLEFT", frame, "TOPLEFT", 0, 0);
        gcdbar:Height(3);
        gcdbar.width = 4;
        gcdbar.height = 3;
        gcdbar:Hide();
    else
        gcdbar:Width(180);
        gcdbar:Point("CENTER", UIParent, "CENTER", 0, -200);
        gcdbar:Height(2);
        gcdbar.width = 4;
        gcdbar.height = 2;
        gcdbar:Hide();
    end
    
    gcdbar.spark = gcdbar:CreateTexture(nil, "DIALOG");
    gcdbar.spark:SetTexture("Interface\\ChatFrame\\ChatFrameBackground");
    gcdbar.spark:SetVertexColor(unpack(gcdbar.Color));
    gcdbar.spark:SetWidth(gcdbar.width);
    gcdbar.spark:SetHeight(gcdbar.height);
    gcdbar.spark:SetBlendMode("ADD");
    gcdbar:SetScript("OnUpdate", OnUpdate);
end
