--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "unitframes", "targetframe", "rangeText", "enableBtn") == true then return; end

local LUF = LUI:GetModule("LUIUnitframes");
local LSM = LibStub("LibSharedMedia-3.0");

function LUF:LoadTargetRangeText(frame)
    if not frame then return; end
    frame.RangeText = T.CreateFrame("Frame", "TargetRangeText", frame);
    local RT = frame.RangeText;
    RT.rcText = frame.RaisedElementParent:CreateFontString(nil, "OVERLAY");
    RT.rcText:ClearAllPoints();
    local fontname = E.db.lui.modules.unitframes.targetframe.rangeText["rangeFontName"];
    local fontsize = E.db.lui.modules.unitframes.targetframe.rangeText["rangeFontSize"];
    local fontflag = E.db.lui.modules.unitframes.targetframe.rangeText["rangeFontFlag"];
    local rangePoi = E.db.lui.modules.unitframes.targetframe.rangeText["rangePoi"];
    local rangePoiX = E.db.lui.modules.unitframes.targetframe.rangeText["rangePoiX"];
    local rangePoiY = E.db.lui.modules.unitframes.targetframe.rangeText["rangePoiY"];
    RT.rcText:FontTemplate(LSM:Fetch("font", fontname), fontsize, fontflag);
    RT.rcText:Point(rangePoi, frame.Health, rangePoi, rangePoiX, rangePoiY);
    RT.rcText:Show();
    RT:SetScript("OnUpdate", function(self, elapsed)
        if (self.elapsed and self.elapsed > 0.2) then
            LUF:UpdateRangeText(frame);
            self.elapsed = 0;
        else
            self.elapsed = (self.elapsed or 0) + elapsed;
        end
    end)
end
