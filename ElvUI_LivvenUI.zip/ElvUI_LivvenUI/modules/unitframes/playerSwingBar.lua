--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "unitframes", "playerframe", "swingBar", "enableBtn") == true then return; end

local LUF = LUI:GetModule("LUIUnitframes");
local LSM = E.LSM or E.Libs.LSM;

local UnitDamage, UnitAttackSpeed, UnitRangedDamage = UnitDamage, UnitAttackSpeed, UnitRangedDamage;
local math_abs, bit_band = math.abs, bit.band;
local COMBATLOG_FILTER_ME = COMBATLOG_FILTER_ME;

local autoshotname = T.GetSpellInfo(75);
local slam = T.GetSpellInfo(1464);
local resetautoshotspells = {};

local swingmode;
local starttime, duration;
local slamstart;

local playerclass;
local swingbar;

local function OnUpdate()
    if slamstart then return; end
    if starttime then
        local spent = T.GetTime() - starttime;
        local perc = spent / duration;
        swingbar.remainingtext:SetFormattedText("%.1f", duration - spent);
        if perc > 1 then
            return swingbar:Hide();
        else
            swingbar:SetValue(perc);
        end
    end
end

function LUF:PLAYER_ENTER_COMBAT()
    local _, _, offhandlow, offhandhigh = UnitDamage("player");
    if math_abs(offhandlow - offhandhigh) <= 0.1 or playerclass == "DRUID" then
        swingmode = 0;
    end
end

function LUF:PLAYER_LEAVE_COMBAT()
    if not swingmode or swingmode == 0 then
        swingmode = nil;
    end
end

function LUF:START_AUTOREPEAT_SPELL()
    swingmode = 1;
end

function LUF:STOP_AUTOREPEAT_SPELL()
    if not swingmode or swingmode == 1 then
        swingmode = nil;
    end
end

function LUF:COMBAT_LOG_EVENT_UNFILTERED()
    if swingmode ~= 0 then return; end
    local timestamp, combatevent, hideCaster, srcGUID, srcName, srcFlags, srcRaidFlags, dstName, dstGUID, dstFlags, dstRaidFlags, spellID, spellName = CombatLogGetCurrentEventInfo();
    if (combatevent == "SWING_DAMAGE" or combatevent == "SWING_MISSED") and (bit_band(srcFlags, COMBATLOG_FILTER_ME) == COMBATLOG_FILTER_ME) then
        self:MeleeSwing();
    elseif (combatevent == "SWING_MISSED") and (bit_band(dstFlags, COMBATLOG_FILTER_ME) == COMBATLOG_FILTER_ME) and spellID == "PARRY" and duration then
        duration = duration * 0.6;
    end
end

function LUF:UNIT_SPELLCAST_SUCCEEDED(event, unit, spell)
    if unit ~= "player" then return; end
    if swingmode == 0 then
        if spell == slam and slamstart then
            starttime = starttime + T.GetTime() - slamstart;
            slamstart = nil;
        end
    elseif swingmode == 1 then
        if spell == autoshotname then
            self:Shoot();
        end
    end
    if resetautoshotspells[spell] then
        swingmode = 1;
        self:Shoot();
    end
end

function LUF:UNIT_SPELLCAST_START(event, unit, spell)
    if unit == "player" and spell == slam then
        slamstart = T.GetTime();
    end
end

function LUF:UNIT_SPELLCAST_INTERRUPTED(event, unit, spell)
    if unit == "player" and spell == slam and slamstart then
        slamstart = nil;
    end
end

function LUF:UNIT_ATTACK(event, unit)
    if unit == "player" then
        if not swingmode then
            return;
        elseif swingmode == 0 then
            duration = UnitAttackSpeed("player");
        else
            duration = UnitRangedDamage("player");
        end
        swingbar.durationtext:SetFormattedText("%.1f", duration);
    end
end

function LUF:MeleeSwing()
    duration = UnitAttackSpeed("player");
    if not duration or duration == 0 then
        duration = nil;
        starttime = nil;
        swingbar:Hide();
        return;
    end
    
    swingbar.durationtext:SetFormattedText("%.1f", duration);
    starttime = T.GetTime();
    swingbar:Show();
end

function LUF:Shoot()
    duration = UnitRangedDamage("player");
    if not duration or duration == 0 then
        duration = nil;
        starttime = nil;
        swingbar:Hide();
        return
    end
    
    swingbar.durationtext:SetFormattedText("%.1f", duration);
    starttime = T.GetTime();
    swingbar:Show();
end

function LUF:LoadSwingBar(frame)
    if not frame then return; end
    local _, c = T.UnitClass("player");
    playerclass = playerclass or c;
    
    self:RegisterEvent("PLAYER_ENTER_COMBAT");
    self:RegisterEvent("PLAYER_LEAVE_COMBAT");
    self:RegisterEvent("START_AUTOREPEAT_SPELL");
    self:RegisterEvent("STOP_AUTOREPEAT_SPELL");
    self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
    self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED");
    if playerclass == "WARRIOR" then
        self:RegisterEvent("UNIT_SPELLCAST_START");
        self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED");
    end
    self:RegisterEvent("UNIT_ATTACK");
    
    swingbar = T.CreateFrame("Statusbar", "SwingBar", frame);
    swingbar:SetClampedToScreen(true);
    swingbar:CreateBackdrop();
    swingbar:SetStatusBarTexture(E["media"].normTex);
    
    swingbar.bg = swingbar:CreateTexture(nil, "BORDER");
    swingbar.bg:SetAllPoints(swingbar);
    swingbar.bg:SetVertexColor(RAID_CLASS_COLORS[E.myclass].r, RAID_CLASS_COLORS[E.myclass].g, RAID_CLASS_COLORS[E.myclass].b, 0.2);
    swingbar.bg:Hide();
    
    local fontname = E.db.lui.modules.unitframes.playerframe.swingBar["swingBarFontName"];
    local fontsize = E.db.lui.modules.unitframes.playerframe.swingBar["swingBarFontSize"];
    local fontflag = E.db.lui.modules.unitframes.playerframe.swingBar["swingBarFontFlag"];

    swingbar.remainingtext = swingbar:CreateFontString(nil, "OVERLAY");
    swingbar.remainingtext:FontTemplate(LSM:Fetch("font", fontname), fontsize, fontflag);
    swingbar.remainingtext:SetTextColor(1, 1, 1);
    if E.db.lui.modules.unitframes.playerframe.swingBar["remainingText"] then
        swingbar.remainingtext:SetPoint("RIGHT", swingbar, "RIGHT", 4, 0);
    end
    
    swingbar.durationtext = swingbar:CreateFontString(nil, "OVERLAY");
    swingbar.durationtext:FontTemplate(LSM:Fetch("font", fontname), fontsize, fontflag);
    swingbar.durationtext:SetTextColor(1, 1, 1);
    if E.db.lui.modules.unitframes.playerframe.swingBar["durationText"] then
        swingbar.durationtext:SetPoint("LEFT", swingbar, "LEFT", 0, 0);
    end

    local holder = T.CreateFrame("Frame", nil, frame);
    holder:Point("TOPRIGHT", frame, "BOTTOMRIGHT", 0, -(frame.BORDER * 1));
    swingbar:Point("BOTTOMRIGHT", holder, "BOTTOMRIGHT", -frame.BORDER, frame.BORDER);
    
    swingbar.Holder = holder;
    E:CreateMover(swingbar.Holder, "SwingBarMover", "Swing", nil, -6, nil, "ALL, SOLO");
    local swingBarWidth = E.db.lui.modules.unitframes.playerframe.swingBar["swingBarWidth"];
    local swingBarHeight =  E.db.lui.modules.unitframes.playerframe.swingBar["swingBarHeight"];
    swingbar:Width(swingBarWidth - (E.PixelMode and 2 or (frame.BORDER * 2)));
    swingbar:Height(swingBarHeight - (E.PixelMode and 2 or (frame.BORDER * 2)));
    swingbar.Holder:Width(swingBarWidth + (E.PixelMode and 0 or (frame.BORDER * 2)));
    swingbar.Holder:Height(swingBarHeight + (E.PixelMode and 0 or (frame.BORDER * 2)));
    swingbar.Holder:GetScript("OnSizeChanged")(swingbar.Holder);
    
    local swingBarColor = E.db.lui.modules.unitframes.playerframe.swingBar["swingBarColor"];
    swingbar:SetStatusBarColor(swingBarColor.r, swingBarColor.g, swingBarColor.b);
    swingbar:SetMinMaxValues(0, 1);
    swingbar:Hide();
    
    swingbar:SetScript("OnUpdate", OnUpdate);
end
