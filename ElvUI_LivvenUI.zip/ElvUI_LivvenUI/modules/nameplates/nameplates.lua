local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LNP = LUI:NewModule("LUINameplates", "AceEvent-3.0");

function LNP:Initialize()
    if E.db.lui.modules.nameplates["castbarTarget"] then self:LoadCastbarTarget(); end
end

local function InitializeCallback()
	LNP:Initialize();
end

LUI:RegisterModule(LNP:GetName(), InitializeCallback);