--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "misc", "general", "autoScreenShoot", "enableBtn") == true then return; end

local LMI = LUI:GetModule("LUIMisc");

local function TakeScreen()
	E:ScheduleTimer(Screenshot, 1);
end

function LMI:LoadAutoScreenShoot()
	self:RegisterEvent("ACHIEVEMENT_EARNED", TakeScreen);
end