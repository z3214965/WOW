local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LMI = LUI:NewModule("LUIMisc", "AceEvent-3.0", "AceHook-3.0");

function LMI:Initialize()
	self:LoadNumberPrefixStyle();
	if E.db.lui.modules.misc.general.alreadyKnown["enableBtn"] then self:LoadAlreadyKnown(); end
	if E.db.lui.modules.misc.general["autoDelete"] then self:LoadAutoDelete(); end
	if E.db.lui.modules.misc.general.autoScreenShoot["enableBtn"] then self:LoadAutoScreenShoot(); end
	if E.db.lui.modules.misc.general["classColors"] then self:LoadClassColors(); end
	if E.db.lui.modules.misc.loot.fastLoot["enableBtn"] then self:LoadFastLoot(); end
	if E.db.lui.modules.misc.inviteGroup["enableBtn"] then self:LoadInviteGroup(); end
	if E.db.lui.modules.misc.general.setPoi["enableBtn"] then self:LoadSetPoi(); end
	if E.db.lui.modules.misc.general.talentProfiles["enableBtn"] then self:LoadTalentProfiles(); end
	if E.db.lui.modules.misc.general["disableTalking"] then self:LoadTalkingHead(); end
	if E.db.lui.modules.misc.general["autoRelease"] then self:LoadAutoRelease(); end
	if E.db.lui.modules.misc.general["autoRepChange"] then self:LoadAutoRepChange(); end
end

local function InitializeCallback()
	LMI:Initialize();
end

LUI:RegisterModule(LMI:GetName(), InitializeCallback);
