--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...))
local LMI = E:GetModule("LuiMisc")

function LMI:LoadNumberPrefixStyle()
    function E:ShortValue(v)
        local shortValueDec = T.format("%%.%df", E.db.general.decimalLength or 1)
        local shortValue = T.abs(v)
        if E.db.general.numberPrefixStyle == "METRIC" then
            if shortValue >= 1e12 then
                return T.format(shortValueDec .. "T", v / 1e12)
            elseif shortValue >= 1e9 then
                return T.format(shortValueDec .. "G", v / 1e9)
            elseif shortValue >= 1e6 then
                return T.format(shortValueDec .. "M", v / 1e6)
            elseif shortValue >= 1e3 then
                return T.format(shortValueDec .. "k", v / 1e3)
            else
                return T.format("%.0f", v)
            end
        elseif E.db.general.numberPrefixStyle == "CHINESE" then
            if shortValue >= 1e8 then
                return T.format(shortValueDec .. "Y", v / 1e8)
            elseif shortValue >= 1e4 then
                return T.format(shortValueDec .. "W", v / 1e4)
            else
                return T.format("%.0f", v)
            end
        elseif E.db.general.numberPrefixStyle == "LUICHINESE" then
            if shortValue >= 1e8 then
                return T.format(shortValueDec .. "亿", v / 1e8)
            elseif shortValue >= 1e4 then
                return T.format(shortValueDec .. "万", v / 1e4)
            else
                return T.format("%.0f", v)
            end
        elseif E.db.general.numberPrefixStyle == "KOREAN" then
            if shortValue >= 1e8 then
                return T.format(shortValueDec .. "억", v / 1e8)
            elseif shortValue >= 1e4 then
                return T.format(shortValueDec .. "만", v / 1e4)
            elseif shortValue >= 1e3 then
                return T.format(shortValueDec .. "천", v / 1e3)
            else
                return T.format("%.0f", v)
            end
        elseif E.db.general.numberPrefixStyle == "GERMAN" then
            if shortValue >= 1e12 then
                return T.format(shortValueDec .. "Bio", v / 1e12)
            elseif shortValue >= 1e9 then
                return T.format(shortValueDec .. "Mrd", v / 1e9)
            elseif shortValue >= 1e6 then
                return T.format(shortValueDec .. "Mio", v / 1e6)
            elseif shortValue >= 1e3 then
                return T.format(shortValueDec .. "Tsd", v / 1e3)
            else
                return T.format("%.0f", v)
            end
        else
            if shortValue >= 1e12 then
                return T.format(shortValueDec .. "T", v / 1e12)
            elseif shortValue >= 1e9 then
                return T.format(shortValueDec .. "B", v / 1e9)
            elseif shortValue >= 1e6 then
                return T.format(shortValueDec .. "M", v / 1e6)
            elseif shortValue >= 1e3 then
                return T.format(shortValueDec .. "K", v / 1e3)
            else
                return T.format("%.0f", v)
            end
        end
    end
end
