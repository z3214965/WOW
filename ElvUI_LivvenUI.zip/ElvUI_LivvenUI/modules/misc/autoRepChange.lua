-- 来源：EUI
-- 作者：EUI
-- 链接：
-- 修改：L
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "misc", "general", "autoRepChange") == true then return; end

local LMI = LUI:GetModule("LUIMisc");

local incpat = gsub(gsub(FACTION_STANDING_INCREASED, "(%%s)", "(.+)"), "(%%d)", "(.+)");
local changedpat = gsub(gsub(FACTION_STANDING_CHANGED, "(%%s)", "(.+)"), "(%%d)", "(.+)");
local decpat = gsub(gsub(FACTION_STANDING_DECREASED, "(%%s)", "(.+)"), "(%%d)", "(.+)");

function LMI:SetWatchedFactionOnReputationBar(event, msg)
    local _, _, faction, amount = T.find(msg, incpat)
    if not faction then _, _, faction, amount = T.find(msg, changedpat) or T.find(msg, decpat); end
    if faction then
        if faction == GUILD then
            faction = T.GetGuildInfo("player");
        end
        local active = T.GetWatchedFactionInfo();
        for factionIndex = 1, T.GetNumFactions() do
            local name = T.GetFactionInfo(factionIndex);
            if name == faction and name ~= active then
                local inactive = T.IsFactionInactive(factionIndex) or T.SetWatchedFactionIndex(factionIndex);
                break;
            end
        end
    end
end

function LMI:LoadAutoRepChange()
    self:RegisterEvent("CHAT_MSG_COMBAT_FACTION_CHANGE", "SetWatchedFactionOnReputationBar");
end
