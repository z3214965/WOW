--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "bags", "moveElvUIBags") == true then return; end

local LBA = LUI:GetModule("LUIBags");

local _G = _G;

function LBA:LoadMoveElvUIBags()
    local f = _G["ElvUI_ContainerFrame"];
    if not f then return; end

    f:SetScript("OnDragStart", function(f) f:StartMoving(); end)
    if (T.GetLocale() == "zhCN") then
        L["Hold Shift + Drag:"] = "按住鼠标左键:"
    elseif (T.GetLocale() == "zhTW") then
        L["Hold Shift + Drag:"] = "按住滑鼠左鍵:"
    else
        L["Hold Shift + Drag:"] = "Hold Drag:"
    end
end