local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LBA = LUI:NewModule("LUIBags");

function LBA:Initialize()
    if E.db.lui.modules.bags["moveElvUIBags"] then self:LoadMoveElvUIBags(); end
end

local function InitializeCallback()
    LBA:Initialize();
end

LUI:RegisterModule(LBA:GetName(), InitializeCallback);
