local LUI, T, E, L, V, P, G = unpack(select(2, ...))
local LQU = E:NewModule("LuiQuest")

function LQU:Initialize()
    if E.db.lui.modules.quest.questAutomation["enable"] then LQU:LoadQuestAutomation() end
    if E.db.lui.modules.quest.questAnnouncment["enable"] then LQU:LoadQuestAnnouncment() end
    if E.db.lui.modules.quest.questListEnhanced["enable"] then LQU:LoadQuestListEnhanced() end
end

local function InitializeCallback()
	LQU:Initialize()
end

E:RegisterModule(LQU:GetName(), InitializeCallback)