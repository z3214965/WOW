local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LQU = LUI:NewModule("LUIQuest");

function LQU:Initialize()
    if E.db.lui.modules.quest.questAutomation["enableBtn"] then LQU:LoadQuestAutomation(); end
    if E.db.lui.modules.quest.questAnnouncment["enableBtn"] then LQU:LoadQuestAnnouncment(); end
    if E.db.lui.modules.quest.questListEnhanced["enableBtn"] then LQU:LoadQuestListEnhanced(); end
end

local function InitializeCallback()
	LQU:Initialize();
end

LUI:RegisterModule(LQU:GetName(), InitializeCallback);