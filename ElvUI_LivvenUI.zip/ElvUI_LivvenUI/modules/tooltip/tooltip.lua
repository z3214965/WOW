local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LTO = LUI:NewModule("LUITooltip", "AceHook-3.0");

function LTO:Initialize()
	if E.db.lui.modules.tooltip["tooltipIcon"] then self:LoadTooltipIcon(); end
	if E.db.lui.modules.tooltip.nameHover["enableBtn"] then self:LoadnameHover(); end
end

local function InitializeCallback()
	LTO:Initialize();
end

LUI:RegisterModule(LTO:GetName(), InitializeCallback);
