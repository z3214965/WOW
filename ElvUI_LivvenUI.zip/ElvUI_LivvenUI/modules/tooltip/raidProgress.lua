-- 来源：S&L
-- 作者：
-- 链接：
-- 修改：L
local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("modules", "tooltip", "raidProg", "enable") == true then return end
local LRP = E:NewModule("LuiRaidProgress", "AceHook-3.0", "AceEvent-3.0")

local TT = E:GetModule("Tooltip")
local MAX_PLAYER_LEVEL = MAX_PLAYER_LEVEL
local _G = _G


LRP.Cache = {}
LRP.playerGUID = T.UnitGUID("player")
LRP.highestKill = 0

LRP.bosses = {
    {-- Uldir
        {-- Mythic
            12789, 12793, 12797, 12801, 12805, 12811, 12816, 12820,
        },
        {-- Heroic
            12788, 12792, 12796, 12800, 12804, 12810, 12815, 12819,
        },
        {-- Normal
            12787, 12791, 12795, 12799, 12803, 12809, 12814, 12818,
        },
        {-- LFR
            12786, 12790, 12794, 12798, 12802, 12808, 12813, 12817,
        },
        "uldir",
    },
    {-- Dazar"Alor
        {-- Mythic
            13331, 13348, 13353, 13362, 13366, 13370, 13374, 13378, 13382,
        },
        {-- Heroic
            13330, 13347, 13351, 13361, 13365, 13369, 13373, 13377, 13381,
        },
        {-- Normal
            13329, 13346, 13350, 13359, 13364, 13368, 13372, 13376, 13380,
        },
        {-- LFR
            13328, 13344, 13349, 13358, 13363, 13367, 13371, 13375, 13379,
        },
        "daz",
    },
    {-- Storm Crucible
        {-- Mythic
            13407, 13413,
        },
        {-- Heroic
            13406, 13412,
        },
        {-- Normal
            13405, 13411,
        },
        {-- LFR
            13404, 13408,
        },
        "sc",
    },
}
LRP.Raids = {}
LRP.modes = {
    ["LONG"] = {
        PLAYER_DIFFICULTY6,
        PLAYER_DIFFICULTY2,
        PLAYER_DIFFICULTY1,
        PLAYER_DIFFICULTY3,
    },
    ["SHORT"] = {
        T.string_utf8sub(PLAYER_DIFFICULTY6, 1, 1),
        T.string_utf8sub(PLAYER_DIFFICULTY2, 1, 1),
        T.string_utf8sub(PLAYER_DIFFICULTY1, 1, 1),
        T.string_utf8sub(PLAYER_DIFFICULTY3, 1, 1),
    },
}

local function PopulateRaidsTable()
    LRP.Raids["LONG"] = {
        LUI:GetMapInfo(1148, "name"),
        LUI:GetMapInfo(1358, "name"),
        LUI:GetMapInfo(1345, "name"),
    }
    LRP.Raids["SHORT"] = {
        L["RAID_ULDIR"],
        L["RAID_DAZALOR"],
        L["RAID_STORMCRUS"],
    }
end

function LRP:GetProgression(guid)
    local kills, complete, pos = 0, false, 0
    local statFunc = guid == LRP.playerGUID and T.GetStatistic or T.GetComparisonStatistic
    
    for raid = 1, #LRP.Raids["LONG"] do
        local option = LRP.bosses[raid][5]
        if E.db.lui.modules.tooltip.raidProg.raids[option] then
            LRP.Cache[guid].header[raid] = {}
            LRP.Cache[guid].info[raid] = {}
            for level = 1, 4 do
                LRP.highestKill = 0
                for statInfo = 1, #LRP.bosses[raid][level] do
                    local bossTable = LRP.bosses[raid][level][statInfo]
                    kills = T.tonumber((statFunc(bossTable)))
                    if kills and kills > 0 then
                        LRP.highestKill = LRP.highestKill + 1
                    end
                end
                pos = LRP.highestKill
                if (LRP.highestKill > 0) then
                    LRP.Cache[guid].header[raid][level] = T.string_format("%s [%s]:", LRP.Raids[E.db.lui.modules.tooltip.raidProg["nameStyle"]][raid], LRP.modes[E.db.lui.modules.tooltip.raidProg["difStyle"]][level])
                    LRP.Cache[guid].info[raid][level] = T.string_format("%d/%d", LRP.highestKill, #LRP.bosses[raid][level])
                    if LRP.highestKill == #LRP.bosses[raid][level] then
                        break
                    end
                end
            end
        end
    end
end

function LRP:UpdateProgression(guid)
    LRP.Cache[guid] = LRP.Cache[guid] or {}
    LRP.Cache[guid].header = LRP.Cache[guid].header or {}
    LRP.Cache[guid].info = LRP.Cache[guid].info or {}
    LRP.Cache[guid].timer = T.GetTime()
    
    LRP:GetProgression(guid)
end

function LRP:SetProgressionInfo(guid, tt)
    if LRP.Cache[guid] and LRP.Cache[guid].header then
        local updated = 0
        for i = 1, tt:NumLines() do
            local leftTipText = _G["GameTooltipTextLeft" .. i]
            for raid = 1, #LRP.Raids["LONG"] do
                for level = 1, 4 do
                    if (leftTipText:GetText() and leftTipText:GetText():find(LRP.Raids[E.db.lui.modules.tooltip.raidProg["nameStyle"]][raid]) and leftTipText:GetText():find(LRP.modes[E.db.lui.modules.tooltip.raidProg["difStyle"]][level]) and (LRP.Cache[guid].header[raid][level] and LRP.Cache[guid].info[raid][level])) then
                        local rightTipText = _G["GameTooltipTextRight" .. i]
                        leftTipText:SetText(LRP.Cache[guid].header[raid][level])
                        rightTipText:SetText(LRP.Cache[guid].info[raid][level])
                        updated = 1
                    end
                end
            end
        end
        if updated == 1 then return end
        if LRP.highestKill > 0 then tt:AddLine(" ") end
        for raid = 1, #LRP.Raids["LONG"] do
            local option = LRP.bosses[raid][5]
            if E.db.lui.modules.tooltip.raidProg.raids[option] then
                for level = 1, 4 do
                    tt:AddDoubleLine(LRP.Cache[guid].header[raid][level], LRP.Cache[guid].info[raid][level], nil, nil, nil, 1, 1, 1)
                end
            end
        end
    end
end

local function AchieveReady(event, GUID)
    if (TT.compareGUID ~= GUID) then return end
    local unit = "mouseover"
    if T.UnitExists(unit) then
        LRP:UpdateProgression(GUID)
        _G["GameTooltip"]:SetUnit(unit)
    end
    T.ClearAchievementComparisonUnit()
    TT:UnregisterEvent("INSPECT_ACHIEVEMENT_READY")
end

local function OnInspectInfo(self, tt, unit, numTries, r, g, b)
    if T.InCombatLockdown() then return end
    if not (unit and T.CanInspect(unit)) then return end
    
    local guid = T.UnitGUID(unit)
    if not LRP.Cache[guid] or (T.GetTime() - LRP.Cache[guid].timer) > 600 then
        if guid == LRP.playerGUID then
            LRP:UpdateProgression(guid)
        else
            T.ClearAchievementComparisonUnit()
            if not self.loadedComparison and select(2, T.IsAddOnLoaded("Blizzard_AchievementUI")) then
                AchievementFrame_DisplayComparison(unit)
                T.HideUIPanel(_G["AchievementFrame"])
                T.ClearAchievementComparisonUnit()
                self.loadedComparison = true
            end
            self.compareGUID = guid
            if T.SetAchievementComparisonUnit(unit) then
                self:RegisterEvent("INSPECT_ACHIEVEMENT_READY", AchieveReady)
            end
            return
        end
    end
    
    LRP:SetProgressionInfo(guid, tt)
end

function LRP:Initialize()
    PopulateRaidsTable()
    T.hooksecurefunc(TT, "AddInspectInfo", OnInspectInfo)
end

local function InitializeCallback()
    if not E.db.lui.modules.tooltip.raidProg["enable"] then return end
    LRP:Initialize()
end

E:RegisterModule(LRP:GetName(), InitializeCallback)
