--来源：LivvenUI
--作者：L
--修改：
local LUI, T, E, L, V, P, G = unpack(select(2, ...))
local LCV = E:NewModule("LUICVar")

function LCV:LoadCVar()
    --获取玩家目前CVar设置
	--general
	if GetCVar("alwaysCompareItems") == "0" then
		E.db.lui.modules.cvar.general.alwaysCompareItems = false
	else
		E.db.lui.modules.cvar.general.alwaysCompareItems = true
	end
	
	if GetCVar("breakUpLargeNumbers") == "0" then
		E.db.lui.modules.cvar.general.breakUpLargeNumbers = false
	else
		E.db.lui.modules.cvar.general.breakUpLargeNumbers = true
	end
	
	if GetCVar("scriptErrors") == "0" then
		E.db.lui.modules.cvar.general.scriptErrors = false
	else
		E.db.lui.modules.cvar.general.scriptErrors = true
	end
	
	if GetCVar("enableWoWMouse") == "0" then
		E.db.lui.modules.cvar.general.enableWoWMouse = false
	else
		E.db.lui.modules.cvar.general.enableWoWMouse = true
	end
	
	E.db.lui.modules.cvar.general.trackQuestSorting = GetCVar("trackQuestSorting")
	
	--interface
	E.db.lui.modules.cvar.interface.cameraDistanceMaxZoomFactor = T.tonumber(GetCVar("cameraDistanceMaxZoomFactor"))
	
	E.db.lui.modules.cvar.interface.weatherDensity = T.tonumber(GetCVar("weatherDensity"))
	
	if GetCVar("ffxGlow") == "0" then
		E.db.lui.modules.cvar.interface.ffxGlow = false
	else
		E.db.lui.modules.cvar.interface.ffxGlow = true
	end
	
	if GetCVar("xpBarText") == "0" then
		E.db.lui.modules.cvar.interface.xpBarText = false
	else
		E.db.lui.modules.cvar.interface.xpBarText = true
	end

	--chat
	if GetCVar("profanityFilter") == "0" then
		E.db.lui.modules.cvar.chat.profanityFilter = false
	else
		E.db.lui.modules.cvar.chat.profanityFilter = true
	end
	
	if GetCVar("removeChatDelay") == "0" then
		E.db.lui.modules.cvar.chat.removeChatDelay = false
	else
		E.db.lui.modules.cvar.chat.removeChatDelay = true
	end
	
	if GetCVar("chatMouseScroll") == "0" then
		E.db.lui.modules.cvar.chat.chatMouseScroll = false
	else
		E.db.lui.modules.cvar.chat.chatMouseScroll = true
	end

	if GetCVar("chatBubbles") == "0" then
		E.db.lui.modules.cvar.chat.chatMouseScroll = false
	else
		E.db.lui.modules.cvar.chat.chatMouseScroll = true
	end
	
	--combat
	if GetCVar("secureAbilityToggle") == "0" then
		E.db.lui.modules.cvar.combat.secureAbilityToggle = false
	else
		E.db.lui.modules.cvar.combat.secureAbilityToggle = true
	end
	
	if GetCVar("stopAutoAttackOnTargetChange") == "0" then
		E.db.lui.modules.cvar.combat.stopAutoAttackOnTargetChange = false
	else
		E.db.lui.modules.cvar.combat.stopAutoAttackOnTargetChange = true
	end
	
	if GetCVar("assistAttack") == "0" then
		E.db.lui.modules.cvar.combat.assistAttack = false
	else
		E.db.lui.modules.cvar.combat.assistAttack = true
	end
	
	E.db.lui.modules.cvar.combat.SpellQueueWindow = T.tonumber(GetCVar("SpellQueueWindow"))
	
	--combatText
	E.db.lui.modules.cvar.combatText.WorldTextScale = T.tonumber(GetCVar("WorldTextScale"))
		--targetCombatText
		if GetCVar("floatingCombatTextCombatDamage") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatDamage = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatDamage = true
		end
		
		if GetCVar("floatingCombatTextCombatLogPeriodicSpells") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatLogPeriodicSpells = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatLogPeriodicSpells = true
		end
		
		if GetCVar("floatingCombatTextPetMeleeDamage") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextPetMeleeDamage = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextPetMeleeDamage = true
		end
		if GetCVar("floatingCombatTextPetSpellDamage") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextPetSpellDamage = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextPetSpellDamage = true
		end
		
		E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatDamageDirectionalScale = T.tonumber(GetCVar("floatingCombatTextCombatDamageDirectionalScale"))
		
		if GetCVar("floatingCombatTextCombatHealing") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatHealing = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatHealing = true
		end
		
		if GetCVar("floatingCombatTextCombatHealingAbsorbTarget") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatHealingAbsorbTarget = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextCombatHealingAbsorbTarget = true
		end
		
		if GetCVar("floatingCombatTextSpellMechanics") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextSpellMechanics = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextSpellMechanics = true
		end
		
		if GetCVar("floatingCombatTextSpellMechanicsOther") == "0" then
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextSpellMechanicsOther = false
		else
			E.db.lui.modules.cvar.combatText.targetCombatText.floatingCombatTextSpellMechanicsOther = true
		end
		
		--playerCombatText
		if GetCVar("enableFloatingCombatText") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.enableFloatingCombatText = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.enableFloatingCombatText = true
		end
		
		E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextFloatMode = T.tonumber(GetCVar("floatingCombatTextFloatMode"))
		
		if GetCVar("floatingCombatTextDodgeParryMiss") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextDodgeParryMiss = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextDodgeParryMiss = true
		end
		
		if GetCVar("floatingCombatTextCombatHealingAbsorbSelf") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextCombatHealingAbsorbSelf = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextCombatHealingAbsorbSelf = true
		end
		
		if GetCVar("floatingCombatTextDamageReduction") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextDamageReduction = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextDamageReduction = true
		end
		
		if GetCVar("floatingCombatTextLowManaHealth") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextLowManaHealth = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextLowManaHealth = true
		end
		
		if GetCVar("floatingCombatTextRepChanges") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextRepChanges = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextRepChanges = true
		end
		
		if GetCVar("floatingCombatTextEnergyGains") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextEnergyGains = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextEnergyGains = true
		end
		
		if GetCVar("floatingCombatTextComboPoints") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextComboPoints = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextComboPoints = true
		end
		
		if GetCVar("floatingCombatTextReactives") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextReactives = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextReactives = true
		end
		
		if GetCVar("floatingCombatTextPeriodicEnergyGains") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextPeriodicEnergyGains = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextPeriodicEnergyGains = true
		end
		
		if GetCVar("floatingCombatTextFriendlyHealers") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextFriendlyHealers = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextFriendlyHealers = true
		end
		
		if GetCVar("floatingCombatTextHonorGains") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextHonorGains = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextHonorGains = true
		end
		
		if GetCVar("floatingCombatTextCombatState") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextCombatState = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextCombatState = true
		end
		
		if GetCVar("floatingCombatTextAuras") == "0" then
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextAuras = false
		else
			E.db.lui.modules.cvar.combatText.playerCombatText.floatingCombatTextAuras = true
		end
		
	--unitframes
	if GetCVar("noBuffDebuffFilterOnTarget") == "0" then
		E.db.lui.modules.cvar.unitframes.noBuffDebuffFilterOnTarget = false
	else
		E.db.lui.modules.cvar.unitframes.noBuffDebuffFilterOnTarget = true
	end
	
	if GetCVar("threatShowNumeric") == "0" then
		E.db.lui.modules.cvar.unitframes.threatShowNumeric = false
	else
		E.db.lui.modules.cvar.unitframes.threatShowNumeric = true
	end
	
	--nameplates
	E.db.lui.modules.cvar.nameplates.nameplateMaxDistance = T.tonumber(GetCVar("nameplateMaxDistance"))
	
	E.db.lui.modules.cvar.nameplates.nameplateOtherAtBase = T.tonumber(GetCVar("nameplateOtherAtBase"))
	
	if GetCVar("ShowClassColorInFriendlyNameplate") == "0" then
		E.db.lui.modules.cvar.nameplates.ShowClassColorInFriendlyNameplate = false
	else
		E.db.lui.modules.cvar.nameplates.ShowClassColorInFriendlyNameplate = true
	end
	
	if GetCVar("nameplatePersonalShowAlways") == "0" then
		E.db.lui.modules.cvar.nameplates.nameplatePersonalShowAlways = false
	else
		E.db.lui.modules.cvar.nameplates.nameplatePersonalShowAlways = true
	end
	
	if GetCVar("nameplatePersonalShowWithTarget") == "0" then
		E.db.lui.modules.cvar.nameplates.nameplatePersonalShowWithTarget = false
	else
		E.db.lui.modules.cvar.nameplates.nameplatePersonalShowWithTarget = true
	end
	
	if GetCVar("nameplatePersonalShowInCombat") == "0" then
		E.db.lui.modules.cvar.nameplates.nameplatePersonalShowInCombat = false
	else
		E.db.lui.modules.cvar.nameplates.nameplatePersonalShowInCombat = true
	end
	
	E.db.lui.modules.cvar.nameplates.nameplateOtherTopInset = T.tonumber(GetCVar("nameplateOtherTopInset"))
	E.db.lui.modules.cvar.nameplates.nameplateLargeTopInset = T.tonumber(GetCVar("nameplateLargeTopInset"))
	
	E.db.lui.modules.cvar.nameplates.nameplateOverlapV = T.tonumber(GetCVar("nameplateOverlapV"))
	
	E.db.lui.modules.cvar.nameplates.nameplateMotionSpeed = T.tonumber(GetCVar("nameplateMotionSpeed"))
	
	E.db.lui.modules.cvar.nameplates.nameplateGlobalScale = T.tonumber(GetCVar("nameplateGlobalScale"))
	
	E.db.lui.modules.cvar.nameplates.nameplateMinScale = T.tonumber(GetCVar("nameplateMinScale"))
end

function LCV:Initialize()
    self:LoadCVar()
end

local function InitializeCallback()
	LCV:Initialize()
end

E:RegisterModule(LCV:GetName(), InitializeCallback)
