local LUI, T, E, L, V, P, G = unpack(select(2, ...))
local LRA = LUI:GetModule("LUIRaid");

local PLAYER_REALM = T.gsub(E.myrealm,'[%s%-]','')
local _G = _G
local RaiseFrameLevel = RaiseFrameLevel

function LRA:CreateAndUpdateIcons()
	local members = T.GetNumGroupMembers()
	for i = 1, members do
		local frame = _G["RaidGroupButton"..i]
		if not frame or (frame and not frame.subframes) then E:Delay(1, LRA.CreateAndUpdateIcons); return end
		local parent = frame.subframes.class
		--frame.subframes.level:Hide()
		if not frame.luiicon then
			frame.luiicon = CreateFrame("Frame", nil, frame)
			frame.luiicon:SetSize(14, 14)
			RaiseFrameLevel(frame.luiicon)
			frame.luiicon.texture = frame.luiicon:CreateTexture(nil, "OVERLAY")
			frame.luiicon.texture:SetAllPoints(frame.luiicon)
		end
		frame.luiicon:SetPoint("RIGHT", parent, "LEFT", -22, -0)

		local unit = T.IsInRaid() and "raid" or "party"
		local role = T.UnitGroupRolesAssigned(unit..i)
		local name, realm = T.UnitName(unit..i)
		local texture = ""
		if (role and role ~= "NONE") and name then	
			name = (realm and realm ~= '') and name..'-'..realm or name ..'-'..PLAYER_REALM;
			texture = LUI.rolePaths["ElvUI"][role]
		end
		frame.luiicon.texture:SetTexture(texture)
	end
end

function LRA:RaidLoaded(event, addon)
	if addon == "Blizzard_RaidUI" then
		LRA:CreateAndUpdateIcons()
		hooksecurefunc("RaidGroupFrame_Update", LRA.CreateAndUpdateIcons)
		self:UnregisterEvent(event)
	end
end

LRA:RegisterEvent("ADDON_LOADED", "RaidLoaded")
