local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LRA = LUI:NewModule("LUIRaid", "AceEvent-3.0");

function LRA:Initialize()
end

local function InitializeCallback()
	LRA:Initialize()
end

LUI:RegisterModule(LRA:GetName(), InitializeCallback)
