local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("modules", "raid", "teamStats") == true then return end

local LTS = E:GetModule("LuiTeamStats")

LTS.VERSION_BOSSES = { -13322, "娜", -13418, "乌", }

local RES = {
    {
        tab = "总览",
        ids = { 7399, -13080, -13449},
        widths = { 70, 50, 50 },
        names = { "大秘次数", "S1大师", "S2大师"},
        tips = { "史诗秘钥副本总次数（包括旧版本）", "《争霸艾泽拉斯》钥石征服者：第一赛季（全10层限时）", "《争霸艾泽拉斯》钥石大师：第一赛季（全15层限时）", "《争霸艾泽拉斯》钥石征服者：第二赛季（全10层限时）", "《争霸艾泽拉斯》钥石大师：第二赛季（全15层限时）"}
    },
}

local INSTANCES = {
    {
        bosses = {
            { "圣光勇士", 13329, 13330, {13331,-13292} },
            { "格洛恩", 13333, 13334, {13336,-13293} },
            { "弗雷菲斯和明光者", 13355, 13356, {13357,-13295} },
            { "丰灵", 13359, 13361, {13362,-13299} },
            { "神选者教团", 13364, 13365, {13366,-13300} },
            { "拉斯塔哈大王", 13368, 13369, {13370,-13311} },
            { "梅卡托克", 13372, 13373, {13374,-13312} },
            { "赢得风暴之墙阻击战", 13376, 13377, {13378,-13313} },
            { "吉安娜·普罗德摩尔", 13380, 13381, {13382,-13314} },
        },
        diff = { "", "H达萨", "M达萨", },
        tab = "达萨罗之战",
    },
    {
        bosses = {
            { "乌纳特，虚空先驱", 13411, 13412, 13413, },
            { "无眠秘党", 13405, 13406, 13407, },
          },
          diff = { "", "H风暴", "M风暴", },
          tab = "风暴熔炉",
    },
}

local TABS = {}

for ord, tab in next, RES do
    local one = { ids = {}, names = {}, tips = {}, tab = tab.tab, widths = {} }
    for i = 1, #tab.ids do
        if tab.names[i] and #tab.names[i] > 0 then
            one.ids[i] = tab.ids[i]
            one.names[i] = tab.names[i]
            one.tips[i] = tab.tips[i]
            one.widths[i] = tab.widths[i]
        end
    end

    for i, ins in ipairs(INSTANCES) do
        for j, diff in ipairs(ins.diff) do
            if diff and #diff > 0 then
                local bosses = {}
                for k = 1, #ins.bosses do
                    bosses[k] = ins.bosses[k][j + 1]
                end
                table.insert(one.ids, bosses)
                table.insert(one.names, diff)
            end
        end
    end
    tinsert(TABS, one)
end

local tip = "完成史诗副本的次数，注意包括普通史诗（非钥石）难度，因为暴雪的BUG，所以很多副本不准"
table.insert(TABS, {
    tab = "史诗副本次数",
    ids = { 12749, 12752, 12763, 12768, 12773, 12776, 12779, 12745, 12782, 12785 },
    widths = { 40, 40, 40, 40, 40, 40, 40, 40, 40, },
    tips = { tip, tip, tip, tip, tip, tip, tip, tip, tip, tip, tip, tip, tip,  },
    names = { "阿塔", "自由", "诸王", "风暴", "围攻", "神庙", "暴富", "地渊", "监狱", "庄园"},
})

table.insert(TABS, {
    tab = "千钧一发",
    any_done = true,
    ids = {
        {-13419}, {-13323}, {-12535},
        {-12111}, {-11875}, {-11192}, {-11580}, {-11191},
        {-10045}, {-9443}, {-9442},
        {-8401, -8400}, {-8260}, {-8238}, {-7487}, {-7486}, {-7485},
    },
    widths = { 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, },
    tips = {
        "千钧一发：乌纳特", "千钧一发：吉安娜", "千钧一发：戈霍恩",
        "千钧一发：阿古斯", "千钧一发：基尔加丹", "千钧一发：古尔丹", "千钧一发：海拉", "千钧一发：萨维斯",
        "千钧一发：黑暗之门（阿克蒙德）", "千钧一发：黑手的熔炉", "千钧一发：元首之陨",
        "千钧一发：加尔鲁什·地狱咆哮（10人或25人）", "千钧一发：莱登", "千钧一发：雷神",
        "千钧一发：惧之煞", "千钧一发：大女皇夏柯希尔", "千钧一发：皇帝的意志",
    },
    names = { "乌纳", "珍娜", "戈霍", "阿古", "基丹", "古尔", "海拉", "萨维", "阿克", "黑手", "悬槌", "小吼", "莱登", "雷神", "永春", "恐心", "魔古" },
})

LTS.TABS = TABS