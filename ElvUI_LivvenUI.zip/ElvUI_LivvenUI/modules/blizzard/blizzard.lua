local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LBL = LUI:NewModule("LUIBlizzard", "AceHook-3.0", "AceEvent-3.0");

function LBL:Initialize()
    if E.db.lui.modules.blizzard["castbarTime"] then self:LoadCastbarTime(); end
    if E.db.lui.modules.blizzard["minimapWheel"] then self:LoadminimapWheel(); end
    if E.db.lui.modules.blizzard.blizzardMoveFrames["enableBtn"] then self:LoadBlizzardMoveFrames(); end
end

local function InitializeCallback()
    LBL:Initialize();
end

LUI:RegisterModule(LBL:GetName(), InitializeCallback);
