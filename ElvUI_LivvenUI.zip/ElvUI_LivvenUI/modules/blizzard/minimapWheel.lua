--来源：LivvenUI
--作者：L
--修改：

local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "blizzard", "minimapWheel") == true then return; end

local LBL = LUI:GetModule("LUIBlizzard");

function LBL:LoadminimapWheel()
    Minimap:EnableMouseWheel(true);
    Minimap:SetScript("OnMouseWheel", function(self, wheel)
        if wheel > 0 then
            _G.MinimapZoomIn:Click();
        elseif wheel < 0 then
            _G.MinimapZoomOut:Click();
        end
    end)
end
