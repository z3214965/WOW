--来源：S&L
--作者：
--修改：L
local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "blizzard", "blizzardMoveFrames", "enableBtn") == true then return; end

local LBL = LUI:GetModule("LUIBlizzard");

local _G = _G;
local EnableMouse = EnableMouse;
local SetMovable = SetMovable;
local SetClampedToScreen = SetClampedToScreen;
local RegisterForDrag = RegisterForDrag;
local StartMoving = StartMoving;
local StopMovingOrSizing = StopMovingOrSizing;

LBL.Frames = {
    "AddonList",
    "AudioOptionsFrame",
    "BankFrame",
    "CharacterFrame",
    "ChatConfigFrame",
    "DressUpFrame",
    "FriendsFrame",
    "FriendsFriendsFrame",
    "GameMenuFrame",
    "GossipFrame",
    "GuildInviteFrame",
    "GuildRegistrarFrame",
    "HelpFrame",
    "InterfaceOptionsFrame",
    "ItemTextFrame",
    "LFDRoleCheckPopup",
    "LFGDungeonReadyDialog",
    "LFGDungeonReadyStatus",
    "LootFrame",
    "MailFrame",
    "MerchantFrame",
    "OpenMailFrame",
    "PVEFrame",
    "PetStableFrame",
    "PetitionFrame",
    "PVPReadyDialog",
    "QuestFrame",
    "QuestLogPopupDetailFrame",
    "RaidBrowserFrame",
    "RaidInfoFrame",
    "RaidParentFrame",
    "ReadyCheckFrame",
    "ReportCheatingDialog",
    "RolePollPopup",
    "ScrollOfResurrectionSelectionFrame",
    "SpellBookFrame",
    "SplashFrame",
    "StackSplitFrame",
    "StaticPopup1",
    "StaticPopup2",
    "StaticPopup3",
    "StaticPopup4",
    "TabardFrame",
    "TaxiFrame",
    "TimeManagerFrame",
    "TradeFrame",
    "TutorialFrame",
    "VideoOptionsFrame",
    "WorldMapFrame",
};

LBL.TempOnly = {
    ["BonusRollFrame"] = true,
    ["BonusRollLootWonFrame"] = true,
    ["BonusRollMoneyWonFrame"] = true,
};

LBL.AddonsList = {
    ["Blizzard_AchievementUI"] = {"AchievementFrame"},
    ["Blizzard_AlliedRacesUI"] = {"AlliedRacesFrame"},
    ["Blizzard_ArchaeologyUI"] = {"ArchaeologyFrame"},
    ["Blizzard_AuctionUI"] = {"AuctionFrame"},
    ["Blizzard_AzeriteUI"] = {"AzeriteEmpoweredItemUI"},
    ["Blizzard_BarberShopUI"] = {"BarberShopFrame"},
    ["Blizzard_BindingUI"] = {"KeyBindingFrame"},
    ["Blizzard_BlackMarketUI"] = {"BlackMarketFrame"},
    ["Blizzard_Calendar"] = {"CalendarCreateEventFrame", "CalendarFrame"},
    ["Blizzard_ChallengesUI"] = {"ChallengesKeystoneFrame"}, -- 'ChallengesLeaderboardFrame'
    ["Blizzard_Collections"] = {"CollectionsJournal", "WardrobeFrame"},
    ["Blizzard_Communities"] = {"CommunitiesFrame"},
    ["Blizzard_EncounterJournal"] = {"EncounterJournal"},
    ["Blizzard_GarrisonUI"] = {
        "GarrisonLandingPage", "GarrisonMissionFrame", "GarrisonCapacitiveDisplayFrame",
        "GarrisonBuildingFrame", "GarrisonRecruiterFrame", "GarrisonRecruitSelectFrame",
        "GarrisonShipyardFrame", "OrderHallMissionFrame", "BFAMissionFrame",
    },
    ["Blizzard_GMChatUI"] = {"GMChatStatusFrame"},
    ["Blizzard_GMSurveyUI"] = {"GMSurveyFrame"},
    ["Blizzard_GuildBankUI"] = {"GuildBankFrame"},
    ["Blizzard_GuildControlUI"] = {"GuildControlUI"},
    ["Blizzard_GuildUI"] = {"GuildFrame", "GuildLogFrame"},
    ["Blizzard_InspectUI"] = {"InspectFrame"},
    ["Blizzard_ItemAlterationUI"] = {"TransmogrifyFrame"},
    ["Blizzard_ItemSocketingUI"] = {"ItemSocketingFrame"},
    ["Blizzard_ItemUpgradeUI"] = {"ItemUpgradeFrame"},
    ["Blizzard_LookingForGuildUI"] = {"LookingForGuildFrame"},
    ["Blizzard_MacroUI"] = {"MacroFrame"},
    ["Blizzard_OrderHallUI"] = {"OrderHallTalentFrame"},
    ["Blizzard_QuestChoice"] = {"QuestChoiceFrame"},
    ["Blizzard_ScrappingMachineUI"] = {"ScrappingMachineFrame"},
    ["Blizzard_TalentUI"] = {"PlayerTalentFrame"},
    ["Blizzard_TradeSkillUI"] = {"TradeSkillFrame"},
    ["Blizzard_TrainerUI"] = {"ClassTrainerFrame"},
    ["Blizzard_VoidStorageUI"] = {"VoidStorageFrame"},
};

LBL.ExlusiveFrames = {
    ["QuestFrame"] = {"GossipFrame", },
    ["GossipFrame"] = {"QuestFrame", },
    ["GameMenuFrame"] = {"VideoOptionsFrame", "InterfaceOptionsFrame", "HelpFrame", },
    ["VideoOptionsFrame"] = {"GameMenuFrame", },
    ["InterfaceOptionsFrame"] = {"GameMenuFrame", },
    ["HelpFrame"] = {"GameMenuFrame", },
};

LBL.NoSpecialFrames = {
    ["StaticPopup1"] = true,
    ["StaticPopup2"] = true,
    ["StaticPopup3"] = true,
    ["StaticPopup4"] = true,
};

LBL.FramesAreaAlter = {
    ["GarrisonMissionFrame"] = "left",
    ["OrderHallMissionFrame"] = "left",
    ["BFAMissionFrame"] = "left",
};

LBL.SpecialDefaults = {
    ["GarrisonMissionFrame"] = {"CENTER", _G.UIParent, "CENTER", 0, 0},
    ["OrderHallMissionFrame"] = {"CENTER", _G.UIParent, "CENTER", 0, 0},
    ["BFAMissionFrame"] = {"CENTER", _G.UIParent, "CENTER", 0, 0},
};

local function OnDragStart(self)
    self.IsMoving = true;
    self:StartMoving();
end

local function OnDragStop(self)
    self:StopMovingOrSizing();
    local Name = self:GetName();
    if LBL.db.remember and not LBL.TempOnly[Name] then
        local a, b, c, d, e = self:GetPoint();
        if self:GetParent() then
            b = self:GetParent():GetName() or UIParent;
            if not _G[b] then b = UIParent; end
        else
            b = UIParent;
        end
        if Name == "QuestFrame" or Name == "GossipFrame" then
            LBL.db.points["GossipFrame"] = {a, b, c, d, e};
            LBL.db.points["QuestFrame"] = {a, b, c, d, e};
        else
            LBL.db.points[Name] = {a, b, c, d, e};
        end
        self:SetUserPlaced(true);
    else
        self:SetUserPlaced(false);
    end
    self.IsMoving = false;
end

local function LoadPosition(self)
    if self.IsMoving == true then return; end
    local Name = self:GetName();
    if not self:GetPoint() then
        if LBL.SpecialDefaults[Name] then
            local a, b, c, d, e = T.unpack(LBL.SpecialDefaults[Name]);
            self:SetPoint(a, b, c, d, e, true);
        else
            self:SetPoint('TOPLEFT', 'UIParent', 'TOPLEFT', 16, -116, true);
        end
        OnDragStop(self);
    end
    
    if LBL.db.remember and LBL.db.points[Name] then
        self:ClearAllPoints();
        local a, b, c, d, e = T.unpack(LBL.db.points[Name]);
        self:SetPoint(a, b, c, d, e, true);
    end
    
    if LBL.ExlusiveFrames[Name] then
        for _, name in T.pairs(LBL.ExlusiveFrames[Name]) do _G[name]:Hide(); end
    end
end

function LBL:RewritePoint(anchor, parent, point, x, y, SLEcalled)
    if not SLEcalled then LoadPosition(self); end
end

function LBL:MakeMovable(Name)
    local frame = _G[Name];
    if not frame then
        LUI:Print("Frame to move doesn't exist: " .. (Name or "Unknown"), "error");
        return;
    end
    
    if Name == "AchievementFrame" then AchievementFrameHeader:EnableMouse(false); end
    
    frame:EnableMouse(true);
    frame:SetMovable(true);
    frame:SetClampedToScreen(true);
    frame:RegisterForDrag("LeftButton");
    frame:HookScript("OnShow", LoadPosition);
    frame:HookScript("OnDragStart", OnDragStart);
    frame:HookScript("OnDragStop", OnDragStop);
    frame:HookScript("OnHide", OnDragStop);
    hooksecurefunc(frame, "SetPoint", LBL.RewritePoint);
    
    frame.ignoreFramePositionManager = true;
    if LBL.FramesAreaAlter[Name] then
        if UIPanelWindows[Name] and UIPanelWindows[Name].area then UIPanelWindows[Name].area = LBL.FramesAreaAlter[Name]; end
    end
end

function LBL:Addons(event, addon)
    addon = LBL.AddonsList[addon];
    if not addon then return; end
    if T.type(addon) == "table" then
        for i = 1, #addon do
            LBL:MakeMovable(addon[i]);
        end
    else
        LBL:MakeMovable(addon);
    end
    LBL.addonCount = LBL.addonCount + 1;
    
    if LBL.addonCount == #LBL.AddonsList then LBL:UnregisterEvent(event); end
end

function LBL:ErrorFrameSize()
    _G["UIErrorsFrame"]:SetSize(LBL.db.errorframe.width, LBL.db.errorframe.height);
end

local ToDelete = {
    ["CalendarViewEventFrame"] = true,
    ["CalendarViewHolidayFrame"] = true,
}

function LBL:LoadBlizzardMoveFrames()
    LBL.db = E.db.lui.modules.blizzard.blizzardMoveFrames;
    LBL.addonCount = 0;
    
    for Name, _ in T.pairs(ToDelete) do
        if LBL.db.points[Name] then
            LBL.db.points[Name] = nil;
        end
    end
    
    PVPReadyDialog:Hide();
    
    if LBL.db.enableBtn then
        for Name, _ in T.pairs(LBL.TempOnly) do
            if LBL.db.points[Name] then
                LBL.db.points[Name] = nil;
            end
        end
        for i = 1, #LBL.Frames do
            LBL:MakeMovable(LBL.Frames[i]);
        end
        
        self:RegisterEvent("ADDON_LOADED", "Addons");
        
        for AddOn, Table in T.pairs(LBL.AddonsList) do
            if IsAddOnLoaded(AddOn) then
                for _, frame in T.pairs(Table) do
                    LBL:MakeMovable(frame);
                end
            end
        end
    end
    
    LBL:ErrorFrameSize();
    function LBL:ForUpdateAll()
        LBL.db = E.db.lui.modules.blizzard.blizzardMoveFrames;
        LBL:ErrorFrameSize();
    end
end
