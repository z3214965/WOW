local LUI, T, E, L, V, P, G = unpack(select(2, ...));
if LUI:CheckDB("modules", "chat", "chatBub", "enableBtn") == true then return; end

local LCH = LUI:GetModule("LUIChat");

function LCH:LoadChatBub()
    if T.IsInInstance() then
        SetCVar("chatBubbles", 1);
        if E.db.lui.modules.chat.chatBub["chatBubTip"] then
            LUI:Print(ENABLE .. L["chatBubbles"]);
        end
    else
        SetCVar("chatBubbles", 0);
        if E.db.lui.modules.chat.chatBub["chatBubTip"] then
            LUI:Print(DISABLE .. L["chatBubbles"]);
        end
    end
end
