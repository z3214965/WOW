local LUI, T, E, L, V, P, G = unpack(select(2, ...))
if LUI:CheckDB("modules", "chat", "chatBub", "enable") == true then return end
local LCB = E:NewModule("LuiChatBub")

function LCB:Initialize()
    if T.IsInInstance() then
        SetCVar("chatBubbles", 1)
        if E.db.lui.modules.chat.chatBub["chatBubTip"] then
            LUI:Print(ENABLE .. L["chatBubbles"])
        end
    else
        SetCVar("chatBubbles", 0)
        if E.db.lui.modules.chat.chatBub["chatBubTip"] then
            LUI:Print(DISABLE .. L["chatBubbles"])
        end
    end
end

local function InitializeCallback()
    if not E.db.lui.modules.chat.chatBub["enable"] then return end
    LCB:Initialize()
end

E:RegisterModule(LCB:GetName(), InitializeCallback)