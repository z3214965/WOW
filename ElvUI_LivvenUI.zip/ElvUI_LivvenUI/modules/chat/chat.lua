local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local LCH = LUI:NewModule("LUIChat", "AceHook-3.0", "AceEvent-3.0");

function LCH:Initialize()
    if E.db.lui.modules.chat.chatBar["enableBtn"] then
        self:LoadChatbar();
        self:LoadChatEmote();
        self:LoadChatMod();
    end
    
    if E.db.lui.modules.chat.chatMSGLoot["enableBtn"] then self:LoadChatMSGLoot(); end
    
    if E.db.lui.modules.chat.chatBub["enableBtn"] then self:RegisterEvent("PLAYER_ENTERING_WORLD", "LoadChatBub"); end
    
    if E.db.lui.modules.chat.chatTradeLog["enableBtn"] then self:LoadChatTradeLog(); end
    
    if E.db.lui.modules.chat.chatRepChange["enableBtn"] then self:LoadChatRepChange(); end
end

local function InitializeCallback()
    LCH:Initialize();
end

LUI:RegisterModule(LCH:GetName(), InitializeCallback);
