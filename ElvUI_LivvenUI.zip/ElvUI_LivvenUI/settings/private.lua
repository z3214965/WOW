local LUI, T, E, L, V, P, G = unpack(select(2, ...))

V.lui = {
    session = {
        day = 0,
    },
}
