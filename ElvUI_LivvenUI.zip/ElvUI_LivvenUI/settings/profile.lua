local LUI, T, E, L, V, P, G = unpack(select(2, ...));

P.lui = {
    general = {
        splashScreen = true,
        loginMsg = true,
        gamemenu = true,
        style = true,
    },
    modules = {
        cvar = {
            general = {
                alwaysCompareItems = false,
                breakUpLargeNumbers = true,
                scriptErrors = false,
                enableWoWMouse = false,
                trackQuestSorting = "top",
            },
            interface = {
                cameraDistanceMaxZoomFactor = 1.9,
                ffxGlow = true,
                xpBarText = true,
                weatherDensity = 3,
            },
            chat = {
                profanityFilter = true,
                removeChatDelay = false,
                chatMouseScroll = true,
                chatBubbles = true,
            },
            combat = {
                secureAbilityToggle = true,
                stopAutoAttackOnTargetChange = false,
                assistAttack = false,
                SpellQueueWindow = 400,
            },
            combatText = {
                worldTextScale = 1.0,
                targetCombatText = {
                    floatingCombatTextCombatDamage = true,
                    floatingCombatTextCombatLogPeriodicSpells = true,
                    floatingCombatTextPetMeleeDamage = true,
                    floatingCombatTextPetSpellDamage = true,
                    floatingCombatTextCombatDamageDirectionalScale = 1,
                    floatingCombatTextCombatHealing = true,
                    floatingCombatTextCombatHealingAbsorbTarget = true,
                    floatingCombatTextSpellMechanics = false,
                    floatingCombatTextSpellMechanicsOther = false,
                },
                playerCombatText = {
                    enableFloatingCombatText = false,
                    floatingCombatTextFloatMode = 1,
                    floatingCombatTextDodgeParryMiss = false,
                    floatingCombatTextCombatHealingAbsorbSelf = true,
                    floatingCombatTextDamageReduction = false,
                    floatingCombatTextLowManaHealth = true,
                    floatingCombatTextRepChanges = false,
                    floatingCombatTextEnergyGains = false,
                    floatingCombatTextComboPoints = false,
                    floatingCombatTextReactives = true,
                    floatingCombatTextPeriodicEnergyGains = false,
                    floatingCombatTextFriendlyHealers = false,
                    floatingCombatTextHonorGains = false,
                    floatingCombatTextCombatState = false,
                    floatingCombatTextAuras = false,
                },
            },
            unitframes = {
                noBuffDebuffFilterOnTarget = false,
                threatShowNumeric = false,
            },
            nameplates = {
                nameplateMaxDistance = 60,
                nameplateOtherAtBase = 0,
                ShowClassColorInFriendlyNameplate = true,
                nameplatePersonalShowAlways = false,
                nameplatePersonalShowWithTarget = false,
                nameplatePersonalShowInCombat = true,
                nameplateOtherTopInset = 0.08,
                nameplateLargeTopInset = 0.1,
                nameplateOverlapV = 1.1,
                nameplateMotionSpeed = 0.025,
                nameplateGlobalScale = 1,
                nameplateMinScale = 0.8,
            }
        },
        misc = {
            general = {
                alreadyKnown = {
                    enableBtn = true,
                    color = {
                        r = 0,
                        g = 1,
                        b = 0,
                    },
                },
                rightButtonMenu = false,
                disableTalking = false,
                classColors = true,
                autoDelete = true,
                autoRelease = true,
                autoRepChange = true,
                autoScreenShoot = {
                    enableBtn = true,
                },
                talentProfiles = {
                    enableBtn = true,
                    talentButtonElvUI = true,
                },
                setPoi = {
                    enableBtn = false,
                    poiCombat = true,
                    poiColor = {r = 0.5, g = 1, b = 1},
                    poiText = "╋",
                    poiTextSize = 22,
                }
            },
            inviteGroup = {
                enableBtn = true,
                ainvkeyword = "321",
                inviteRank = {},
            },
            loot = {
                lootSpecManager = {
                    enableBtn = true,
                },
                fastLoot = {
                    enableBtn = true,
                    lootSpeed = "光速",
                },
            },
        },
        quest = {
            questAutomation = {
                enableBtn = true,
                syncBtn = false,
                autoChoices = true,
                frameBtn = true,
                frameBtnElvUI = true,
            },
            questAnnouncment = {
                enableBtn = true,
                syncBtn = false,
                questSolo = true,
                questParty = true,
                questRaid = true,
                questInstance = true,
                questNoDetail = false,
                frameBtn = true,
                frameBtnElvUI = true,
            },
            questListEnhanced = {
                enableBtn = true,
                questTitleColor = true,
                questList = {
                    titleFont = E.db.general.font,
                    titleFontSize = 12,
                    titleFontFlag = "NONE",
                    infoFont = E.db.general.font,
                    infoFontSize = 12,
                    infoFontFlag = "NONE",
                },
                questLevel = {
                    titleLevel = true,
                    detailLevel = true,
                    ignoreHighLevel = true,
                },
                questFrame = {
                    frameTitle = false,
                    leftSide = false,
                    leftSideSize = 18,
                },
            }
        },
        unitframes = {
            playerframe = {
                gcdBar = true,
                swingBar = {
                    enableBtn = true,
                    swingBarColor = {r = 1, b = 1, g = 1, a = 1},
                    swingBarWidth = 270,
                    swingBarHeight = 18,
                    remainingText = true,
                    durationText = true,
                    swingBarFontName = E.db.general.font,
                    swingBarFontSize = 12,
                    swingBarFontFlag = "OUTLINE",
                }
            },
            targetframe = {
                rangeText = {
                    enableBtn = true,
                    rangeFontName = E.db.general.font,
                    rangeFontSize = 12,
                    rangeFontFlag = "OUTLINE",
                    rangePoi = "BOTTOMLEFT",
                    rangePoiX = 0,
                    rangePoiY = 0,
                }
            },
            focusframe = {
                rangeText = {
                    enableBtn = true,
                    rangeFontName = E.db.general.font,
                    rangeFontSize = 12,
                    rangeFontFlag = "OUTLINE",
                    rangePoi = "BOTTOMLEFT",
                    rangePoiX = 0,
                    rangePoiY = 0,
                }
            }
        },
        chat = {
            chatBar = {
                enableBtn = true,
                chatBarPoi = "chatBarIN",
                syncBtn = false,
            },
            chatBub = {
                enableBtn = true,
                chatBubTip = false,
            },
            chatTradeLog = {
                enableBtn = true,
                tradeSendChat = false,
            },
            chatMSGLoot = {
                enableBtn = true,
                chatMSGLootGS = false,
            },
            chatRepChange = {
                enableBtn = true,
            },
        },
        combat = {
            announceSystem = {
                enableBtn = true,
                raidSpells = {
                    enableBtn = true,
                },
                resAndThreatSpells = {
                    enableBtn = true,
                    resAndThreat = true,
                    resThanks = true,
                },
                taunt = {
                    enableBtn = true,
                    playerSmart = false,
                    includeMiss = true,
                    otherTankSmart = false,
                    includeOtherTank = true,
                    petSmart = false,
                    includePet = true,
                },
            },
            combatNotification = {
                enableBtn = true,
                combatNotiEntering = "进入战斗",
                combatNotiLeaving = "离开战斗",
                combatNotiFont = E.db.general.font,
                combatNotiSize = 25,
                combatNotiFlag = "OUTLINE",
            },
            combatShortcut = {
                raidMarkingKey = {
                    raidMarkingButton1 = "alt",
                    raidMarkingButton2 = "LeftButton",
                },
                setFocusKey = {
                    setFocusButton1 = "shift",
                    setFocusButton2 = "1",
                },
            }
        },
        actionbars = {
            randomHearthstone = {
                enableBtn = true,
            },
        },
        maps = {
            whoClickMinimap = true,
            squareMinimap = {
                enableBtn = true,
                squareMinimapDC = "DOWN",
            },
        },
        blizzard = {
            castbarTime = false,
            minimapWheel = false,
            blizzardMoveFrames = {
                enableBtn = false,
                remember = false,
                points = {},
                errorframe = {
                    height = 60,
                    width = 512,
                },
            },
        },
        tooltip = {
            atlasLootReverse = true,
            tooltipIcon = true,
            raidProg = {
                enableBtn = true,
                nameStyle = "SHORT",
                difStyle = "SHORT",
                raids = {
                    antorus = false,
                    uldir = true,
                    daz = true,
                    sc = true,
                },
            },
            nameHover = {
                enableBtn = true,
                guildName = true,
                guildRank = true,
                race = true,
                realm = true,
                titles = true,
                fontName = E.db.general.font,
                fontSize = 10,
                fontFlag = "OUTLINE",
            },
        },
        nameplates = {
            castbarTarget = true,
        },
        bags = {
            moveElvUIBags = true,
        },
        raid = {
            raidManager = true,
            teamStats = true,
        }
    },
    media = {
        zoneTexts = {
            enableBtn = true,
            zoneText = {
				fontName = E.db.general.font,
				fontSize = 32,
				fontFlag = "OUTLINE",
				width = 512,
			},
			subzoneText = {
				fontName = E.db.general.font,
				fontSize = 25,
				fontFlag = "OUTLINE",
				width = 512,
			},
			pvpstatusText = {
				fontName = E.db.general.font,
				fontSize = 22,
				fontFlag = "OUTLINE",
				width = 512,
			},
        },
        miscTexts = {
            mailText = {
                enableBtn = true,
				fontName = E.db.general.font,
				fontSize = 12,
				fontFlag = "NONE",
			},
			editboxText = {
                enableBtn = true,
				fontName = E.db.general.font,
				fontSize = 12,
				fontFlag = "NONE",
			},
			questGossip = {
                enableBtn = true,
				fontName = E.db.general.font,
				fontSize = 12,
				fontFlag = "NONE",
            },
            questFontSuperHuge = {
                enableBtn = true,
				fontName = E.db.general.font,
				fontSize = 12,
				fontFlag = "NONE",
			},
			questHeader = {
                enableBtn = true,
                fontcolor = {r = 1, g = 0.82, b = 0},
				fontName = E.db.general.font,
				fontSize = 12,
				fontFlag = "OUTLINE",
			},
			questTracker = {
                enableBtn = true,
				fontcolor = {r = 1, g = 0.82, b = 0},
				fontName = E.db.general.font,
				fontSize = 12,
				fontFlag = "NONE",
			},
        }
    }
}
