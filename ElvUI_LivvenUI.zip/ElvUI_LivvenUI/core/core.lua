local E, L, V, P, G = unpack(ElvUI);
local EP = LibStub("LibElvUIPlugin-1.0");
local AddOnName, Engine = ...;
local _G = _G;
local tonumber = tonumber;
local format = string.format;

local LUI = LibStub("AceAddon-3.0"):NewAddon(AddOnName, "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0", "AceHook-3.0");
LUI.callbacks = LUI.callbacks or LibStub("CallbackHandler-1.0"):New(LUI);

LUI.Title = format("|cff9482c9%s|r", AddOnName);
LUI.Version = format("|cfff960d9%s|r", GetAddOnMetadata(AddOnName, "Version"));
LUI.Header = LUI.Title .. " |cfff960d9v|r" .. LUI.Version;
LUI.Configs = {};
LUI["styling"] = {};
LUI.Logo = [[Interface\AddOns\ElvUI_LivvenUI\media\textures\LUILogo.tga]];
LUI.SmallLogo = [[Interface\AddOns\ElvUI_LivvenUI\media\textures\LUISmallLogo.tga]];

local Toolkit = {};

Engine[1] = LUI
Engine[2] = Toolkit
Engine[3] = E
Engine[4] = L
Engine[5] = V
Engine[6] = P
Engine[7] = G
_G[AddOnName] = Engine;

LUI.ElvUIV = tonumber(E.version);
LUI.ElvUIX = tonumber(GetAddOnMetadata(AddOnName, "X-ElvVersion"));

local function GetOptions()
    for _, func in Toolkit.pairs(LUI.Configs) do
        func();
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
    LUI:Initialize()
end)

function LUI:Initialize()
    if LUI.ElvUIV < LUI.ElvUIX then
        E:StaticPopup_Show("VERSION_MISMATCH");
        return;
    end
    self.initialized = true;
    self:LoadCommands();
    --if LUI.falgDB == false then self:RegisterEvent("PLAYER_LEAVING_WORLD", "CreateDB"); end   --L: 恢复检测ElvDB
    self:InitializeModules();
    self:SetupProfileCallbacks();

    if E.db.lui.general.splashScreen then self:SplashScreen(); end
    if E.db.lui.general.gamemenu then self:GameMenu(); end
    if E.db.lui.general.loginMsg then
        LUI:Print(Toolkit.format(L["LUI_LOGIN_MSG"], LUI.Header, LUI:PrintLink("/lui"), LUI:PrintLink("Livven#51778")));
    end
    E:Delay(5, function()LUI:CheckVersion() end);
    
    EP:RegisterPlugin(AddOnName, GetOptions);
end
