local LUI, T, E, L, V, P, G = unpack(select(2, ...));

LUI.falgDB = false;

function LUI:WipeDB()
	LUI.falgDB = true;
	E.db["LUIDB"] = nil;
	E.global["LUIDB"] = nil;
end

local function CreateProfilesDB()
	ElvDB.profiles[E.myname..' - '..E.myrealm]["LUIDB"] = {
		general = {
			splashScreen = E.db.lui.general["splashScreen"],
			loginMsg = E.db.lui.general["loginMsg"],
			gamemenu = E.db.lui.general["gamemenu"],
		},
		special = {
			teamStats = E.db.lui.special["teamStats"],
		},
		modules = {
			tooltip = {
				atlasLootReverse = E.db.lui.modules.tooltip["atlasLootReverse"],
				showFaction = E.db.lui.modules.tooltip["showFaction"],
				raidProg = {
					enableBtn = E.db.lui.modules.tooltip.raidProg["enableBtn"],
				},
			},
			unitframes = {
				playerframe = {
					gcdBar = E.db.lui.modules.unitframes.playerframe["gcdBar"],
					swingBar = {
						enableBtn = E.db.lui.modules.unitframes.playerframe.swingBar["enableBtn"],
					},
				},
				targetframe = {
					rangeText = {
						enableBtn = E.db.lui.modules.unitframes.targetframe.rangeText["enableBtn"],
					},
				},
				focusframe = {
					rangeText = {
						enableBtn = E.db.lui.modules.unitframes.focusframe.rangeText["enableBtn"],
					},
				},
			},
			quest = {
				questAutomation = {
					enableBtn = E.db.lui.modules.quest.questAutomation["enableBtn"],
				},
				questAnnouncment = {
					enableBtn = E.db.lui.modules.quest.questAnnouncment["enableBtn"],
				},
				questListEnhanced = {
					enableBtn = E.db.lui.modules.quest.questListEnhanced["enableBtn"],
				},
			},
			maps = {
				whoClickMinimap = E.db.lui.modules.maps["whoClickMinimap"],
				squareMinimap = {
					enableBtn = E.db.lui.modules.maps.squareMinimap["enableBtn"],
				},
			},
			combat = {
				announceSystem = {
					enableBtn = E.db.lui.modules.combat.announceSystem["enableBtn"],
				},
				combatNotification = {
					enableBtn = E.db.lui.modules.combat.combatNotification["enableBtn"],
				},
			},
			chat = {
				chatBar = {
					enableBtn = E.db.lui.modules.chat.chatBar["enableBtn"],
				},
				chatBub = {
					enableBtn = E.db.lui.modules.chat.chatBub["enableBtn"],
				},
				chatTradeLog = {
					enableBtn = E.db.lui.modules.chat.chatTradeLog["enableBtn"],
				},
				chatMSGLoot = {
					enableBtn = E.db.lui.modules.chat.chatMSGLoot["enableBtn"],
				},
				chatRepChange = {
					enableBtn = E.db.lui.modules.chat.chatRepChange["enableBtn"],
				},
			},
			blizzard = {
				castbarTime = E.db.lui.modules.blizzard["castbarTime"],
				minimapWheel = E.db.lui.modules.blizzard["minimapWheel"],
				blizzardMoveFrames = {
					enableBtn = E.db.lui.modules.blizzard.blizzardMoveFrames["enableBtn"],
				},
			},
			misc = {
				general = {
					alreadyKnown = {
						enableBtn = E.db.lui.modules.misc.general.alreadyKnown["enableBtn"],
					},
					rightButtonMenu = E.db.lui.modules.misc.general["rightButtonMenu"],
					disableTalking = E.db.lui.modules.misc.general["disableTalking"],
					classColors = E.db.lui.modules.misc.general["classColors"],
					autoRelease = E.db.lui.modules.misc.general["autoRelease"],
					autoRepChange = E.db.lui.modules.misc.general["autoRepChange"],
					autoScreenShoot = {
						enableBtn = E.db.lui.modules.misc.general.autoScreenShoot["enableBtn"]
					},
					talentProfiles = {
						enableBtn = E.db.lui.modules.misc.general.talentProfiles["enableBtn"],
					},
				},
				loot = {
					fastLoot = {
						enableBtn = E.db.lui.modules.misc.loot.fastLoot["enableBtn"],
					},
					lootSpecManager = {
						enableBtn = E.db.lui.modules.misc.loot.lootSpecManager["enableBtn"],
					},
				},
			},
			nameplates = {
				castbarTarget = E.db.lui.modules.nameplates["castbarTarget"],
			},
			bags = {
				moveElvUIBags = E.db.lui.modules.bags["moveElvUIBags"],
			}
		},
	}
end

local function CreateGlobalDB()
	ElvDB.global["LUIDB"] = {
		modules = {
			filters = {
				infoFilter = {
					enableBtn = E.global.lui.modules.filters.infoFilter["enableBtn"],
				},
				pmFilter = {
					enableBtn = E.global.lui.modules.filters.pmFilter["enableBtn"],
				},
			},
		},
	}
end

function LUI:CreateDB()
	if LUI.falgDB == false then
		CreateProfilesDB();
		CreateGlobalDB();
	end
	LUI.falgDB = false;
end
