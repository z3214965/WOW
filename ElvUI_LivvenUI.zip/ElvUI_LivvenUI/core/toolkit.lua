local LUI, T, E, L, V, P, G = unpack(select(2, ...))

local _G = _G
T.string_find = string.find
T.format = format
T.string_format = string.format
T.string_gmatch = string.gmatch
T.string_join = string.join
T.string_match = string.match
T.string_split = string.split
T.string_len = string.len
T.string_lower = string.lower
T.string_sub = string.sub
T.string_upper = string.upper
T.string_utf8sub = string.utf8sub
T.table_sort = table.sort
T.table_concat = table.concat
T.table_copy = table.copy
T.table_wipe = table.wipe
T.math_modf = math.modf
T.AcceptQuest = AcceptQuest
T.Ambiguate = Ambiguate
T.BNConnected = BNConnected
T.BNGetFriendGameAccountInfo = BNGetFriendGameAccountInfo
T.BNGetFriendIndex = BNGetFriendIndex
T.BNGetFriendInfo = BNGetFriendInfo
T.BNGetGameAccountInfo = BNGetGameAccountInfo
T.BNGetNumFriendGameAccounts = BNGetNumFriendGameAccounts
T.BNGetNumFriends = BNGetNumFriends
T.C_AreaPoiInfo_GetAreaPOISecondsLeft = C_AreaPoiInfo.GetAreaPOISecondsLeft
T.C_Calendar_GetDate = C_Calendar.GetDate
T.C_Calendar_GetDayEvent = C_Calendar.GetDayEvent
T.C_Calendar_GetNumDayEvents = C_Calendar.GetNumDayEvents
T.C_Calendar_GetNumPendingInvites = C_Calendar.GetNumPendingInvites
T.C_Calendar_OpenCalendar = C_Calendar.OpenCalendar
T.C_Calendar_SetAbsMonth = C_Calendar.SetAbsMonth
T.C_Club_GetClubInfo = C_Club.GetClubInfo
T.C_DateAndTime_GetCurrentCalendarTime = C_DateAndTime.GetCurrentCalendarTime
T.C_FriendList_AddFriend = C_FriendList.AddFriend
T.C_FriendList_GetNumFriends = C_FriendList.GetNumFriends
T.C_Garrison_IsPlayerInGarrison = C_Garrison.IsPlayerInGarrison
T.C_IslandsQueue_GetIslandsWeeklyQuestID = C_IslandsQueue.GetIslandsWeeklyQuestID
T.C_Map_GetBestMapForUnit = C_Map.GetBestMapForUnit
T.C_TaskQuest_GetQuestsForPlayerByMapID = C_TaskQuest.GetQuestsForPlayerByMapID
T.C_Map_GetCurrentMapAreaID = C_Map.GetCurrentMapAreaID
T.C_Map_GetMapInfo = C_Map.GetMapInfo
T.C_Reputation_GetFactionParagonInfo = C_Reputation.GetFactionParagonInfo
T.C_Reputation_IsFactionParagon = C_Reputation.IsFactionParagon
T.C_Timer_NewTicker = C_Timer.NewTicker
T.C_Timer_After = C_Timer.After
T.C_AzeriteEmpoweredItem_HasBeenViewed = C_AzeriteEmpoweredItem.HasBeenViewed
T.C_AzeriteEmpoweredItem_SetHasBeenViewed = C_AzeriteEmpoweredItem.SetHasBeenViewed
T.CanCooperateWithGameAccount = CanCooperateWithGameAccount
T.CanEditOfficerNote = CanEditOfficerNote
T.CanEditPublicNote = CanEditPublicNote
T.CanInspect = CanInspect
T.ClearAchievementComparisonUnit = ClearAchievementComparisonUnit
T.CloseQuest = CloseQuest
T.CreateFrame = CreateFrame
T.date = date
T.difftime = difftime
T.DisableAddOn = DisableAddOn
T.error = error
T.FauxScrollFrame_GetOffset = FauxScrollFrame_GetOffset
T.FlipCameraYaw = FlipCameraYaw
T.floor = floor
T.GameTooltip = GameTooltip
T.GetAchievementInfo = GetAchievementInfo
T.GetActiveSpecGroup = GetActiveSpecGroup
T.GetActiveTitle = GetActiveTitle
T.GetAutoQuestPopUp = GetAutoQuestPopUp
T.GetAverageItemLevel = GetAverageItemLevel
T.GetBattlefieldScore = GetBattlefieldScore
T.GetBuildInfo = GetBuildInfo
T.GetBuybackItemLink = GetBuybackItemLink
T.GetChannelName = GetChannelName
T.GetClassInfo = GetClassInfo
T.GetComparisonStatistic = GetComparisonStatistic
T.GetContainerItemID = GetContainerItemID
T.GetContainerItemInfo = GetContainerItemInfo
T.GetContainerItemLink = GetContainerItemLink
T.GetContainerItemQuestInfo = GetContainerItemQuestInfo
T.GetContainerNumSlots = GetContainerNumSlots
T.GetItemInfoFromHyperlink = GetItemInfoFromHyperlink
T.GetCurrencyInfo = GetCurrencyInfo
T.GetCurrencyListSize = GetCurrencyListSize
T.GetCurrentRegion = GetCurrentRegion
T.GetCursorPosition = GetCursorPosition
T.GetCVar = GetCVar
T.GetCVarBool = GetCVarBool
T.GetDetailedItemLevelInfo = GetDetailedItemLevelInfo
T.GetFactionInfo = GetFactionInfo
T.GetFriendInfo = GetFriendInfo
T.GetFriendshipReputation = GetFriendshipReputation
T.GetFriendshipReputationRanks = GetFriendshipReputationRanks
T.GetGameTime = GetGameTime
T.getglobal = getglobal
T.GetGossipActiveQuests = GetGossipActiveQuests
T.GetGossipAvailableQuests = GetGossipAvailableQuests
T.GetGuildInfo = GetGuildInfo
T.GetGuildLogoInfo = GetGuildLogoInfo
T.GetGuildRosterInfo = GetGuildRosterInfo
T.GetGuildRosterMOTD = GetGuildRosterMOTD
T.GetInboxHeaderInfo = GetInboxHeaderInfo
T.GetInspectArenaData = GetInspectArenaData
T.GetInspectGuildInfo = GetInspectGuildInfo
T.GetInspectHonorData = GetInspectHonorData
T.GetInspectRatedBGData = GetInspectRatedBGData
T.GetInspectSpecialization = GetInspectSpecialization
T.GetInstanceInfo = GetInstanceInfo
T.GetInventoryItemDurability = GetInventoryItemDurability
T.GetInventoryItemID = GetInventoryItemID
T.GetInventoryItemLink = GetInventoryItemLink
T.GetInventoryItemQuality = GetInventoryItemQuality
T.GetInventoryItemTexture = GetInventoryItemTexture
T.GetInventorySlotInfo = GetInventorySlotInfo
T.GetItemCooldown = GetItemCooldown
T.GetItemCount = GetItemCount
T.GetItemIcon = GetItemIcon
T.GetItemInfo = GetItemInfo
T.GetItemQualityColor = GetItemQualityColor
T.GetInventoryItemCooldown = GetInventoryItemCooldown
T.GetLFGDungeonEncounterInfo = GetLFGDungeonEncounterInfo
T.GetLFGDungeonNumEncounters = GetLFGDungeonNumEncounters
T.GetLocale = GetLocale
T.GetLootRollItemInfo = GetLootRollItemInfo
T.GetLootRollItemLink = GetLootRollItemLink
T.GetLootSlotInfo = GetLootSlotInfo
T.GetLootSlotLink = GetLootSlotLink
T.GetLootSlotType = GetLootSlotType
T.GetMaxPlayerHonorLevel = GetMaxPlayerHonorLevel
T.GetMaxPlayerLevel = GetMaxPlayerLevel
T.GetMaxTalentTier = GetMaxTalentTier
T.getmetatable = getmetatable
T.GetMinimapZoneText = GetMinimapZoneText
T.GetMouseFocus = GetMouseFocus
T.GetNumActiveQuests = GetNumActiveQuests
T.GetNumAutoQuestPopUps = GetNumAutoQuestPopUps
T.GetNumAvailableQuests = GetNumAvailableQuests
T.GetNumBattlefieldScores = GetNumBattlefieldScores
T.GetNumClasses = GetNumClasses
T.GetNumFactions = GetNumFactions
T.GetNumGossipActiveQuests = GetNumGossipActiveQuests
T.GetNumGossipAvailableQuests = GetNumGossipAvailableQuests
T.GetNumGossipOptions = GetNumGossipOptions
T.GetNumGroupMembers = GetNumGroupMembers
T.GetNumGuildMembers = GetNumGuildMembers
T.GetNumLootItems = GetNumLootItems
T.GetNumQuestChoices = GetNumQuestChoices
T.GetNumQuestItems = GetNumQuestItems
T.GetNumQuestLeaderBoards = GetNumQuestLeaderBoards
T.GetNumQuestLogEntries = GetNumQuestLogEntries
T.GetNumSavedInstances = GetNumSavedInstances
T.GetNumSavedWorldBosses = GetNumSavedWorldBosses
T.GetNumSpecializations = GetNumSpecializations
T.GetNumSpecializationsForClassID = GetNumSpecializationsForClassID
T.GetNumSubgroupMembers = GetNumSubgroupMembers
T.GetNumTrackingTypes = GetNumTrackingTypes
T.GetNumWorldPVPAreas = GetNumWorldPVPAreas
T.GetPersonalRatedInfo = GetPersonalRatedInfo
T.GetPlayerInfoByGUID = GetPlayerInfoByGUID
T.GetProfessionInfo = GetProfessionInfo
T.GetProfessions = GetProfessions
T.GetPVPLifetimeStats = GetPVPLifetimeStats
T.GetQuestDifficultyColor = GetQuestDifficultyColor
T.GetQuestItemInfo = GetQuestItemInfo
T.GetQuestLink = GetQuestLink
T.GetQuestLogIndexByID = GetQuestLogIndexByID
T.GetQuestLogLeaderBoard = GetQuestLogLeaderBoard
T.GetQuestLogTitle = GetQuestLogTitle
T.GetQuestObjectiveInfo = GetQuestObjectiveInfo
T.GetRaidRosterInfo = GetRaidRosterInfo
T.GetRealmName = GetRealmName
T.GetRealZoneText = GetRealZoneText
T.GetSavedInstanceInfo = GetSavedInstanceInfo
T.GetSavedWorldBossInfo = GetSavedWorldBossInfo
T.GetScreenHeight = GetScreenHeight
T.GetScreenWidth = GetScreenWidth
T.GetSpecialization = GetSpecialization
T.GetSpecializationInfo = GetSpecializationInfo
T.GetSpecializationInfoByID = GetSpecializationInfoByID
T.GetSpecializationInfoForClassID = GetSpecializationInfoForClassID
T.GetSpecializationRole = GetSpecializationRole
T.GetSpellBookItemInfo = GetSpellBookItemInfo
T.GetSpellCooldown = GetSpellCooldown
T.GetSpellInfo = GetSpellInfo
T.GetStatistic = GetStatistic
T.GetSubZoneText = GetSubZoneText
T.GetTalentInfo = GetTalentInfo
T.GetTalentInfoByID = GetTalentInfoByID
T.GetTalentLink = GetTalentLink
T.GetThreatStatusColor = GetThreatStatusColor
T.GetTime = GetTime
T.ToggleFrame = ToggleFrame
T.GetTrackingInfo = GetTrackingInfo
T.GetTradeSkillNumReagents = GetTradeSkillNumReagents
T.GetTradeSkillReagentInfo = GetTradeSkillReagentInfo
T.GetTradeTargetItemLink = GetTradeTargetItemLink
T.GetUnitName = GetUnitName
T.GetWatchedFactionInfo = GetWatchedFactionInfo
T.GetWhoInfo = GetWhoInfo
T.GetWorldPVPAreaInfo = GetWorldPVPAreaInfo
T.GetXPExhaustion = GetXPExhaustion
T.GetZonePVPInfo = GetZonePVPInfo
T.GetZoneText = GetZoneText
T.gsub = gsub
T.string_gsub = string.gsub
T.GuildRoster = GuildRoster
T.HasInspectHonorData = HasInspectHonorData
T.HideUIPanel = HideUIPanel
T.hooksecurefunc = hooksecurefunc
T.InCombatLockdown = InCombatLockdown
T.InviteUnit = InviteUnit
T.ipairs = ipairs
T.IsAddOnLoaded = IsAddOnLoaded
T.UIParentLoadAddOn = UIParentLoadAddOn
T.IsAvailableQuestTrivial = IsAvailableQuestTrivial
T.IsEquippableItem = IsEquippableItem
T.IsFactionInactive = IsFactionInactive
T.IsInGroup = IsInGroup
T.IsInGuild = IsInGuild
T.IsInInstance = IsInInstance
T.IsInRaid = IsInRaid
T.IsLFGDungeonJoinable = IsLFGDungeonJoinable
T.IsPartyLFG = IsPartyLFG
T.IsQuestFlaggedCompleted = IsQuestFlaggedCompleted
T.IsQuestWatched = IsQuestWatched
T.IsSpellKnown = IsSpellKnown
T.IsUsableItem = IsUsableItem
T.IsXPUserDisabled = IsXPUserDisabled
T.LoadAddOn = LoadAddOn
T.next = next
T.pairs = pairs
T.PlaySound = PlaySound
T.print = print
T.QuestGetAutoAccept = QuestGetAutoAccept
T.QuestIsFromAreaTrigger = QuestIsFromAreaTrigger
T.random = random
T.RemoveFriend = RemoveFriend
T.RequestRaidInfo = RequestRaidInfo
T.SearchLFGGetResults = SearchLFGGetResults
T.SecondsToTime = SecondsToTime
T.SelectActiveQuest = SelectActiveQuest
T.SelectAvailableQuest = SelectAvailableQuest
T.SelectGossipActiveQuest = SelectGossipActiveQuest
T.SelectGossipAvailableQuest = SelectGossipAvailableQuest
T.SelectGossipOption = SelectGossipOption
T.SendChatMessage = SendChatMessage
T.SetAchievementComparisonUnit = SetAchievementComparisonUnit
T.SetCVar = SetCVar
T.SetItemRef = SetItemRef
T.setmetatable = setmetatable
T.SetOverrideBindingClick = SetOverrideBindingClick
T.SetWatchedFactionIndex = SetWatchedFactionIndex
T.ShowFriends = ShowFriends
T.ShowQuestComplete = ShowQuestComplete
T.StaticPopup_Hide = StaticPopup_Hide
T.strfind = strfind
T.strlower = strlower
T.strmatch = strmatch
T.strsplit = strsplit
T.time = time
T.tinsert = tinsert
T.table_insert = table.insert
T.tonumber = tonumber
T.tostring = tostring
T.tremove = tremove
T.UIFrameFadeIn = UIFrameFadeIn
T.UIFrameFadeOut = UIFrameFadeOut
T.UnitAura = UnitAura
T.UnitBuff = UnitBuff
T.UnitCanAttack = UnitCanAttack
T.UnitClass = UnitClass
T.UnitPower = UnitPower
T.UnitPowerMax = UnitPowerMax
T.UnitDebuff = UnitDebuff
T.UnitDetailedThreatSituation = UnitDetailedThreatSituation
T.UnitExists = UnitExists
T.UnitFactionGroup = UnitFactionGroup
T.UnitIsBattlePet = UnitIsBattlePet
T.UnitBattlePetType = UnitBattlePetType
T.UnitBattlePetSpeciesID = UnitBattlePetSpeciesID
T.UnitSex = UnitSex
T.UnitFullName = UnitFullName
T.UnitGroupRolesAssigned = UnitGroupRolesAssigned
T.UnitGUID = UnitGUID
T.UnitHonor = UnitHonor
T.UnitHonorLevel = UnitHonorLevel
T.UnitHonorMax = UnitHonorMax
T.UnitInParty = UnitInParty
T.UnitInRaid = UnitInRaid
T.UnitInVehicle = UnitInVehicle
T.UnitIsAFK = UnitIsAFK
T.UnitIsConnected = UnitIsConnected
T.UnitIsDead = UnitIsDead
T.UnitIsDeadOrGhost = UnitIsDeadOrGhost
T.UnitIsDND = UnitIsDND
T.UnitIsInMyGuild = UnitIsInMyGuild
T.UnitIsPlayer = UnitIsPlayer
T.UnitIsUnit = UnitIsUnit
T.UnitIsVisible = UnitIsVisible
T.UnitLevel = UnitLevel
T.UnitName = UnitName
T.UnitPVPName = UnitPVPName
T.UnitRace = UnitRace
T.UnitReaction = UnitReaction
T.UnitStat = UnitStat
T.UseContainerItem = UseContainerItem
T.UnitDamage = UnitDamage
T.UnitAttackSpeed = UnitAttackSpeed
T.UnitRangedDamage = UnitRangedDamage
T.abs = abs
T.math_abs = math.abs
T.bit_band = bit.band
T.C_Map_GetMapArtID = C_Map.GetMapArtID
T.C_Map_GetMapArtLayers = C_Map.GetMapArtLayers
T.C_MapExplorationInfo_GetExploredMapTextures = C_MapExplorationInfo.GetExploredMapTextures
T.math_ceil = math.ceil
T.tContains = tContains
T.C_PetBattles_IsInBattle = C_PetBattles.IsInBattle
T.GetNumQuestWatches = GetNumQuestWatches
T.GetQuestWatchInfo = GetQuestWatchInfo
T.GetQuestLogSpecialItemInfo = GetQuestLogSpecialItemInfo
T.GetItemSpell = GetItemSpell
T.IsArtifactPowerItem = IsArtifactPowerItem
T.GetQuestLogSpecialItemCooldown = GetQuestLogSpecialItemCooldown
T.CooldownFrame_Set = CooldownFrame_Set
T.IsItemInRange = IsItemInRange
T.GetBindingKey = GetBindingKey
T.mod = mod
T.RaiseFrameLevel = RaiseFrameLevel
T.GetCombatRating = GetCombatRating
T.UnitAttackPower = UnitAttackPower
T.UnitRangedAttackPower = UnitRangedAttackPower
T.UnitArmor = UnitArmor
T.GetCombatRatingBonus = GetCombatRatingBonus
T.GetVersatilityBonus = GetVersatilityBonus
T.GetParryChance = GetParryChance
T.GetDodgeChance = GetDodgeChance
T.GetBlockChance = GetBlockChance
T.GetSpellHitModifier = GetSpellHitModifier
T.GetHitModifier = GetHitModifier
T.GetMeleeHaste = GetMeleeHaste
T.GetCritChance = GetCritChance
T.GetRangedHaste = GetRangedHaste
T.GetRangedCritChance = GetRangedCritChance
T.UnitSpellHaste = UnitSpellHaste
T.GetModResilienceDamageReduction = GetModResilienceDamageReduction
T.GetLifesteal = GetLifesteal
T.UnitHealthMax = UnitHealthMax
T.math_min = math.min
T.math_sqrt = math.sqrt
T.ShowUIPanel = ShowUIPanel
T.SocketInventoryItem = SocketInventoryItem
T.GetManaRegen = GetManaRegen
T.GetSpellBonusHealing = GetSpellBonusHealing
T.GetSpellBonusDamage = GetSpellBonusDamage
T.IsSpellOverlayed = IsSpellOverlayed
T.C_AzeriteEmpoweredItem_IsAzeriteEmpoweredItemByID = C_AzeriteEmpoweredItem.IsAzeriteEmpoweredItemByID
T.DepositReagentBank = DepositReagentBank
T.C_AzeriteEmpoweredItem_GetPowerInfo = C_AzeriteEmpoweredItem.GetPowerInfo
T.C_AzeriteItem_FindActiveAzeriteItem = C_AzeriteItem.FindActiveAzeriteItem
T.C_AzeriteItem_GetPowerLevel = C_AzeriteItem.GetPowerLevel
T.C_AzeriteEmpoweredItem_GetAllTierInfoByItemID = C_AzeriteEmpoweredItem.GetAllTierInfoByItemID
T.C_AzeriteEmpoweredItem_IsPowerAvailableForSpec = C_AzeriteEmpoweredItem.IsPowerAvailableForSpec
T.IsControlKeyDown = IsControlKeyDown
T.C_AzeriteEmpoweredItem_IsAzeriteEmpoweredItem = C_AzeriteEmpoweredItem.IsAzeriteEmpoweredItem
T.C_AzeriteEmpoweredItem_GetAllTierInfo = C_AzeriteEmpoweredItem.GetAllTierInfo
T.C_AzeriteEmpoweredItem_IsPowerSelected = C_AzeriteEmpoweredItem.IsPowerSelected
T.PlayerHasToy = PlayerHasToy
T.GetMacroInfo = GetMacroInfo
T.GetNumMacros = GetNumMacros
T.CreateMacro = CreateMacro
T.PickupMacro = PickupMacro
T.EditMacro = EditMacro
T.GetBindLocation = GetBindLocation
T.C_ToyBox_IsToyUsable = C_ToyBox.IsToyUsable
T.AnimateTexCoords = AnimateTexCoords
T.JoinTemporaryChannel = JoinTemporaryChannel
T.ChatFrame_RemoveChannel = ChatFrame_RemoveChannel
T.ChatFrame_AddChannel = ChatFrame_AddChannel
T.SlashCmdList = SlashCmdList
T.strtrim = strtrim
T.strsub = strsub
T.ChatFrame_AddMessageEventFilter = ChatFrame_AddMessageEventFilter
T.GetSpellCritChance = GetSpellCritChance
T.CheckInteractDistance = CheckInteractDistance
T.GetPlayerTradeMoney = GetPlayerTradeMoney
T.GetTargetTradeMoney = GetTargetTradeMoney
T.table_getn = table.getn
T.strlen = strlen
T.UnitIsGroupLeader = UnitIsGroupLeader
T.UnitIsGroupAssistant = UnitIsGroupAssistant
T.IsEveryoneAssistant = IsEveryoneAssistant
T.CombatLogGetCurrentEventInfo = CombatLogGetCurrentEventInfo
T.GetSpellLink = GetSpellLink
T.HasNewMail = HasNewMail
T.RegisterStateDriver = RegisterStateDriver
T.pcall = pcall
T.C_PetJournal_GetNumCollectedInfo = C_PetJournal.GetNumCollectedInfo
T.GetAuctionItemLink = GetAuctionItemLink
T.GetMerchantItemLink = GetMerchantItemLink
T.SetItemButtonNameFrameVertexColor = SetItemButtonNameFrameVertexColor
T.SetItemButtonSlotVertexColor = SetItemButtonSlotVertexColor
T.SetItemButtonTextureVertexColor = SetItemButtonTextureVertexColor
T.SetItemButtonNormalTextureVertexColor = SetItemButtonNormalTextureVertexColor
T.AuraUtil_FindAuraByName = AuraUtil.FindAuraByName
T.RepopMe = RepopMe
T.Screenshot = Screenshot
T.IsModifiedClick = IsModifiedClick
T.LootSlot = LootSlot
T.ConvertToRaid = ConvertToRaid
T.string_byte = string.byte
T.UnitRealmRelationship = UnitRealmRelationship
T.SendWho = SendWho
T.GuildInvite = GuildInvite
T.AbbreviateNumbers = AbbreviateNumbers
T.GetHaste = GetHaste
T.GetMasteryEffect = GetMasteryEffect
T.max = max
T.PanelTemplates_GetSelectedTab = PanelTemplates_GetSelectedTab
T.GetQuestTagInfo = GetQuestTagInfo
T.GetQuestLogSelection = GetQuestLogSelection

T.StringToUpper = function(str)
	return (T.string_gsub(str, "^%l", T.string_upper))
end

T.MapInfoTable = {}

T.InfoColor = "|cff9482c9"
T.GreyColor = "|cffB5B5B5"

LUI.rolePaths = {
	["ElvUI"] = {
		TANK = [[Interface\AddOns\ElvUI\media\textures\tank]],
		HEALER = [[Interface\AddOns\ElvUI\media\textures\healer]],
		DAMAGER = [[Interface\AddOns\ElvUI\media\textures\dps]]
    },
}

-- Class Color stuff
LUI.ClassColor = E.myclass == "PRIEST" and E.PriestColors or (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[E.myclass] or RAID_CLASS_COLORS[E.myclass])
LUI.ClassColors = {}

local colors = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
for class in pairs(colors) do
	LUI.ClassColors[class] = {}
	LUI.ClassColors[class].r = colors[class].r
	LUI.ClassColors[class].g = colors[class].g
	LUI.ClassColors[class].b = colors[class].b
	LUI.ClassColors[class].colorStr = colors[class].colorStr
end
LUI.r, LUI.g, LUI.b = LUI.ClassColors[E.myclass].r, LUI.ClassColors[E.myclass].g, LUI.ClassColors[E.myclass].b

local BC = {}
for k, v in pairs(LOCALIZED_CLASS_NAMES_MALE) do
	BC[v] = k
end

for k, v in pairs(LOCALIZED_CLASS_NAMES_FEMALE) do
	BC[v] = k
end

LUI.colors = {
	class = {},
}

LUI.colors.class = {
	["DEATHKNIGHT"]	= { 0.77,	0.12,	0.23 },
	["DEMONHUNTER"]	= { 0.64,	0.19,	0.79 },
	["DRUID"]		= { 1,		0.49,	0.04 },
	["HUNTER"]		= { 0.58,	0.86,	0.49 },
	["MAGE"]		= { 0.2,	0.76,	1 },
	["MONK"]		= { 0,		1,		0.59 },
	["PALADIN"]		= { 0.96,	0.55,	0.73 },
	["PRIEST"]		= { 0.99,	0.99,	0.99 },
	["ROGUE"]		= { 1,		0.96,	0.41 },
	["SHAMAN"]		= { 0,		0.44,	0.87 },
	["WARLOCK"]		= { 0.6,	0.47,	0.85 },
	["WARRIOR"]		= { 0.9,	0.65,	0.45 },
}

for class, color in pairs(LUI.colors.class) do
	LUI.colors.class[class] = { r = color[1], g = color[2], b = color[3] }
end

function LUI:ClassColor(class)
	local color = LUI.ClassColors[class]
	if not color then return 1, 1, 1 end
	return color.r, color.g, color.b
end

function LUI:GetClassColorString(class)
	local color = LUI.colors.class[BC[class] or class]
	return E:RGBToHex(color.r, color.g, color.b)
end

function LUI:GetIconFromID(type, id)
    local path
    if type == "item" then
        path = select(10, T.GetItemInfo(id))
    elseif type == "spell" then
        path = select(3, T.GetSpellInfo(id))
    elseif type == "achiev" then
        path = select(10, T.GetAchievementInfo(id))
    end
    return path or nil
end

function LUI:BagSearch(itemId)
    for container = 0, NUM_BAG_SLOTS do
        for slot = 1, T.GetContainerNumSlots(container) do
            if itemId == T.GetContainerItemID(container, slot) then
                return container, slot
            end
        end
    end
end

function LUI:CheckDB(args1, args2, args3, args4, args5, args6)
    if E.db["lui"] then
        for k, v in T.pairs(E.db["lui"]) do
            if k == args1 and type(v) == "table" then
                for k, v in T.pairs(v) do
                    if k == args2 and type(v) == "table" then
                        for k, v in T.pairs(v) do
                            if k == args3 and type(v) == "table" then
                                for k, v in T.pairs(v) do
                                    if k == args4 and type(v) == "table" then
                                        for k, v in T.pairs(v) do
                                            if k == args5 and type(v) == "table" then
                                                for k, v in T.pairs(v) do
                                                    if k == args6 and type(v) == "table" then
                                                    elseif k == args6 and v == false then return true
                                                    end
                                                end
                                            elseif k == args5 and v == false then return true
                                            end
                                        end
                                    elseif k == args4 and v == false then return true
                                    end
                                end
                            elseif k == args3 and v == false then return true
                            end
                        end
                    elseif k == args2 and v == false then return true
                    end
                end
            elseif k == args1 and v == false then return true
            end
        end
        return false
    elseif E.global["lui"] then
        for k, v in T.pairs(E.global["lui"]) do
            if k == args1 and type(v) == "table" then
                for k, v in T.pairs(v) do
                    if k == args2 and type(v) == "table" then
                        for k, v in T.pairs(v) do
                            if k == args3 and type(v) == "table" then
                                for k, v in T.pairs(v) do
                                    if k == args4 and type(v) == "table" then
                                        for k, v in T.pairs(v) do
                                            if k == args5 and type(v) == "table" then
                                                for k, v in T.pairs(v) do
                                                    if k == args6 and type(v) == "table" then
                                                    elseif k == args6 and v == false then return true
                                                    end
                                                end
                                            elseif k == args5 and v == false then return true
                                            end
                                        end
                                    elseif k == args4 and v == false then return true
                                    end
                                end
                            elseif k == args3 and v == false then return true
                            end
                        end
                    elseif k == args2 and v == false then return true
                    end
                end
            elseif k == args1 and v == false then return true
            end
        end
        return false
    else
        return false
    end
end

function LUI:Print(msg, type)
	if type == "error" then
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", "|cffff0000LivvenUI Error:|r ", msg))
	elseif type == "warning" then
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", "|cffd3cf00LivvenUI Warning:|r ", msg))
	elseif type == "info" then
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", "|cff14adcdLivvenUI Info:|r ", msg))
	else
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", E["media"].hexvaluecolor, "LivvenUI:|r ", msg))
	end
end

function LUI:GetMapInfo(id, arg)
	if not arg then return end
	local MapInfo
	if T.MapInfoTable[id] then
		MapInfo = T.MapInfoTable[id]
	else
		MapInfo = C_Map.GetMapInfo(id)
		T.MapInfoTable[id] = MapInfo
	end
	if not MapInfo then return UNKNOWN end
	if arg == "all" then return MapInfo["name"], MapInfo["mapID"], MapInfo["parentMapID"], MapInfo["mapType"] end
	return MapInfo[arg]
end

function LUI:cOption(name)
    local color = "|cff9482c9%s|r"
    return (color):format(name)
end

function LUI:PrintURL(url)
    return format("|cff9482c9[|Hurl:%s|h%s|h]|r", url, url)
end

function LUI:PrintLink(link)
    return format("|cff9482c9|Hurl:%s|h%s|h|r", link, link)
end

function LUI:MismatchText()
    local text = format(L["LUI_ELV_OUTDATED_MSG"], LUI.ElvUIV, LUI.ElvUIX)
    return text
end

function LUI:CreateText(f, layer, fontsize, flag, justifyh)
    local text = f:CreateFontString(nil, layer)
    text:SetFont(E.media.normFont, fontsize, flag)
    text:SetJustifyH(justifyh or "CENTER")
    return text
end

local function Styling(f, useStripes, useGradient, useShadow, shadowOverlayWidth, shadowOverlayHeight, shadowOverlayAlpha)
    assert(f, "doesn't exist!")
    local frameName = f.GetName and f:GetName()
    if f.styling or E.db.lui.general.style ~= true then return end
    
    local style = CreateFrame("Frame", frameName or nil, f)
    
    if not (useStripes) then
        local stripes = f:CreateTexture(f:GetName() and f:GetName() .. "Overlay" or nil, "BORDER", f)
        stripes:ClearAllPoints()
        stripes:SetPoint("TOPLEFT", 1, -1)
        stripes:SetPoint("BOTTOMRIGHT", -1, 1)
        stripes:SetTexture([[Interface\AddOns\ElvUI_LivvenUI\media\textures\stripes.blp]], true, true)
        stripes:SetSnapToPixelGrid(false)
        stripes:SetTexelSnappingBias(0)
        stripes:SetHorizTile(true)
        stripes:SetVertTile(true)
        stripes:SetBlendMode("ADD")
        
        f.stripes = stripes
    end
    
    if not (useGradient) then
        local gradient = f:CreateTexture(f:GetName() and f:GetName() .. "Overlay" or nil, "BORDER", f)
        gradient:ClearAllPoints()
        gradient:SetPoint("TOPLEFT", 1, -1)
        gradient:SetPoint("BOTTOMRIGHT", -1, 1)
        gradient:SetTexture([[Interface\AddOns\ElvUI_LivvenUI\media\textures\gradient.tga]])
        gradient:SetSnapToPixelGrid(false)
        gradient:SetTexelSnappingBias(0)
        gradient:SetVertexColor(.3, .3, .3, .15)
        
        f.gradient = gradient
    end
    
    if not (useShadow) then
        local mshadow = f:CreateTexture(f:GetName() and f:GetName() .. "Overlay" or nil, "BORDER", f)
        mshadow:SetInside(f, 0, 0)
        mshadow:Width(shadowOverlayWidth or 33)
        mshadow:Height(shadowOverlayHeight or 33)
        mshadow:SetTexture([[Interface\AddOns\ElvUI_LivvenUI\media\textures\mshadow.tga]])
        mshadow:SetSnapToPixelGrid(false)
        mshadow:SetTexelSnappingBias(0)
        mshadow:SetVertexColor(1, 1, 1, shadowOverlayAlpha or 0.6)
        
        f.mshadow = mshadow
    end
    
    style:SetFrameLevel(f:GetFrameLevel() + 1)
    f.styling = style
    
    LUI["styling"][style] = true
end

local function addapi(object)
    local mt = T.getmetatable(object).__index
    if not object.Styling then mt.Styling = Styling end
    if not object.StripFrame then mt.StripFrame = StripFrame end
    if not object.CreateOverlay then mt.CreateOverlay = CreateOverlay end
    if not object.CreateBorder then mt.CreateBorder = CreateBorder end
    if not object.CreatePanel then mt.CreatePanel = CreatePanel end
end

local handled = {["Frame"] = true}
local object = CreateFrame("Frame")
addapi(object)
addapi(object:CreateTexture())
addapi(object:CreateFontString())

object = EnumerateFrames()
while object do
    if not object:IsForbidden() and not handled[object:GetObjectType()] then
        addapi(object)
        handled[object:GetObjectType()] = true
    end
    object = EnumerateFrames(object)
end
