local LUI, T, E, L, V, P, G = unpack(select(2, ...));
local _G = _G
local getmetatable = getmetatable;

--This shit should be in Alphabetical Order to make it easier to see what is here or not... DARTH!
T.GetBuildInfo = GetBuildInfo;
T.GetTalentLink = GetTalentLink;
T.GetPlayerInfoByGUID = GetPlayerInfoByGUID;
T.GetCursorPosition = GetCursorPosition;
--Adding a lot of shit from global functions--
T.format = string.format;
T.strlower = strlower;
T.random = random;
--Time/date
T.date = date;
T.time = time;
T.difftime = difftime;
T.GetTime = GetTime;
--Unit infos
T.UnitLevel = UnitLevel;
T.UnitClass = UnitClass;
T.UnitRace = UnitRace;
T.UnitName = UnitName;
T.UnitInVehicle = UnitInVehicle;
T.UnitFullName = UnitFullName;
T.GetUnitName = GetUnitName;
T.UnitFactionGroup = UnitFactionGroup;
T.UnitAura = UnitAura;
T.UnitBuff = UnitBuff;
T.UnitDebuff = UnitDebuff;
T.GetSpecialization = GetSpecialization;
T.GetSpecializationInfo = GetSpecializationInfo;
T.GetSpecializationInfoByID = GetSpecializationInfoByID;
T.GetSpecializationRole = GetSpecializationRole;
T.GetTalentInfo = GetTalentInfo;
T.GetTalentInfoByID = GetTalentInfoByID;
T.GetNumSpecializationsForClassID = GetNumSpecializationsForClassID;
T.GetSpecializationInfoForClassID = GetSpecializationInfoForClassID;
T.GetAverageItemLevel = GetAverageItemLevel;
T.UnitStat = UnitStat;
T.UnitIsPlayer = UnitIsPlayer;
T.UnitInRaid = UnitInRaid;
T.UnitInParty = UnitInParty;
T.UnitPVPName = UnitPVPName;
T.UnitIsAFK = UnitIsAFK;
T.UnitIsDND = UnitIsDND;
T.UnitIsDead = UnitIsDead;
T.UnitExists = UnitExists;
T.UnitReaction = UnitReaction;
T.UnitIsConnected = UnitIsConnected;
T.UnitIsUnit = UnitIsUnit;
T.UnitGUID = UnitGUID;
T.UnitCanAttack = UnitCanAttack;
T.UnitDetailedThreatSituation = UnitDetailedThreatSituation;
T.GetThreatStatusColor = GetThreatStatusColor;
T.CanInspect = CanInspect;
T.GetStatistic = GetStatistic;
T.GetComparisonStatistic = GetComparisonStatistic;
T.GetAchievementInfo = GetAchievementInfo;
T.UnitHonor = UnitHonor;
T.UnitHonorMax = UnitHonorMax;
T.UnitHonorLevel = UnitHonorLevel;
T.GetMaxPlayerHonorLevel = GetMaxPlayerHonorLevel;
T.UnitIsVisible = UnitIsVisible;
T.UnitIsDeadOrGhost = UnitIsDeadOrGhost;
T.HasInspectHonorData = HasInspectHonorData;
T.GetInspectSpecialization = GetInspectSpecialization;
T.SetSmallGuildTabardTextures = SetSmallGuildTabardTextures;
T.GetInventoryItemTexture = GetInventoryItemTexture;
--Class
T.GetNumClasses = GetNumClasses;
T.GetClassInfo = GetClassInfo;
-- T.
--Items
T.IsUsableItem = IsUsableItem;
T.GetInventoryItemLink = GetInventoryItemLink;
T.GetInventorySlotInfo = GetInventorySlotInfo;
T.GetInventoryItemDurability = GetInventoryItemDurability;
T.GetInventoryItemQuality = GetInventoryItemQuality;
T.GetItemInfo = GetItemInfo;
T.GetDetailedItemLevelInfo = GetDetailedItemLevelInfo;
T.GetBuybackItemLink = GetBuybackItemLink;
T.GetItemIcon = GetItemIcon;
T.GetItemCooldown = GetItemCooldown;
T.GetItemCount = GetItemCount;
T.IsEquippableItem = IsEquippableItem;
T.GetItemQualityColor = GetItemQualityColor;
T.GetInventoryItemID = GetInventoryItemID;
T.SetItemRef = SetItemRef;
-- T.
--XP
T.IsXPUserDisabled = IsXPUserDisabled;
T.GetMaxPlayerLevel = GetMaxPlayerLevel;
T.GetXPExhaustion = GetXPExhaustion;
--rep
T.GetWatchedFactionInfo = GetWatchedFactionInfo;
T.GetNumFactions = GetNumFactions;
T.IsFactionInactive = IsFactionInactive;
T.SetWatchedFactionIndex = SetWatchedFactionIndex;
--Social
T.IsInGuild = IsInGuild;
T.GuildRoster = GuildRoster;
T.GetGuildInfo = GetGuildInfo;
T.GetNumGuildMembers = GetNumGuildMembers;
T.GetGuildRosterInfo = GetGuildRosterInfo;
T.GetGuildRosterMOTD = GetGuildRosterMOTD;
T.GetGuildLogoInfo = GetGuildLogoInfo;
T.GetInspectGuildInfo = GetInspectGuildInfo;
T.CanEditOfficerNote = CanEditOfficerNote;
T.CanEditPublicNote = CanEditPublicNote;
T.InviteUnit = InviteUnit;
--Professions
T.GetProfessions = GetProfessions;
T.GetProfessionInfo = GetProfessionInfo;
T.GetTradeSkillNumReagents = GetTradeSkillNumReagents;
T.GetTradeSkillReagentInfo = GetTradeSkillReagentInfo;
--Screen stuff
T.GetScreenWidth = GetScreenWidth;
T.GetScreenHeight = GetScreenHeight;
T.GetMouseFocus = GetMouseFocus;
--Spells
T.GetSpellCooldown = GetSpellCooldown;
T.GetSpellInfo = GetSpellInfo;
T.IsSpellKnown = IsSpellKnown;
T.GetSpellBookItemInfo = GetSpellBookItemInfo;
--Tables
T.pairs = pairs;
T.ipairs = ipairs;
T.tinsert = tinsert;
T.tremove = tremove;
T.tcopy = table.copy;
T.twipe = table.wipe;
T.unpack = unpack;
T.select = select;
T.sort = table.sort;
T.tconcat = table.concat;
T.next = next;
--Camera
T.FlipCameraYaw = FlipCameraYaw;
--Instance
T.IsInInstance = IsInInstance;
T.GetLFGDungeonNumEncounters = GetLFGDungeonNumEncounters;
T.GetLFGDungeonEncounterInfo = GetLFGDungeonEncounterInfo;
T.GetInstanceInfo = GetInstanceInfo;
T.IsLFGDungeonJoinable = IsLFGDungeonJoinable;
--Combat
T.InCombatLockdown = InCombatLockdown;
--PvP
T.GetNumWorldPVPAreas = GetNumWorldPVPAreas;
T.GetWorldPVPAreaInfo = GetWorldPVPAreaInfo;
T.GetNumBattlefieldScores = GetNumBattlefieldScores;
T.GetBattlefieldScore = GetBattlefieldScore;
T.GetPVPLifetimeStats = GetPVPLifetimeStats;
T.GetPersonalRatedInfo = GetPersonalRatedInfo;
T.GetInspectArenaData = GetInspectArenaData;
T.GetInspectRatedBGData = GetInspectRatedBGData;
T.GetInspectHonorData = GetInspectHonorData;
--Map
T.GetZoneText = GetZoneText;
T.GetRealZoneText = GetRealZoneText;
T.GetMinimapZoneText = GetMinimapZoneText;
T.GetMapNameByID = C_Map.GetMapInfo;
T.GetCurrentMapAreaID = C_Map.GetCurrentMapAreaID;
T.GetSubZoneText = GetSubZoneText;
T.GetBestMapForUnit = C_Map.GetBestMapForUnit;
T.GetZonePVPInfo = GetZonePVPInfo;
--Currency
T.GetCurrencyListSize = GetCurrencyListSize;
T.GetCurrencyInfo = GetCurrencyInfo;

T.error = error;
T.type = type;
T.GetInboxHeaderInfo = GetInboxHeaderInfo;
--Addons
T.IsAddOnLoaded = IsAddOnLoaded;
T.DisableAddOn = DisableAddOn;
T.SendAddonMessage = SendAddonMessage;

T.GetQuestDifficultyColor = GetQuestDifficultyColor;

--Strings
T.split = string.split;
T.join = string.join;
T.match = string.match;
T.strlen = string.len;
T.gsub = gsub;
T.find = string.find;
T.print = print;
T.upper = string.upper;
T.StringToUpper = function(str)
	return (T.gsub(str, "^%l", T.upper));
end
--Math
T.floor = floor;
T.tonumber = tonumber;
T.tostring = tostring;
--Groups
T.IsInGroup = IsInGroup;
T.IsInRaid = IsInRaid;
T.IsPartyLFG = IsPartyLFG;
T.GetNumSubgroupMembers = GetNumSubgroupMembers;
T.GetNumGroupMembers = GetNumGroupMembers;
T.UnitGroupRolesAssigned = UnitGroupRolesAssigned;
T.GetRaidRosterInfo = GetRaidRosterInfo;
--Friend
T.BNGetNumFriends = BNGetNumFriends;
T.BNGetFriendInfo = BNGetFriendInfo;
T.BNGetGameAccountInfo = BNGetGameAccountInfo;
T.BNGetFriendIndex = BNGetFriendIndex;
T.GetFriendInfo = GetFriendInfo;
T.GetNumFriends = C_FriendList.GetNumFriends;
--Quests
T.GetQuestLogTitle = GetQuestLogTitle;
T.GetNumQuestLogEntries = GetNumQuestLogEntries;
--Loot
T.GetNumLootItems = GetNumLootItems;
T.GetLootSlotInfo = GetLootSlotInfo;
T.GetLootSlotType = GetLootSlotType;
T.GetLootSlotLink = GetLootSlotLink;
T.GetLootRollItemInfo = GetLootRollItemInfo;
T.GetLootRollItemLink = GetLootRollItemLink;
--Factions
T.GetFactionInfo = GetFactionInfo;
T.GetFriendshipReputation = GetFriendshipReputation;
T.GetFriendshipReputationRanks = GetFriendshipReputationRanks;
--Bags
T.GetContainerNumSlots = GetContainerNumSlots;
T.GetContainerItemID = GetContainerItemID;
T.GetContainerItemInfo = GetContainerItemInfo;
T.GetContainerItemLink = GetContainerItemLink;
T.GetTradeTargetItemLink = GetTradeTargetItemLink;
T.GetCurrentCalendarTime = C_DateAndTime.GetCurrentCalendarTime;
T.CreateFrame = CreateFrame;
T.gmatch = string.gmatch;
T.sub = string.sub;

T.UIFrameFadeIn = UIFrameFadeIn;
T.getglobal = getglobal;
T.modf = math.modf
T.setmetatable = setmetatable
T.hooksecurefunc = hooksecurefunc
T.FauxScrollFrame_GetOffset = FauxScrollFrame_GetOffset
T.SearchLFGGetResults = SearchLFGGetResults
T.GetWhoInfo = GetWhoInfo
T.AcceptQuest = AcceptQuest;
T.CloseQuest = CloseQuest;
T.GetActiveTitle = GetActiveTitle;
T.GetAutoQuestPopUp = GetAutoQuestPopUp;
T.GetContainerItemQuestInfo = GetContainerItemQuestInfo;
T.GetGossipActiveQuests = GetGossipActiveQuests;
T.GetGossipAvailableQuests = GetGossipAvailableQuests;
T.GetNumActiveQuests = GetNumActiveQuests;
T.GetNumAutoQuestPopUps = GetNumAutoQuestPopUps;
T.GetNumAvailableQuests = GetNumAvailableQuests;
T.GetNumGossipActiveQuests = GetNumGossipActiveQuests;
T.GetNumGossipAvailableQuests = GetNumGossipAvailableQuests;
T.GetNumGossipOptions = GetNumGossipOptions;
T.GetNumQuestChoices = GetNumQuestChoices;
T.GetNumQuestItems = GetNumQuestItems;
T.GetNumTrackingTypes = GetNumTrackingTypes;
T.GetQuestItemInfo = GetQuestItemInfo;
T.GetQuestLogIndexByID = GetQuestLogIndexByID;
T.GetTrackingInfo = GetTrackingInfo;
T.IsAvailableQuestTrivial = IsAvailableQuestTrivial;
T.IsQuestFlaggedCompleted = IsQuestFlaggedCompleted;
T.QuestGetAutoAccept = QuestGetAutoAccept;
T.QuestIsFromAreaTrigger = QuestIsFromAreaTrigger;
T.SelectActiveQuest = SelectActiveQuest;
T.SelectAvailableQuest = SelectAvailableQuest;
T.SelectGossipActiveQuest = SelectGossipActiveQuest;
T.SelectGossipAvailableQuest = SelectGossipAvailableQuest;
T.SelectGossipOption = SelectGossipOption;
T.ShowQuestComplete = ShowQuestComplete;
T.StaticPopup_Hide = StaticPopup_Hide;
T.UseContainerItem = UseContainerItem;
T.SetOverrideBindingClick = SetOverrideBindingClick;
T.strmatch = strmatch;
T.GetChannelName = GetChannelName;
T.GetClubInfo = C_Club.GetClubInfo;
T.strfind = strfind;
T.strsplit = strsplit;
T.SendChatMessage = SendChatMessage;
T.SetCVar = SetCVar;
T.ShowFriends = ShowFriends;
T.UnitIsInMyGuild = UnitIsInMyGuild;
T.Ambiguate = Ambiguate;
T.AddFriend = C_FriendList.AddFriend;
T.BNGetNumFriendGameAccounts = BNGetNumFriendGameAccounts;
T.BNGetFriendGameAccountInfo = BNGetFriendGameAccountInfo;
T.GetRealmName = GetRealmName;
T.RemoveFriend = RemoveFriend;
T.GetQuestLink = GetQuestLink;
T.IsQuestWatched = IsQuestWatched;
T.GetNumQuestLeaderBoards = GetNumQuestLeaderBoards;
T.GetQuestLogLeaderBoard = GetQuestLogLeaderBoard;
T.GetNumSpecializations = GetNumSpecializations;
T.GetMaxTalentTier = GetMaxTalentTier;
T.GetActiveSpecGroup = GetActiveSpecGroup;
T.GetLocale = GetLocale;
T.utf8sub = string.utf8sub
T.ClearAchievementComparisonUnit = ClearAchievementComparisonUnit;
T.SetAchievementComparisonUnit = SetAchievementComparisonUnit;
T.HideUIPanel = HideUIPanel;
T.C_Reputation_IsFactionParagon = C_Reputation.IsFactionParagon;
T.C_Reputation_GetFactionParagonInfo = C_Reputation.GetFactionParagonInfo;
T.C_TimerNewTicker = C_Timer.NewTicker

T.MapInfoTable = {};

T.InfoColor = "|cff9482c9"
T.GreyColor = "|cffB5B5B5"

function LUI:CheckDB(args1, args2, args3, args4, args5, args6)
    if E.db["lui"] then
        for k, v in T.pairs(E.db["lui"]) do
            if k == args1 and T.type(v) == "table" then
                for k, v in T.pairs(v) do
                    if k == args2 and T.type(v) == "table" then
                        for k, v in T.pairs(v) do
                            if k == args3 and T.type(v) == "table" then
                                for k, v in T.pairs(v) do
                                    if k == args4 and T.type(v) == "table" then
                                        for k, v in T.pairs(v) do
                                            if k == args5 and T.type(v) == "table" then
                                                for k, v in T.pairs(v) do
                                                    if k == args6 and T.type(v) == "table" then
                                                    elseif k == args6 and v == false then return true;
                                                    end
                                                end
                                            elseif k == args5 and v == false then return true;
                                            end
                                        end
                                    elseif k == args4 and v == false then return true;
                                    end
                                end
                            elseif k == args3 and v == false then return true;
                            end
                        end
                    elseif k == args2 and v == false then return true;
                    end
                end
            elseif k == args1 and v == false then return true;
            end
        end
        return false;
    elseif E.global["lui"] then
        for k, v in T.pairs(E.global["lui"]) do
            if k == args1 and T.type(v) == "table" then
                for k, v in T.pairs(v) do
                    if k == args2 and T.type(v) == "table" then
                        for k, v in T.pairs(v) do
                            if k == args3 and T.type(v) == "table" then
                                for k, v in T.pairs(v) do
                                    if k == args4 and T.type(v) == "table" then
                                        for k, v in T.pairs(v) do
                                            if k == args5 and T.type(v) == "table" then
                                                for k, v in T.pairs(v) do
                                                    if k == args6 and T.type(v) == "table" then
                                                    elseif k == args6 and v == false then return true;
                                                    end
                                                end
                                            elseif k == args5 and v == false then return true;
                                            end
                                        end
                                    elseif k == args4 and v == false then return true;
                                    end
                                end
                            elseif k == args3 and v == false then return true;
                            end
                        end
                    elseif k == args2 and v == false then return true;
                    end
                end
            elseif k == args1 and v == false then return true;
            end
        end
        return false;
    else
        return false;
    end
end

function LUI:Print(msg, type)
	if type == "error" then
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", "|cffff0000LivvenUI Error:|r ", msg))
	elseif type == "warning" then
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", "|cffd3cf00LivvenUI Warning:|r ", msg))
	elseif type == "info" then
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", "|cff14adcdLivvenUI Info:|r ", msg))
	else
		(_G[E.db.general.messageRedirect] or DEFAULT_CHAT_FRAME):AddMessage(strjoin("", E["media"].hexvaluecolor, "LivvenUI:|r ", msg))
	end
end

function LUI:GetMapInfo(id, arg)
	if not arg then return end
	local MapInfo
	if T.MapInfoTable[id] then
		MapInfo = T.MapInfoTable[id]
	else
		MapInfo = C_Map.GetMapInfo(id)
		T.MapInfoTable[id] = MapInfo
	end
	if not MapInfo then return UNKNOWN end
	if arg == "all" then return MapInfo["name"], MapInfo["mapID"], MapInfo["parentMapID"], MapInfo["mapType"] end
	return MapInfo[arg]
end

function LUI:SetupProfileCallbacks()
	E.data.RegisterCallback(self, "OnProfileChanged", "UpdateAll")
	E.data.RegisterCallback(self, "OnProfileCopied", "UpdateAll")
	E.data.RegisterCallback(self, "OnProfileReset", "UpdateAll")
end

function LUI:UpdateRegisteredDBs()
	if (not LUI["RegisteredDBs"]) then
		return
	end
	local dbs = LUI["RegisteredDBs"]
	for tbl, path in T.pairs(dbs) do
		self:UpdateRegisteredDB(tbl, path)
	end
end

function LUI:UpdateRegisteredDB(tbl, path)
	local path_parts = {strsplit(".", path)}
	local _db = E.db.lui
	for _, path_part in T.ipairs(path_parts) do
		_db = _db[path_part]
	end
	tbl.db = _db
end

function LUI:RegisterDB(tbl, path)
	if (not LUI["RegisteredDBs"]) then
		LUI["RegisteredDBs"] = {}
	end
	self:UpdateRegisteredDB(tbl, path)
	LUI["RegisteredDBs"][tbl] = path
end

function LUI:UpdateAll()
	self:UpdateRegisteredDBs();
	for _, mod in T.pairs(self["RegisteredModules"]) do
		if mod and mod.ForUpdateAll then
			mod:ForUpdateAll();
		end
	end
end

LUI["RegisteredModules"] = {}
function LUI:RegisterModule(name)
	if self.initialized then
		local module = self:GetModule(name)
		if (module and module.Initialize) then
			module:Initialize()
		end
	else
		self["RegisteredModules"][#self["RegisteredModules"] + 1] = name
	end
end

function LUI:InitializeModules()
    for _, moduleName in T.pairs(LUI["RegisteredModules"]) do
		local module = self:GetModule(moduleName)
		if module.Initialize then
			module:Initialize()
		else
			LUI:Print("Module <"..moduleName.."> does not loaded.", "error")
		end
	end
end

function LUI:DasOptions()
    E:ToggleConfig(); LibStub("AceConfigDialog-3.0-ElvUI"):SelectGroup("ElvUI", "lui");
end

function LUI:LoadCommands()
    self:RegisterChatCommand("lui", "DasOptions");
end

function LUI:cOption(name)
    local color = "|cff9482c9%s|r";
    return (color):format(name);
end

function LUI:PrintURL(url)
    return format("|cff9482c9[|Hurl:%s|h%s|h]|r", url, url);
end

function LUI:PrintLink(link)
    return format("|cff9482c9|Hurl:%s|h%s|h|r", link, link);
end

function LUI:MismatchText()
    local text = format(L["LUI_ELV_OUTDATED_MSG"], LUI.ElvUIV, LUI.ElvUIX);
    return text;
end

function LUI:CreateText(f, layer, fontsize, flag, justifyh)
    local text = f:CreateFontString(nil, layer);
    text:SetFont(E.media.normFont, fontsize, flag);
    text:SetJustifyH(justifyh or "CENTER");
    return text;
end

local function Styling(f, useStripes, useGradient, useShadow, shadowOverlayWidth, shadowOverlayHeight, shadowOverlayAlpha)
    assert(f, "doesn't exist!");
    local frameName = f.GetName and f:GetName();
    if f.styling or E.db.lui.general.style ~= true then return; end
    
    local style = CreateFrame("Frame", frameName or nil, f);
    
    if not (useStripes) then
        local stripes = f:CreateTexture(f:GetName() and f:GetName() .. "Overlay" or nil, "BORDER", f);
        stripes:ClearAllPoints();
        stripes:SetPoint("TOPLEFT", 1, -1);
        stripes:SetPoint("BOTTOMRIGHT", -1, 1);
        stripes:SetTexture([[Interface\AddOns\ElvUI_LivvenUI\media\textures\stripes.blp]], true, true);
        stripes:SetSnapToPixelGrid(false);
        stripes:SetTexelSnappingBias(0);
        stripes:SetHorizTile(true);
        stripes:SetVertTile(true);
        stripes:SetBlendMode("ADD");
        
        f.stripes = stripes;
    end
    
    if not (useGradient) then
        local gradient = f:CreateTexture(f:GetName() and f:GetName() .. "Overlay" or nil, "BORDER", f);
        gradient:ClearAllPoints();
        gradient:SetPoint("TOPLEFT", 1, -1);
        gradient:SetPoint("BOTTOMRIGHT", -1, 1);
        gradient:SetTexture([[Interface\AddOns\ElvUI_LivvenUI\media\textures\gradient.tga]]);
        gradient:SetSnapToPixelGrid(false);
        gradient:SetTexelSnappingBias(0);
        gradient:SetVertexColor(.3, .3, .3, .15);
        
        f.gradient = gradient;
    end
    
    if not (useShadow) then
        local mshadow = f:CreateTexture(f:GetName() and f:GetName() .. "Overlay" or nil, "BORDER", f);
        mshadow:SetInside(f, 0, 0);
        mshadow:Width(shadowOverlayWidth or 33);
        mshadow:Height(shadowOverlayHeight or 33);
        mshadow:SetTexture([[Interface\AddOns\ElvUI_LivvenUI\media\textures\mshadow.tga]]);
        mshadow:SetSnapToPixelGrid(false);
        mshadow:SetTexelSnappingBias(0);
        mshadow:SetVertexColor(1, 1, 1, shadowOverlayAlpha or 0.6);
        
        f.mshadow = mshadow;
    end
    
    style:SetFrameLevel(f:GetFrameLevel() + 1);
    f.styling = style;
    
    LUI["styling"][style] = true;
end

local function addapi(object)
    local mt = getmetatable(object).__index;
    if not object.Styling then mt.Styling = Styling; end
    if not object.StripFrame then mt.StripFrame = StripFrame; end
    if not object.CreateOverlay then mt.CreateOverlay = CreateOverlay; end
    if not object.CreateBorder then mt.CreateBorder = CreateBorder; end
    if not object.CreatePanel then mt.CreatePanel = CreatePanel; end
end

local handled = {["Frame"] = true};
local object = CreateFrame("Frame");
addapi(object);
addapi(object:CreateTexture());
addapi(object:CreateFontString());

object = EnumerateFrames();
while object do
    if not object:IsForbidden() and not handled[object:GetObjectType()] then
        addapi(object);
        handled[object:GetObjectType()] = true;
    end
    object = EnumerateFrames(object);
end
