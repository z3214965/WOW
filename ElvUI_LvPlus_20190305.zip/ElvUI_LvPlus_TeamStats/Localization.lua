local _, addon = ...

addon.L = addon.L or NewLocale();
local L = addon.L;

L["BtnRescanText"] = "重新获取";
L["BtnRescanTipTitle"] = "重新获取天赋/装等/珠宝信息";
L["BtnRescanTip"] = "为了减少资源占用,插件并不会实时更新成员信息，请选中要更新的成员后点击此按钮";

L["BtnAnnText"] = "信息广播";
L["BtnAnnTipTitle"] = "信息广播";
L["BtnAnnTip"] = "将选中团员的信息发布到团队频道, 请谨慎选择, 防止刷屏和纠纷。";
L["BtnAnnPopupText"] = "确定广播|cffff7f00[%d]|r条信息到|cffff7f00[%s]|r频道吗?";
L["BtnAnnNoSelect"] = "请至少选择一个团员";

L["TitleText"] = "团队信息统计";
L["HeaderClass"] = CLASS;
L["HeaderPlayerName"] = "成员名称";
L["HeaderGS"] = "装等";
L["HeaderHealth"] = "血量";

L["StatusGetting"] = "正在获取资料";
L["StatusCannotGet"] = "有玩家距离过远,无法获得";
L["StatusAllDone"] = "全部资料获取完毕";
L["StatusPaused"] = "战斗中暂停获取";

L["HUNTER"]="猎人";
L["WARLOCK"]="术士";
L["PRIEST"]="牧师";
L["PALADIN"]="圣骑";
L["MAGE"]="法师";
L["ROGUE"]="盗贼";
L["DRUID"]="德鲁伊";
L["SHAMAN"]="萨满";
L["WARRIOR"]="战士";
L["DEATHKNIGHT"]="死骑";

L["MiniTipTitle"] = "团队信息统计";
L["MiniTip"] = "打开团队信息统计界面, 集中查看所有团员的天赋、装等和副本击杀情况. 图标闪烁表示有新获取的数据";

if L["zhTW"] then
end