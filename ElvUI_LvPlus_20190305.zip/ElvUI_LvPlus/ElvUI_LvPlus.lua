local E, L, V, P, G = unpack(ElvUI);
local LP = E:NewModule('LvPlus', 'AceEvent-3.0');
local LSM = LibStub("LibSharedMedia-3.0")
local EP = LibStub("LibElvUIPlugin-1.0")

local addonName, addonTable = ...
LP.Title = GetAddOnMetadata(addonName, "Title")
LP.Version = GetAddOnMetadata(addonName, "Version")
function LP:Print(msg, r, g, b, id)
	local hexvaluecolor = E.media.hexvaluecolor or '|cff00b3ff'
	(_G[E.db.general.messageRedirect] or _G.DEFAULT_CHAT_FRAME):AddMessage(strjoin('', hexvaluecolor, 'ElvUI_LvPlus:|r ', msg), r, g, b, id)
end


P["LvPlus"] = {
	["LvGeneral"]  = {
		["General"] = {		
			["LvAboutUI"] = {
				["RightButtonMenu"] = false,
				["DisableTalking"] = false,
				["AlreadyKnown"] = true,
				["ClassColors"] = true,
				["AutoDelete"] = true,
				["TalentProfiles"] = true,
				["TalentButtonElvUI"] = true,
				["AutoScreenShoot"] = {
					["EnableBtn"] = true,
				},
				["RaidMarkingKey"] = {
					["RaidMarkingButton1"] = 'alt',
					["RaidMarkingButton2"] = 'LeftButton',
				},
				["SetFocusKey"] = {
					["SetFocusButton1"] = 'shift',
					["SetFocusButton2"] = '1',
				},
				["SetPoi"] = {
					["EnableBtn"] = false,
					["PoiCombat"] = true,
					["PoiColor"] = { r = 0.5, g = 1, b = 1 },
					["PoiText"] = '╋',
					["PoiTextSize"] = 22,
				}
			},
			["LvNamePlate"] = {
				["NamePlatesCastBar"] = true,
			},
			["LvAboutLoot"] = {
				["FastLoot"] = {
					["EnableBtn"] = false,
					["LootSpeed"] = '光速',
				},
			},
			["LvActionbar"] = {
				["RandomHearthstone"] = {
					["EnableBtn"] = true,
				},
			},
			["LvChatFrame"] = {
				["ChatBar"] = {
					["EnableBtn"] = true,					
					["ChatBarPoi"] = 0,
					["SyncBtn"] = false,					
				},
				["SmartChatBub"] = {
					["EnableBtn"] = true,	
					["SmartChatBubTip"] = false,
				},
				["TradeLog"] = {
					["EnableBtn"] = true,	
					["TradeSendChat"] = false,
				},
				["ChatMSGLoot"] = {
					["EnableBtn"] = true,	
					["ChatMSGLootGS"] = false,
				},
				["RepChange"] = {
					["EnableBtn"] = true,
				},
			},
			["LvToolTips"] = {
			},
			["LvMinimap"] = {
				["WhoClickMinimap"] = true,
				["EnableBtn"] = true,
				["SquareMinimapDC"] = 'DOWN',
			},
			["LvCombatNotification"] = {
				["EnableBtn"] = true,
				["CombatNotiEntering"] = "进入战斗",
				["CombatNotiLeaving"] = "离开战斗",
				["CombatNotiFont"] = E.db.general.font,
				["CombatNotiSize"] = 25,
				["CombatNotiFlag"] = "OUTLINE",	
			},
			["LvInviteGroup"] = {
				["EnableBtn"] = true,
				["Ainvkeyword"] = "123",
				["InviteRank"] = {},
			},
			["LvAnnouceSystem"] = {
				["EnableBtn"] = true,
				["RaidSpells"] = {
					["EnableBtn"] = true,
				},
				["ResAndThreatSpells"] = {
					["EnableBtn"] = true,
					["ResAndThreat"] = true,
					["ResThanks"] = true,
				},
				["Taunt"] = {
					["EnableBtn"] = true,
					["PlayerSmart"] = false,
					["IncludeMiss"] = true,
					["OtherTankSmart"] = false,
					["IncludeOtherTank"] = true,
					["PetSmart"] = false,
					["IncludePet"] = true,
				},
			},
			["LvBlizzardUI"] = {
				["LvStatusbar"] = true,
				["CastbarTime"] = false,
				["MinimapWheel"] = false,
			},
		},
		["LvSetCVar"] = {
			["General"] = {
				["alwaysCompareItems"] = false,
				["breakUpLargeNumbers"] = true,
				["scriptErrors"] = false,
				["enableWoWMouse"] = false,
				["trackQuestSorting"] = "top",
			},
			["LvAboutUI"] = {
				["cameraDistanceMaxZoomFactor"] = 1.9,
				["ffxGlow"] = true,
				["xpBarText"] = true,
				["weatherDensity"] = 3,
			},
			["LvChatFrame"] = {
				["profanityFilter"] = true,
				["removeChatDelay"] = false,
				["chatMouseScroll"] = true,
			},
			["LvCombat"] = {
				["secureAbilityToggle"] = true,
				["stopAutoAttackOnTargetChange"] = false,
				["assistAttack"] = false,
				["SpellQueueWindow"] = 400,
			},
			["LvCombatText"] = {
				["WorldTextScale"] = 1.0,
				["TargetCombatText"] = {
					["floatingCombatTextCombatDamage"] = true,
					["floatingCombatTextCombatLogPeriodicSpells"] = true,
					["floatingCombatTextPetMeleeDamage"] = true,
					["floatingCombatTextPetSpellDamage"] = true,
					["floatingCombatTextCombatDamageDirectionalScale"] = 1,
					["floatingCombatTextCombatHealing"] = true,
					["floatingCombatTextCombatHealingAbsorbTarget"] = true,
					["floatingCombatTextSpellMechanics"] = false,
					["floatingCombatTextSpellMechanicsOther"] = false,
				},
				["PlayerCombatText"] = {
					["enableFloatingCombatText"] = false,
					["floatingCombatTextFloatMode"] = 1,
					["floatingCombatTextDodgeParryMiss"] = false,
					["floatingCombatTextCombatHealingAbsorbSelf"] = true,
					["floatingCombatTextDamageReduction"] = false,
					["floatingCombatTextLowManaHealth"] = true,
					["floatingCombatTextRepChanges"] = false,
					["floatingCombatTextEnergyGains"] = false,
					["floatingCombatTextComboPoints"] = false,
					["floatingCombatTextReactives"] = true,
					["floatingCombatTextPeriodicEnergyGains"] = false,
					["floatingCombatTextFriendlyHealers"] = false,
					["floatingCombatTextHonorGains"] = false,
					["floatingCombatTextCombatState"] = false,
					["floatingCombatTextAuras"] = false,
				},
			},
			["LvUnitFrame"] = {
				["noBuffDebuffFilterOnTarget"] = false,
				["threatShowNumeric"] = false,
			},
			["LvNamePlate"] = {
				["nameplateMaxDistance"] = 60,
				["nameplateOtherAtBase"] = 0,
				["ShowClassColorInFriendlyNameplate"] = true,		
				["nameplatePersonalShowAlways"] = false,
				["nameplatePersonalShowWithTarget"] = false,
				["nameplatePersonalShowInCombat"] = true,
				["nameplateOtherTopInset"] = 0.08,
				["nameplateLargeTopInset"] = 0.1,
				["nameplateOverlapV"] = 1.1,
				["nameplateMotionSpeed"] = 0.025,
				["nameplateGlobalScale"] = 1,
				["nameplateMinScale"] = 0.8,
			},
		},
		["QuestGroup"] = {
			["QuestAutomation"] = {
				["EnableBtn"] = true,
				["SyncBtn"] = false,
				["AutoChoices"] = true,
				["FrameButton"] = true,
				["FrameButtonElvUI"] = true,
			},
			["QuestAnnouncment"] = {
				["EnableBtn"] = true,
				["SyncBtn"] = false,
				["QuestSolo"] = true,
				["QuestParty"] = true,
				["QuestRaid"] = true,
				["QuestInstance"] = true,
				["QuestNoDetail"] = false,
				["FrameButton"] = true,
				["FrameButtonElvUI"] = true,
			},
			["QuestListEnhanced"] = {
				["EnableBtn"] = false,
				["TitleColor"] = true,
				["QuestList"] = {
					["TitleFont"] = E.db.general.font,
					["TitleFontSize"] = 14,
					["TitleFontFlag"] = "NONE",
					["InfoFont"] = E.db.general.font,
					["InfoFontSize"] = 14,
					["InfoFontFlag"] = "NONE",
				},
				["QuestLevel"] = {
					["TitleLevel"] = true,
					["DetailLevel"] = true,
					["IgnoreHighLevel"] = true,
				},
				["QuestFrame"] = {
					["FrameTitle"] = false,
					["LeftSide"] = false,
					["LeftSideSize"] = 18,
				},
			},
		}
	},
}
G["LvPlus"] = {
	["InfoFilter"] = {
		["EnableBtn"] = false,
		["PMFilter"] = {
			["EnableBtn"] = false,
			["TestLevel"] = true,
			["LevelFilter"] = 2,
			["DKLevelFilter"] = 57,
			["DHLevelFilter"] = 99,
		},
		["InfoFilterGeneral"] = {
			["EnableBtn"] = true,
			["Debug"] = false,
			["KeywordsMatchNumber"] = 1,
			["RtNum"] = 3,
			["NoWhisperSticky"] = false,
			["RepeatTime"] = 45,
			["BlackWord"] = {},
			['BlackName'] = {},
		},
	}
}

function LP:CreatLvPlus()
	local LvChangeLog = {
	"20190305",
	"更新 进出战斗提示 提供预设字体、字体大小、字体描边选项",
	"优化 智能声望显示 显示方式",
	"20190304",
	"新增 CVar控制台 比较全面的控制台，基本涵盖了游戏内需要设定的比较多的CVar，且有中文说明及默认设置",
	"新增 智能声望显示 功能，聊天框显示声望获取情况，包括巅峰声望以及可兑换奖励提醒",
	"新增 交易记录提醒 功能，交易时对话框内显示交易对象及交易情况，且可直接点击密语",
	"新增 智能聊天气泡 功能，副本外不显示气泡 防止广告骚扰，进副本自动开气泡",
	"更新 聊天条内嵌 方式更改为文本下降而不是框体增高，修复宠物战斗引起的bug",
	"(不想改ElvUI原文件，ElvUI聊天框部分设定会还原内嵌，RL 或者 重登 或者 调整字体大小可再次内嵌)",
	"更新 天赋配置管理 下拉框匹配ElvUI 10.91 新函数",
	"20190227",
	"聊天条增加位置选择",
	"修复聊天条大脚世界频道状态保存的BUG",
	"修复右键黑名单功能",
	"优化自动交接和任务通报按钮的逻辑关系，分开管控按钮及美化",
	"20190225",
	"本来加了个进出副本自动折叠任务栏，结果10.88的ElvUI出了个任务栏Auto Hide，boss战自动隐藏任务框架，就又删掉了- -",
	"增加光速拾取功能，并有3种档位 光速捡什么都看不到，极快能看到一丝，稍快能大概开清捡了什么",
	"之前添加过屏蔽关键词 和 屏蔽黑名单 的 需要重新在设置一次了",
	"信息过滤 增加密语屏蔽模块，现在可以正确的按职业等级分别屏蔽密语",
	"重写了部分按钮开启关闭之间的关联性",
	"增加任务栏按钮开关，调整了自动交接任务和任务通告按钮的位置",
	"修复 物品来源查询 造成的ElvUI调用系统函数错误",
	"20190224",
	"调整了自动交接任务和任务通告按钮的位置",
	"恢复及优化 聊天信息过滤 - 垃圾间隔 功能，可屏蔽最近出现的表情广告",
	"20190223",
	"删除暴雪UI插件，个人习惯用的，恢复ElvUI控制任务栏",
	"删除玩具箱插件，准备换个变身玩具插件",
	"修复团队信息统计调用系统函数引起的错误",
	"20190218",
	"更新随机炉石玩具宏插件，现在可以正确的在战斗中使用所有炉石玩具了",
	"几个单体插件 用不着的直接可以删除or ESC 控制台禁用",
	"增加单体插件 玩具箱 小地图按钮控制 包括玩具分类、版本、出处，一键使用随机变身/自定义玩具 来自7.3的ToyBoxQ 复活及汉化",
	"--------------------------------------------------------------------------------",
	"聊天框战利品记录 玩家名字改职业色，可直接点击M语（聊天条按钮控制开关）",
	"若开启团队信息统计并已获取到该装等，则还会显示装等（增加开关控制是否显示装等）",
	"作用大概就是 小号毛装可以直接M吧- -",
	"---------------------------------------------------------------------------------",
	"修复团队信息统计战斗中使用会报错的问题",
	"20190217",
	"增加暴雪UI的选项(可使部分UI脱离ElvUI管控，回归原始UI，比如：任务栏/坐骑栏等)",
	"增加随机炉石玩具宏插件 来自NGA的混乱时雨RandomHearthstone",
	"增加单体插件 自动切换拾取专精功能",
	"单体插件 物品来源查询更新 鼠标提示装备来源 数据库来自爱不易",
	"单体插件 团员信息统计更新 小地图按钮控制 来自爱不易",
	"修复一些小bug",
	"移除坐骑信息，最新ElvUI版本自带了",
	"移除信息过滤中过滤重复的功能，因为ElvUI自带了",
	"增加天赋配置管理按钮ElvUI美化",
	"20190127",
	"因团队信息统计和物品来源鼠标提示较占内存和会造成卡顿，变更为了单体插件，方便开关",
	"增加天赋配置管理模块",
	"增加物品来源鼠标提示",
	"增加小地图显示点击者",
	"20190126",
	"增加团队信息统计模块，因团队人员较多时收集信息会造成卡顿，默认关闭",
	"任务栏自动交接/任务通报按钮ElvUI美化",
	"信息过滤开关现在能正确的开启和关闭所有相关功能",
	"修复信息过滤中无法删除关键词的错误",
	"20190123",
	"增加特殊技能通告模块，包括团本技能（法师：桌子/传送门；术士：门/糖；机器人/大餐/邮箱/部分玩具）/战复/误导/嘲讽",
	"20190122A",
	"修复禁用剧情对话框",
	"20190121",	"增加任务相关模块，包括自动交接/自动选择奖励/任务通报/任务列表字体相关设置/任务标题职业色染色/任务等级/任务框体标题相关设置/任务栏增加自动交接及通报按钮（关闭功能可隐藏）/部分COPY自WINDTOOL，修正了其放弃任务时的报错和任务等级-忽略最高等级开关无效等",
	"修复成就自动截图功能",
	"20190116",
	"修复右键增强黑名单功能",
	"升级了右键增强功能",
	"修复信息过滤中的一处判断错误，现在能正确的防刷屏了",
	"增加自动填入DELETE",
	"重写已学物品染色功能，现在能正确的开启和关闭了",
	"临时修复已学物品染色报错，但暂时无法按钮开关该功能，默认为开",
	"20190115",
	"增加成就自动截图",
	"增加好友列表职业染色",
	"增加已学物品染色",
	"增加了全局中文单位选择 增强功能-一般设置-界面相关中选择",
	"优化了部分功能使其在正确的时间调用",
	"20190114",
	"再次修复了小地图无法正确收集小图标的问题",
	"临时修复了便捷组队的一处错误",
	"增加聊天频道条包含频道切换条;TAB切换;属性通报/Boss一句话攻略;聊天表情;ROLL点;加入/离开大脚世界频道",
	"增加便捷组队，关键词自动组队，公会按级别组队功能",
	"增加禁用剧情对话框按钮",
	"20190113",
	"重写框架所有代码便于扩展",
	"右键增强增加英雄榜/添加黑名单功能",
	"修复收集小地图图标与Addonskin的冲突，现在能正确的收集小图标了",
	"增加信息过滤/防刷屏/屏蔽黑名单功能",
	"20190112",
	"添加自定义进出战斗提示",
	"添加右键菜单增强功能",
	"修复了姓名板施法条颜色问题",
	"20190111",
	"CVAR镜头最远距离",
	"屏幕中心指示器",
	"姓名板施法条显示当前目标",
	"CVAR装备自动对比",
	"快速团队标记",
	"快速设置焦点",
	"坐骑信息",
	"收集小地图图标",
	}

	local DeleteChoisedToggle = false;
	local DeleteAllToggle = false;

	E.Options.args.LvPlus = {
		order = 999,
		type = "group",
		name = L["LvPlus"],
		args = {
			header1 = {
				order = 1,
				type = "header",
				name = LP.Title .. " " .. LP.Version,
			},		
			description1 = {
				order = 2,
				type  = "description",
				name  = "有问题加：小飞侠#53600",
			},
			spacer1 = {
				order = 3,
				type  = "description",
				name  = "\n",
			},
			ChangeLog = {
				order = 4,
				type = "group",
				guiInline = true,
				name = L["ChangeLog"],
				args = {},
			},
			LvGeneral = {
				order = 5,
				type = "group",
				name = L["LvGeneral"],
				childGroups = "tab",
				get = function(info) return E.db.LvPlus.LvGeneral[ info[#info] ] end,
				set = function(info, value) E.db.LvPlus.LvGeneral[ info[#info] ] = value end,
				args = {
					General = {
						order = 1,
						type = "group",
						name = L["General"],
						get = function(info) return E.db.LvPlus.LvGeneral.General[ info[#info] ] end,
						set = function(info, value) E.db.LvPlus.LvGeneral.General[ info[#info] ] = value end,
						args = {
							LvAboutUI = {
								order = 1,
								type = "group",
								guiInline = false,
								name = L["LvAboutUI"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									RightButtonMenu = {
										order = 1,
										type = "toggle",
										name = L["RightButtonMenu"],
									},
									DisableTalking = {
										order = 2,
										type = 'toggle',
										name = L["DisableTalking"],
									},
									AlreadyKnown = {
										order = 3,
										type = 'toggle',
										name = L["AlreadyKnown"],
									},
									ClassColors = {
										order = 4,
										type = 'toggle',
										name = L["ClassColors"],
									},
									TalentProfiles = {
										order = 5,
										type = "toggle",
										name = L["TalentProfiles"],
									},
									TalentButtonElvUI = {
										order = 6,
										type = "toggle",
										name = L["TalentButtonElvUI"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.TalentProfiles end,
									},
									AutoDelete = {
										order = 7,
										type = "toggle",
										name = L["AutoDelete"],
									},
									numberPrefixStyle = {
										order = 8,
										type = "select",
										name = L["Unit Prefix Style"],
										desc = L["The unit prefixes you want to use when values are shortened in ElvUI. This is mostly used on UnitFrames."],
										get = function(info) return E.db.general.numberPrefixStyle end,
										set = function(info, value) E.db.general.numberPrefixStyle = value; E:StaticPopup_Show("CONFIG_RL") end,
										values = {
											["METRIC"] = "Metric (k, M, G)",
											["ENGLISH"] = "English (K, M, B)",
											["CHINESE"] = "Chinese (W, Y)",
											["KOREAN"] = "Korean (천, 만, 억)",
											["GERMAN"] = "German (Tsd, Mio, Mrd)",
											["LVCHINESE"] = "中文 (万, 亿)",
										},
									},
									RaidMarkingKey = {
										order = 9,
										type = "group",
										guiInline = true,
										name = L["RaidMarkingKey"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey[ info[#info] ] = value end,
										args = {
											RaidMarkingButton1 = {
												order = 1,
												type = "select",
												name = L["RaidMarkingButton"]..'1',
												values = {
													['ctrl'] = "Ctrl",
													['alt'] = "Alt",
													['shift'] = "Shift",
													['none'] = NONE,
												}
											},
											RaidMarkingButton2 = {
												order = 2,
												type = "select",
												name = L["RaidMarkingButton"]..'2',
												disabled = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey.RaidMarkingButton1 == 'none' end,
												values = {
													["LeftButton"] = L["MouseButton1"],
													["RightButton"] = L["MouseButton2"],
												}
											}
										}
									},
									SetFocusKey = {
										order = 10,
										type = "group",
										guiInline = true,
										name = L["SetFocusKey"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
										args = {
											SetFocusButton1 = {
												order = 1,
												type = "select",
												name = L["SetFocusButton"]..'1',
												values = {
													['shift'] = 'Shift',
													['ctrl'] = 'Ctrl',
													['alt'] = 'Alt',
													['none'] = NONE,
												}
											},
											SetFocusButton2 = {
												order = 2,
												type = "select",
												name = L["SetFocusButton"]..'2',
												values = {
													['1'] = L["MouseButton1"],
													['2'] = L["MouseButton2"],
													['3'] = L["MouseButton3"],
													['4'] = L["MouseButton4"],
												},
												disabled = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton1 == 'none' end,
											}
										}
									},
									SetPoi = {
										order = 11,
										type = "group",
										guiInline = true,
										name = L["SetPoi"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiCombat = {
												order = 2,
												type = 'toggle',
												name = L["PoiCombat"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiColor = {
												order = 3,
												type = "color",
												name = L["PoiColor"],
												hasAlpha = false,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												get = function(info)
													local t = E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													local d = P.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													return t.r, t.g, t.b, t.a, d.r, d.g, d.b
												end,
												set = function(info, r, g, b)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiColor = {}
													local t = E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													t.r, t.g, t.b = r, g, b
													E:GetModule('SetPoi'):SetPoi();
												end,	
											},
											PoiText = {
												order = 4,
												type = 'select',
												name = L["PoiText"],
												values = {
													['┼'] = '┼',
													['╋'] = '╋',
													['◆'] = '◆',
													['■'] = '■',
													['●'] = '●',
													['※'] = '※',
													['↓'] = '↓',
												},
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiTextSize = {
												order = 5,
												type = 'range',
												name = L["PoiTextSize"],
												min = 10, max = 50, step = 1,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
										},
									},
									AutoScreenShoot = {
										order = 12,
										type = "group",
										guiInline = true,
										name = L["AutoScreenShoot"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")
												end,
											},
											ScreenFormat = {
												order = 2,
												name = L["ScreenFormat"],
												type = "select",
												values = {
													["jpeg"] = "JPG",
													["tga"] = "TGA",
												},
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn end,
												get = function(info) return GetCVar("screenshotFormat") end,
												set = function(info, value) SetCVar("screenshotFormat", value) end,
											},
											ScreenQuality = {
												order = 3,
												name = L["ScreenQuality"],
												type = "range",
												min = 3, max = 10, step = 1,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn end,
												get = function(info) return tonumber(GetCVar("screenshotQuality")) end,
												set = function(info, value) SetCVar("screenshotQuality", tostring(value)) end,
											},
										},
									},
								},
							},
							LvAboutLoot = {
								order = 2,
								type = "group",
								guiInline = false,
								name = L["LvAboutLoot"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutLoot[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutLoot[ info[#info] ] = value end,
								args = {
									LootSpecMangager = {
										order = 1,
										type = 'execute',
										name = L["LootSpecMangager"],
										func = function() LTSM_GUI.frame:Show();E:ToggleConfig(); end,
									},
									FastLoot = {
										order = 2,
										type = "group",
										guiInline = true,
										name = L["FastLoot"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutLoot.FastLoot[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutLoot.FastLoot[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												desc = L["FastLoot_DESC"],
											},
											LootSpeed = {
												order = 2,
												type = "select",
												name = L["LootSpeed"],
												desc = L["LootSpeed_DESC"],
												values = {
													['光速'] = "光速",
													['极快'] = "极快",
													['稍快'] = "稍快",
												},
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutLoot.FastLoot.EnableBtn end,
											},
										},
									},
								},
							},
							LvActionbar = {
								order = 3,
								type = "group",
								guiInline = false,
								name = L["LvActionbar"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvActionbar[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvActionbar[ info[#info] ] = value end,
								args = {
									RandomHearthstone = {
										order = 1,
										type = "group",
										guiInline = true,
										name = L["RandomHearthstone"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvActionbar.RandomHearthstone[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvActionbar.RandomHearthstone[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvActionbar.RandomHearthstone[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")	
												end,
											},
											CreatRHS = {
												order = 2,
												type = 'execute',
												name = L["CreatRHS"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvActionbar.RandomHearthstone.EnableBtn end,
												func = function() E:GetModule('LvPlusRandomHearthStone'):Macro_Refresh(); E:ToggleConfig(); end,
											},
										},
									}
								}
							},
							LvNamePlate = {
								order = 4,
								type = "group",
								guiInline = false,
								name = L["LvNamePlate"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvNamePlate[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvNamePlate[ info[#info] ] = value end,
								args = {
									NamePlatesCastBar ={
										order = 1,
										type = "toggle",
										name = L["NamePlatesCastBar"],
										desc = L["NamePlatesCastBar_DESC"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvNamePlate[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
											
									}
								}
							},
							LvChatFrame = {
								order = 5,
								type = "group",
								guiInline = false,
								name = L["LvChatFrame"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									ChatBar = {
										order = 1,
										type = "group",
										guiInline = true,
										name = L["ChatBar"],
										desc = L["ChatBar_DESC"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatBar[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatBar[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
											},
											ChatBarPoi = {
												order = 2,
												type = "select",
												name = L["ChatBarPoi"],
												desc = L["ChatBarPoi_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatBar.EnableBtn end,
												values = {
													[0] = "内嵌",
													[1] = "聊天框上方",
													[2] = "聊天框下方",
												},
											},
										},
									},
									TradeLog = {
										order = 2,
										type = "group",
										guiInline = true,
										name = L["TradeLog"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame.TradeLog[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame.TradeLog[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												desc = L["TradeLog_DESC"],
											},
											TradeSendChat = {
												order = 2,
												type = "toggle",
												name = L["TradeSendChat"],
												desc = L["TradeSendChat_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvChatFrame.TradeLog.EnableBtn end,							
											},
										},
									},
									ChatMSGLoot = {
										order = 3,
										type = "group",
										guiInline = true,
										name = L["ChatMSGLoot"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatMSGLoot[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatMSGLoot[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												desc = L["ChatMSGLoot_DESC"]
											},
											ChatMSGLootGS = {
												order = 2,
												type = "toggle",
												name = L["ChatMSGLootGS"],
												desc = L["ChatMSGLootGS_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatMSGLoot.EnableBtn end,							
											},
										},
									},
									SmartChatBub = {
										order = 4,
										type = "group",
										guiInline = true,
										name = L["SmartChatBub"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame.SmartChatBub[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame.SmartChatBub[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												desc = L["SmartChatBub_DESC"],
											},
											SmartChatBubTip = {
												order = 2,
												type = "toggle",
												name = L["SmartChatBubTip"],
												desc = L["SmartChatBubTip_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvChatFrame.SmartChatBub.EnableBtn; end,							
											},
										},
									},
									RepChange = {
										order = 5,
										type = "group",
										guiInline = true,
										name = L["RepChange"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame.RepChange[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame.RepChange[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												desc = L["RepChange_DESC"],
											},
										},
									},
								},
							},
							LvMinimap = {
								order = 6,
								type = "group",
								guiInline = false,
								name = L["LvMinimap"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")	
								end,
								args = {
									WhoClickMinimap = {
										order = 1,
										type = "toggle",
										name = L["WhoClickMinimap"],
									},
									SquareMinimap = {
										order = 2,
										type = "group",
										guiInline = true,
										name = L["SquareMinimap"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
											},
											SquareMinimapDC = {
												order = 20,
												type = 'select',
												name = L["SquareMinimapDC"],
												values = {
													['UP'] = L['UP'],
													['DOWN'] = L['DOWN'],
													['LEFT'] = L['LEFT'],
													['RIGHT'] = L['RIGHT'],
												},
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvMinimap.EnableBtn end,
											}
										}
									}
								}
							},
							LvCombatNotification = {
								order = 7,
								type = "group",
								guiInline = false,
								name = L["LvCombatNotification"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")	
								end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
									},
									CombatNotiEntering = {
										order = 3,
										type = "input",
										name = L["CombatNotiEntering"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification["EnableBtn"]; end,
									},
									CombatNotiLeaving = {
										order = 5,
										type = "input",
										name = L["CombatNotiLeaving"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification["EnableBtn"] end,
									},
									CombatNotiFont = {
										order = 2,
										type = 'select',
										dialogControl = 'LSM30_Font',
										values = LSM:HashTable('font'),
										name = L["CombatNotiFont"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification["EnableBtn"] end,
									},
									CombatNotiSize = {
										order = 4,
										type = 'range',
										min = 1, max = 100, step = 1,
										name = L["CombatNotiSize"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification["EnableBtn"] end,
									},
									CombatNotiFlag = {
										order = 6,
										type = 'select',
										values = {
											["NONE"] = L["NONE"],
											["OUTLINE"] = "OUTLINE",
											["THICKOUTLINE"] = "THICKOUTLINE",
											["MONOCHROMEOUTLINE"] = "MONOCROMEOUTLINE",
										},
										name = L["CombatNotiFlag"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification["EnableBtn"] end,
									},
								}
							},
							LvInviteGroup = {
								order = 8,
								type = 'group',
								name = L["LvInviteGroup"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value end,						
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									Ainvkeyword = {
										order = 2,
										type = "input",
										name = L["Ainvkeyword"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvInviteGroup.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value end,					
									},
									Spacer = {
										order = 3,
										type = 'description',
										name = '',
										desc = '',
									},
									InviteRank = {
										order = 4,
										type = 'multiselect',
										name = L["InviteRank"],
										disabled = function(info) return not IsInGuild() end,
										values = E:GetModule('InviteGroup'):GetGuildRanks(),
										get = function(info, k) return E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[k] end,
										set = function(info, k, v) E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[k] = v; end,
									},						
									RefreshRank = {
										order = 5,
										type = 'execute',
										name = L["RefreshRank"],
										func = function()
											E.Options.args.LvPlus.args.LvGeneral.args.General.args.LvInviteGroup.args.InviteRank.values = E:GetModule('InviteGroup'):GetGuildRanks();
										end,
									},
									StartInvite = {
										order = 6,
										type = 'execute',
										name = L['StartInvite'],
										disabled = function(info) return not IsInGuild() end,
										func = function() 
											for k, v in pairs(E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank) do
												if v then
													SendChatMessage(format(L['Invite guild ranks is %s member, in 10 sec.'], GuildControlGetRankName(k)), 'GUILD')
												end
											end
											E:ScheduleTimer(E:GetModule('InviteGroup').InviteRanks, 10);
										end,
									},
								},
							},
							LvAnnouceSystem = {
								order = 9,
								type = 'group',
								name = L["LvAnnouceSystem"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										width = "full",
										name = L["EnableBtn"],
									},
									RaidSpells = {
										order = 2,
										type = 'group',
										guiInline = true,
										name = L["RaidSpells"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.RaidSpells[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.RaidSpells[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												desc = L["RaidSpells_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
										},
									},
									ResAndThreatSpells = {
										order = 3,
										type = 'group',
										guiInline = true,
										name = L["ResAndThreatSpells"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 0,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
											},
											ResAndThreat = {
												order = 1,
												type = "toggle",
												name = L["ResAndThreat"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells.EnableBtn
													end
												end,
											},
											ResThanks = {
												order = 2,
												type = "toggle",
												name = L["ResThanks"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells.EnableBtn
													end
												end,
											},
										},										
									},
									Taunt = {
										order = 5,
										type = 'group',
										guiInline = true,
										name = L["Taunt"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 0,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
											},
											PlayerSmart = {
												order = 1,
												type = "toggle",
												name = L["PlayerSmart"],
												desc = L["Taunt_DESC"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn
													end
												end,														
											},
											IncludeMiss ={
												order = 2,
												type = "toggle",
												name = L["IncludeMiss"],
												desc = L["Include_DESC"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn
													end
												end,
											},
											OtherTankSmart = {
												order = 3,
												type = "toggle",
												name = L["OtherTankSmart"],
												desc = L["Taunt_DESC"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn
													end
												end,
											},
											IncludeOtherTank = {
												order = 4,
												type = "toggle",
												name = L["IncludeOtherTank"],
												desc = L["Include_DESC"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn
													end
												end,
											},
											PetSmart = {
												order = 5,
												type = "toggle",
												name = L["PetSmart"],
												desc = L["Taunt_DESC"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn
													end
												end,
											},	
											IncludePet = {
												order = 6,
												type = "toggle",
												name = L["IncludePet"],
												desc = L["Include_DESC"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn then
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn
													end
												end,
											},			
										},
									},
								},
							},
							LvBlizzardUI = {
								order = 10,
								type = 'group',
								name = L["LvBlizzardUI"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvBlizzardUI[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvBlizzardUI[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									LvStatusbar = {
										order = 1,
										type = "toggle",
										name = L["LvStatusbar"],
									},
									CastbarTime = {
										order = 2,
										type = "toggle",
										name = L["CastbarTime"],
									},
									MinimapWheel = {
										order = 3,
										type = "toggle",
										name = L["MinimapWheel"],
									},
								}
							},
						}
					},
					LvSetCVar = {
						order = 2,
						type = "group",
						name = L["LvSetCVar"],
						get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar[ info[#info] ] end,
						set = function(info, value) E.db.LvPlus.LvGeneral.LvSetCVar[ info[#info] ] = value end,
						args = {
							General = {
								order = 1,
								type = "group",
								guiInline = false,
								name = L["General"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.General[ info[#info] ] end,
								args = {
									alwaysCompareItems = {
										order = 1,
										type = "toggle",
										name = L["alwaysCompareItems"],
										desc = L["alwaysCompareItems_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.General[ info[#info] ] = value;
											SetCVar("alwaysCompareItems", (value == true and 1 or 0));
										end,
									},
									breakUpLargeNumbers = {
										order = 2,
										type = "toggle",
										name = L["breakUpLargeNumbers"],
										desc = L["breakUpLargeNumbers_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.General[ info[#info] ] = value;
											SetCVar("breakUpLargeNumbers", (value == true and 1 or 0));
										end,
									},
									scriptErrors = {
										order = 3,
										type = "toggle",
										name = L["scriptErrors"],
										desc = L["scriptErrors_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.General[ info[#info] ] = value;
											SetCVar("scriptErrors", (value == true and 1 or 0));
										end,
									},
									enableWoWMouse = {
										order = 4,
										type = "toggle",
										name = L["enableWoWMouse"],
										desc = L["enableWoWMouse_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.General[ info[#info] ] = value;
											SetCVar("enableWoWMouse", (value == true and 1 or 0));
										end,
									},
									trackQuestSorting = {
										order = 5,
										type = "select",
										name = L["trackQuestSorting"],
										desc = L["trackQuestSorting_DESC"],
										values = {
											["top"] = "顶部",
											["proximity"] = "邻近",
										},
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.General[ info[#info] ] = value;
											SetCVar("trackQuestSorting", value);
										end,
									},
								},
							},
							LvAboutUI = {
								order = 2,
								type = "group",
								guiInline = false,
								name = L["LvAboutUI"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI[ info[#info] ] end,
								args = {
									cameraDistanceMaxZoomFactor = {
										order = 1,
										type = "range",
										min = 1.0, max = 2.6, step = 0.1,
										name = L["cameraDistanceMaxZoomFactor"],
										desc = L["cameraDistanceMaxZoomFactor_DESC"],
										set = function(info, value)
											SetCVar("cameraDistanceMaxZoomFactor", value);
											E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI[ info[#info] ] = value;
										end,
									},
									weatherDensity = {
										order = 2,
										type = "range",
										min = 0, max = 3, step = 1,
										name = L["weatherDensity"],
										desc = L["weatherDensity_DESC"],
										set = function(info, value)
											SetCVar("weatherDensity", value);
											E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI[ info[#info] ] = value;
										end,
									},
									ffxGlow = {
										order = 3,
										type = "toggle",
										name = L["ffxGlow"],
										desc = L["ffxGlow_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI[ info[#info] ] = value;
											SetCVar("ffxGlow", (value == true and 1 or 0));
										end,
									},
									xpBarText = {
										order = 4,
										type = "toggle",
										name = L["xpBarText"],
										desc = L["xpBarText_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI[ info[#info] ] = value;
											SetCVar("xpBarText", (value == true and 1 or 0));
											E:StaticPopup_Show("CONFIG_RL");
										end,
									},
								},
							},
							LvChatFrame = {
								order = 3,
								type = "group",
								guiInline = false,
								name = L["Chat"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame[ info[#info] ] end,
								args = {
									profanityFilter = {
										order = 1,
										type = "toggle",
										name = L["profanityFilter"],
										desc = L["profanityFilter_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame[ info[#info] ] = value;
											SetCVar("profanityFilter", (value == true and 1 or 0));
										end,
									},
									removeChatDelay = {
										order = 2,
										type = "toggle",
										name = L["removeChatDelay"],
										desc = L["removeChatDelay_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame[ info[#info] ] = value;
											SetCVar("removeChatDelay", (value == true and 1 or 0));
										end,
									},
									chatMouseScroll = {
										order = 3,
										type = "toggle",
										name = L["chatMouseScroll"],
										desc = L["chatMouseScroll_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame[ info[#info] ] = value;
											SetCVar("chatMouseScroll", (value == true and 1 or 0));
										end,
									},
								},
							},
							LvCombat = {
								order = 4,
								type = "group",
								guiInline = false,
								name = L["LvCombat"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat[ info[#info] ] end,
								args = {
									secureAbilityToggle = {
										order = 1,
										type = "toggle",
										name = L["secureAbilityToggle"],
										desc = L["secureAbilityToggle_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat[ info[#info] ] = value;
											SetCVar("secureAbilityToggle", (value == true and 1 or 0));
										end,
									},
									stopAutoAttackOnTargetChange = {
										order = 2,
										type = "toggle",
										name = L["stopAutoAttackOnTargetChange"],
										desc = L["stopAutoAttackOnTargetChange_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat[ info[#info] ] = value;
											SetCVar("stopAutoAttackOnTargetChange", (value == true and 1 or 0));
										end,
									},
									assistAttack = {
										order = 3,
										type = "toggle",
										name = L["assistAttack"],
										desc = L["assistAttack_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat[ info[#info] ] = value;
											SetCVar("assistAttack", (value == true and 1 or 0));
										end,
									},
									SpellQueueWindow = {
										order = 4,
										type = "range",
										min = 0, max = 400, step = 1,
										name = L["SpellQueueWindow"],
										desc = L["SpellQueueWindow_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat[ info[#info] ] = value;
											SetCVar("SpellQueueWindow", value);
										end,
									},
								},
							},
							LvCombatText = {
								order = 5,
								type = "group",
								guiInline = false,
								name = L["LvCombatText"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText[ info[#info] ] end,
								args = {
									WorldTextScale = {
										order = 1,
										type = "range",
										min = 0.5, max = 2.5, step = 0.1,
										name = L["WorldTextScale"],
										desc = L["WorldTextScale_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText[ info[#info] ] = value;
											SetCVar("WorldTextScale", value);
										end,
									},
									TargetCombatText = {
										order = 2,
										type = "group",
										guiInline = true,
										name = L["TargetCombatText"],
										get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] end,
										args = {
											floatingCombatTextCombatDamage = {
												order = 1,
												type = "toggle",
												name = L["floatingCombatTextCombatDamage"],
												desc = L["floatingCombatTextCombatDamage_DESC"],
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatDamage", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextCombatLogPeriodicSpells = {
												order = 2,
												type = "toggle",
												name = L["floatingCombatTextCombatLogPeriodicSpells"],
												desc = L["floatingCombatTextCombatLogPeriodicSpells_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText["floatingCombatTextCombatDamage"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatLogPeriodicSpells", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextPetMeleeDamage = {
												order = 3,
												type = "toggle",
												name = L["floatingCombatTextPetMeleeDamage"],
												desc = L["floatingCombatTextPetMeleeDamage_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText["floatingCombatTextCombatDamage"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextPetMeleeDamage", (value == true and 1 or 0));
													SetCVar("floatingCombatTextPetSpellDamage", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextCombatDamageDirectionalScale = {
												order = 4,
												type = "range",
												min = 1, max = 5, step = 1,
												name = L["floatingCombatTextCombatDamageDirectionalScale"],
												desc = L["floatingCombatTextCombatDamageDirectionalScale_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText["floatingCombatTextCombatDamage"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatDamageDirectionalScale", value);
												end,
											},
											floatingCombatTextCombatHealing = {
												order = 5,
												type = "toggle",
												name = L["floatingCombatTextCombatHealing"],
												desc = L["floatingCombatTextCombatHealing_DESC"],
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatHealing", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextCombatHealingAbsorbTarget = {
												order = 6,
												type = "toggle",
												name = L["floatingCombatTextCombatHealingAbsorbTarget"],
												desc = L["floatingCombatTextCombatHealingAbsorbTarget_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText["floatingCombatTextCombatHealing"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatHealingAbsorbTarget", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextSpellMechanics = {
												order = 7,
												type = "toggle",
												name = L["floatingCombatTextSpellMechanics"],
												desc = L["floatingCombatTextSpellMechanics_DESC"],
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextSpellMechanics", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextSpellMechanicsOther = {
												order = 8,
												type = "toggle",
												name = L["floatingCombatTextSpellMechanicsOther"],
												desc = L["floatingCombatTextSpellMechanicsOther_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText["floatingCombatTextSpellMechanics"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextSpellMechanicsOther", (value == true and 1 or 0));
												end,
											},
										},
									},
									PlayerCombatText = {
										order = 3,
										type = "group",
										guiInline = true,
										name = L["PlayerCombatText"],
										get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value end,
										args = {
											enableFloatingCombatText = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["enableFloatingCombatText"],
												desc = L["enableFloatingCombatText_DESC"],
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("enableFloatingCombatText", (value == true and 1 or 0));
												end,
											},	
											floatingCombatTextFloatMode = {
												order = 2,
												type = "select",
												name = L["floatingCombatTextFloatMode"],
												desc = L["floatingCombatTextFloatMode_DESC"],
												values = {
													[1] = "向上滚动",
													[2] = "向下滚动",
													[3] = "弧形",
												},
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextFloatMode", value);
												end,
											},
											floatingCombatTextDodgeParryMiss = {
												order = 3,
												type = "toggle",
												name = L["floatingCombatTextDodgeParryMiss"],
												desc = L["floatingCombatTextDodgeParryMiss_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextDodgeParryMiss", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextCombatHealingAbsorbSelf = {
												order = 4,
												type = "toggle",
												name = L["floatingCombatTextCombatHealingAbsorbSelf"],
												desc = L["floatingCombatTextCombatHealingAbsorbSelf_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatHealingAbsorbSelf", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextDamageReduction = {
												order = 5,
												type = "toggle",
												name = L["floatingCombatTextDamageReduction"],
												desc = L["floatingCombatTextDamageReduction_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextDamageReduction", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextLowManaHealth = {
												order = 6,
												type = "toggle",
												name = L["floatingCombatTextLowManaHealth"],
												desc = L["floatingCombatTextLowManaHealth_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextLowManaHealth", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextRepChanges = {
												order = 7,
												type = "toggle",
												name = L["floatingCombatTextRepChanges"],
												desc = L["floatingCombatTextRepChanges_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextRepChanges", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextEnergyGains = {
												order = 8,
												type = "toggle",
												name = L["floatingCombatTextEnergyGains"],
												desc = L["floatingCombatTextEnergyGains_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextEnergyGains", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextComboPoints = {
												order = 9,
												type = "toggle",
												name = L["floatingCombatTextComboPoints"],
												desc = L["floatingCombatTextComboPoints_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextComboPoints", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextReactives = {
												order = 10,
												type = "toggle",
												name = L["floatingCombatTextReactives"],
												desc = L["floatingCombatTextReactives_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextReactives", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextPeriodicEnergyGains = {
												order = 11,
												type = "toggle",
												name = L["floatingCombatTextPeriodicEnergyGains"],
												desc = L["floatingCombatTextPeriodicEnergyGains_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextPeriodicEnergyGains", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextFriendlyHealers = {
												order = 12,
												type = "toggle",
												name = L["floatingCombatTextFriendlyHealers"],
												desc = L["floatingCombatTextFriendlyHealers_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextFriendlyHealers", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextHonorGains = {
												order = 13,
												type = "toggle",
												name = L["floatingCombatTextHonorGains"],
												desc = L["floatingCombatTextHonorGains_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextHonorGains", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextCombatState = {
												order = 14,
												type = "toggle",
												name = L["floatingCombatTextCombatState"],
												desc = L["floatingCombatTextCombatState_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextCombatState", (value == true and 1 or 0));
												end,
											},
											floatingCombatTextAuras = {
												order = 15,
												type = "toggle",
												name = L["floatingCombatTextAuras"],
												desc = L["floatingCombatTextAuras_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText["enableFloatingCombatText"] end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText[ info[#info] ] = value;
													SetCVar("floatingCombatTextAuras", (value == true and 1 or 0));
												end,
											},
										},
									},
								},
							},
							LvUnitFrame = {
								order = 6,
								type = "group",
								guiInline = false,
								name = L["LvUnitFrame"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame[ info[#info] ] = value end,
								args = {
									noBuffDebuffFilterOnTarget = {
										order = 1,
										type = "toggle",
										name = L["noBuffDebuffFilterOnTarget"],
										desc = L["noBuffDebuffFilterOnTarget_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame[ info[#info] ] = value;
											SetCVar("noBuffDebuffFilterOnTarget", (value == true and 1 or 0));
										end,
									},
									threatShowNumeric = {
										order = 2,
										type = "toggle",
										name = L["threatShowNumeric"],
										desc = L["threatShowNumeric_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame[ info[#info] ] = value;
											SetCVar("threatShowNumeric", (value == true and 1 or 0));
										end,
									},
								},
							},
							LvNamePlate = {
								order = 7,
								type = "group",
								guiInline = false,
								name = L["LvNamePlate"],
								get = function(info) return E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value end,
								args = {
									nameplatePersonalShowAlways = {
										order = 1,
										type = "toggle",
										name = L["nameplatePersonalShowAlways"],
										desc = L["nameplatePersonalShowAlways_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplatePersonalShowAlways", (value == true and 1 or 0));
										end,
									},
									nameplateMaxDistance = {
										order = 2,
										type = "range",
										min = 10, max = 100, step = 1,
										name = L["nameplateMaxDistance"],
										desc = L["nameplateMaxDistance_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplateMaxDistance", value);
										end,
									},
									nameplatePersonalShowWithTarget = {
										order = 3,
										type = "toggle",
										name = L["nameplatePersonalShowWithTarget"],
										desc = L["nameplatePersonalShowWithTarget_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplatePersonalShowWithTarget", (value == true and 1 or 0));
										end,
									},
									nameplateGlobalScale = {
										order = 4,
										type = "range",
										min = 0.5, max = 2, step = 0.1,
										name = L["nameplateGlobalScale"],
										desc = L["nameplateGlobalScale_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplateGlobalScale", value);
											SetCVar("nameplateGlobalScale", value);
										end,
									},
									nameplatePersonalShowInCombat = {
										order = 5,
										type = "toggle",
										name = L["nameplatePersonalShowInCombat"],
										desc = L["nameplatePersonalShowInCombat_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplatePersonalShowInCombat", (value == true and 1 or 0));
										end,
									},
									nameplateMinScale = {
										order = 6,
										type = "range",
										min = 0.3, max = 2, step = 0.1,
										name = L["nameplateMinScale"],
										desc = L["nameplateMinScale_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplateMinScale", value);
											SetCVar("nameplateMinScale", value);
										end,
									},
									ShowClassColorInFriendlyNameplate = {
										order = 7,
										type = "toggle",
										name = L["ShowClassColorInFriendlyNameplate"],
										desc = L["ShowClassColorInFriendlyNameplate_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("ShowClassColorInFriendlyNameplate", (value == true and 1 or 0));
										end,
									},
									nameplateOtherTopInset = {
										order = 8,
										type = "range",
										min = 0, max = 0.1, step = 0.01,
										name = L["nameplateOtherTopInset"],
										desc = L["nameplateOtherTopInset_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											if value == 0 then
												value = -1;
											end
											SetCVar("nameplateOtherTopInset", value);
											SetCVar("nameplateLargeTopInset", value);
										end,
									},
									nameplateOtherAtBase = {
										order = 9,
										type = "select",
										name = L["nameplateOtherAtBase"],
										desc = L["nameplateOtherAtBase_DESC"],
										values = {
											[0] = "头上",
											[2] = "脚下",
										},
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplateOtherAtBase", value);
										end,
									},
									nameplateOverlapV = {
										order = 10,
										type = "range",
										min = 0.2, max = 1.6, step = 0.1,
										name = L["nameplateOverlapV"],
										desc = L["nameplateOverlapV_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplateOverlapV", value);
											SetCVar("nameplateOverlapV", value);
										end,
									},
									nameplateMotionSpeed = {
										order = 11,
										type = "range",
										min = 0, max = 1.000, step = 0.025,
										name = L["nameplateMotionSpeed"],
										desc = L["nameplateMotionSpeed_DESC"],
										set = function(info, value)
											E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate[ info[#info] ] = value;
											SetCVar("nameplateMotionSpeed", value);
											SetCVar("nameplateMotionSpeed", value);
										end,
									},
								
								},
							},
						},
					},
					QuestGroup = {
						order = 2,
						type = "group",
						name = L["QuestGroup"],
						get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup[ info[#info] ] end,
						set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup[ info[#info] ] = value end,	
						args = {
							QuestAutomation = {
								order = 1,
								type = "group",
								guiInline = true,
								name = L["QuestAutomation"],
								desc = L["QuestAutomation_DESC"],
								get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation[ info[#info] ] = value
									E:StaticPopup_Show("CONFIG_RL");
								end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										width = "full",
										name = L["EnableBtn"],
									},
									AutoChoices = {
										order = 2,
										type = "toggle",
										name = L["AutoChoices"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation.EnableBtn end,
									},
									FrameButton = {
										order = 3,
										type = "toggle",
										name = L["FrameButton"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation.EnableBtn end,
									},
									FrameButtonElvUI = {
										order = 4,
										type = "toggle",
										name = L["FrameButtonElvUI"],
										disabled = function(info)
											if not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation.EnableBtn then
												return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation.EnableBtn
											else
												return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation.FrameButton
											end
										end,
									},
								},
							},
							QuestAnnouncment = {
								order = 2,
								type = "group",
								guiInline = true,
								name = L["QuestAnnouncment"],
								get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment[ info[#info] ] = value
									E:StaticPopup_Show("CONFIG_RL");
								end,	
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										width = "full",
										name = L["EnableBtn"],
									},								
									QuestSolo = {
										order = 2,
										type = "toggle",
										name = L["QuestSolo"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestParty = {
										order = 3,
										type = "toggle",
										name = L["QuestParty"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestRaid = {
										order = 4,
										type = "toggle",
										name = L["QuestRaid"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestInstance = {
										order = 5,
										type = "toggle",
										name = L["QuestInstance"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestNoDetail = {
										order = 6,
										type = "toggle",
										name = L["QuestNoDetail"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									FrameButton = {
										order = 7,
										type = "toggle",
										name = L["FrameButton"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									FrameButtonElvUI = {
										order = 8,
										type = "toggle",
										name = L["FrameButtonElvUI"],
										disabled = function(info)
											if not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn then
												return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn
											else
												return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.FrameButton
											end
										end,
									},
								},
							},
							QuestListEnhanced = {
								order = 3,
								type = "group",
								name = L["QuestListEnhanced"],
								guiInline = true,
								get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL");
								end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
									},
									TitleColor = {
										order = 2,
										type = "toggle",
										name = L["TitleColor"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
									},
									QuestList = {
										order = 3,
										type = "group",
										name = L["QuestList"],
										guiInline = true,
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,
										args = {
											TitleFont = {
												order = 1,
												type = 'select',
												dialogControl = 'LSM30_Font',
												values = LSM:HashTable('font'),
												name = L["TitleFont"],
											},
											TitleFontSize = {
												order = 2,
												type = 'range',
												min = 6, max = 22, step = 1,
												name = L["TitleFontSize"],
											},
											TitleFontFlag = {
												order = 3,
												type = 'select',
												values = {
													["NONE"] = L["NONE"],
													["OUTLINE"] = "OUTLINE",
													["THICKOUTLINE"] = "THICKOUTLINE",
													["MONOCHROMEOUTLINE"] = "MONOCROMEOUTLINE",
												},
												name = L["TitleFontFlag"],
											},
											InfoFont = {
												order = 4,
												type = 'select',
												dialogControl = 'LSM30_Font',
												values = LSM:HashTable('font'),
												name = L["InfoFont"],
											},
											InfoFontSize = {
												order = 5,
												type = 'range',
												min = 6, max = 22, step = 1,
												name = L["InfoFontSize"],
											},
											InfoFontFlag = {
												order = 6,
												type = 'select',
												values = {
													["NONE"] = L["NONE"],
													["OUTLINE"] = "OUTLINE",
													["THICKOUTLINE"] = "THICKOUTLINE",
													["MONOCHROMEOUTLINE"] = "MONOCROMEOUTLINE",
												},
												name = L["InfoFontFlag"],
											},
										},
									},
									QuestLevel = {
										order = 4,
										type = "group",
										name = L["QuestLevel"],
										guiInline = true,
										disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,
										args = {
											TitleLevel = {
												order = 1,
												type = "toggle",
												name = L["TitleLevel"],
											},
											DetailLevel = {
												order = 2,
												type = "toggle",
												name = L["DetailLevel"],
											},
											IgnoreHighLevel = {
												order = 3,
												type = "toggle",
												name = L["IgnoreHighLevel"],
											},
										},
									},
									QuestFrame = {
										order = 5,
										type = "group",
										name = L["QuestFrame"],
										guiInline = true,
										get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,
										args = {
											FrameTitle = {
												order = 1,
												type = "toggle",
												name = DISABLE..L["FrameTitle"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
											},											
											LeftSide = {
												order = 2,
												type = "toggle",
												name  = L["LeftSide"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn then
														return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn
													else
														return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.FrameTitle
													end
												end,
											},
											LeftSideSize = {
												order = 3,
												type  = 'range',
												min	  = 10, max	  = 30, step  = 1,
												name  = L["LeftSideSize"],
												disabled = function(info)
													if not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn then
														return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn
													elseif E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.FrameTitle then
														return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.FrameTitle
													else
														return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.LeftSide
													end
												end,
											},
										},
									},
								},
							},
						},
					},
				}
			},
			InfoFilter = {
				order = 6,
				type = "group",
				name = L["InfoFilter"],
				get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
				set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value end,
				args = {
					EnableBtn = {
						order = 1,
						type = "toggle",
						name = L["EnableBtn"],
						set = function(info, value) E.global.LvPlus.InfoFilter.EnableBtn = value;
							E:StaticPopup_Show("CONFIG_RL");
						end,
					},
					PMFilter = {
						order = 2,
						type = "group",
						name = L["PMFilter"],
						guiInline = true,
						disabled = function(info) return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter.PMFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter.PMFilter[ info[#info] ] = value;
							E:StaticPopup_Show("CONFIG_RL");
						end,
						args = {
							EnableBtn = {
								order = 1,
								type = "toggle",
								name = L["EnableBtn"],
								desc = L["PMFilter_DESC"]
							},
							TestLevel = {
								order = 2,
								type = "toggle",
								name = L["TestLevel"],
								desc = L["TestLevel_DESC"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.PMFilter.EnableBtn
									end
								end,
							},
							LevelFilter = {
								order = 3,
								type = 'range',
								min = 1, max = MAX_PLAYER_LEVEL-1, step = 1,
								name = L["LevelFilter"],
								desc = L["LevelFilter_DESC"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.PMFilter.EnableBtn
									end
								end,
							},
							DKLevelFilter = {
								order = 4,
								type = 'range',
								min = 57, max = MAX_PLAYER_LEVEL-1, step = 1,
								name = L["DKLevelFilter"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.PMFilter.EnableBtn
									end
								end,
							},
							DHLevelFilter = {
								order = 5,
								type = 'range',
								min = 99, max = MAX_PLAYER_LEVEL-1, step = 1,
								name = L["DHLevelFilter"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.PMFilter.EnableBtn
									end
								end,
							},
						},
					},
					InfoFilterGeneral = {
						order = 3,
						type = "group",
						name = L["InfoFilterGeneral"],
						guiInline = true,
						disabled = function(info) return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] = value;
							E:StaticPopup_Show("CONFIG_RL");
						end,
						args = {
							EnableBtn = {
								order = 1,
								type = "toggle",
								name = L["EnableBtn"],
								desc = L["InfoFilterGeneral_DESC"]
							},
							Debug = {
								order = 2,
								type = "toggle",
								name = L["Debug"],
								desc = L["Debug_DESC"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
								set = function(info, value) E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] = value end,
							},
							NoWhisperSticky = {
								order = 3,
								type = "toggle",
								name = L["NoWhisperSticky"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
								set = function(info, value)
									E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] = value;
									if value then
										ChatTypeInfo.WHISPER.sticky = 0
										ChatTypeInfo.BN_WHISPER.sticky = 0
									else
										ChatTypeInfo.WHISPER.sticky = 1
										ChatTypeInfo.BN_WHISPER.sticky = 1
									end
									E:StaticPopup_Show("CONFIG_RL");
								end,
							},
							KeywordsMatchNumber = {
								order = 4,
								type = "range",
								name = L["KeywordsMatchNumber"],
								min = 1, max = 10, step = 1,
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
							},
							RtNum = {
								order = 5,
								type = 'range',
								min = 0, max = 8, step = 1,
								name = L["RtNum"],
								desc = L["RtNum_DESC"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
							},
							RepeatTime = {
								order = 6,
								type = 'range',
								min = 0, max = 120, step = 1,
								name = L["RepeatTime"],
								desc = L["RepeatTime_DESC"],
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
							},
							BlackWord = {
								order = 7,
								type = "group",
								name = L["BlackWord"],
								guiInline = true,
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
								get = function(info) return E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] end,
								set = function(info, value) E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] = value; end,
								args = {
									BlackWordIntro = {
										order = 1,
										type = "description",
										name = L["BlackWordIntro"],
									},
									NewWord = {
										order = 2,
										type = "input",
										name = L["NewWord"],
										get = function(info) return "" end,
										set = function(info, value)
											E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord[value] = true
											E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.BlackWordList.values[value] = value;
										end,
									},
									DeleteWord = {
										order = 3,
										type = "input",
										name = L["DeleteWord"],
										get = function(info) return "" end,
										set = function(info, value)
											if E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord[value] ~= nil then
												E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord[value] = nil
												E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.BlackWordList.values[value] = nil
											end
										end,
									},
									BlackWordSpacer = {
										order = 4,
										type = 'description',
										name = '',
									},				
									DeleteChoisedKeywords= {
										order = 5,
										type = "execute",
										name = L["DeleteChoisedKeywords"],
										func = function()
											if not DeleteChoisedToggle then
												DeleteChoisedToggle = true;
												E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywordsYES"];
												C_Timer.After(5, function()
													DeleteChoisedToggle = false;
													E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywords"];
												end)
											else						
												for k, v in pairs(E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord) do
													if v then
														E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord[k] = nil;
													end
												end
												DeleteChoisedToggle = false;
												E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywords"];
												wipe(E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.BlackWordList.values);
												for k, v in pairs(E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord) do
													E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.BlackWordList.values[k] = k
												end
											end
										end,
									},
									DeleteAllKeywords = {
										order = 6,
										type = "execute",
										name = L["DeleteAllKeywords"],
										func = function()
											if not DeleteAllToggle then
												DeleteAllToggle = true;
												E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywordsYES"];
												C_Timer.After(5, function()
													DeleteAllToggle = false;
													E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywords"];
												end)							
											else						
												wipe(E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord);
												wipe(E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.BlackWordList.values);
												DeleteAllToggle = false;
												E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywords"];
											end
										end,
									},				
									BlackWordList = {
										order = 10,
										type = "multiselect",
										name = L["BlackWordList"],
										get = function(info, k) return E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord[k] end,
										set = function(info, k, v)
											E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord[k] = v
										end,
										values = {
										}
									}
								}
							},
							BlackName = {
								order = 8,
								type = "group",
								name = L["BlackName"],
								guiInline = true,
								disabled = function(info)
									if not E.global.LvPlus.InfoFilter.EnableBtn then
										return not E.global.LvPlus.InfoFilter.EnableBtn
									else
										return not E.global.LvPlus.InfoFilter.InfoFilterGeneral.EnableBtn
									end
								end,
								get = function(info) return E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] end,
								set = function(info, value) E.global.LvPlus.InfoFilter.InfoFilterGeneral[ info[#info] ] = value; end,
								args = {
									BlackNameIntro = {
										order = 0,
										type = "description",
										name = L["BlackNameIntro"],
									},
									NewName = {
										order = 1,
										type = "input",
										name = L["NewName"],
										get = function(info) return "" end,
										set = function(info, value)
											E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName[value] = value
										end,
									},
									DeleteName = {
										order = 2,
										type = "input",
										name = L["DeleteName"],
										get = function(info) return "" end,
										set = function(info, value)
											if E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName[value] ~= nil then
												E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName[value] = nil
											end
										end,
									},
									RestoreDefaults = {
										order = 3,
										type = "execute",
										name = L["RestoreDefaults"],
										func = function() wipe(E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName);
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									BlackNameList = {
										order = 4,
										type = "multiselect",
										name = L["BlackNameList"],
										get = function(info, k) return E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName[k] end,
										set = function(info, k, v)
											E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName[k] = v
										end,
										values = {
										},
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	for i = 1, #LvChangeLog do
		local Lvlog = LvChangeLog[i]
		E.Options.args.LvPlus.args.ChangeLog.args[Lvlog] = {
			order = i,
			type  = "description",
			name  = LvChangeLog[i],
		}
	end
	
	for k, v in pairs(E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackWord) do
		E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackWord.args.BlackWordList.values[k] = k
	end
	
	for k, v in pairs(E.global.LvPlus.InfoFilter.InfoFilterGeneral.BlackName) do
		E.Options.args.LvPlus.args.InfoFilter.args.InfoFilterGeneral.args.BlackName.args.BlackNameList.values[k] = k
	end
end

function LP:Initialize()
	EP:RegisterPlugin(addonName, LP.CreatLvPlus)
end

local function InitializeCallback()
	LP:Initialize()
end

E:RegisterModule(LP:GetName(), InitializeCallback)