local E, L, V, P, G = unpack(ElvUI); --Import: Engine, Locales, PrivateDB, ProfileDB, GlobalDB
local NPCB = E:NewModule('NamePlatesCastBar', 'AceEvent-3.0');
local mod = E:GetModule('NamePlates')

function NPCB:Initialize()
	function mod:UpdateElement_Cast(frame, event, ...)
		if(self.db.units[frame.UnitType].castbar.enable ~= true) then return end

		local arg1, arg2 = ...;
		local unit = frame.displayedUnit
		if ( event == "PLAYER_ENTERING_WORLD" ) then
			local nameSpell = UnitCastingInfo(unit);
			local nameChannel

			if not nameSpell then
				nameChannel = UnitChannelInfo(unit);
			end

			if nameSpell then
				event = "UNIT_SPELLCAST_START";
				arg1 = unit;
			elseif nameChannel then
				event = "UNIT_SPELLCAST_CHANNEL_START";
				arg1 = unit;
			else
				frame.CastBar:Hide()
			end
		end

		if ( unit == 'player' and event == "UNIT_SPELLCAST_SENT") then
			frame.CastBar.curTarget = (arg2 and arg2 ~= "" and self.db.units[frame.UnitType].castbar.displayTarget) and arg2 or nil
		end

		if ( arg1 ~= unit ) then
			return;
		end

		if ( event == "UNIT_SPELLCAST_START" ) then
			local name, _, texture, startTime, endTime, _, castID, notInterruptible = UnitCastingInfo(unit);
			if ( not name) then
				frame.CastBar:Hide();
				return;
			end

			frame.CastBar.canInterrupt = not notInterruptible

			if ( frame.CastBar.Spark ) then
				frame.CastBar.Spark:Show();
			end

			local _, class = UnitClass (unit .. "target")
			if class then
				local colors = (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[class]) or RAID_CLASS_COLORS[class];
				class = colors and colors.colorStr
				local targetName = UnitName (unit .. "target")
				frame.CastBar.curTarget =(class and strjoin('', '|c', class, targetName)) or targetName
				frame.CastBar.Name:SetText(name .. " > " .. frame.CastBar.curTarget)
			else
				frame.CastBar.Name:SetText(name)
			end

			frame.CastBar.value = (GetTime() - (startTime / 1000));
			frame.CastBar.maxValue = (endTime - startTime) / 1000;
			frame.CastBar:SetMinMaxValues(0, frame.CastBar.maxValue);
			frame.CastBar:SetValue(frame.CastBar.value);

			if ( frame.CastBar.Icon ) then
				frame.CastBar.Icon.texture:SetTexture(texture);
			end

			frame.CastBar.casting = true;
			frame.CastBar.castID = castID;
			frame.CastBar.channeling = nil;
			frame.CastBar.holdTime = 0

			frame.CastBar:Show()
		elseif ( event == "UNIT_SPELLCAST_STOP" or event == "UNIT_SPELLCAST_CHANNEL_STOP") then
			if ( not frame.CastBar:IsVisible() ) then
				frame.CastBar:Hide();
			end
			if ( (frame.CastBar.casting and event == "UNIT_SPELLCAST_STOP" and select(2, ...) == frame.CastBar.castID) or
				 (frame.CastBar.channeling and event == "UNIT_SPELLCAST_CHANNEL_STOP") ) then
				if ( frame.CastBar.Spark ) then
					frame.CastBar.Spark:Hide();
				end

				frame.CastBar:SetValue(frame.CastBar.maxValue);
				if ( event == "UNIT_SPELLCAST_STOP" ) then
					frame.CastBar.casting = nil;
				else
					frame.CastBar.channeling = nil;
				end
				frame.CastBar.canInterrupt = nil
				frame.CastBar:Hide()
			end
		elseif ( event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" ) then
			if ( frame.CastBar:IsShown() and (frame.CastBar.casting and select(2, ...) == frame.CastBar.castID) ) then
				frame.CastBar:SetValue(frame.CastBar.maxValue);
				if ( frame.CastBar.Spark ) then
					frame.CastBar.Spark:Hide();
				end

				if event == "UNIT_SPELLCAST_FAILED" then
					frame.CastBar.Name:SetText(FAILED);
				else
					frame.CastBar.Name:SetText(INTERRUPTED);
				end

				frame.CastBar.casting = nil;
				frame.CastBar.channeling = nil;
				frame.CastBar.canInterrupt = nil
				frame.CastBar.holdTime = self.db.units[frame.UnitType].castbar.timeToHold --How long the castbar should stay visible after being interrupted, in seconds
			end
		elseif ( event == "UNIT_SPELLCAST_DELAYED" ) then
			if ( frame:IsShown() ) then
				local name, _, _, startTime, endTime, _, _, notInterruptible = UnitCastingInfo(unit);
				if ( not name ) then
					frame.CastBar:Hide();
					return;
				end

				frame.CastBar.Name:SetText(name)
				frame.CastBar.value = (GetTime() - (startTime / 1000));
				frame.CastBar.maxValue = (endTime - startTime) / 1000;
				frame.CastBar:SetMinMaxValues(0, frame.CastBar.maxValue);
				frame.CastBar.canInterrupt = not notInterruptible
				if ( not frame.CastBar.casting ) then
					if ( frame.CastBar.Spark ) then
						frame.CastBar.Spark:Show();
					end

					frame.CastBar.casting = true;
					frame.CastBar.channeling = nil;
				end
			end
		elseif ( event == "UNIT_SPELLCAST_CHANNEL_START" ) then
			local name, _, texture, startTime, endTime, _, notInterruptible = UnitChannelInfo(unit);
			if ( not name) then
				frame.CastBar:Hide();
				return;
			end

			local _, class = UnitClass (unit .. "target")
			if class then
				local colors = (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[class]) or RAID_CLASS_COLORS[class];
				class = colors and colors.colorStr
				local targetName = UnitName (unit .. "target")
				frame.CastBar.curTarget =(class and strjoin('', '|c', class, targetName)) or targetName
				frame.CastBar.Name:SetText(name .. " > " .. frame.CastBar.curTarget)
			else
				frame.CastBar.Name:SetText(name)
			end
			
			frame.CastBar.value = (endTime / 1000) - GetTime();
			frame.CastBar.maxValue = (endTime - startTime) / 1000;
			frame.CastBar:SetMinMaxValues(0, frame.CastBar.maxValue);
			frame.CastBar:SetValue(frame.CastBar.value);
			frame.CastBar.holdTime = 0

			if ( frame.CastBar.Icon ) then
				frame.CastBar.Icon.texture:SetTexture(texture);
			end
			if ( frame.CastBar.Spark ) then
				frame.CastBar.Spark:Hide();
			end
			frame.CastBar.canInterrupt = not notInterruptible
			frame.CastBar.casting = nil;
			frame.CastBar.channeling = true;

			frame.CastBar:Show();
		elseif ( event == "UNIT_SPELLCAST_CHANNEL_UPDATE" ) then
			if ( frame.CastBar:IsShown() ) then
				local name, _, _, startTime, endTime, _, notInterruptible = UnitChannelInfo(unit);
				if ( not name ) then
					frame.CastBar:Hide();
					return;
				end
				frame.CastBar.canInterrupt = not notInterruptible
				frame.CastBar.Name:SetText(name)
				frame.CastBar.value = ((endTime / 1000) - GetTime());
				frame.CastBar.maxValue = (endTime - startTime) / 1000;
				frame.CastBar:SetMinMaxValues(0, frame.CastBar.maxValue);
				frame.CastBar:SetValue(frame.CastBar.value);
			end
		elseif ( event == "UNIT_SPELLCAST_INTERRUPTIBLE" ) then
			frame.CastBar.canInterrupt = true
		elseif ( event == "UNIT_SPELLCAST_NOT_INTERRUPTIBLE" ) then
			frame.CastBar.canInterrupt = nil
		end

		if(frame.CastBar.canInterrupt) then
			frame.CastBar:SetStatusBarColor(self.db.castColor.r, self.db.castColor.g, self.db.castColor.b)
		else
			frame.CastBar:SetStatusBarColor(self.db.castNoInterruptColor.r, self.db.castNoInterruptColor.g, self.db.castNoInterruptColor.b)
		end

		if frame.CastBar:IsShown() then --This is so we can trigger based on Cast Name or Interruptible
			self:UpdateElement_Filters(frame, "UpdateElement_Cast")
		else
			frame.CastBar.canInterrupt = nil --Only remove this when it's not shown so we can use it in style filter
		end

		self:QuestIcon_RelativePosition(frame, "Castbar")

		if(self.db.classbar.enable and self.db.classbar.position == "BELOW") then
			self:ClassBar_Update()
		end
	end
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvNamePlate.NamePlatesCastBar then
		return
	end
	NPCB:Initialize()
end

E:RegisterModule(NPCB:GetName(), InitializeCallback)