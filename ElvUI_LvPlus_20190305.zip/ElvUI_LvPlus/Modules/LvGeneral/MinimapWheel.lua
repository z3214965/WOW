local E, L, V, P, G = unpack(ElvUI);
local MW = E:NewModule('MinimapWheel');

function MW:Initialize()
	Minimap:EnableMouseWheel(true)
	Minimap:SetScript("OnMouseWheel", function(self, wheel)
		if wheel > 0 then
			_G.MinimapZoomIn:Click()
		elseif wheel < 0 then
			_G.MinimapZoomOut:Click()
		end
	end)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvBlizzardUI.MinimapWheel then
		return
	end
	MW:Initialize()
end

E:RegisterModule(MW:GetName(), InitializeCallback)