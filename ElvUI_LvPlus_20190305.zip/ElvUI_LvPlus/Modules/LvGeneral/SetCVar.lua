local E, L, V, P, G, _ = unpack(ElvUI);
local LP = E:GetModule('LvPlus');
local SC = E:NewModule('SetCVar');

local tonumber = tonumber;

local function GetCVarSet()
	--获取玩家目前CVar设置
	--General
	if GetCVar("alwaysCompareItems") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.General.alwaysCompareItems = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.General.alwaysCompareItems = true;
	end
	
	if GetCVar("breakUpLargeNumbers") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.General.breakUpLargeNumbers = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.General.breakUpLargeNumbers = true;
	end
	
	if GetCVar("scriptErrors") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.General.scriptErrors = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.General.scriptErrors = true;
	end
	
	if GetCVar("enableWoWMouse") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.General.enableWoWMouse = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.General.enableWoWMouse = true;
	end
	
	E.db.LvPlus.LvGeneral.LvSetCVar.General.trackQuestSorting = GetCVar("trackQuestSorting");
	
	--LvAboutUI
	E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI.cameraDistanceMaxZoomFactor = tonumber(GetCVar("cameraDistanceMaxZoomFactor"));
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI.weatherDensity = tonumber(GetCVar("weatherDensity"));
	
	if GetCVar("ffxGlow") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI.ffxGlow = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI.ffxGlow = true;
	end
	
	if GetCVar("xpBarText") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI.xpBarText = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvAboutUI.xpBarText = true;
	end

	--LvChatFrame
	if GetCVar("profanityFilter") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame.profanityFilter = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame.profanityFilter = true;
	end
	
	if GetCVar("removeChatDelay") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame.removeChatDelay = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame.removeChatDelay = true;
	end
	
	if GetCVar("chatMouseScroll") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame.chatMouseScroll = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvChatFrame.chatMouseScroll = true;
	end
	
	--LvCombat
	if GetCVar("secureAbilityToggle") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.secureAbilityToggle = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.secureAbilityToggle = true;
	end
	
	if GetCVar("stopAutoAttackOnTargetChange") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.stopAutoAttackOnTargetChange = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.stopAutoAttackOnTargetChange = true;
	end
	
	if GetCVar("assistAttack") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.assistAttack = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.assistAttack = true;
	end
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvCombat.SpellQueueWindow = tonumber(GetCVar("SpellQueueWindow"));
	
	--LvCombatText
	E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.WorldTextScale = tonumber(GetCVar("WorldTextScale"));
		--TargetCombatText
		if GetCVar("floatingCombatTextCombatDamage") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatDamage = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatDamage = true;
		end
		
		if GetCVar("floatingCombatTextCombatLogPeriodicSpells") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatLogPeriodicSpells = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatLogPeriodicSpells = true;
		end
		
		if GetCVar("floatingCombatTextPetMeleeDamage") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextPetMeleeDamage = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextPetMeleeDamage = true;
		end
		if GetCVar("floatingCombatTextPetSpellDamage") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextPetSpellDamage = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextPetSpellDamage = true;
		end
		
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatDamageDirectionalScale = tonumber(GetCVar("floatingCombatTextCombatDamageDirectionalScale"));
		
		if GetCVar("floatingCombatTextCombatHealing") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatHealing = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatHealing = true;
		end
		
		if GetCVar("floatingCombatTextCombatHealingAbsorbTarget") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatHealingAbsorbTarget = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextCombatHealingAbsorbTarget = true;
		end
		
		if GetCVar("floatingCombatTextSpellMechanics") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextSpellMechanics = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextSpellMechanics = true;
		end
		
		if GetCVar("floatingCombatTextSpellMechanicsOther") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextSpellMechanicsOther = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.TargetCombatText.floatingCombatTextSpellMechanicsOther = true;
		end
		
		--PlayerCombatText
		if GetCVar("enableFloatingCombatText") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.enableFloatingCombatText = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.enableFloatingCombatText = true;
		end
		
		E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextFloatMode = tonumber(GetCVar("floatingCombatTextFloatMode"));
		
		if GetCVar("floatingCombatTextDodgeParryMiss") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextDodgeParryMiss = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextDodgeParryMiss = true;
		end
		
		if GetCVar("floatingCombatTextCombatHealingAbsorbSelf") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextCombatHealingAbsorbSelf = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextCombatHealingAbsorbSelf = true;
		end
		
		if GetCVar("floatingCombatTextDamageReduction") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextDamageReduction = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextDamageReduction = true;
		end
		
		if GetCVar("floatingCombatTextLowManaHealth") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextLowManaHealth = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextLowManaHealth = true;
		end
		
		if GetCVar("floatingCombatTextRepChanges") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextRepChanges = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextRepChanges = true;
		end
		
		if GetCVar("floatingCombatTextEnergyGains") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextEnergyGains = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextEnergyGains = true;
		end
		
		if GetCVar("floatingCombatTextComboPoints") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextComboPoints = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextComboPoints = true;
		end
		
		if GetCVar("floatingCombatTextReactives") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextReactives = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextReactives = true;
		end
		
		if GetCVar("floatingCombatTextPeriodicEnergyGains") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextPeriodicEnergyGains = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextPeriodicEnergyGains = true;
		end
		
		if GetCVar("floatingCombatTextFriendlyHealers") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextFriendlyHealers = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextFriendlyHealers = true;
		end
		
		if GetCVar("floatingCombatTextHonorGains") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextHonorGains = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextHonorGains = true;
		end
		
		if GetCVar("floatingCombatTextCombatState") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextCombatState = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextCombatState = true;
		end
		
		if GetCVar("floatingCombatTextAuras") == "0" then
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextAuras = false;
		else
			E.db.LvPlus.LvGeneral.LvSetCVar.LvCombatText.PlayerCombatText.floatingCombatTextAuras = true;
		end
		
	--LvUnitFrame
	if GetCVar("noBuffDebuffFilterOnTarget") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame.noBuffDebuffFilterOnTarget = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame.noBuffDebuffFilterOnTarget = true;
	end
	
	if GetCVar("threatShowNumeric") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame.threatShowNumeric = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvUnitFrame.threatShowNumeric = true;
	end
	
	--LvNamePlate
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateMaxDistance = tonumber(GetCVar("nameplateMaxDistance"));
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateOtherAtBase = tonumber(GetCVar("nameplateOtherAtBase"));
	
	if GetCVar("ShowClassColorInFriendlyNameplate") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.ShowClassColorInFriendlyNameplate = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.ShowClassColorInFriendlyNameplate = true;
	end
	
	if GetCVar("nameplatePersonalShowAlways") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplatePersonalShowAlways = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplatePersonalShowAlways = true;
	end
	
	if GetCVar("nameplatePersonalShowWithTarget") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplatePersonalShowWithTarget = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplatePersonalShowWithTarget = true;
	end
	
	if GetCVar("nameplatePersonalShowInCombat") == "0" then
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplatePersonalShowInCombat = false;
	else
		E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplatePersonalShowInCombat = true;
	end
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateOtherTopInset = tonumber(GetCVar("nameplateOtherTopInset"));
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateLargeTopInset = tonumber(GetCVar("nameplateLargeTopInset"));
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateOverlapV = tonumber(GetCVar("nameplateOverlapV"));
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateMotionSpeed = tonumber(GetCVar("nameplateMotionSpeed"));
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateGlobalScale = tonumber(GetCVar("nameplateGlobalScale"));
	
	E.db.LvPlus.LvGeneral.LvSetCVar.LvNamePlate.nameplateMinScale = tonumber(GetCVar("nameplateMinScale"));
end

function SC:Initialize()
	GetCVarSet();
end

local function InitializeCallback()
	SC:Initialize();
end

E:RegisterModule(SC:GetName(), InitializeCallback)