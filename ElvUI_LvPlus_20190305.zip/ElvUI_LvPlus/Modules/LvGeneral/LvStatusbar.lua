local E, L, V, P, G = unpack(ElvUI);
local LS = E:NewModule('LvStatusbar');
local LSM = LibStub("LibSharedMedia-3.0")

function LS:Initialize()
	LSM:Register("statusbar", "ElvUI_01", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_01.tga]]) 
	LSM:Register("statusbar", "ElvUI_02", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_02.tga]]) 
	LSM:Register("statusbar", "ElvUI_03", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_03.tga]]) 
	LSM:Register("statusbar", "ElvUI_04", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_04.tga]]) 
	LSM:Register("statusbar", "ElvUI_05", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_05.tga]]) 
	LSM:Register("statusbar", "ElvUI_06", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_06.tga]]) 
	LSM:Register("statusbar", "ElvUI_07", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_07.tga]]) 
	LSM:Register("statusbar", "ElvUI_08", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_08.tga]]) 
	LSM:Register("statusbar", "ElvUI_09", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_09.tga]]) 
	LSM:Register("statusbar", "ElvUI_10", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_10.tga]]) 
	LSM:Register("statusbar", "ElvUI_11", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_11.tga]]) 
	LSM:Register("statusbar", "ElvUI_12", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_12.tga]]) 
	LSM:Register("statusbar", "ElvUI_13", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_13.tga]]) 
	LSM:Register("statusbar", "ElvUI_14", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_14.tga]]) 
	LSM:Register("statusbar", "ElvUI_15", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_15.tga]]) 
	LSM:Register("statusbar", "ElvUI_16", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_16.tga]])
	LSM:Register("statusbar", "ElvUI_17", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_17.tga]]) 
	LSM:Register("statusbar", "ElvUI_18", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_18.tga]]) 
	LSM:Register("statusbar", "ElvUI_19", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_19.tga]]) 
	LSM:Register("statusbar", "ElvUI_20", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_20.tga]]) 
	LSM:Register("statusbar", "ElvUI_21", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_21.tga]]) 
	LSM:Register("statusbar", "ElvUI_22", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_22.tga]])
	LSM:Register("statusbar", "ElvUI_23", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_23.tga]])
	LSM:Register("statusbar", "ElvUI_24", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\ElvUI_24.tga]])
	LSM:Register("statusbar", "FXGG_1", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\FX_001.tga]])
	LSM:Register("statusbar", "FXGG_2", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\FX_002.tga]])
	LSM:Register("statusbar", "FXGG_3", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\FX_003.tga]])
	LSM:Register("statusbar", "FXGG_4", [[Interface\AddOns\ElvUI_LvPlus\Media\statusbar\FX_004.tga]])
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvBlizzardUI.LvStatusbar then
		return
	end
	LS:Initialize()
end

E:RegisterModule(LS:GetName(), InitializeCallback)