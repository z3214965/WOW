local E, L, V, P, G = unpack(ElvUI)
local FL = E:NewModule('FastLoot');

function FL:Initialize()
	local Delay = 0
	local FLSpeed
	if E.db.LvPlus.LvGeneral.General.LvAboutLoot.FastLoot.LootSpeed == "光速" then
		FLSpeed = 0
	elseif E.db.LvPlus.LvGeneral.General.LvAboutLoot.FastLoot.LootSpeed == "极快" then
		FLSpeed = 0.1
	else
		FLSpeed = 0.2
	end
	local faster = CreateFrame("Frame")
	faster:RegisterEvent("LOOT_READY")
	faster:SetScript("OnEvent",function()
		if GetTime() - Delay >= FLSpeed then
			if GetCVarBool("autoLootDefault") ~= IsModifiedClick("AUTOLOOTTOGGLE") then
				for i = GetNumLootItems(), 1, -1 do
					LootSlot(i)
				end
				Delay = GetTime()
			end
		end
	end)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvAboutLoot.FastLoot.EnableBtn then return end
	FL:Initialize()
end

E:RegisterModule(FL:GetName(), InitializeCallback)