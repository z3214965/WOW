local E, L, V, P, G, _ = unpack(ElvUI);
local LP = E:GetModule('LvPlus');
local RC = E:NewModule('RepChange', 'AceEvent-3.0');

local format = string.format
local rep = {};
local extraRep = {};
local C_Reputation_IsFactionParagon = C_Reputation.IsFactionParagon;
local GetFactionInfo = GetFactionInfo;
local GetNumFactions = GetNumFactions;
local getglobal = getglobal;

local SR_REP_MSG = "%s: %+d (%d/%d)";
local SR_EXTRAREP_MSG = "%s: %+d (%d/10000) (巅峰)";

local function createMessage(msg)
	local info = ChatTypeInfo["COMBAT_FACTION_CHANGE"];
	for j = 1, 4, 1 do
		local chatfrm = getglobal("ChatFrame"..j);
		for k,v in pairs(chatfrm.messageTypeList) do
			if v == "COMBAT_FACTION_CHANGE" then
				chatfrm:AddMessage(msg, info.r, info.g, info.b, info.id);
				break;
			end
		end
	end
end

local function initExtraRep(factionID, name)
	local currentValue, threshold, _, hasRewardPending = C_Reputation.GetFactionParagonInfo(factionID);
	if not extraRep[name] then
		extraRep[name] = currentValue % threshold;
		if hasRewardPending then
			extraRep[name] = extraRep[name] + threshold;
		end
	end
	if extraRep[name] > threshold and (not hasRewardPending) then
		extraRep[name] = extraRep[name] - threshold;
	end
end

function RC:SR_Update()
	local numFactions = GetNumFactions(self);
	for i = 1, numFactions, 1 do
		local name, _, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild, factionID = GetFactionInfo(i);
		local value = 0;
		if barValue >= 42000 then
			local hasParagon = C_Reputation_IsFactionParagon(factionID);
			if hasParagon then
				initExtraRep(factionID,name);
				local currentValue, threshold, _, hasRewardPending = C_Reputation.GetFactionParagonInfo(factionID);
				value = currentValue % threshold;
				if hasRewardPending then 
					value = value + threshold;
				end
				local extraChange = value - extraRep[name];
				if extraChange ~= 0 then
					extraRep[name] = value;
					local extra_msg = format(SR_EXTRAREP_MSG, name, extraChange, value);
					createMessage(extra_msg);
				end
			end
		elseif name and (not isHeader) or (hasRep) then
			if not rep[name] then
				rep[name] = barValue;
			end
			local change = barValue - rep[name];
			if change ~= 0 then
				rep[name] = barValue;
				local msg = format(SR_REP_MSG, name, change, barValue - barMin, barMax - barMin)
				createMessage(msg);
			end
		end
	end
end

function RC:Initialize()
	self:RegisterEvent("UPDATE_FACTION", "SR_Update");
	ChatFrame_AddMessageEventFilter("CHAT_MSG_COMBAT_FACTION_CHANGE", function() return true; end);
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvChatFrame.RepChange.EnableBtn then return; end
	RC:Initialize();
end

E:RegisterModule(RC:GetName(), InitializeCallback)