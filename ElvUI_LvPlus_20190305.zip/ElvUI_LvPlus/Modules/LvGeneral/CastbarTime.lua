local E, L, V, P, G = unpack(ElvUI);
local CT = E:NewModule('CastbarTime', 'AceHook-3.0');

CastingBarFrame.timer = CastingBarFrame:CreateFontString(nil) 
CastingBarFrame.timer:SetFont("Fonts\\ARIALN.ttf", 14, "NONE") 
CastingBarFrame.timer:SetPoint("RIGHT", CastingBarFrame, "RIGHT", 0, -15) 
CastingBarFrame.update = .1 

local function CastingBarFrame_OnUpdate_Hook(self, elapsed)
	if not self.timer then return end
	if self.update and self.update < elapsed then
		if self.casting then
			self.timer:SetText(format("%.1f / %.1f", max(self.maxValue - self.value, 0), self.maxValue))
		elseif self.channeling then
			self.timer:SetText(format("%.1f / %.1f", max(self.value, 0), self.maxValue))
		else
			self.timer:SetText("")
		end

		self.update = .1
	else
		self.update = self.update - elapsed
	end
end

function CT:Initialize()
	CastingBarFrame:HookScript('OnUpdate', CastingBarFrame_OnUpdate_Hook)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvBlizzardUI.CastbarTime then
		return
	end
	CT:Initialize()
end

E:RegisterModule(CT:GetName(), InitializeCallback)