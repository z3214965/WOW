local E, L, V, P, G, _ = unpack(ElvUI);
local ASS = E:NewModule('AutoScreenShoot', 'AceEvent-3.0')

function ASS:TakeScreen()
	E:ScheduleTimer(Screenshot, 1)
end

function ASS:Initialize()
	self:RegisterEvent("ACHIEVEMENT_EARNED", "TakeScreen")
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn then
		return
	end
	ASS:Initialize()
end

E:RegisterModule(ASS:GetName(), InitializeCallback)