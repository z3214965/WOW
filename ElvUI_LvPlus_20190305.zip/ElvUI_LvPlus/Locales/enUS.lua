local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "enUS")
if not L then return end
-- 设置主界面
-- zhCN
-- 设置主界面
L["LvPlus"] = true
L["ChangeLog"] = true
L["LvGeneral"] = true
L["EnableBtn"] = true
L["UP"] = true
L["DOWN"] = true
L["LEFT"] = true
L["RIGHT"] = true
L["NONE"] = true
-- 任务
L["QuestGroup"] = true
	L["FrameButton"] = true
	L["FrameButtonElvUI"] = true
	L["QuestAutomation"] = true
		L["QuestAutomation_DESC"] = true
		L["AutoChoices"] = true
	L["QuestAnnouncment"] = true
		L["QuestSolo"] = true
		L["QuestParty"] = true
		L["QuestRaid"] = true
		L["QuestInstance"] = true
		L["QuestNoDetail"] = true
	L["QuestListEnhanced"] = true
		L["QuestList"] = true
			L["TitleFont"] = true
			L["TitleFontSize"] = true
			L["TitleFontFlag"] = true
			L["InfoFont"] = true
			L["InfoFontSize"] = true
			L["InfoFontFlag"] = true
		L["TitleColor"]	= true
		L["QuestLevel"] = true
			L["TitleLevel"] = true
			L["DetailLevel"] = true
			L["IgnoreHighLevel"] = true
		L["QuestFrame"] = true
			L["FrameTitle"] = true
			L["LeftSide"] = true
			L["LeftSideSize"] = true
-- 界面增强
L["LvAboutUI"] = true
	L["RightButtonMenu"] = true
	L["Armory"] = true
	L["Query Detail"] = true
	L["Get Name"] = true
	L["Guild Invite"] = true
	L["Add Friend"] = true
	L["Report MyStats"] = true
	L["LVBLACKNAME"] = true
	L["DisableTalking"] = true
	L["AlreadyKnown"] = true
	L["ClassColors"] = true
	L["AutoScreenShoot"] = true
	L["AutoDelete"] = true
	L["TalentProfiles"] = true
	L["TalentButtonElvUI"] = true
	L["LvBlizzard"] = true
	L["LvBlizzard_DESC"] = true
	L["ScreenFormat"] = true
	L["ScreenQuality"] = true
	L["RaidMarkingKey"] = true
	L["RaidMarkingButton"] = true
	L["SetFocusKey"] = true
	L["SetFocusButton"] = true
	L["MouseButton1"] = true
	L["MouseButton2"] = true
	L["MouseButton3"] = true
	L["MouseButton4"] = true
	L["SetPoi"] = true
	L["PoiCombat"] = true
	L["PoiColor"] = true
	L["PoiText"] = true
	L["PoiTextSize"] = true
L["LvSetCVAR"] = true
	L["AutoCompare"] = true
	L["AutoCompare_DESC"] = true
	L["CameraFactor"] = true
	L["DisableProfanityFilter"] = true
L["LvAboutLoot"] = true
	L["LootSpecMangager"] = true
	L["FastLoot"] = true
		L["FastLoot_DESC"] = true
		L["LootSpeed"] = true
		L["LootSpeed_DESC"] = true
L["LvActionbar"] = true
	L["RandomHearthstone"] = true
	L["CreatRHS"] = true
L["LvNamePlate"] = true
	L["NamePlatesCastBar"] = true
	L["NamePlatesCastBar_DESC"] = true
L["LvChatFrame"] = true
	L["ChatBar"] = true
	L["ChatBar_DESC"] = true
	L["ChatBarPoi"] = true
	L["ChatBarPoi_DESC"] = true
	L["ChatBub"] = true
	L["SmartChatBub"] = true
	L["SmartChatBub_DESC"] = true
	L["SmartChatBubTip"] = true
	L["SmartChatBubTip_DESC"] = true
	L["TradeLog"] = true
	L["TradeLog_DESC"] = true
	L["TradeSendChat"] = true
	L["TradeSendChat_DESC"] = true
	L["ChatMSGLoot"] = true
	L["ChatMSGLoot_DESC"] = true
	L["ChatMSGLootGS"] = true
	L["ChatMSGLootGS_DESC"] = true
	L["Roll 1-100"] = true
	L["BigFootChannel"] = true
	L["Enable/DisableBigFootChannel"] = true
	L['says'] = true
	L['yells'] = true
	L['G'] = true
	L['O'] = true
	L['P'] = true
	L['R'] = true
	L['RW'] = true
	L['I'] = true
	L['BG'] = true
L["LvToolTips"] = true
	-- L["MountInfo"] = true
	-- L["MountInfo_DESC"] = true
	-- L["MountInfohaved"] = true
	-- L["MountInfonothaved"] = true
L["LvMinimap"] = true
	L["WhoClickMinimap"] = true
	L["SquareMinimap"] = true
	L["SquareMinimapDC"] = true
L["LvCombatNotification"] = true
	L["CombatNotiEntering"] = true
	L["CombatNotiLeaving"] = true
L["LvInviteGroup"] = true
	L["Ainvkeyword"] = true
	L["InviteRank"] = true
	L["RefreshRank"] = true
	L['StartInvite'] = true
	L['Invite guild ranks is %s member, in 10 sec.'] = true
L["LvAnnouceSystem"] = true
	L["RaidSpells"] = true
	L["RaidSpells_DESC"] = true
	L["ResAndThreatSpells"] = true
		L["ResAndThreat"] = true
		L["ResThanks"] = true
	L["Taunt"] = true
	L["Taunt_DESC"] = true
	L["Include_DESC"] = true
		L["PlayerSmart"] = true
		L["IncludeMiss"] = true
		L["OtherTankSmart"] = true
		L["IncludeOtherTank"] = true
		L["PetSmart"] = true
		L["IncludePet"] = true
L["LvBlizzardUI"] = true
	L["LvStatusbar"] = true
	L["CastbarTime"] = true
	L["MinimapWheel"] = true
-- 聊天过滤
L["InfoFilter"] = true
	L["PMFilter"] = true
		L["PMFilter_DESC"] = true
	L["InfoFilterGeneral"] = true
		L["InfoFilterGeneral_DESC"] = true
		L["Debug"] = true
		L["Debug_DESC"] = true
		L["KeywordsMatchNumber"] = true
		L["RtNum"] = true
		L["RtNum_DESC"] = true
		L["NoWhisperSticky"] = true
		L["TestLevel"] = true
		L["TestLevel_DESC"] = true
		L["DKLevelFilter"] = true
		L["DHLevelFilter"] = true
		L["LevelFilter"] = true
		L["LevelFilter_DESC"] = true
		L["RepeatTime"] = true
		L["RepeatTime_DESC"] = true
		L["BlackWord"] = true
		L["BlackWordIntro"] = true
		L["NewWord"] = true
		L["DeleteWord"] = true
		L["DeleteChoisedKeywords"] = true
		L["DeleteChoisedKeywordsYES"] = true
		L["DeleteAllKeywords"] = true
		L["DeleteAllKeywordsYES"] = true
		L["BlackWordList"] = true
		L["BlackName"] = true
		L["BlackNameIntro"] = true
		L["NewName"] = true
		L["DeleteName"] = true
		L["RestoreDefaults"] = true
		L["BlackNameList"] = true


-- ===================== Part for TradeLog ==================
TRADE_LOG_MONEY_NAME = {
	gold = "g",
	silver = "s",
	copper = "c",
}

CANCEL_REASON_TEXT = {
	self = "I cancelled it",
	other = "target cancelled it",
	toofar = "we are too faraway",
	selfrunaway = "I moved away",
	selfhideui = "I hid ui",
	unknown = "unknown reason",
}

TRADE_LOG_SUCCESS_NO_EXCHANGE = "Trade with [%t] was COMPLETED, but no exchange made.";
TRADE_LOG_SUCCESS = "Trade with [%t] was COMPLETED.";
TRADE_LOG_DETAIL = "Detail";
TRADE_LOG_CANCELLED = "Trade with [%t] was CANCELLED: %r.";
TRADE_LOG_FAILED = "Trade with [%t] was FAILED: %r.";
TRADE_LOG_FAILED_NO_TARGET = "Trade FAILED: %r.";
TRADE_LOG_HANDOUT = "lost";
TRADE_LOG_RECEIVE = "got";
TRADE_LOG_ENCHANT = "enchant";
TRADE_LOG_ITEM_NUMBER = "%d items";
TRADE_LOG_CHANNELS = {
	whisper = "Whisper",
	raid = "Raid",
	party = "Party",
	say = "Say",
	yell = "Yell",
}
TRADE_LOG_ANNOUNCE = "NOTIFY";
TRADE_LOG_ANNOUNCE_TIP = "Check this to automatically announce after trading."

TRADE_LOG_RESULT_TEXT_SHORT = { 
	cancelled = "cancel", 
	complete = "ok", 
	error = "failed", 
}

TRADE_LOG_RESULT_TEXT = {
	cancelled = "Trade Cancelled", 
	complete = "Trade Completed", 
	error = "Trade Failed", 
}

TRADE_LOG_MONTH_SUFFIX = "-"
TRADE_LOG_DAY_SUFFIX = ""

TRADE_LOG_COMPLETE_TOOLTIP = "Click to show detail";


RECENT_TRADE_TIME = "%d %s ago"
RECENT_TRADE_TITLE = "Recent Trade"

-- ===================== Part for TradeList ==================
TRADE_LIST_CLEAR_HISTORY = "CLEAR"
TRADE_LIST_SCALE = "Detail Scale"
TRADE_LIST_FILTER = "Completed Only"

TRADE_LIST_HEADER_WHEN = "Time"
TRADE_LIST_HEADER_WHO = "Recipent"
TRADE_LIST_HEADER_WHERE = "Location"
TRADE_LIST_HEADER_SEND = "Lost"
TRADE_LIST_HEADER_RECEIVE = "Got"
TRADE_LIST_HEADER_RESULT = "Result"

TRADE_LIST_CLEAR_CONFIRM = "Records before today will be totally cleared!";

TRADE_LIST_TITLE = "TradeLog"
TRADE_LIST_DESC = "Show recent trade logs, or the reasons of failed trades."