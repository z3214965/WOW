local E, L, V, P, G = unpack(ElvUI);
local SM = E:NewModule('SquareMinimap', 'AceEvent-3.0');


local BlackList = {
	["AddOnSkins"] = true,
	["HelpOpenTicketButton"] = true,
	["ZygorGuidesViewerMapIcon"] = true,
	["MiniMapTrackingButton"] = true,
	["MiniMapTrackingFrame"] = true,
	["MiniMapMeetingStoneFrame"] = true,
	["MiniMapMailFrame"] = true,
	["MiniMapBattlefieldFrame"] = true,
	["MiniMapWorldMapButton"] = true,
	["MiniMapPing"] = true,
	["MinimapBackdrop"] = true,
	["MinimapZoomIn"] = true,
	["MinimapZoomOut"] = true,
	["BookOfTracksFrame"] = true,
	["GatherNote"] = true,
	["FishingExtravaganzaMini"] = true,
	["MiniNotePOI"] = true,
	["RecipeRadarMinimapIcon"] = true,
	["FWGMinimapPOI"] = true,
	["CartographerNotesPOI"] = true,
	["MBB_MinimapButtonFrame"] = true,
	["EnhancedFrameMinimapButton"] = true,
	["GFW_TrackMenuFrame"] = true,
	["GFW_TrackMenuButton"] = true,
	["TDial_TrackingIcon"] = true,
	["TDial_TrackButton"] = true,
	["MiniMapTracking"] = true,
	["GatherMatePin"] = true,
	["HandyNotesPin"] = true,
	["TimeManagerClockButton"] = true,
	["GameTimeFrame"] = true,
	["DA_Minimap"] = true,
	["ElvConfigToggle"] = true,
	["MiniMapInstanceDifficulty"] = true,
	["MinimapZoneTextButton"] = true,
	["GuildInstanceDifficulty"] = true,
	["MiniMapVoiceChatFrame"] = true,
	["MiniMapRecordingButton"] = true,
	["QueueStatusMinimapButton"] = true,
	["GatherArchNote"] = true,
	["ZGVMarker"] = true,
	["QuestPointerPOI"] = true,
	["poiMinimap"] = true,
	["MiniMapLFGFrame"] = true,
	["PremadeFilter_MinimapButton"] = true,
	["GarrisonMinimapButton"] = true,
}
local WhiteList = {
	["BagSync_MinimapButton"] = true,
}

local buttons = {}
local maxbuttonsize = 32



local function CreateMinimapButton()
	local button = CreateFrame("Button", "LvMinimapButton", E.UIParent)
	E.FrameLocks['LvMinimapButton'] = true;
		
	button:SetFrameStrata("MEDIUM")
	button:RegisterForClicks("anyUp")

	button:SetClampedToScreen(true)
	button:StyleButton()
	button:SetTemplate('Default')
	button:Size(20)
	button:Point('CENTER', Minimap, 'TOPLEFT', 0, -E.db.general.minimap.size / 2)
	E:CreateMover(button, "LvMinimapButtonMover", L['Square minimap icons'], nil, nil, nil, "ALL,SOLO", nil, "lvplus,lvplus_general")
	button.texture = button:CreateTexture(nil, 'OVERLAY')
	button.texture:Size(22)
	button.texture:Point('CENTER')
	button.texture:SetTexture('Interface\\AddOns\\ElvUI\\media\\textures\\Minus')
	button:SetScript("OnClick", function(self, button)
		if button == "RightButton" then
			E:ToggleConfig()
		else
			for i = 1, #buttons do
				if buttons[i]:IsShown() then buttons[i]:Hide() else buttons[i]:Show() end
			end
		end
	end)
		
	return button
end

local function PositionAndStyle(button)
	for i = 1, #buttons do
		buttons[i]:ClearAllPoints()
		if E.db.LvPlus.LvGeneral.General.LvMinimap.SquareMinimapDC == 'DOWN' then
			if i == 1 then
				buttons[i]:Point("TOP", button, "BOTTOM", 0, -2)
			elseif i > 1 then
				buttons[i]:Point("TOP", button, "BOTTOM", 0, -maxbuttonsize*(i-1)-i)
			end
		elseif E.db.LvPlus.LvGeneral.General.LvMinimap.SquareMinimapDC == 'LEFT' then
			if i == 1 then
				buttons[i]:Point("RIGHT", button, "LEFT", -2, 0)
			elseif i > 1 then
				buttons[i]:Point("RIGHT", button, "LEFT", -maxbuttonsize*(i-1)-i, 0)
			end
		elseif E.db.LvPlus.LvGeneral.General.LvMinimap.SquareMinimapDC == 'RIGHT' then
			if i == 1 then
				buttons[i]:Point("LEFT", button, "RIGHT", 2, 0)
			elseif i > 1 then
				buttons[i]:Point("LEFT", button, "RIGHT", maxbuttonsize*(i-1)+i, 0)
			end
		else
			if i == 1 then
				buttons[i]:Point("BOTTOM", button, "TOP", 0, 2)
			else
				buttons[i]:Point("BOTTOM", button, "TOP", 0, maxbuttonsize*(i-1)+i)
			end
		end
		buttons[i].ClearAllPoints = E.dummy
		buttons[i].SetPoint = E.dummy
		buttons[i]:Hide()
		if (buttons[i]:HasScript("OnClick")) then
			buttons[i]:HookScript("OnClick", function(self)
				for i = 1, #buttons do
					if buttons[i]:IsShown() then buttons[i]:Hide() end
				end
			end)
		elseif (buttons[i]:HasScript("OnMouseUp")) then
			buttons[i]:HookScript("OnMouseUp", function(self)
				for i = 1, #buttons do
					if buttons[i]:IsShown() then buttons[i]:Hide() end
				end
			end)
		end
	end
end

local function buttonCollect()
	local button = _G['LvMinimapButton'] or CreateMinimapButton()
	if #buttons > 0 then return; end
		
	for i, child in ipairs({Minimap:GetChildren()}) do
		local childName = child:GetName()
		if not BlackList[childName] then
			if ((child:IsObjectType("Button") and child:GetNumRegions() >= 3) or WhiteList[childName]) and child:IsShown() then
				pcall(child.SetParent,button)
				if child:GetHeight() and child:GetHeight() > maxbuttonsize then
					maxbuttonsize = child:GetHeight();
				end
				tinsert(buttons, child)
			end
		end
	end
	if #buttons == 0 then
		button:Hide()
	else
		button:Show()
	end
		
	PositionAndStyle(button)
end
	
function SM:ButtonCollect()		
	if GarrisonLandingPageMinimapButton then
		GarrisonLandingPageMinimapButton:SetSize(36,36)
	end
		
	if IsAddOnLoaded('MBB') then DisableAddOn('MBB') end	

	buttonCollect()
	E:ScheduleTimer(buttonCollect, 2)
end
	
	
function SM:Initialize()
	self:RegisterEvent("PLAYER_ENTERING_WORLD", "ButtonCollect")
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvMinimap.EnableBtn then
		return
	end
	SM:Initialize()
end

E:RegisterModule(SM:GetName(), InitializeCallback)