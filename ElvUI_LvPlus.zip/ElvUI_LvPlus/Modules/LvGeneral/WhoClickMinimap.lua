local E, L, V, P, G = unpack(ElvUI);
local WCM = E:NewModule('WhoClickMinimap', 'AceEvent-3.0');

function WCM:Initialize()
	local addon = CreateFrame('ScrollingMessageFrame', false, Minimap) 
	addon:SetHeight(12) 
	addon:SetWidth(100) 
	addon:SetPoint('BOTTOM', Minimap, 0, 20) 

	addon:SetFont(STANDARD_TEXT_FONT, 12, '') 
	addon:SetJustifyH'CENTER' 
	addon:SetJustifyV'CENTER' 
	addon:SetMaxLines(1) 
	addon:SetFading(true) 
	addon:SetFadeDuration(3) 
	addon:SetTimeVisible(5) 

	addon:RegisterEvent'MINIMAP_PING' 
	addon:SetScript('OnEvent', function(self, event, u) 
		local c = RAID_CLASS_COLORS[select(2,UnitClass(u))] 
		local name = UnitName(u) 
		addon:AddMessage(name, c.r, c.g, c.b) 
	end)
end

local function InitializeCallback()
	if not E.db.LvPlus.LvGeneral.General.LvMinimap.WhoClickMinimap then
		return
	end
	WCM:Initialize()
end

E:RegisterModule(WCM:GetName(), InitializeCallback)