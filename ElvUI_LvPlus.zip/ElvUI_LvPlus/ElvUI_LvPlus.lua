local E, L, V, P, G = unpack(ElvUI);
local LP = E:NewModule('LvPlus', 'AceEvent-3.0');
local LSM = LibStub("LibSharedMedia-3.0")
local EP = LibStub("LibElvUIPlugin-1.0")
local addonName, addonTable = ...

P["LvPlus"] = {
	["LvGeneral"]  = {
		["General"] = {		
			["LvAboutUI"] = {
				["RightButtonMenu"] = false,
				["DisableTalking"] = false,
				["AlreadyKnown"] = true,
				["ClassColors"] = true,
				["AutoDelete"] = true,
				["TalentProfiles"] = true,
				["TalentButtonElvUI"] = true,
				["AutoScreenShoot"] = {
					["EnableBtn"] = true,
				},
				["RaidMarkingKey"] = {
					["RaidMarkingButton1"] = 'alt',
					["RaidMarkingButton2"] = 'LeftButton',
				},
				["SetFocusKey"] = {
					["SetFocusButton1"] = 'shift',
					["SetFocusButton2"] = '1',
				},
				["SetPoi"] = {
					["EnableBtn"] = false,
					["PoiCombat"] = true,
					["PoiColor"] = { r = 0.5, g = 1, b = 1 },
					["PoiText"] = '╋',
					["PoiTextSize"] = 22,
				}
			},
			["LvNamePlates"] = {
				["NamePlatesCastBar"] = true,
			},
			["LvSetCVAR"] = {
				["AutoCompare"] = true,
				["CameraFactor"] = 2,
			},
			["LvAboutActionbar"] = {
				["RandomHearthstone"] = {
					["EnableBtn"] = true,
				},
			},
			["LvChatFrame"] = {
				["ChatBar"] = true,
				["ChatMSGLootGS"] = true,
			},
			["LvToolTips"] = {
			},
			["LvMinimap"] = {
				["WhoClickMinimap"] = true,
				["EnableBtn"] = true,
				["SquareMinimapDC"] = 'DOWN',
			},
			["LvCombatNotification"] = {
				["EnableBtn"] = true,
				["CombatNotiEntering"] = "进入战斗",
				["CombatNotiLeaving"] = "离开战斗",
			},
			["LvInviteGroup"] = {
				["EnableBtn"] = true,
				["Ainvkeyword"] = "123",
				["InviteRank"] = {},
			},
			["LvAnnouceSystem"] = {
				["EnableBtn"] = true,
				["RaidSpells"] = {
					["EnableBtn"] = true,
				},
				["ResAndThreatSpells"] = {
					["EnableBtn"] = true,
					["ResAndThreat"] = true,
					["ResThanks"] = true,
				},
				["Taunt"] = {
					["EnableBtn"] = true,
					["PlayerSmart"] = false,
					["IncludeMiss"] = true,
					["OtherTankSmart"] = false,
					["IncludeOtherTank"] = true,
					["PetSmart"] = false,
					["IncludePet"] = true,
				},
			},
			["LvBlizzardUI"] = {
				["LvStatusbar"] = true,
				["CastbarTime"] = false,
				["MinimapWheel"] = false,
			},
		},
		["QuestGroup"] = {
			["QuestAutomation"] = true,
			["AutoQuestBtn"] = false,
			["AutoChoices"] = false,
			["QuestButtonElvUI"] = true,
			["QuestAnnouncment"] = {
				["EnableBtn"] = true,
				["QuestAnnouncmentBtn"] = false,
				["QuestSolo"] = true,
				["QuestParty"] = true,
				["QuestRaid"] = true,
				["QuestInstance"] = true,
				["QuestNoDetail"] = false,
			},
			["QuestListEnhanced"] = {
				["EnableBtn"] = true,
				["TitleColor"] = true,
				["QuestList"] = {
					["TitleFont"] = E.db.general.font,
					["TitleFontSize"] = 14,
					["TitleFontFlag"] = "NONE",
					["InfoFont"] = E.db.general.font,
					["InfoFontSize"] = 14,
					["InfoFontFlag"] = "NONE",
				},
				["QuestLevel"] = {
					["TitleLevel"] = true,
					["DetailLevel"] = true,
					["IgnoreHighLevel"] = true,
				},
				["QuestFrame"] = {
					["FrameTitle"] = true,
					["LeftSide"] = false,
					["LeftSideSize"] = 18,
				},
			},
		}
	},
}
G["LvPlus"] = {
	["InfoFilter"] = {
		["EnableBtn"] = false,
		["Debug"] = false,
		["KeywordsMatchNumber"] = 1,
		["RtNum"] = 3,
		["FilterFriend"] = true,
		["NoWhisperSticky"] = false,
		["DisableProfanityFilter"] = true,
		["LevelFilter"] = 10,
		["RepeatTime"] = 45,
		["BlackWord"] = {},
		['BlackName'] = {},
	}
}

function LP:CreatLvPlus()
	local LvChangeLog = {
	"20190224",
	"调整了自动交接任务和任务通告按钮的位置",
	"恢复及优化 聊天信息过滤 - 垃圾间隔 功能，可屏蔽最近出现的表情广告",
	"20190223",
	"删除暴雪UI插件，个人习惯用的，恢复ElvUI控制任务栏",
	"删除玩具箱插件，准备换个变身玩具插件",
	"修复团队信息统计调用系统函数引起的错误",
	"20190218",
	"更新随机炉石玩具宏插件，现在可以正确的在战斗中使用所有炉石玩具了",
	"几个单体插件 用不着的直接可以删除or ESC 控制台禁用",
	"增加单体插件 玩具箱 小地图按钮控制 包括玩具分类、版本、出处，一键使用随机变身/自定义玩具 来自7.3的ToyBoxQ 复活及汉化",
	"--------------------------------------------------------------------------------",
	"聊天框战利品记录 玩家名字改职业色，可直接点击M语（聊天条按钮控制开关）",
	"若开启团队信息统计并已获取到该装等，则还会显示装等（增加开关控制是否显示装等）",
	"作用大概就是 小号毛装可以直接M吧- -",
	"---------------------------------------------------------------------------------",
	"修复团队信息统计战斗中使用会报错的问题",
	"20190217",
	"增加暴雪UI的选项(可使部分UI脱离ElvUI管控，回归原始UI，比如：任务栏/坐骑栏等)",
	"增加随机炉石玩具宏插件 来自NGA的混乱时雨RandomHearthstone",
	"增加单体插件 自动切换拾取专精功能",
	"单体插件 物品来源查询更新 鼠标提示装备来源 数据库来自爱不易",
	"单体插件 团员信息统计更新 小地图按钮控制 来自爱不易",
	"修复一些小bug",
	"移除坐骑信息，最新ElvUI版本自带了",
	"移除信息过滤中过滤重复的功能，因为ElvUI自带了",
	"增加天赋配置管理按钮ElvUI美化",
	"20190127",
	"因团队信息统计和物品来源鼠标提示较占内存和会造成卡顿，变更为了单体插件，方便开关",
	"增加天赋配置管理模块",
	"增加物品来源鼠标提示",
	"增加小地图显示点击者",
	"20190126",
	"增加团队信息统计模块，因团队人员较多时收集信息会造成卡顿，默认关闭",
	"任务栏自动交接/任务通报按钮ElvUI美化",
	"信息过滤开关现在能正确的开启和关闭所有相关功能",
	"修复信息过滤中无法删除关键词的错误",
	"20190123",
	"增加特殊技能通告模块，包括团本技能（法师：桌子/传送门；术士：门/糖；机器人/大餐/邮箱/部分玩具）/战复/误导/嘲讽",
	"20190122A",
	"修复禁用剧情对话框",
	"20190121",	"增加任务相关模块，包括自动交接/自动选择奖励/任务通报/任务列表字体相关设置/任务标题职业色染色/任务等级/任务框体标题相关设置/任务栏增加自动交接及通报按钮（关闭功能可隐藏）/部分COPY自WINDTOOL，修正了其放弃任务时的报错和任务等级-忽略最高等级开关无效等",
	"修复成就自动截图功能",
	"20190116",
	"修复右键增强黑名单功能",
	"升级了右键增强功能",
	"修复信息过滤中的一处判断错误，现在能正确的防刷屏了",
	"增加自动填入DELETE",
	"重写已学物品染色功能，现在能正确的开启和关闭了",
	"临时修复已学物品染色报错，但暂时无法按钮开关该功能，默认为开",
	"20190115",
	"增加成就自动截图",
	"增加好友列表职业染色",
	"增加已学物品染色",
	"增加了全局中文单位选择 增强功能-一般设置-界面相关中选择",
	"优化了部分功能使其在正确的时间调用",
	"20190114",
	"再次修复了小地图无法正确收集小图标的问题",
	"临时修复了便捷组队的一处错误",
	"增加聊天频道条包含频道切换条;TAB切换;属性通报/Boss一句话攻略;聊天表情;ROLL点;加入/离开大脚世界频道",
	"增加便捷组队，关键词自动组队，公会按级别组队功能",
	"增加禁用剧情对话框按钮",
	"20190113",
	"重写框架所有代码便于扩展",
	"右键增强增加英雄榜/添加黑名单功能",
	"修复收集小地图图标与Addonskin的冲突，现在能正确的收集小图标了",
	"增加信息过滤/防刷屏/屏蔽黑名单功能",
	"20190112",
	"添加自定义进出战斗提示",
	"添加右键菜单增强功能",
	"修复了姓名板施法条颜色问题",
	"20190111",
	"CVAR镜头最远距离",
	"屏幕中心指示器",
	"姓名板施法条显示当前目标",
	"CVAR装备自动对比",
	"快速团队标记",
	"快速设置焦点",
	"坐骑信息",
	"收集小地图图标",
	}

	local DeleteChoisedToggle = false;
	local DeleteAllToggle = false;

	E.Options.args.LvPlus = {
		order = 999,
		type = "group",
		name = L["LvPlus"],
		args = {
			ChangeLog = {
				order = -1,
				type = "group",
				guiInline = true,
				name = L["ChangeLog"],
				args = {},
			},
			LvGeneral = {
				order = 1,
				type = "group",
				name = L["LvGeneral"],
				childGroups = "tab",
				get = function(info) return E.db.LvPlus.LvGeneral[ info[#info] ] end,
				set = function(info, value) E.db.LvPlus.LvGeneral[ info[#info] ] = value end,
				args = {
					General = {
						order = 1,
						type = "group",
						name = L["General"],
						get = function(info) return E.db.LvPlus.LvGeneral.General[ info[#info] ] end,
						set = function(info, value) E.db.LvPlus.LvGeneral.General[ info[#info] ] = value end,
						args = {
							LvSetCVAR = {
								order = 1,
								type = "group",
								guiInline = false,
								name = L["LvSetCVAR"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] = value end,
								args = {
									AutoCompare = {
										order = 1,
										type = "toggle",
										name = L["AutoCompare"],
										desc = L["AutoCompare_DESC"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] = value;
											if not value then
												SetCVar("alwaysCompareItems", "0");
											else
												SetCVar("alwaysCompareItems", "1");
											end							
										end,
									},
									CameraFactor = {
										order = 2,
										type = "range",
										min = 1, max = 2.6, step = 0.1,
										name = L["CameraFactor"],
										set = function(info, value) SetCVar("cameraDistanceMaxZoomFactor", value);
											E.db.LvPlus.LvGeneral.General.LvSetCVAR[ info[#info] ] = value
										end,
									},
								}
							},
							LvAboutUI = {
								order = 2,
								type = "group",
								guiInline = false,
								name = L["LvAboutUI"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value end,
								args = {
									RightButtonMenu = {
										order = 1,
										type = "toggle",
										name = L["RightButtonMenu"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")		
										end,
									},
									DisableTalking = {
										order = 2,
										type = 'toggle',
										name = L["DisableTalking"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									AlreadyKnown = {
										order = 3,
										type = 'toggle',
										name = L["AlreadyKnown"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									ClassColors = {
										order = 4,
										type = 'toggle',
										name = L["ClassColors"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									TalentProfiles = {
										order = 5,
										type = "toggle",
										name = L["TalentProfiles"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									TalentButtonElvUI = {
										order = 6,
										type = "toggle",
										name = L["TalentButtonElvUI"],
										disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.TalentProfiles end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									AutoDelete = {
										order = 7,
										type = "toggle",
										name = L["AutoDelete"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									numberPrefixStyle = {
										order = 8,
										type = "select",
										name = L["Unit Prefix Style"],
										desc = L["The unit prefixes you want to use when values are shortened in ElvUI. This is mostly used on UnitFrames."],
										get = function(info) return E.db.general.numberPrefixStyle end,
										set = function(info, value) E.db.general.numberPrefixStyle = value; E:StaticPopup_Show("CONFIG_RL") end,
										values = {
											["METRIC"] = "Metric (k, M, G)",
											["ENGLISH"] = "English (K, M, B)",
											["CHINESE"] = "Chinese (W, Y)",
											["KOREAN"] = "Korean (천, 만, 억)",
											["GERMAN"] = "German (Tsd, Mio, Mrd)",
											["LVCHINESE"] = "中文 (万, 亿)",
										},
									},
									AutoScreenShoot = {
										order = 9,
										type = "group",
										guiInline = true,
										name = L["AutoScreenShoot"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")
												end,
											},
											ScreenFormat = {
												order = 2,
												name = L["ScreenFormat"],
												type = "select",
												values = {
													["jpeg"] = "JPG",
													["tga"] = "TGA",
												},
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn end,
												get = function(info) return GetCVar("screenshotFormat") end,
												set = function(info, value) SetCVar("screenshotFormat", value) end,
											},
											ScreenQuality = {
												order = 3,
												name = L["ScreenQuality"],
												type = "range",
												min = 3, max = 10, step = 1,
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.AutoScreenShoot.EnableBtn end,
												get = function(info) return tonumber(GetCVar("screenshotQuality")) end,
												set = function(info, value) SetCVar("screenshotQuality", tostring(value)) end,
											},
										},
									},
									RaidMarkingKey = {
										order = 10,
										type = "group",
										guiInline = true,
										name = L["RaidMarkingKey"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey[ info[#info] ] = value end,
										args = {
											RaidMarkingButton1 = {
												order = 1,
												type = "select",
												name = L["RaidMarkingButton"]..'1',
												values = {
													['ctrl'] = "Ctrl",
													['alt'] = "Alt",
													['shift'] = "Shift",
													['none'] = NONE,
												}
											},
											RaidMarkingButton2 = {
												order = 2,
												type = "select",
												name = L["RaidMarkingButton"]..'2',
												disabled = function() return E.db.LvPlus.LvGeneral.General.LvAboutUI.RaidMarkingKey.RaidMarkingButton1 == 'none' end,
												values = {
													["LeftButton"] = L["MouseButton1"],
													["RightButton"] = L["MouseButton2"],
												}
											}
										}
									},
									SetFocusKey = {
										order = 11,
										type = "group",
										guiInline = true,
										name = L["SetFocusKey"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
										args = {
											SetFocusButton1 = {
												order = 1,
												type = "select",
												name = L["SetFocusButton"]..'1',
												values = {
													['shift'] = 'Shift',
													['ctrl'] = 'Ctrl',
													['alt'] = 'Alt',
													['none'] = NONE,
												}
											},
											SetFocusButton2 = {
												order = 2,
												type = "select",
												name = L["SetFocusButton"]..'2',
												values = {
													['1'] = L["MouseButton1"],
													['2'] = L["MouseButton2"],
													['3'] = L["MouseButton3"],
													['4'] = L["MouseButton4"],
												},
												disabled = function() return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetFocusKey.SetFocusButton1 == 'none' end,
											}
										}
									},
									SetPoi = {
										order = 12,
										type = "group",
										guiInline = true,
										name = L["SetPoi"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												width = "full",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiCombat = {
												order = 2,
												type = 'toggle',
												name = L["PoiCombat"],
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiColor = {
												order = 3,
												type = "color",
												name = L["PoiColor"],
												hasAlpha = false,
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												get = function(info)
													local t = E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													local d = P.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													return t.r, t.g, t.b, t.a, d.r, d.g, d.b
												end,
												set = function(info, r, g, b)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.PoiColor = {}
													local t = E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ]
													t.r, t.g, t.b = r, g, b
													E:GetModule('SetPoi'):SetPoi();
												end,	
											},
											PoiText = {
												order = 4,
												type = 'select',
												name = L["PoiText"],
												values = {
													['┼'] = '┼',
													['╋'] = '╋',
													['◆'] = '◆',
													['■'] = '■',
													['●'] = '●',
													['※'] = '※',
													['↓'] = '↓',
												},
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
											PoiTextSize = {
												order = 5,
												type = 'range',
												name = L["PoiTextSize"],
												min = 10, max = 50, step = 1,
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi.EnableBtn end,
												set = function(info, value)
													E.db.LvPlus.LvGeneral.General.LvAboutUI.SetPoi[ info[#info] ] = value;
													E:GetModule('SetPoi'):SetPoi();
												end,
											},
										}
									}
								}
							},
							LvAboutLoot = {
								order = 3,
								type = "group",
								guiInline = false,
								name = L["LvAboutLoot"],
								args = {
									LootSpecMangager = {
										order = 1,
										type = 'execute',
										name = L["LootSpecMangager"],
										func = function() LTSM_GUI.frame:Show();E:ToggleConfig(); end,
									}
								},
							},
							LvAboutActionbar = {
								order = 4,
								type = "group",
								guiInline = false,
								name = L["LvAboutActionbar"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutActionbar[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutActionbar[ info[#info] ] = value end,
								args = {
									RandomHearthstone = {
										order = 1,
										type = "group",
										guiInline = true,
										name = L["RandomHearthstone"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAboutActionbar.RandomHearthstone[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutActionbar.RandomHearthstone[ info[#info] ] = value end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
												set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAboutActionbar.RandomHearthstone[ info[#info] ] = value;
													E:StaticPopup_Show("CONFIG_RL")	
												end,
											},
											CreatRHS = {
												order = 2,
												type = 'execute',
												name = L["CreatRHS"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAboutActionbar.RandomHearthstone.EnableBtn end,
												func = function() E:GetModule('LvPlusRandomHearthStone'):Macro_Refresh(); E:ToggleConfig(); end,
											},
										},
									}
								}
							},
							LvNamePlates = {
								order = 5,
								type = "group",
								guiInline = false,
								name = L["LvNamePlates"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvNamePlates[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvNamePlates[ info[#info] ] = value end,
								args = {
									NamePlatesCastBar ={
										order = 1,
										type = "toggle",
										name = L["NamePlatesCastBar"],
										desc = L["NamePlatesCastBar_DESC"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvNamePlates[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
											
									}
								}
							},
							LvChatFrame = {
								order = 6,
								type = "group",
								guiInline = false,
								name = L["LvChatFrame"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvChatFrame[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvChatFrame[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									ChatBar = {
										order = 1,
										type = "toggle",
										name = L["ChatBar"],
										desc = L["ChatBar_DESC"],
									},
									ChatMSGLootGS = {
										order = 2,
										type = "toggle",
										name = L["ChatMSGLootGS"],
										desc = L["ChatMSGLootGS_DESC"],
										disabled = function() return not E.db.LvPlus.LvGeneral.General.LvChatFrame.ChatBar end,
									},
								}
							},
							LvToolTips = {
								order = 7,
								type = "group",
								guiInline = false,
								name = L["LvToolTips"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvToolTips[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvToolTips[ info[#info] ] = value end,
								args = {
								}
							},
							LvMinimap = {
								order = 8,
								type = "group",
								guiInline = false,
								name = L["LvMinimap"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")	
								end,
								args = {
									WhoClickMinimap = {
										order = 1,
										type = "toggle",
										name = L["WhoClickMinimap"],
									},
									SquareMinimap = {
										order = 2,
										type = "group",
										guiInline = true,
										name = L["SquareMinimap"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvMinimap[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = L["EnableBtn"],
											},
											SquareMinimapDC = {
												order = 20,
												type = 'select',
												name = L["SquareMinimapDC"],
												values = {
													['UP'] = L['UP'],
													['DOWN'] = L['DOWN'],
													['LEFT'] = L['LEFT'],
													['RIGHT'] = L['RIGHT'],
												},
												disabled = function() return not E.db.LvPlus.LvGeneral.General.LvMinimap.EnableBtn end,
											}
										}
									}
								}
							},
							LvCombatNotification = {
								order = 9,
								type = "group",
								guiInline = false,
								name = L["LvCombatNotification"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										width = "full",
										name = L["EnableBtn"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")	
										end,
									},
									CombatNotiEntering = {
										order = 2,
										type = "input",
										name = L["CombatNotiEntering"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value end,
									},
									CombatNotiLeaving = {
										order = 3,
										type = "input",
										name = L["CombatNotiLeaving"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvCombatNotification.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvCombatNotification[ info[#info] ] = value end,
									}
								}
							},
							LvInviteGroup = {
								order = 10,
								type = 'group',
								name = L["LvInviteGroup"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value end,						
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
									},
									Ainvkeyword = {
										order = 2,
										type = "input",
										name = L["Ainvkeyword"],
										disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvInviteGroup.EnableBtn end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvInviteGroup[ info[#info] ] = value end,					
									},
									Spacer = {
										order = 3,
										type = 'description',
										name = '',
										desc = '',
									},
									InviteRank = {
										order = 4,
										type = 'multiselect',
										name = L["InviteRank"],
										disabled = function() return not IsInGuild() end,
										values = E:GetModule('InviteGroup'):GetGuildRanks(),
										get = function(info, k) return E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[k] end,
										set = function(info, k, v) E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank[k] = v; end,
									},						
									RefreshRank = {
										order = 5,
										type = 'execute',
										name = L["RefreshRank"],
										func = function()
											E.Options.args.LvPlus.args.LvGeneral.args.General.args.LvInviteGroup.args.InviteRank.values = E:GetModule('InviteGroup'):GetGuildRanks();
										end,
									},
									StartInvite = {
										order = 6,
										type = 'execute',
										name = L['StartInvite'],
										disabled = function() return not IsInGuild() end,
										func = function() 
											for k, v in pairs(E.db.LvPlus.LvGeneral.General.LvInviteGroup.InviteRank) do
												if v then
													SendChatMessage(format(L['Invite guild ranks is %s member, in 10 sec.'], GuildControlGetRankName(k)), 'GUILD')
												end
											end
											E:ScheduleTimer(E:GetModule('InviteGroup').InviteRanks, 10);
										end,
									},
								},
							},
							LvAnnouceSystem = {
								order = 11,
								type = 'group',
								name = L["LvAnnouceSystem"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										width = "full",
										name = ENABLE..'/'..DISABLE..L["LvAnnouceSystem"],
									},
									RaidSpells = {
										order = 2,
										type = 'group',
										guiInline = true,
										name = L["RaidSpells"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.RaidSpells[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.RaidSpells[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 1,
												type = "toggle",
												name = ENABLE..'/'..DISABLE..L["RaidSpells"],
												desc = L["RaidSpells_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
										},
									},
									ResAndThreatSpells = {
										order = 3,
										type = 'group',
										guiInline = true,
										name = L["ResAndThreatSpells"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 0,
												type = "toggle",
												width = "full",
												name = ENABLE..'/'..DISABLE..L["ResAndThreatSpells"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											ResAndThreat = {
												order = 1,
												type = "toggle",
												name = L["ResAndThreat"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											ResThanks = {
												order = 2,
												type = "toggle",
												name = L["ResThanks"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.ResAndThreatSpells.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
										},										
									},
									Taunt = {
										order = 5,
										type = 'group',
										guiInline = true,
										name = L["Taunt"],
										get = function(info) return E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL")
										end,
										args = {
											EnableBtn = {
												order = 0,
												type = "toggle",
												width = "full",
												name = ENABLE..'/'..DISABLE..L["Taunt"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											PlayerSmart = {
												order = 1,
												type = "toggle",
												name = L["PlayerSmart"],
												desc = L["Taunt_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											IncludeMiss ={
												order = 2,
												type = "toggle",
												name = L["IncludeMiss"],
												desc = L["Include_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											OtherTankSmart = {
												order = 3,
												type = "toggle",
												name = L["OtherTankSmart"],
												desc = L["Taunt_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											IncludeOtherTank = {
												order = 4,
												type = "toggle",
												name = L["IncludeOtherTank"],
												desc = L["Include_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},
											PetSmart = {
												order = 5,
												type = "toggle",
												name = L["PetSmart"],
												desc = L["Taunt_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},	
											IncludePet = {
												order = 6,
												type = "toggle",
												name = L["IncludePet"],
												desc = L["Include_DESC"],
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.Taunt.EnableBtn end,
												disabled = function(info) return not E.db.LvPlus.LvGeneral.General.LvAnnouceSystem.EnableBtn end,
											},			
										},
									},
								},
							},
							LvBlizzardUI = {
								order = 12,
								type = 'group',
								name = L["LvBlizzardUI"],
								get = function(info) return E.db.LvPlus.LvGeneral.General.LvBlizzardUI[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.General.LvBlizzardUI[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL")
								end,
								args = {
									LvStatusbar = {
										order = 1,
										type = "toggle",
										name = L["LvStatusbar"],
									},
									CastbarTime = {
										order = 2,
										type = "toggle",
										name = L["CastbarTime"],
									},
									MinimapWheel = {
										order = 3,
										type = "toggle",
										name = L["MinimapWheel"],
									},
								}
							},
						}
					},
					QuestGroup = {
						order = 2,
						type = "group",
						name = L["QuestGroup"],
						get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup[ info[#info] ] end,
						set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup[ info[#info] ] = value end,	
						args = {
							QuestAutomation = {
								order = 1,
								type = "toggle",
								name = ENABLE..'/'..DISABLE..L["QuestAutomation"],
								desc = L["QuestAutomation_DESC"],
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup[ info[#info] ] = value
									E:StaticPopup_Show("CONFIG_RL");
								end,
							},
							AutoQuestBtn = {
								order = 2,
								type = "toggle",
								name = L["AutoQuestBtn"],
								desc = L["AutoQuestBtn_DESC"],
								disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation end,
							},
							AutoChoices = {
								order = 3,
								type = "toggle",
								name = L["AutoChoices"],
								disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation end,
							},
							QuestButtonElvUI = {
								order = 4,
								type = "toggle",
								name = L["QuestButtonElvUI"],
								disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAutomation end,
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup[ info[#info] ] = value
									E:StaticPopup_Show("CONFIG_RL");
								end,
							},
							QuestAnnouncment = {
								order = 5,
								type = "group",
								name = L["QuestAnnouncment"],
								guiInline = true,
								get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment[ info[#info] ] = value end,	
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,	
									},
									QuestAnnouncmentBtn = {
										order = 2,
										type = "toggle",
										name = L["QuestAnnouncmentBtn"],
										desc = L["QuestAnnouncmentBtn_DESC"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},									
									QuestSolo = {
										order = 3,
										type = "toggle",
										name = L["QuestSolo"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestParty = {
										order = 4,
										type = "toggle",
										name = L["QuestParty"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestRaid = {
										order = 5,
										type = "toggle",
										name = L["QuestRaid"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestInstance = {
										order = 6,
										type = "toggle",
										name = L["QuestInstance"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
									QuestNoDetail = {
										order = 7,
										type = "toggle",
										name = L["QuestNoDetail"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestAnnouncment.EnableBtn end,
									},
								},
							},
							QuestListEnhanced = {
								order = 6,
								type = "group",
								name = L["QuestListEnhanced"],
								guiInline = true,
								get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced[ info[#info] ] end,
								set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced[ info[#info] ] = value;
									E:StaticPopup_Show("CONFIG_RL");
								end,
								args = {
									EnableBtn = {
										order = 1,
										type = "toggle",
										name = L["EnableBtn"],
									},
									TitleColor = {
										order = 2,
										type = "toggle",
										name = L["TitleColor"],
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
									},
									QuestList = {
										order = 3,
										type = "group",
										name = L["QuestList"],
										guiInline = true,
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestList[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,
										args = {
											TitleFont = {
												order = 1,
												type = 'select',
												dialogControl = 'LSM30_Font',
												values = LSM:HashTable('font'),
												name = L["TitleFont"],
											},
											TitleFontSize = {
												order = 2,
												type = 'range',
												min = 6, max = 22, step = 1,
												name = L["TitleFontSize"],
											},
											TitleFontFlag = {
												order = 3,
												type = 'select',
												values = {
													["NONE"] = L["NONE"],
													["OUTLINE"] = "OUTLINE",
													["THICKOUTLINE"] = "THICKOUTLINE",
													["MONOCHROMEOUTLINE"] = "MONOCROMEOUTLINE",
												},
												name = L["TitleFontFlag"],
											},
											InfoFont = {
												order = 4,
												type = 'select',
												dialogControl = 'LSM30_Font',
												values = LSM:HashTable('font'),
												name = L["InfoFont"],
											},
											InfoFontSize = {
												order = 5,
												type = 'range',
												min = 6, max = 22, step = 1,
												name = L["InfoFontSize"],
											},
											InfoFontFlag = {
												order = 6,
												type = 'select',
												values = {
													["NONE"] = L["NONE"],
													["OUTLINE"] = "OUTLINE",
													["THICKOUTLINE"] = "THICKOUTLINE",
													["MONOCHROMEOUTLINE"] = "MONOCROMEOUTLINE",
												},
												name = L["InfoFontFlag"],
											},
										},
									},
									QuestLevel = {
										order = 4,
										type = "group",
										name = L["QuestLevel"],
										guiInline = true,
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestLevel[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,
										args = {
											TitleLevel = {
												order = 1,
												type = "toggle",
												name = L["TitleLevel"],
											},
											DetailLevel = {
												order = 2,
												type = "toggle",
												name = L["DetailLevel"],
											},
											IgnoreHighLevel = {
												order = 3,
												type = "toggle",
												name = L["IgnoreHighLevel"],
											},
										},
									},
									QuestFrame = {
										order = 5,
										type = "group",
										name = L["QuestFrame"],
										guiInline = true,
										disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.EnableBtn end,
										get = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame[ info[#info] ] end,
										set = function(info, value) E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame[ info[#info] ] = value;
											E:StaticPopup_Show("CONFIG_RL");
										end,
										args = {
											FrameTitle = {
												order = 1,
												type = "toggle",
												name = ENABLE..'/'..DISABLE..L["FrameTitle"],
											},											
											LeftSide = {
												order = 2,
												type = "toggle",
												name  = L["LeftSide"],
												disabled = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.FrameTitle end,
											},
											LeftSideSize = {
												order = 3,
												type  = 'range',
												min	  = 10, max	  = 30, step  = 1,
												name  = L["LeftSideSize"],
												disabled = function(info) return E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.FrameTitle end,
												disabled = function() return not E.db.LvPlus.LvGeneral.QuestGroup.QuestListEnhanced.QuestFrame.LeftSide end,
											},
										},
									},
								},
							},
						},
					},
				}
			},
			InfoFilter = {
				order = 2,
				type = "group",
				name = L["InfoFilter"],
				get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
				set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value end,
				args = {
					EnableBtn = {
						order = 1,
						type = "toggle",
						name = L["EnableBtn"],
						set = function(info, value) E.global.LvPlus.InfoFilter.EnableBtn = value;
							E:StaticPopup_Show("CONFIG_RL");
						end,
					},
					InfoFilterGeneral = {
						order = 2,
						type = "group",
						name = L["InfoFilterGeneral"],
						guiInline = true,
						disabled = function() return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value end,
						args = {
							Debug = {
								order = 1,
								type = "toggle",
								name = L["Debug"],
								desc = L["Debug_DESC"],
							},
							KeywordsMatchNumber = {
								order = 2,
								type = "range",
								name = L["KeywordsMatchNumber"],
								min = 1, max = 10, step = 1,
							},
							RtNum = {
								order = 3,
								type = 'range',
								min = 0, max = 8, step = 1,
								name = L["RtNum"],
								desc = L["RtNum_DESC"],
							},
							FilterFriend = {
								order = 4,
								type = "toggle",
								name = L["FilterFriend"],
								desc = L["FilterFriend_DESC"],
							},
							NoWhisperSticky = {
								order = 5,
								type = "toggle",
								name = L["NoWhisperSticky"],
								set = function(info, value)
									E.global.LvPlus.InfoFilter[ info[#info] ] = value;
									if value then
										ChatTypeInfo.WHISPER.sticky = 0
										ChatTypeInfo.BN_WHISPER.sticky = 0
									else
										ChatTypeInfo.WHISPER.sticky = 1
										ChatTypeInfo.BN_WHISPER.sticky = 1
									end
									E:StaticPopup_Show("CONFIG_RL");
								end,
							},
							DisableProfanityFilter = {
								order = 6,
								type = "toggle",
								name = L["DisableProfanityFilter"],
								set = function(info, value)
									E.global.LvPlus.InfoFilter[ info[#info] ] = value;
									if value then
										SetCVar("profanityFilter", "0");
									else
										SetCVar("profanityFilter", "1");
									end
								end,
							},
							LevelFilter = {
								order = 7,
								type = 'range',
								min = 0, max = MAX_PLAYER_LEVEL-1, step = 1,
								name = L["LevelFilter"],
								desc = L["LevelFilter_DESC"],
								set = function(info, value)
									if E.global.LvPlus.InfoFilter[ info[#info] ] < 1 and value >= 1 then
										E.global.LvPlus.InfoFilter[ info[#info] ] = value;
										E:StaticPopup_Show("CONFIG_RL");
									end
									if E.global.LvPlus.InfoFilter[ info[#info] ] >= 1 and value < 1 then
										E.global.LvPlus.InfoFilter[ info[#info] ] = value;
										E:StaticPopup_Show("CONFIG_RL");
									end
									E.global.LvPlus.InfoFilter[ info[#info] ] = value;
								end,
							},
							RepeatTime = {
								order = 8,
								type = 'range',
								min = 0, max = 120, step = 1,
								name = L["RepeatTime"],
								desc = L["RepeatTime_DESC"],
							},
						},
					},
					BlackWord = {
						order = 3,
						type = "group",
						name = L["BlackWord"],
						guiInline = true,
						disabled = function() return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value; end,
						args = {
							BlackWordIntro = {
								order = 1,
								type = "description",
								name = L["BlackWordIntro"],
							},
							NewWord = {
								order = 2,
								type = "input",
								name = L["NewWord"],
								get = function(info) return "" end,
								set = function(info, value)
									E.global.LvPlus.InfoFilter.BlackWord[value] = true
									E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[value] = value;
								end,
							},
							DeleteWord = {
								order = 3,
								type = "input",
								name = L["DeleteWord"],
								get = function(info) return "" end,
								set = function(info, value)
									if E.global.LvPlus.InfoFilter.BlackWord[value] ~= nil then
										E.global.LvPlus.InfoFilter.BlackWord[value] = nil
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[value] = nil
									end
								end,
							},
							BlackWordSpacer = {
								order = 4,
								type = 'description',
								name = '',
							},				
							DeleteChoisedKeywords= {
								order = 5,
								type = "execute",
								name = L["DeleteChoisedKeywords"],
								func = function()
									if not DeleteChoisedToggle then
										DeleteChoisedToggle = true;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywordsYES"];
										C_Timer.After(5, function()
											DeleteChoisedToggle = false;
											E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywords"];
										end)
									else						
										for k, v in pairs(E.global.LvPlus.InfoFilter.BlackWord) do
											if v then
												E.global.LvPlus.InfoFilter.BlackWord[k] = nil;
											end
										end
										DeleteChoisedToggle = false;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteChoisedKeywords.name = L["DeleteChoisedKeywords"];
										wipe(E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values);
										for k, v in pairs(E.global.LvPlus.InfoFilter.BlackWord) do
											E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[k] = k
										end
									end
								end,
							},
							DeleteAllKeywords = {
								order = 6,
								type = "execute",
								name = L["DeleteAllKeywords"],
								func = function()
									if not DeleteAllToggle then
										DeleteAllToggle = true;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywordsYES"];
										C_Timer.After(5, function()
											DeleteAllToggle = false;
											E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywords"];
										end)							
									else						
										wipe(E.global.LvPlus.InfoFilter.BlackWord);
										wipe(E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values);
										DeleteAllToggle = false;
										E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.DeleteAllKeywords.name = L["DeleteAllKeywords"];
									end
								end,
							},				
							BlackWordList = {
								order = 10,
								type = "multiselect",
								name = L["BlackWordList"],
								get = function(info, k) return E.global.LvPlus.InfoFilter.BlackWord[k] end,
								set = function(info, k, v)
									E.global.LvPlus.InfoFilter.BlackWord[k] = v
								end,
								values = {
								}
							}
						}
					},
					BlackName = {
						order = 4,
						type = "group",
						name = L["BlackName"],
						guiInline = true,
						disabled = function() return not E.global.LvPlus.InfoFilter.EnableBtn end,
						get = function(info) return E.global.LvPlus.InfoFilter[ info[#info] ] end,
						set = function(info, value) E.global.LvPlus.InfoFilter[ info[#info] ] = value; end,
						args = {
							BlackNameIntro = {
								order = 0,
								type = "description",
								name = L["BlackNameIntro"],
							},
							NewName = {
								order = 1,
								type = "input",
								name = L["NewName"],
								get = function(info) return "" end,
								set = function(info, value)
									E.global.LvPlus.InfoFilter.BlackName[value] = value
								end,
							},
							DeleteName = {
								order = 2,
								type = "input",
								name = L["DeleteName"],
								get = function(info) return "" end,
								set = function(info, value)
									if E.global.LvPlus.InfoFilter.BlackName[value] ~= nil then
										E.global.LvPlus.InfoFilter.BlackName[value] = nil
									end
								end,
							},
							RestoreDefaults = {
								order = 3,
								type = "execute",
								name = L["RestoreDefaults"],
								func = function() wipe(E.global.LvPlus.InfoFilter.BlackName);
									E:StaticPopup_Show("CONFIG_RL")
								end,
							},
							BlackNameList = {
								order = 4,
								type = "multiselect",
								name = L["BlackNameList"],
								get = function(info, k) return E.global.LvPlus.InfoFilter.BlackName[k] end,
								set = function(info, k, v)
									E.global.LvPlus.InfoFilter.BlackName[k] = v
								end,
								values = {
								},
							}
						}
					}
				}
			}
		}
	}
	
	for i = 1, #LvChangeLog do
		local Lvlog = LvChangeLog[i]
		E.Options.args.LvPlus.args.ChangeLog.args[Lvlog] = {
			order = i,
			type  = "description",
			name  = LvChangeLog[i],
		}
	end
	
	for k, v in pairs(E.global.LvPlus.InfoFilter.BlackWord) do
		E.Options.args.LvPlus.args.InfoFilter.args.BlackWord.args.BlackWordList.values[k] = k
	end
	
	for k, v in pairs(E.global.LvPlus.InfoFilter.BlackName) do
		E.Options.args.LvPlus.args.InfoFilter.args.BlackName.args.BlackNameList.values[k] = k
	end
end

function LP:Initialize()
	EP:RegisterPlugin(addonName, LP.CreatLvPlus)
end

local function InitializeCallback()
	LP:Initialize()
end

E:RegisterModule(LP:GetName(), InitializeCallback)