
BigWigs:AddColors("High Priest Venoxis", {
	[96466] = "orange",
	[96477] = {"blue","orange"},
	[96509] = "red",
	[96653] = "green",
	[96842] = "red",
})

BigWigs:AddColors("Bloodlord Mandokir", {
	[96684] = {"blue","yellow"},
	[96724] = "yellow",
	[96740] = "red",
	[96776] = "yellow",
	[96800] = "red",
})

BigWigs:AddColors("High Priestess Kilnara", {
	[-2702] = "red",
	[96423] = {"blue","yellow"},
	[96435] = "red",
	[96457] = "red",
	[96592] = {"blue","yellow"},
	["stages"] = "yellow",
})

BigWigs:AddColors("Zanzil", {
	[96316] = {"blue","red","yellow"},
	[96338] = "yellow",
	[96914] = "yellow",
})

BigWigs:AddColors("Jin'do the Godbreaker", {
	[-2910] = {"blue","red"},
	[97170] = "red",
	[97172] = {"red","yellow"},
	["stages"] = "red",
})
