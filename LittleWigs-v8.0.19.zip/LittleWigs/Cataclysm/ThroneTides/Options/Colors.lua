
BigWigs:AddColors("Lady Naz'jar", {
	[75683] = "yellow",
})

BigWigs:AddColors("Commander Ulthok", {
	[76026] = {"blue","orange"},
	[76047] = "red",
	[76094] = {"blue","yellow"},
	[76100] = "yellow",
})

BigWigs:AddColors("Mindbender Ghur'sha", {
	[76207] = {"blue","red"},
	[76230] = "blue",
	[76307] = "orange",
	["stages"] = "green",
})

BigWigs:AddColors("Ozumat", {
	["stages"] = {"green","yellow"},
})
