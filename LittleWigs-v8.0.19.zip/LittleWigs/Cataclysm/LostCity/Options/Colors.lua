
BigWigs:AddColors("General Husam", {
	[83113] = {"blue","yellow"},
	[83445] = "red",
	[91263] = "orange",
})

BigWigs:AddColors("Lockmaw", {
	[81630] = {"blue","yellow"},
	[81690] = {"blue","red"},
	[84784] = "orange",
})

BigWigs:AddColors("High Prophet Barim", {
	[82506] = "red",
	[82622] = "blue",
	[88814] = {"blue","yellow"},
})

BigWigs:AddColors("Siamat", {
	["servant"] = "red",
	["stages"] = {"cyan","green"},
})
