local L = BigWigs:NewBossLocale("Siamat", "zhTW")
if not L then return end
if L then
	L.servant = "召喚希亞梅特的僕從"
	L.servant_desc = "當希亞梅特的僕從被召喚時發出警報。"
end
