
BigWigs:AddColors("Akil'zon", {
	[43648] = {"blue","red"},
	[97318] = {"blue","red"},
})

BigWigs:AddColors("Nalorakk", {
	[42398] = {"blue","yellow"},
	[42402] = {"blue","orange"},
	["stages"] = "red",
})

BigWigs:AddColors("Jan'alai", {
	[-2625] = "yellow",
	[-2622] = "orange",
	[97497] = {"blue","red"},
})

BigWigs:AddColors("Halazzi", {
	[43139] = "red",
	[43302] = "orange",
	[43303] = {"blue","yellow"},
	[97499] = "orange",
	["stages"] = {"green","yellow"},
})

BigWigs:AddColors("Hex Lord Malacrass", {
	[43383] = "red",
	[43421] = {"blue","orange"},
	[43431] = "orange",
	[43451] = "orange",
	[43501] = {"blue","yellow"},
	[43548] = "orange",
})

BigWigs:AddColors("Daakara", {
	[17207] = "orange",
	[43093] = {"blue","yellow"},
	[43095] = "yellow",
	[43150] = {"blue","red"},
	["stages"] = "red",
})
