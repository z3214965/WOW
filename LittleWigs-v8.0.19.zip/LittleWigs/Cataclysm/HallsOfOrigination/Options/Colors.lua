
BigWigs:AddColors("Temple Guardian Anhuur", {
	[74938] = {"red","yellow"},
	[75592] = {"blue","yellow"},
})

BigWigs:AddColors("Anraphet", {
	[75603] = {"blue","orange"},
	[75609] = "blue",
	[75622] = "red",
	[76184] = {"blue","yellow"},
})

BigWigs:AddColors("Isiset", {
	[-2556] = {"cyan","green"},
	[74045] = "blue",
	[74135] = "blue",
	[74137] = "red",
	[74373] = "yellow",
})

BigWigs:AddColors("Ammunae", {
	[75790] = "yellow",
	[76043] = {"blue","orange","red"},
	[80968] = {"blue","yellow"},
})

BigWigs:AddColors("Rajh", {
	[-2863] = "blue",
	[-2862] = "orange",
	[-2861] = "yellow",
	[76355] = {"cyan","green"},
})
