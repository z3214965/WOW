local L = BigWigs:NewBossLocale("Well Of Eternity Trash", "zhTW")
if not L then return end
if L then
	L.custom_on_autotalk = "自动对话"
	--L.custom_on_autotalk_desc = "Instantly select Illidan's gossip option."
end
