
BigWigs:AddSounds("Peroth'arn", {
	[105442] = "Long",
	[105493] = "Long",
	[105544] = "Alert",
	["eyes"] = "Info",
})

BigWigs:AddSounds("Queen Azshara", {
	[-3969] = "Long",
	[-3968] = "Alert",
})

BigWigs:AddSounds("Mannoroth and Varo'then", {
	[-4287] = "Info",
})
