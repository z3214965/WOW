
BigWigs:AddColors("Echo of Baine", {
	[-4141] = {"green","red"},
	[-4140] = {"blue","red"},
})
