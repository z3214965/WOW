
BigWigs:AddColors("General Umbriss", {
	[74634] = "orange",
	[74670] = {"blue","red"},
	[74846] = {"blue","yellow"},
	[74853] = "yellow",
})

BigWigs:AddColors("Forgemaster Throngus", {
	[74908] = "red",
	[74976] = "blue",
	[74981] = "red",
	[74987] = "blue",
	[75007] = "red",
	[75056] = {"blue","orange"},
})

BigWigs:AddColors("Drahga Shadowburner", {
	[75218] = "yellow",
	[90950] = "red",
})

BigWigs:AddColors("Erudax", {
	[75664] = "orange",
	[75755] = "red",
	[75763] = "red",
	["summon"] = "yellow",
})
