
BigWigs:AddColors("Grand Vizier Ertan", {
	[86340] = "yellow",
})

BigWigs:AddColors("Altairus", {
	[88282] = "blue",
	[88286] = "blue",
	[88308] = {"blue","orange"},
})

BigWigs:AddColors("Asaad", {
	[86930] = "red",
	[87618] = "yellow",
})
