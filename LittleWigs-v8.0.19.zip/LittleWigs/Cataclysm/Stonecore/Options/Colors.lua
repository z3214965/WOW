
BigWigs:AddColors("Corborus", {
	[86881] = "blue",
	["burrow"] = {"red","yellow"},
})

BigWigs:AddColors("Slabhide", {
	[80801] = "blue",
	[92265] = "red",
})

BigWigs:AddColors("Ozruk", {
	[78903] = "orange",
	[78939] = "red",
	[80467] = "yellow",
	[92426] = "red",
})

BigWigs:AddColors("High Priestess Azil", {
	[79050] = "red",
	[79345] = {"blue","yellow"},
})
