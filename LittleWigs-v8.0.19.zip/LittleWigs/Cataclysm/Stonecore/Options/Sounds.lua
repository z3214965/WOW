
BigWigs:AddSounds("Corborus", {
	[86881] = "Alarm",
	["burrow"] = "Info",
})

BigWigs:AddSounds("Slabhide", {
	[80801] = "Alarm",
	[92265] = "Alert",
})

BigWigs:AddSounds("Ozruk", {
	[78903] = "Alarm",
	[78939] = "Alarm",
	[92426] = "Alert",
})

BigWigs:AddSounds("High Priestess Azil", {
	[79050] = "Alert",
})
