
BigWigs:AddColors("Heartsbane Triad", {
	[260703] = {"blue","orange"},
	[260741] = "orange",
	[260773] = "red",
	[260805] = {"blue","cyan"},
	[260926] = {"blue","orange"},
})

BigWigs:AddColors("Soulbound Goliath", {
	[260508] = "yellow",
	[260512] = {"blue","yellow"},
	[260541] = {"blue","cyan"},
	[260569] = "blue",
	[267907] = {"blue","orange"},
})

BigWigs:AddColors("Raal the Gluttonous", {
	[264694] = {"blue","orange"},
	[264734] = "orange",
	[264923] = "red",
	[264931] = "yellow",
	[265002] = "orange",
})

BigWigs:AddColors("Lord and Lady Waycrest", {
	[261438] = "yellow",
	[261440] = {"blue","red"},
	[261447] = {"blue","cyan"},
	[268306] = "orange",
})

BigWigs:AddColors("Gorak Tul", {
	[266181] = "red",
	[266198] = "green",
	[266225] = "orange",
	[266266] = "yellow",
})

BigWigs:AddColors("Waycrest Manor Trash", {
	[263905] = "yellow",
	[263943] = {"blue","orange"},
	[263959] = "red",
	[263961] = "yellow",
	[264038] = "orange",
	[264050] = "yellow",
	[264105] = {"blue","orange","yellow"},
	[264150] = "red",
	[264390] = "red",
	[264396] = "yellow",
	[264456] = "yellow",
	[264520] = "yellow",
	[264525] = "red",
	[264556] = "blue",
	[265346] = "orange",
	[265352] = "red",
	[265368] = "cyan",
	[265407] = "orange",
	[265741] = "yellow",
	[265759] = "orange",
	[265760] = "red",
	[265876] = "red",
	[265880] = {"blue","orange"},
	[265881] = "yellow",
	[271174] = "yellow",
})
