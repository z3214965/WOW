local L = BigWigs:NewBossLocale("Freehold Trash", "zhTW")
if not L then return end
if L then
	-- L.sharkbait = "Sharkbait"
	-- L.enforcer = "Irontide Enforcer"
	-- L.bonesaw = "Irontide Bonesaw"
	-- L.crackshot = "Irontide Crackshot"
	-- L.corsair = "Irontide Corsair"
	-- L.duelist = "Cutwater Duelist"
	-- L.oarsman = "Irontide Oarsman"
	-- L.juggler = "Cutwater Knife Juggler"
	-- L.scrapper = "Blacktooth Scrapper"
	-- L.knuckleduster = "Blacktooth Knuckleduster"
	-- L.swabby = "Bilge Rat Swabby"
	-- L.trapper = "Vermin Trapper"
	-- L.rat_buccaneer = "Bilge Rat Buccaneer"
	-- L.padfoot = "Bilge Rat Padfoot"
	-- L.rat = "Soggy Shiprat"
	-- L.crusher = "Irontide Crusher"
	-- L.lightning = "Lightning"
	-- L.lightning_caught = "Lightning caught after %s seconds!"
	-- L.ludwig = "Ludwig Von Tortollen"
	-- L.buccaneer = "Irontide Buccaneer"
	-- L.ravager = "Irontide Ravager"
	-- L.officer = "Irontide Officer"
	-- L.stormcaller = "Irontide Stormcaller"
end

L = BigWigs:NewBossLocale("Ring of Booty", "zhTW")
if L then
	-- Our champion that sleeps with the fishes... literally! The Freehold Fanatic... the Master of the Jagged Jawbone Jab... the Powerful Pugilist Predator... Trothak the Shark Puncher!
	-- L.warmup_trigger = "sleeps with the fishes..."
end
