
BigWigs:AddSounds("Adderis and Aspix", {
	[263246] = "info",
	[263371] = "warning",
	[263573] = "alert",
})

BigWigs:AddSounds("Merektha", {
	[263912] = "alert",
	[263914] = "warning",
	[263927] = "alarm",
	[263958] = "warning",
	[264206] = {"info","long"},
	[264239] = "alarm",
})

BigWigs:AddSounds("Galvazzt", {
	[266512] = "warning",
	[266923] = {"alarm","info"},
})

BigWigs:AddSounds("Avatar of Sethraliss", {
	[268024] = "alert",
	[269686] = "alarm",
	[269688] = "info",
	[273677] = "warning",
})
