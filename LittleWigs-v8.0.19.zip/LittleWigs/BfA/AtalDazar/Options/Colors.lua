
BigWigs:AddColors("Priestess Alun'za", {
	[255558] = {"blue","green"},
	[255577] = "red",
	[255579] = "yellow",
	[255582] = {"blue","orange"},
	[258709] = "blue",
})

BigWigs:AddColors("Vol'kaal", {
	[250241] = "green",
	[250258] = "yellow",
	[250585] = "blue",
	[259572] = "red",
})

BigWigs:AddColors("Rezan", {
	[255371] = "red",
	[255434] = "yellow",
	[257407] = {"blue","orange"},
})

BigWigs:AddColors("Yazma", {
	[249919] = "yellow",
	[250036] = "blue",
	[250050] = "yellow",
	[250096] = "orange",
	[259187] = "red",
})

BigWigs:AddColors("Atal'Dazar Trash", {
	[252687] = {"blue","orange"},
	[252781] = "blue",
	[253517] = "yellow",
	[253544] = "orange",
	[253583] = "red",
	[253721] = "yellow",
	[255041] = "orange",
	[255567] = "yellow",
	[256849] = "orange",
	[260666] = "yellow",
})
