local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "ruRU")
if not L then return end
if L then
	L.skyscreamer = "Ненасытный небесный крикун"
	L.tlonja = "Т'лонджа"
	L.shieldbearer = "Щитоносец из армии Зула"
	L.witchdoctor = "Занчульская знахарка"
	L.kisho = "Диномант Киш'о"
	L.priestess = "Позолоченная жрица"
	L.stalker = "Крадущийся теневой клинок"
	L.confessor = "Дазар'айский духовник"
	L.augur = "Дазар'айский авгур"
end
