local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "esES") or BigWigs:NewBossLocale("Atal'Dazar Trash", "esMX")
if not L then return end
if L then
	L.skyscreamer = "Vociferador de cielos hambriento"
	L.tlonja = "T'lonja"
	L.shieldbearer = "Portaescudos de Zul"
	L.witchdoctor = "Médica bruja Zanchuli"
	L.kisho = "Dinomántica Kish'o"
	L.priestess = "Sacerdotisa dorada"
	L.stalker = "Acechador Hoja de las Sombras"
	L.confessor = "Confesor Dazar'ai"
	L.augur = "Augur Dazar'ai"
end
