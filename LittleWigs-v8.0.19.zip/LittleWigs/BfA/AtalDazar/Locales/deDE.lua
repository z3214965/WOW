local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "deDE")
if not L then return end
if L then
	L.skyscreamer = "Fressender Himmelskreischer"
	L.tlonja = "T'lonja"
	L.shieldbearer = "Zuls Schildträger"
	L.witchdoctor = "Hexendoktorin der Zanchuli"
	L.kisho = "Dinomantin Kish'o"
	L.priestess = "Goldene Priesterin"
	L.stalker = "Schattenklingenpirscher"
	L.confessor = "Bekenner der Dazar'ai"
	L.augur = "Augur der Dazar'ai"
end
