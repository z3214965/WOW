local L = BigWigs:NewBossLocale("Atal'Dazar Trash", "frFR")
if not L then return end
if L then
	L.skyscreamer = "Hurleciel becqueteur"
	L.tlonja = "T'lonja"
	L.shieldbearer = "Porte-bouclier de Zul"
	L.witchdoctor = "Féticheuse zanchuli"
	L.kisho = "Dinomancienne Kish'o"
	L.priestess = "Prêtresse dorée"
	L.stalker = "Lame-de-l'ombre traqueur"
	L.confessor = "Confesseur dazar'ai"
	L.augur = "Augure dazar'ai"
end
