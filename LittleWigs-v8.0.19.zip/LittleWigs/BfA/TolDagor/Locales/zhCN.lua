local L = BigWigs:NewBossLocale("Tol Dagor Trash", "zhCN")
if not L then return end
if L then
	L.vicejaw = "下水道钳嘴鳄"
	L.thug = "铁潮暴徒"
	L.seaspeaker = "水鼠帮海语者"
	L.flamecaster = "艾什凡火法师"
	L.officer = "艾什凡军官"
	L.marine = "艾什凡水兵"
	L.priest = "艾什凡炉火医师"
end
