local L = BigWigs:NewBossLocale("Tol Dagor Trash", "frFR")
if not L then return end
if L then
	L.vicejaw = "Vile-mâchoire des égouts"
	L.thug = "Criminel des Lamineurs"
	L.seaspeaker = "Orateur des mers des Soutaillons"
	L.flamecaster = "Pyromante corsandre"
	L.officer = "Officier corsandre"
	L.marine = "Soldat de marine corsandre"
	L.priest = "Prêtresse corsandre"
end
