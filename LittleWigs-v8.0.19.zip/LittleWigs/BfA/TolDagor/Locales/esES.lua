local L = BigWigs:NewBossLocale("Tol Dagor Trash", "esES") or BigWigs:NewBossLocale("Tol Dagor Trash", "esMX")
if not L then return end
if L then
	L.vicejaw = "Malafauce de cloaca"
	L.thug = "Matón Marea de Hierro"
	L.seaspeaker = "Orador del mar de las Ratas de Pantoque"
	L.flamecaster = "Taumaturga ígnea de los Gobernalle"
	L.officer = "Oficial de los Gobernalle"
	L.marine = "Marino de los Gobernalle"
	L.priest = "Sacerdotisa de los Gobernalle"
end
