local L = BigWigs:NewBossLocale("Tol Dagor Trash", "ruRU")
if not L then return end
if L then
	L.vicejaw = "Сточный злобнокус"
	L.thug = "Громила из братства Стальных Волн"
	L.seaspeaker = "Морской колдун из братства Трюмных Крыс"
	L.flamecaster = "Маг огня корпорации Эшвейнов"
	L.officer = "Офицер корпорации Эшвейнов"
	L.marine = "Морпех корпорации Эшвейнов"
	L.priest = "Жрица корпорации Эшвейнов"
end
