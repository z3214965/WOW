local L = BigWigs:NewBossLocale("Tol Dagor Trash", "ptBR")
if not L then return end
if L then
	L.vicejaw = "Boca-de-alicate de Esgoto"
	L.thug = "Bandido Maré-férrea"
	L.seaspeaker = "Falamares Rato de Porão"
	L.flamecaster = "Lança-chamas Grimpagris"
	L.officer = "Oficial Grimpagris"
	L.marine = "Fuzileiro Grimpagris"
	L.priest = "Sacerdotisa Grimpagris"
end
