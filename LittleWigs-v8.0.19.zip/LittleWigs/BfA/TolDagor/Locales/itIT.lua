local L = BigWigs:NewBossLocale("Tol Dagor Trash", "itIT")
if not L then return end
if L then
	L.vicejaw = "Morsovile delle Fogne"
	L.thug = "Teppista Marferreo"
	L.seaspeaker = "Oratore Marino dei Ratti di Sentina"
	L.flamecaster = "Evocafiamme dei Bracescura"
	L.officer = "Ufficiale dei Bracescura"
	L.marine = "Soldato dei Bracescura"
	L.priest = "Sacerdotessa dei Bracescura"
end
