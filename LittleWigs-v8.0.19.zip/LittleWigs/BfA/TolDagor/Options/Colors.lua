
BigWigs:AddColors("The Sand Queen", {
	[257092] = "yellow",
	[257495] = "orange",
	[257608] = {"blue","red"},
	[257609] = "yellow",
})

BigWigs:AddColors("Jes Howlis", {
	[257777] = {"blue","yellow"},
	[257785] = "red",
	[257791] = "orange",
	[257793] = "cyan",
	[257827] = {"blue","green","orange"},
})

BigWigs:AddColors("Knight Captain Valyri", {
	[256955] = "red",
	[256970] = "yellow",
	[257028] = {"blue","yellow"},
})

BigWigs:AddColors("Overseer Korgus", {
	[256038] = {"blue","red"},
	[256083] = "yellow",
	[256105] = {"blue","orange"},
	[256198] = "cyan",
	[256199] = "cyan",
	[263345] = "yellow",
})

BigWigs:AddColors("Tol Dagor Trash", {
	[258079] = {"blue","orange"},
	[258128] = "yellow",
	[258153] = "yellow",
	[258313] = "red",
	[258634] = "orange",
	[258864] = "orange",
	[258917] = "red",
	[258935] = "orange",
})
