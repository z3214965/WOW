
BigWigs:AddSounds("The Sand Queen", {
	[257092] = "Alert",
	[257495] = "Long",
	[257608] = "Alarm",
	[257609] = "Info",
})

BigWigs:AddSounds("Jes Howlis", {
	[257777] = "alarm",
	[257785] = "Warning",
	[257791] = "Alert",
	[257793] = "Long",
	[257827] = {"Alert","alert","info"},
})

BigWigs:AddSounds("Knight Captain Valyri", {
	[256955] = "Warning",
	[256970] = "Alert",
	[257028] = "Alarm",
})

BigWigs:AddSounds("Overseer Korgus", {
	[256038] = "Warning",
	[256083] = "Alert",
	[256105] = {"alarm","warning"},
	[256198] = "Info",
	[256199] = "Info",
	[263345] = "Alert",
})

BigWigs:AddSounds("Tol Dagor Trash", {
	[258079] = "alarm",
	[258128] = "alert",
	[258153] = "alert",
	[258313] = "warning",
	[258634] = "alarm",
	[258864] = "long",
	[258917] = "alarm",
	[258935] = "warning",
})
