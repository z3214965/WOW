
BigWigs:AddSounds("Chopper Redhook", {
	[257326] = "alarm",
	[257348] = "alert",
	[257459] = "warning",
	[257585] = "warning",
	[273721] = "alert",
	["adds"] = "long",
})

BigWigs:AddSounds("Sergeant Bainbridge", {
	[257585] = "warning",
	[260924] = "alarm",
	[260954] = "warning",
	[261428] = "alert",
	[277965] = "alert",
	["adds"] = "long",
})

BigWigs:AddSounds("Dread Captain Lockwood", {
	[268230] = "alarm",
	[268260] = "alarm",
	[268752] = "long",
	[268963] = "info",
	[269029] = "alarm",
	[272471] = "alert",
})

BigWigs:AddSounds("Hadal Darkfathom", {
	[257882] = "alarm",
	[261563] = "alert",
	[276068] = "warning",
})

BigWigs:AddSounds("Viq'Goth", {
	[269266] = "alarm",
	[269366] = "info",
	[270185] = "alarm",
	[270605] = "alert",
	[275014] = "warning",
	["stages"] = "long",
})
