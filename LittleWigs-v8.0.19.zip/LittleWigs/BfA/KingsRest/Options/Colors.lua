
BigWigs:AddColors("The Golden Serpent", {
	[265773] = {"blue","orange"},
	[265781] = "red",
	[265910] = "purple",
	[265923] = "yellow",
})

BigWigs:AddColors("Mchimba the Embalmer", {
	[267618] = {"blue","orange"},
	[267639] = "red",
	[267702] = {"blue","green","yellow"},
})

BigWigs:AddColors("The Council of Tribes", {
	[266206] = "yellow",
	[266231] = {"blue","orange"},
	[266237] = "purple",
	[266951] = {"blue","red"},
	[267060] = "yellow",
	[267273] = "orange",
	["stages"] = "cyan",
})

BigWigs:AddColors("Dazar, The First King", {
	[268586] = "purple",
	[268932] = {"blue","orange"},
	[269231] = "blue",
	[269369] = "red",
	["stages"] = {"cyan","yellow"},
})
