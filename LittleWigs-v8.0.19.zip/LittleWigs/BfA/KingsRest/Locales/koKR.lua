local L = BigWigs:NewBossLocale("Dazar, The First King", "koKR")
if not L then return end
if L then
	-- L.spears_active = "Spear Launchers Active"
end
