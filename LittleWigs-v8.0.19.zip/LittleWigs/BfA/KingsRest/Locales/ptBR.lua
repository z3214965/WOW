local L = BigWigs:NewBossLocale("Dazar, The First King", "ptBR")
if not L then return end
if L then
	-- L.spears_active = "Spear Launchers Active"
end
