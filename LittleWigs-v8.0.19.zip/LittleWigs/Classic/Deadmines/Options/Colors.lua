
BigWigs:AddColors("Glubtok", {
	["stages"] = "cyan",
})

BigWigs:AddColors("Helix Gearbreaker", {
	[88352] = {"blue","red"},
})

BigWigs:AddColors("Foe Reaper 5000", {
	[88481] = "orange",
	[88495] = {"blue","red"},
	[88522] = "yellow",
})

BigWigs:AddColors("Vanessa VanCleef", {
	[92614] = "orange",
	[95542] = "yellow",
})
