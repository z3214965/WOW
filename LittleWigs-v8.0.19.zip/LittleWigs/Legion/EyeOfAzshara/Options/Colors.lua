
BigWigs:AddColors("Warlord Parjesh", {
	[191900] = "yellow",
	[192053] = "blue",
	[192072] = "yellow",
	[192094] = {"blue","red"},
	[192131] = {"blue","red"},
	[196563] = "yellow",
	[197064] = "orange",
	[197502] = "green",
})

BigWigs:AddColors("Lady Hatecoil", {
	[193597] = "orange",
	[193611] = "yellow",
	[193698] = "blue",
	[196610] = "green",
	["blob"] = "red",
})

BigWigs:AddColors("Serpentrix", {
	[191855] = {"blue","red"},
	[191873] = "yellow",
})

BigWigs:AddColors("King Deepbeard", {
	[193018] = "blue",
	[193051] = "yellow",
	[193093] = "orange",
	[193152] = {"blue","red"},
})

BigWigs:AddColors("Wrath of Azshara", {
	[192617] = "yellow",
	[192675] = "orange",
	[192706] = {"blue","red"},
	[192985] = "green",
	[197365] = {"blue","red"},
})

BigWigs:AddColors("Eye of Azshara Trash", {
	[195046] = "yellow",
	[195109] = "yellow",
	[195129] = "red",
	[195284] = "yellow",
	[196027] = "yellow",
	[196127] = "yellow",
	[196870] = "yellow",
	[197105] = {"blue","yellow"},
	[225089] = "orange",
})
