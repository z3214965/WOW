# BigWigs

## [v121.4](https://github.com/BigWigsMods/BigWigs/tree/v121.4) (2018-11-08)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v121.3...v121.4)

- BattleOfDazaralor/GrongHorde: Updates for Mythic testing  
- BattleOfDazaralor/Mekkatorque: Minor fixes for Mythic testing  
- BattleOfDazaralor/Council: Initial updates with Aspect abilities  
- BattleOfDazaralor/Grimfang: update for Mythic testing and fix an error in the horde equivalent  
- BattleOfDazaralor/Flamefist: Update for Mythic testing  
- BattleOfDazaralor/Frida & Kanae: Updates for Mythic testing  
- BattleOfDazaralor/Blockade: PTR Updates  
