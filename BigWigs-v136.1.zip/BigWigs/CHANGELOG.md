# BigWigs

## [v136.1](https://github.com/BigWigsMods/BigWigs/tree/v136.1) (2019-02-20)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v136...v136.1)

- BattleOfDazaralor: Locale fix.  
- Update zhCN (#608)  
- BattleOfDazaralor/Rastakhan: Add Flash to Death's Door and improve Plague of Fire timers in stage 3  
