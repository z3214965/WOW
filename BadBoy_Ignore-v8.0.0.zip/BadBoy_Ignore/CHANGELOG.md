# BadBoy_Ignore

## [v8.0.0](https://github.com/funkydude/BadBoy_Ignore/tree/v8.0.0) (2018-07-17)
[Full Changelog](https://github.com/funkydude/BadBoy_Ignore/compare/v7.3.0...v8.0.0)

- bump version  
- update travis file  
