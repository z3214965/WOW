local L = BigWigs:NewBossLocale("The Violet Hold Trash", "deDE")
if not L then return end
if L then
	L.portals = "Portale"
	L.portals_desc = "Informationen über Portale."
end
