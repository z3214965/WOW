
BigWigs:AddSounds("Mal'Ganis", {
	[52723] = "Info",
})
