local L = BigWigs:NewBossLocale("Gal'darah", "zhCN")
if not L then return end
if L then
	L.forms = "形态"
	L.forms_desc = "当迦尔达拉转换形态前发出警报。"

	L.form_rhino = "犀牛形态"
	L.form_troll = "巨魔形态"
end
