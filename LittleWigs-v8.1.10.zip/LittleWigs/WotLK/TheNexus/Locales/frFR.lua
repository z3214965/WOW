local L = BigWigs:NewBossLocale("The Nexus Trash", "frFR")
if not L then return end
if L then
	L.slayer = "Pourfendeur de mages"
	L.steward = "Régisseur"
end
