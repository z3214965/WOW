local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "frFR")
if not L then return end
if L then
	L.runeshaper = "Formerune forge-foudre"
	L.sentinel = "Sentinelle forge-foudre"
end
