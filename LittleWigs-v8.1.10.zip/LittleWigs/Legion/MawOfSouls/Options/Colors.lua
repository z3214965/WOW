
BigWigs:AddColors("Ymiron", {
	[193211] = "orange",
	[193364] = "red",
	[193566] = "yellow",
	[193977] = "yellow",
})

BigWigs:AddColors("Harbaron", {
	[194216] = "orange",
	[194231] = "yellow",
	[194325] = {"blue","red"},
	[194668] = "blue",
})

BigWigs:AddColors("Helya", {
	[185539] = "blue",
	[196947] = "cyan",
	[197262] = {"blue","yellow"},
	[198495] = "red",
	[202088] = "orange",
	[227233] = "orange",
	["destructor_tentacle"] = "yellow",
	["stages"] = "cyan",
})

BigWigs:AddColors("Maw of Souls Trash", {
	[192019] = "yellow",
	[194615] = "yellow",
	[194657] = "orange",
	[195293] = "orange",
	[198324] = {"blue","red"},
	[198405] = {"red","yellow"},
	[199514] = {"blue","orange"},
	[199589] = {"blue","orange"},
	[216197] = "orange",
})
