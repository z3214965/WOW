
BigWigs:AddSounds("Zuraal", {
	[244433] = "Warning",
	[244579] = "Warning",
	[244602] = "Alert",
	[244621] = {"Info","Long"},
	[244653] = "Warning",
	[246134] = "Alarm",
})

BigWigs:AddSounds("Saprish", {
	[245802] = {"Alert","Long"},
	[245873] = "Info",
	[247206] = "Alarm",
	[247245] = "Alert",
	[248831] = "Warning",
})

BigWigs:AddSounds("Viceroy Nezhar", {
	[-15926] = "Info",
	[244751] = "Alarm",
	[244906] = "Alert",
	[246324] = "Long",
	[248736] = "Long",
	[248804] = "Info",
})

BigWigs:AddSounds("L'ura", {
	[245164] = "Warning",
	[247795] = "Warning",
	[247816] = "Long",
	[247930] = "Alert",
	[248535] = "Info",
	[249009] = "Alarm",
})

BigWigs:AddSounds("Seat of the Triumvirate Trash", {
	[245510] = "Alarm",
	[248227] = "Warning",
	[249078] = "Info",
	[249081] = "Alarm",
})
