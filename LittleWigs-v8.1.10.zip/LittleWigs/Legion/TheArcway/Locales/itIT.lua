local L = BigWigs:NewBossLocale("The Arcway Trash", "itIT")
if not L then return end
if L then
	L.anomaly = "Anomalia Arcana"
	L.shade = "Ombra Distorcente"
	L.wraith = "Avvizzito del Mana Spettrale"
	L.blade = "Guardia dell'Ira Vilspada"
	L.chaosbringer = "Portatore del Caos Eredar"
end
