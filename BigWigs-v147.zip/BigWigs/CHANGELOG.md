# BigWigs

## [v147](https://github.com/BigWigsMods/BigWigs/tree/v147) (2019-05-06)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v146.1...v147)

- bump version  
- Update zhTW (#660)  
- Update zhTW (#661)  
- Update zhTW (#662)  
- Update zhTW (#663)  
- CrucibleOfStorms/Locales: Update Unstable Resonance say locale to be custom\_off_  
- CrucibleOfStorms/Uunat: Improvements and Update Locales  
- CrucibleOfStorms/Uunat: Add missing parentheses  
- CrucibleOfStorms/Uunat: Update mythic timers, Add a yell option for Relic holders, Mark relics with icons, Add respawn timer  
- Loader: Fix options error when using a source checkout  
- Options: Add ME\_ONLY\_EMPHASIZE icon  
- Give test messages a chance to show as emphasized  
- CrucibleOfStorms/Cabal: Add respawn time, enable emphasize (me only) by default for Crushing Doubt.  
