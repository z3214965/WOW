local L = BigWigs:NewBossLocale("Warbringer Yenajz", "ptBR")
if not L then return end
if L then
	--L.tear = "You stood in a Reality Tear"
end
