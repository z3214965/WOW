local L = BigWigs:NewBossLocale("Warbringer Yenajz", "deDE")
if not L then return end
if L then
	L.tear = "Du standest in einem Riss in der Realität"
end
