# BigWigs

## [v134](https://github.com/BigWigsMods/BigWigs/tree/v134) (2019-02-08)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v133...v134)

- update zhCN. (#590)  
- bump version  
- Plugins/BossBlock: Add "entering Dazar'alor" to the list of movies to skip.  
- BattleOfDazaralor/Trash: Add Impale.  
- BattleOfDazaralor/Jadefire: Fix some issues with the infobox.  
- BattleOfDazaralor/Grong: Do not show Ferocious Roar bar timer on LFR/Normal (#592)  
- BattleOfDazaralor/Opulence: Add Surging Gold  
- BattleOfDazaralor/Opulence: Fix Volatile Charge bar  
- BattleOfDazaralor/Blockade: Don't fade out bars in p2, Fix color for Sister Death  
- BattleOfDazaralor/Jaina: Fix intermission message and textual mistake in the options  
- BattleOfDazaralor/Jaina: Add Kultiran Corsair (Ship left/right) warnings and bars, Add stopbars for stage 1, add Mythic abilities, Add Intermission 1 time to complete warning  
- BattleOfDazaralor/Blockade: Fix Siren Spawn events for mythic p2  
- BattleOfDazaralor/Mekkatorque: Add options for repeating says when you're shrunk or controlling a robot (default off)  
- BattleOfDazaralor/Mekkatorque: Actually use heroic timers on heroic  
- BattleOfDazaralor/Mekkatorque: Fixed all timers for mythic and heroic  
- BattleOfDazaralor/Champion: Fix Seal of Retribution warning showing after a wipe.  
- BattleOfDazaralor/Opulence: Make sure hex marking doesn't re-use markers on other hex players.  
