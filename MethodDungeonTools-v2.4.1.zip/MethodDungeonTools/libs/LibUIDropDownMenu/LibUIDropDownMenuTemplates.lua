local _G = getfenv(0)
local MAJOR_VERSION = "LibUIDropDownMenuTemplates-2.0"
local MINOR_VERSION = 90000 + tonumber(("$Rev: 40 $"):match("%d+"))

local LibStub = _G.LibStub
if not LibStub then error(MAJOR_VERSION .. " requires LibStub.") end
local Lib = LibStub:NewLibrary(MAJOR_VERSION, MINOR_VERSION)
if not Lib then return end

L_UIDropDownCustomMenuEntryMixin = {};

function L_UIDropDownCustomMenuEntryMixin:GetPreferredEntryWidth()
	return self:GetWidth();
end

function L_UIDropDownCustomMenuEntryMixin:OnSetOwningButton()
end

function L_UIDropDownCustomMenuEntryMixin:SetOwningButton(button)
	self:SetParent(button:GetParent());
	self.owningButton = button;
	self:OnSetOwningButton();
end

function L_UIDropDownCustomMenuEntryMixin:GetOwningDropdown()
	return self.owningButton:GetParent();
end

function L_UIDropDownCustomMenuEntryMixin:SetContextData(contextData)
	self.contextData = contextData;
end

function L_UIDropDownCustomMenuEntryMixin:GetContextData()
	return self.contextData;
end

function L_UIDropDownCustomMenuEntryMixin:OnEnter()
	L_UIDropDownMenu_StopCounting(self:GetOwningDropdown());
end

function L_UIDropDownCustomMenuEntryMixin:OnLeave()
	L_UIDropDownMenu_StartCounting(self:GetOwningDropdown());
end

function L_Create_UIDropDownCustomMenuEntry(name, parent)
	local f = _G[name] or CreateFrame("Frame", name, parent or nil)
	f:EnableMouse(true)
	f:Hide()

	f:SetScript("OnEnter", function(self)
		L_UIDropDownMenu_StopCounting(self:GetOwningDropdown())
	end)
	f:SetScript("OnLeave", function(self)
		L_UIDropDownMenu_StartCounting(self:GetOwningDropdown())
	end)

	f:SetScript("GetPreferredEntryWidth", function(self)
		return self:GetWidth()
	end)
	f:SetScript("SetOwningButton", function(self, button)
		self:SetParent(button:GetParent())
		self.owningButton = button
		self:OnSetOwningButton()
	end)
	f:SetScript("GetOwningDropdown", function(self)
		return self.owningButton:GetParent()
	end)
	f:SetScript("SetContextData", function(self, contextData)
		self.contextData = contextData
	end)
	f:SetScript("GetContextData", function(self)
		return self.contextData
	end)

	return f
end
