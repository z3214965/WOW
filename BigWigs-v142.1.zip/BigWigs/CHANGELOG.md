# BigWigs

## [v142.1](https://github.com/BigWigsMods/BigWigs/tree/v142.1) (2019-03-29)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v142...v142.1)

- update zhCN (#634)  
- Update deDE (#632)  
- Update deDE (#631)  
- Core/BossPrototype: Fix GetBossId for units other than boss1 with mobid (#635)  
