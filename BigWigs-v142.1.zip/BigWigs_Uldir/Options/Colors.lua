
BigWigs:AddColors("Taloc", {
	[270290] = "blue",
	[271224] = {"blue","yellow"},
	[271296] = "red",
	[271728] = "orange",
	[271895] = {"blue","yellow"},
	[275189] = "yellow",
	[275205] = {"blue","orange"},
	[275270] = "blue",
	[275432] = {"blue","red"},
	["stages"] = "green",
})

BigWigs:AddColors("MOTHER", {
	[267787] = {"blue","purple","red"},
	[267795] = {"blue","yellow"},
	[267878] = "red",
	[268198] = "orange",
	[268253] = {"blue","yellow"},
	[269051] = {"cyan","red"},
	[274205] = {"blue","green"},
	[279662] = {"blue","yellow"},
})

BigWigs:AddColors("Fetid Devourer", {
	[262277] = "purple",
	[262288] = "orange",
	[262313] = {"blue","orange"},
	[262314] = {"blue","orange"},
	[262364] = {"cyan","red"},
	[262378] = "cyan",
	["breath"] = "yellow",
})

BigWigs:AddColors("Zek'voz, Herald of N'zoth", {
	[-18397] = "cyan",
	[-18390] = "cyan",
	[264382] = {"blue","yellow"},
	[265231] = "orange",
	[265248] = "purple",
	[265360] = {"blue","yellow"},
	[265530] = "red",
	[265646] = {"blue","red"},
	[265662] = "blue",
	[267180] = "yellow",
	[267239] = "yellow",
	["mythic_adds"] = "cyan",
	["stages"] = "green",
})

BigWigs:AddColors("Vectis", {
	[265127] = "blue",
	[265143] = "blue",
	[265178] = {"blue","purple"},
	[265206] = "orange",
	[265212] = {"blue","orange"},
	[265217] = "cyan",
	[266459] = "red",
	[267242] = "orange",
	[274990] = "blue",
})

BigWigs:AddColors("Zul", {
	[-18530] = "cyan",
	[269936] = "blue",
	[273288] = "yellow",
	[273350] = "orange",
	[273361] = "orange",
	[273365] = {"blue","yellow"},
	[273451] = "red",
	[274271] = {"blue","orange"},
	[274358] = {"blue","purple"},
	[276299] = "yellow",
	["bloodhexer"] = "cyan",
	["crawg"] = "cyan",
	["crusher"] = "cyan",
	["stages"] = "green",
})

BigWigs:AddColors("Mythrax the Unraveler", {
	[272115] = "orange",
	[272404] = "red",
	[272536] = {"blue","yellow"},
	[273282] = {"blue","purple","red"},
	[273538] = "orange",
	[273810] = "yellow",
	[273949] = "red",
	[274230] = "green",
	[276922] = {"cyan","green","orange"},
	[279013] = "red",
	[279157] = "orange",
	["stages"] = {"cyan","green"},
})

BigWigs:AddColors("G'huun", {
	[-18109] = "green",
	[263235] = {"blue","red"},
	[263307] = "orange",
	[263321] = "blue",
	[263482] = "green",
	[267409] = "red",
	[267412] = "purple",
	[267427] = "yellow",
	[267462] = "orange",
	[267509] = "cyan",
	[270287] = "blue",
	[270373] = "yellow",
	[270447] = {"blue","purple"},
	[272506] = {"blue","orange"},
	[274582] = "red",
	[275160] = "orange",
	[277007] = {"blue","red"},
	["stages"] = "cyan",
})

BigWigs:AddColors("Uldir Trash", {
	[276540] = "red",
	[277047] = {"blue","yellow"},
	[278990] = "red",
})
