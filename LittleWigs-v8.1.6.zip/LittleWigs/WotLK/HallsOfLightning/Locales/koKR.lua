local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "koKR")
if not L then return end
if L then
	L.runeshaper = "폭풍벼림 룬세공사"
	L.sentinel = "폭풍벼림 파수병"
end
