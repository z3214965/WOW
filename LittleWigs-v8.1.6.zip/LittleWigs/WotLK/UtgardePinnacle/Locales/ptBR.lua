local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "ptBR")
if not L then return end
if L then
	L.berserker = "Berserker Ymarjar"
end
