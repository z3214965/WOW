
BigWigs:AddSounds("Svala Sorrowgrave", {
	[48276] = "Info",
})

BigWigs:AddSounds("Skadi the Ruthless", {
	[59322] = {"Alarm","Info"},
})

BigWigs:AddSounds("Utgarde Pinnacle Trash", {
	[49106] = "Alert",
})
