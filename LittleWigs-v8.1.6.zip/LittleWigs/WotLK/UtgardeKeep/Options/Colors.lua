
BigWigs:AddColors("Prince Keleseth", {
	[48400] = {"blue","red"},
})

BigWigs:AddColors("Skarvald & Dalronn", {
	[43650] = {"blue","yellow"},
	["stages"] = "green",
})

BigWigs:AddColors("Ingvar the Plunderer", {
	[42669] = "yellow",
	[42708] = "red",
	[42730] = {"blue","orange"},
	["stages"] = "cyan",
})
