
BigWigs:AddSounds("Bronjahm", {
	[68839] = "Alert",
})

BigWigs:AddSounds("Devourer of Souls", {
	[69051] = "Alert",
})
