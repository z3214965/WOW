local L = BigWigs:NewBossLocale("The Nexus Trash", "itIT")
if not L then return end
if L then
	L.slayer = "Cacciamaghi"
	L.steward = "Custode"
end
