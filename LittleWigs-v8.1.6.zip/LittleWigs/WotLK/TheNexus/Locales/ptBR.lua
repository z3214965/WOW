local L = BigWigs:NewBossLocale("The Nexus Trash", "ptBR")
if not L then return end
if L then
	L.slayer = "Matador de Magos"
	L.steward = "Administrador"
end
