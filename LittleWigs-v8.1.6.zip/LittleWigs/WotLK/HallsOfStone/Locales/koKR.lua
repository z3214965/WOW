local L = BigWigs:NewBossLocale("Tribunal of Ages", "koKR")
if not L then return end
if L then
	--L.engage_trigger = "Now keep an eye out" -- Now keep an eye out! I'll have this licked in two shakes of a--
	--L.defeat_trigger = "The old magic fingers" --  Ha! The old magic fingers finally won through! Now let's get down to--
	--L.fail_trigger = "Not yet... not ye--"

	--L.timers = "Timers"
	--L.timers_desc = "Timers for various events that take place."

	--L.victory = "Victory"
end
