
BigWigs:AddSounds("Anub'arakAN", {
	[53472] = "Warning",
})
