local L = BigWigs:NewBossLocale("Trial of the Champion Trash", "frFR")
if not L then return end
if L then
	--L.custom_on_autotalk = "Autotalk"
	--L.custom_on_autotalk_desc = "Instantly select gossip option to start encounters."
end
