
BigWigs:AddColors("Grand Champions", {
	[-7534] = "blue",
	[66043] = {"blue","yellow"},
	[67528] = "orange",
	[67534] = {"blue","yellow"},
})

BigWigs:AddColors("Eadric the Pure", {
	[66935] = "orange",
})

BigWigs:AddColors("Argent Confessor Paletress", {
	[66515] = {"green","red","yellow"},
	[66537] = "orange",
	[66619] = {"blue","yellow"},
	["confess"] = {"red","yellow"},
})

BigWigs:AddColors("The Black Knight", {
	[-7598] = "orange",
	[67781] = "blue",
})
