
BigWigs:AddColors("Amalgam of Souls", {
	[194956] = "yellow",
	[195254] = "yellow",
	[196587] = {"red","yellow"},
})

BigWigs:AddColors("Illysanna Ravencrest", {
	[197797] = {"blue","yellow"},
	[197974] = "red",
})

BigWigs:AddColors("Smashspite", {
	[198073] = "orange",
	[198079] = {"blue","yellow"},
	[198245] = "green",
	[198446] = "red",
})

BigWigs:AddColors("Kurtalos Ravencrest", {
	[198641] = "yellow",
	[198820] = "yellow",
	[202019] = {"red","yellow"},
})

BigWigs:AddColors("Black Rook Hold Trash", {
	[197974] = "orange",
	[200248] = "yellow",
	[200261] = "orange",
	[200291] = "red",
	[200343] = "yellow",
	[203163] = {"blue","orange"},
	[214003] = "red",
	[225573] = "yellow",
	[227913] = "yellow",
})
