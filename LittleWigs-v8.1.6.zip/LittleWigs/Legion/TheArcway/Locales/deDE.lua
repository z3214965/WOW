local L = BigWigs:NewBossLocale("The Arcway Trash", "deDE")
if not L then return end
if L then
	L.anomaly = "Arkananomalie"
	L.shade = "Warpschemen"
	L.wraith = "Verdorrtes Managespenst"
	L.blade = "Teufelsklinge der Zornwächter"
	L.chaosbringer = "Chaosbringer der Eredar"
end
