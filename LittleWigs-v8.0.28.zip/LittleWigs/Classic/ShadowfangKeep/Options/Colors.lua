
BigWigs:AddColors("Baron Ashbury", {
	[93423] = "red",
	[93581] = {"blue","orange"},
	[93757] = "yellow",
})

BigWigs:AddColors("Baron Silverlaine", {
	[93857] = {"red","yellow"},
})

BigWigs:AddColors("Commander Springvale", {
	[93687] = "blue",
	[93844] = "orange",
	[93852] = {"blue","red"},
})

BigWigs:AddColors("Lord Walden", {
	[93505] = "red",
	[93527] = "yellow",
	[93617] = {"blue","cyan","orange"},
	[93689] = "cyan",
	[93697] = "red",
})

BigWigs:AddColors("Lord Godfrey", {
	[93520] = {"blue","red"},
	[93629] = {"blue","orange"},
	[93675] = {"blue","yellow"},
	[93707] = "cyan",
})
