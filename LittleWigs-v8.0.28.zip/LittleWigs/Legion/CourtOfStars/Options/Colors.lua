
BigWigs:AddColors("Patrol Captain Gerdo", {
	[207261] = "orange",
	[207278] = "yellow",
	[207806] = "yellow",
	[207815] = "yellow",
	[219488] = "red",
})

BigWigs:AddColors("Talixae Flamewreath", {
	[207881] = "orange",
	[207906] = "red",
	[208165] = "yellow",
})

BigWigs:AddColors("Advisor Melandrus", {
	[209602] = "red",
	[209628] = "orange",
	[209676] = "yellow",
	[224333] = "yellow",
})

BigWigs:AddColors("Court of Stars Trash", {
	[207979] = "yellow",
	[207980] = "yellow",
	[209027] = "red",
	[209033] = {"blue","orange","yellow"},
	[209378] = "yellow",
	[209404] = {"blue","orange","yellow"},
	[209410] = "yellow",
	[209413] = {"blue","orange","red"},
	[209477] = "yellow",
	[209485] = "yellow",
	[209495] = "red",
	[209512] = "blue",
	[211299] = "red",
	[211391] = "blue",
	[211401] = "red",
	[211464] = "red",
	[211470] = {"blue","orange","yellow"},
	[212031] = "red",
	[212784] = {"red","yellow"},
	[214688] = "yellow",
	[214690] = {"blue","orange"},
	[214692] = "yellow",
	[214697] = {"blue","cyan","green"},
	[216000] = "yellow",
	[216006] = "yellow",
	[216096] = "yellow",
	[216110] = "yellow",
	[224377] = "red",
	[225100] = "yellow",
	["announce_buff_items"] = "cyan",
	["spy_helper"] = {"cyan","green"},
})
