
BigWigs:AddColors("Archdruid Glaidalis", {
	[196376] = {"blue","yellow"},
	[198379] = "red",
	[198408] = "blue",
})

BigWigs:AddColors("Oakheart", {
	[204574] = "yellow",
	[204646] = {"blue","orange"},
	[204666] = "red",
	[204667] = "red",
})

BigWigs:AddColors("Dresaron", {
	[191325] = "yellow",
	[199345] = "red",
	[199460] = "blue",
})

BigWigs:AddColors("Shade of Xavius", {
	[200050] = "yellow",
	[200185] = {"blue","orange"},
	[200238] = {"blue","red"},
	[200289] = {"blue","yellow"},
})

BigWigs:AddColors("Darkheart Thicket Trash", {
	[200580] = "orange",
	[200658] = "yellow",
	[200684] = {"blue","red"},
	[200768] = "orange",
	[201226] = "orange",
	[201272] = "orange",
	[201399] = "yellow",
	[218759] = "blue",
	[225562] = "orange",
})
