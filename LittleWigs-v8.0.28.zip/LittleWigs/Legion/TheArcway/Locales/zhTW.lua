local L = BigWigs:NewBossLocale("The Arcway Trash", "zhTW")
if not L then return end
if L then
	L.anomaly = "祕法異常體"
	L.shade = "扭曲之影"
	L.wraith = "凋萎者法力怨靈"
	L.blade = "憤怒守衛魔刃兵"
	--L.chaosbringer = "Eredar Chaosbringer"
end
