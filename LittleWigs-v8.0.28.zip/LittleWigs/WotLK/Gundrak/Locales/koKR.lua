local L = BigWigs:NewBossLocale("Gal'darah", "koKR")
if not L then return end
if L then
	--L.forms = "Forms"
	--L.forms_desc = "Warn before Gal'darah changes forms."

	--L.form_rhino = "Rhino Form"
	--L.form_troll = "Troll Form"
end
