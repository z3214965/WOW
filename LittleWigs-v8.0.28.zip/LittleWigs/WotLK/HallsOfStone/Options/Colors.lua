
BigWigs:AddColors("Krystallus", {
	[50810] = "orange",
})

BigWigs:AddColors("Maiden of Grief", {
	[59726] = {"blue","orange","red"},
	[59772] = "blue",
})

BigWigs:AddColors("Tribunal of Ages", {
	[59866] = "blue",
	[59868] = {"blue","orange"},
	["timers"] = "yellow",
})

BigWigs:AddColors("Sjonnir The Ironshaper", {
	[50834] = "blue",
	[50840] = "orange",
})
