
BigWigs:AddColors("Meathook", {
	[52696] = {"blue","red"},
})

BigWigs:AddColors("Salramm the Fleshcrafter", {
	[58845] = {"blue","red"},
})

BigWigs:AddColors("Chrono-Lord Epoch", {
	[52772] = {"blue","red"},
})

BigWigs:AddColors("Mal'Ganis", {
	[52721] = {"blue","red"},
	[52723] = "red",
})

BigWigs:AddColors("Infinite Corruptor", {
	[60588] = {"blue","red"},
})
