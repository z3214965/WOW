local L = BigWigs:NewBossLocale("The Nexus Trash", "zhTW")
if not L then return end
if L then
	--L.slayer = "Mage Slayer"
	--L.steward = "Steward"
end
