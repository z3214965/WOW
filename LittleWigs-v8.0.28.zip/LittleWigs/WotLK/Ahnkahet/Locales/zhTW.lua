local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "zhTW")
if not L then return end
if L then
	--L.spellflinger = "Ahn'kahar Spell Flinger"
	--L.eye = "Eye of Taldaram"
	--L.darkcaster = "Twilight Darkcaster"
end
