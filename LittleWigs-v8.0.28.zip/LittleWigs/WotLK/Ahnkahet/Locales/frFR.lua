local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "frFR")
if not L then return end
if L then
	L.spellflinger = "Lanceur de sorts ahn'kahar"
	L.eye = "Oeil de Taldaram"
	L.darkcaster = "Invocateur noir du Crépuscule"
end
