local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "zhCN")
if not L then return end
if L then
	L.berserker = "伊米亚狂战士"
end
