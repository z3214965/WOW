local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "deDE")
if not L then return end
if L then
	L.berserker = "Berserker der Ymirjar"
end
