local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "ruRU")
if not L then return end
if L then
	L.berserker = "Имирьярский берсерк"
end
