if not WATCHDOG_VARS then WATCHDOG_VARS = {} end
if not _G then _G = {} end
