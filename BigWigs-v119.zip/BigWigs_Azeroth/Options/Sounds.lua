
BigWigs:AddSounds("Ji'arak", {
	[260908] = "info",
	[261088] = "long",
	[261467] = "alert",
})

BigWigs:AddSounds("Azurethos, The Winged Typhoon", {
	[274829] = "warning",
	[274832] = "long",
	[274839] = "long",
})

BigWigs:AddSounds("Doom's Howl", {
	[271120] = "alarm",
	[271163] = "alert",
	[271164] = "info",
	[271223] = "long",
	[271800] = "warning",
})

BigWigs:AddSounds("The Lion's Roar", {
	[271120] = "alarm",
	[271163] = "alert",
	[271164] = "info",
	[271223] = "long",
	[271800] = "warning",
})

BigWigs:AddSounds("Warbringer Yenajz", {
	[274842] = "info",
	[274904] = "alarm",
	[274932] = "long",
})

BigWigs:AddSounds("Dunegorger Kraulok", {
	[275200] = "info",
	[276046] = "long",
})
