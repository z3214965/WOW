
BigWigs:AddColors("Ji'arak", {
	[260908] = "yellow",
	[261088] = "red",
	[261467] = "orange",
})

BigWigs:AddColors("Azurethos, The Winged Typhoon", {
	[274829] = "red",
	[274832] = "purple",
	[274839] = "yellow",
})

BigWigs:AddColors("Doom's Howl", {
	[271120] = "blue",
	[271163] = "purple",
	[271164] = "orange",
	[271223] = "cyan",
	[271800] = "red",
})

BigWigs:AddColors("The Lion's Roar", {
	[271120] = "blue",
	[271163] = "purple",
	[271164] = "orange",
	[271223] = "cyan",
	[271800] = "red",
})

BigWigs:AddColors("Warbringer Yenajz", {
	[274842] = "yellow",
	[274904] = "blue",
	[274932] = "red",
})

BigWigs:AddColors("Dunegorger Kraulok", {
	[275200] = "orange",
	[276046] = "red",
})
