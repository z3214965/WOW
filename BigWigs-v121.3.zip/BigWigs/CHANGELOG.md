# BigWigs

## [v121.3](https://github.com/BigWigsMods/BigWigs/tree/v121.3) (2018-10-24)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v121.2...v121.3)

- BattleOfDazaralor/Mekkatorque: Drycode  
- BattleOfDazaralor/Rastakhan: Drycode  
- Uldir/Mother: Don't trigger a beam timer update in the first room  
- Uldir/Mythrax: Change proximity check to 5 yards (#565)  
