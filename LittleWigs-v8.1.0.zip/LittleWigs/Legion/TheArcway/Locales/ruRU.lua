local L = BigWigs:NewBossLocale("The Arcway Trash", "ruRU")
if not L then return end
if L then
	L.anomaly = "Волшебная аномалия"
	L.shade = "Искаженная тень"
	L.wraith = "Иссохший - магический призрак"
	L.blade = "Страж гнева - клинок Скверны"
	L.chaosbringer = "Эредарский вестник хаоса"
end
