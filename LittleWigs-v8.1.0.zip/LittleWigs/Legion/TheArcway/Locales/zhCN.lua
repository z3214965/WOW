local L = BigWigs:NewBossLocale("The Arcway Trash", "zhCN")
if not L then return end
if L then
	L.anomaly = "奥术畸体"
	L.shade = "迁跃之影"
	L.wraith = "枯法法力怨灵"
	L.blade = "愤怒卫士邪刃者"
	L.chaosbringer = "艾瑞达混沌使者"
end
