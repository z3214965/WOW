local L = BigWigs:NewBossLocale("Maw of Souls Trash", "ptBR")
if not L then return end
if L then
	L.soulguard = "Guarda da Alma Encharcado"
	L.champion = "Campeão Helarjar"
	L.mariner = "Fuzileiro da Vigília Noturna"
	L.swiftblade = "Mardiçoado Lâmina Célere"
	L.mistmender = "Remenda-bruma Mardiçoada"
	L.mistcaller = "Chamabruma Helarjar"
	L.skjal = "Skjal"
end
