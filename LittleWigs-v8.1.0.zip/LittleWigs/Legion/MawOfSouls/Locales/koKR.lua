local L = BigWigs:NewBossLocale("Maw of Souls Trash", "koKR")
if not L then return end
if L then
	L.soulguard = "물에 젖은 영혼 경비병"
	L.champion = "헬라리아르 용사"
	L.mariner = "어둠의 순찰대 갑판원"
	L.swiftblade = "바다의 저주를 받은 쾌속검날"
	L.mistmender = "바다의 저주를 받은 안개치유사"
	L.mistcaller = "헬라리아르 안개소환사"
	L.skjal = "스키알"
end
