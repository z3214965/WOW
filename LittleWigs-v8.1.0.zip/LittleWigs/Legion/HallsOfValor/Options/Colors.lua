
BigWigs:AddColors("Hymdall", {
	[191284] = "red",
	[193092] = "yellow",
	[193235] = {"blue","orange"},
})

BigWigs:AddColors("Hyrja", {
	[191976] = {"blue","yellow"},
	[192018] = "red",
	[192048] = {"blue","yellow"},
	[192307] = "orange",
	[200901] = "orange",
})

BigWigs:AddColors("Fenryr", {
	[196512] = "red",
	[196543] = "orange",
	[196838] = {"blue","orange"},
	[197556] = {"blue","yellow"},
	["stages"] = "cyan",
})

BigWigs:AddColors("God-King Skovald", {
	[193659] = {"blue","red"},
	[193668] = "yellow",
	[193702] = "blue",
	[193826] = "orange",
})

BigWigs:AddColors("Odyn", {
	[197961] = {"orange","yellow"},
	[198077] = "red",
	[198263] = "red",
	[200988] = "orange",
	["warmup"] = "cyan",
})

BigWigs:AddColors("Halls of Valor Trash", {
	[191508] = "red",
	[192158] = "red",
	[192563] = "red",
	[198745] = "yellow",
	[198888] = "red",
	[198931] = "red",
	[198934] = "red",
	[199210] = "red",
	[199341] = "red",
	[199726] = "red",
	[199805] = {"blue","orange"},
	[210875] = "red",
	[215430] = {"blue","orange"},
	[215433] = "red",
})
