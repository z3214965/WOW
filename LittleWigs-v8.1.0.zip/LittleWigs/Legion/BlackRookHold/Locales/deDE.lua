local L = BigWigs:NewBossLocale("Black Rook Hold Trash", "deDE")
if not L then return end
if L then
	L.arcanist = "Auferstandener Arkanist"
	L.champion = "Seelengeschändeter Champion"
	L.swordsman = "Auferstandener Schwertkämpfer"
	L.archer = "Auferstandene Bogenschützin"
	L.scout = "Auferstandener Späher"
	L.councilor = "Geisterhafter Berater"
	L.dominator = "Teufelsgrollunterwerfer"
end
