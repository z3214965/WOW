
BigWigs:AddColors("Rokmora", {
	[188114] = "yellow",
	[188169] = "orange",
	[192800] = "blue",
})

BigWigs:AddColors("Ularogg Cragshaper", {
	[198428] = "red",
	[198496] = "yellow",
	[198564] = "yellow",
	["bellow"] = "orange",
})

BigWigs:AddColors("Naraxas", {
	[-12527] = "yellow",
	[199178] = {"blue","green","orange"},
	[199775] = "yellow",
	[205549] = "red",
	[210150] = "orange",
})

BigWigs:AddColors("Dargrul", {
	[200154] = {"blue","yellow"},
	[200404] = "green",
	[200551] = "green",
	[200700] = "orange",
	[200732] = "red",
})

BigWigs:AddColors("Neltharions Lair Trash", {
	[183088] = "yellow",
	[193585] = "red",
	[202181] = "red",
	[226296] = "orange",
})
