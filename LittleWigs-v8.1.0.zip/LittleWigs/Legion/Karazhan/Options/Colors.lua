
BigWigs:AddColors("Maiden of Virtue", {
	[227508] = "yellow",
	[227789] = {"blue","green","red"},
	[227800] = "yellow",
	[227809] = {"blue","red"},
	[227823] = {"orange","red"},
})

BigWigs:AddColors("Opera Hall: Wikket", {
	[227410] = "orange",
	[227447] = "yellow",
	[227477] = "orange",
	[227776] = "red",
})

BigWigs:AddColors("Opera Hall: Westfall Story", {
	[227568] = "yellow",
	[227777] = "red",
	[227783] = "orange",
	["stages"] = "cyan",
})

BigWigs:AddColors("Opera Hall: Beautiful Beast", {
	[227985] = {"blue","orange"},
	[227987] = "yellow",
	[228019] = "red",
	[228025] = "red",
	[228221] = {"blue","orange"},
	[232153] = "orange",
	["stages"] = {"cyan","green"},
})

BigWigs:AddColors("Attumen the Huntsman", {
	[227365] = "yellow",
	[227404] = "yellow",
	[227493] = "red",
	[228852] = "orange",
	[228895] = "red",
	["stages"] = "cyan",
})

BigWigs:AddColors("Moroes", {
	[227463] = {"blue","orange"},
	[227545] = "orange",
	[227578] = "red",
	[227616] = "red",
	[227646] = {"blue","yellow"},
	[227672] = "red",
	[227736] = "yellow",
	[227742] = {"blue","orange"},
	[227851] = {"blue","orange"},
	[227872] = "cyan",
})

BigWigs:AddColors("The Curator", {
	[227254] = {"cyan","green"},
	[227267] = "yellow",
	[227279] = {"blue","orange"},
})

BigWigs:AddColors("Shade of Medivh", {
	[227592] = {"blue","orange"},
	[227615] = {"orange","red"},
	[227628] = "yellow",
	[227779] = {"blue","yellow"},
	[228269] = {"blue","red","yellow"},
	[228334] = "yellow",
	["stages"] = "cyan",
})

BigWigs:AddColors("Mana Devourer", {
	[227297] = "orange",
	[227502] = {"blue","green"},
	[227523] = {"blue","yellow"},
	[227618] = "red",
})

BigWigs:AddColors("Viz'aduum the Watcher", {
	[229083] = {"blue","red","yellow"},
	[229151] = "yellow",
	[229159] = {"blue","red"},
	[229248] = {"blue","orange"},
	[229284] = "orange",
	[229905] = "blue",
	[230084] = {"green","orange"},
	["stages"] = "green",
})

BigWigs:AddColors("Nightbane", {
	[228785] = "red",
	[228790] = {"green","red"},
	[228792] = {"green","red"},
	[228796] = {"blue","red"},
	[228808] = {"blue","orange"},
	[228829] = {"blue","orange"},
	[228834] = "red",
	[228835] = {"blue","orange"},
	[228837] = "yellow",
	[229307] = "yellow",
	["stages"] = "cyan",
})

BigWigs:AddColors("Karazhan Trash", {
	[227966] = "yellow",
	[227999] = "yellow",
	[228279] = "yellow",
	[228528] = "yellow",
	[228575] = "red",
	[228625] = "yellow",
	[241774] = "orange",
})
