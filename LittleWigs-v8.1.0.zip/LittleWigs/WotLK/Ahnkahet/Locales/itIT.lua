local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "itIT")
if not L then return end
if L then
	L.spellflinger = "Scagliamagie di Ahn'kahar"
	L.eye = "Occhio di Taldaram"
	L.darkcaster = "Mago Oscuro del Crepuscolo"
end
