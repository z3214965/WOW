local L = BigWigs:NewBossLocale("Ahn'kahet Trash", "esES") or BigWigs:NewBossLocale("Ahn'kahet Trash", "esMX")
if not L then return end
if L then
	L.spellflinger = "Lanzahechizos Ahn'kahar"
	L.eye = "Ojo de Taldaram"
	L.darkcaster = "Taumaturgo oscuro Crepuscular"
end
