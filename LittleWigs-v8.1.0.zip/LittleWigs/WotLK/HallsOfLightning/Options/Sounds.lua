
BigWigs:AddSounds("Ionar", {
	[52770] = "Info",
	[59795] = "Alarm",
})

BigWigs:AddSounds("Loken", {
	[59835] = "Alert",
})

BigWigs:AddSounds("Halls of Lightning Trash", {
	[59165] = "Alarm",
	[61581] = {"Long","Warning"},
})
