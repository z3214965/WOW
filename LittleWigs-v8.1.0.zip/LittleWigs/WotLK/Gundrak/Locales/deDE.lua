local L = BigWigs:NewBossLocale("Gal'darah", "deDE")
if not L then return end
if L then
	L.forms = "Formen"
	L.forms_desc = "Warnen bevor Gal'darah seine Form ändert."

	L.form_rhino = "Dinoform"
	L.form_troll = "Trollform"
end
