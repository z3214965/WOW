local L = BigWigs:NewBossLocale("Gal'darah", "ptBR")
if not L then return end
if L then
	L.forms = "Formas"
	L.forms_desc = "Avisar antes de Gal'darah mudar de forma."

	L.form_rhino = "Forma de Rinoceronte"
	L.form_troll = "Forma de Troll"
end
