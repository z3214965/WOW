
BigWigs:AddSounds("Slad'ran", {
	[59842] = {"Alarm","Info"},
})

BigWigs:AddSounds("Drakkari Colossus", {
	[59451] = "Alarm",
})

BigWigs:AddSounds("Moorabi", {
	[55098] = "Warning",
})

BigWigs:AddSounds("Eck the Ferocious", {
	[55817] = "Info",
})

BigWigs:AddSounds("Gal'darah", {
	[59825] = "Alarm",
	[59827] = "Info",
})
