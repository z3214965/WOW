local L = BigWigs:NewBossLocale("The Nexus Trash", "koKR")
if not L then return end
if L then
	L.slayer = "마법사 사냥개"
	L.steward = "청지기"
end
