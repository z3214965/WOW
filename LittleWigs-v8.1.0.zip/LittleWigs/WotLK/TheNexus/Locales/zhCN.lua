local L = BigWigs:NewBossLocale("The Nexus Trash", "zhCN")
if not L then return end
if L then
	L.slayer = "法师杀手"
	L.steward = "管家"
end
