
BigWigs:AddColors("Drakos the Interrogator", {
	[50774] = "red",
})

BigWigs:AddColors("Varos Cloudstrider", {
	[-7442] = "orange",
	[51021] = "blue",
	[51054] = {"blue","red"},
})

BigWigs:AddColors("Mage-Lord Urom", {
	[51103] = "blue",
	[51110] = "yellow",
	[51121] = {"blue","orange"},
})

BigWigs:AddColors("Ley-Guardian Eregos", {
	[51162] = "red",
	[51170] = "yellow",
})
