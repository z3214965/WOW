local L = BigWigs:NewBossLocale("Utgarde Pinnacle Trash", "frFR")
if not L then return end
if L then
	L.berserker = "Berserker ymirjar"
end
