
BigWigs:AddColors("Falric", {
	[72422] = {"blue","orange"},
	[72426] = {"blue","red"},
})

BigWigs:AddColors("Marwyn", {
	[72363] = "red",
	[72368] = {"blue","yellow"},
	[72383] = {"blue","orange"},
})
