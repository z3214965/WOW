local L = BigWigs:NewBossLocale("The Violet Hold Trash", "esES") or BigWigs:NewBossLocale("The Violet Hold Trash", "esMX")
if not L then return end
if L then
	--L.portals = "Portals"
	--L.portals_desc = "Information about portals."
end
