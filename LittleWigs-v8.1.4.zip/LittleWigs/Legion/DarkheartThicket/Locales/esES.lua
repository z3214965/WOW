local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "esES") or BigWigs:NewBossLocale("Darkheart Thicket Trash", "esMX")
if not L then return end
if L then
	L.ruiner = "Arruinador Almaespanto"
	L.poisoner = "Envenenador Almaespanto"
	L.razorbeak = "Picovaja enloquecido"
	L.grizzly = "Oso pardo con piel supurante"
	L.fury = "Furia manchada de sangre"
	L.imp = "Diablillo de fuego aterrador"
end
