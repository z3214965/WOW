
BigWigs:AddSounds("Amalgam of Souls", {
	[194956] = "Warning",
	[196587] = {"Alert","Warning"},
})

BigWigs:AddSounds("Illysanna Ravencrest", {
	[197797] = "Alarm",
	[197974] = "Alarm",
})

BigWigs:AddSounds("Smashspite", {
	[198073] = "Info",
	[198079] = "Warning",
	[198245] = "Alarm",
	[198446] = "Alert",
})

BigWigs:AddSounds("Kurtalos Ravencrest", {
	[198641] = "Info",
	[198820] = "Warning",
	[202019] = {"Info","Warning"},
})

BigWigs:AddSounds("Black Rook Hold Trash", {
	[197974] = "Alarm",
	[200248] = "Alert",
	[200261] = "Alarm",
	[200291] = "Alert",
	[200343] = "Warning",
	[203163] = "Warning",
	[214003] = "Alarm",
	[225573] = "Alarm",
	[227913] = "Alarm",
})
