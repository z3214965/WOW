local L = BigWigs:NewBossLocale("The Arcway Trash", "koKR")
if not L then return end
if L then
	L.anomaly = "비전 변형물"
	L.shade = "뒤틀린 그림자"
	L.wraith = "메마른 마나 망령"
	L.blade = "격노수호병 지옥검사"
	L.chaosbringer = "에레다르 혼돈인도자"
end
