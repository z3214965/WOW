
BigWigs:AddColors("Krik'thir the Gatewatcher", {
	[28747] = "red",
	[52592] = {"blue","yellow"},
})

BigWigs:AddColors("Hadronox", {
	[53030] = "orange",
	[53400] = "yellow",
})

BigWigs:AddColors("Anub'arakAN", {
	[-6359] = "cyan",
	[53472] = "yellow",
})
