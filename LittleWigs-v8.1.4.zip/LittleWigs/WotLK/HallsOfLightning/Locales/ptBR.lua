local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "ptBR")
if not L then return end
if L then
	L.runeshaper = "Traçarrunas Forjado em Tempestade"
	L.sentinel = "Sentinela Forjada em Tempestade"
end
