local L = BigWigs:NewBossLocale("Halls of Lightning Trash", "itIT")
if not L then return end
if L then
	L.runeshaper = "Plasmarune Forgiatuono"
	L.sentinel = "Sentinella Forgiatuono"
end
