
BigWigs:AddSounds("Forgemaster Garfrost", {
	[68789] = "Alarm",
	[70381] = "Alert",
})

BigWigs:AddSounds("Ick & Krick", {
	[68987] = "Alert",
	[70274] = "Alarm",
})

BigWigs:AddSounds("Scourgelord Tyrannus", {
	[69172] = "Alert",
	[69275] = "Alarm",
})
