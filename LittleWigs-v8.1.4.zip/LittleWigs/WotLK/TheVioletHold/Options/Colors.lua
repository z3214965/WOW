
BigWigs:AddColors("The Violet Hold Trash", {
	["portals"] = "yellow",
})
