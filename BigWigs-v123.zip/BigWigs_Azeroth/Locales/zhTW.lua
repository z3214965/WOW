local L = BigWigs:NewBossLocale("Warbringer Yenajz", "zhTW")
if not L then return end
if L then
	--L.tear = "You stood in a Reality Tear"
end
