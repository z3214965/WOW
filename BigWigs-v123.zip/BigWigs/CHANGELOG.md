# BigWigs

## [v123](https://github.com/BigWigsMods/BigWigs/tree/v123) (2018-12-14)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v122...v123)

- Uldir: Add trash warning for Bloodshot Rage  
- Uldir/Zekvoz: UnregisterUnitEvent call is no longer needed.  
- Uldir/Zekvoz: Encounter Event spell for stage changes is now live  
- Uldir/Taloc: Tweak cudgel timers  
- bump version  
- bump toc  
- Plugins/AutoReply: IsCharacterFriend() has been replaced by C\_FriendList.IsFriend()  
